#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Garde post-build STEP 3 : refuse de laisser passer un arbre de compilation
# incohérent vers une simulation.
#
# POURQUOI CE SCRIPT EXISTE
# Deux échecs consécutifs, de nature différente, ont eu la même conséquence :
# une commande de simulation atteignable avec un build qui ne correspondait pas
# aux sources.
#
#   1. `./ns3 build` déclenche une ré-exécution automatique de CMake quand un
#      CMakeLists.txt change, et cette ré-exécution REMET les options aux
#      défauts : examples et tests repassent à OFF. Les suites deviennent
#      « unknown test suite name » et le pilote « program not found ».
#
#   2. `unzip` restaure les horodatages de l'archive. Une source restaurée peut
#      être PLUS ANCIENNE que l'objet déjà compilé ; ninja la considère à jour
#      et ne la recompile jamais. On obtient alors un exécutable neuf lié contre
#      une bibliothèque périmée -- ou, si les signatures ont changé, cinq
#      `undefined reference` incompréhensibles à la lecture des sources.
#
# Ni l'un ni l'autre n'est visible dans les sources : il faut interroger le
# BUILD. C'est ce que fait ce script, et il échoue fermé (exit != 0).
#
# Usage :  bash experiments/check_step03_build.sh [racine-ns3]
#          (défaut : le répertoire courant)
# ---------------------------------------------------------------------------
set -u

ROOT="${1:-$(pwd)}"
LIB="$ROOT/build/lib/libns3.48-mtcaodv-default.so"
FAILURES=0

fail() { printf 'FAIL  %s\n' "$1"; FAILURES=$((FAILURES + 1)); }
pass() { printf 'ok    %s\n' "$1"; }

printf '== Garde post-build STEP 3 (%s) ==\n' "$ROOT"

# --- 1. La bibliothèque du module existe-t-elle ? -------------------------
if [ ! -f "$LIB" ]; then
    fail "bibliothèque absente : $LIB (le module n'a jamais été construit)"
    printf '\nRIEN D AUTRE NE PEUT ETRE VERIFIE. Lancez :\n'
    printf '  ./ns3 configure --enable-examples --enable-tests && ./ns3 build\n'
    exit 1
fi
pass "bibliothèque présente : $(basename "$LIB")"

# --- 2. Les symboles STEP 3 sont-ils réellement exportés ? ----------------
# On interroge la bibliothèque, pas la source : c'est la seule façon de
# détecter un objet périmé. Les cinq compteurs de rejet sont ceux ajoutés par
# la correction « mauvais bout du chemin » ; leur absence signifie que l'objet
# provient de la version antérieure de forwarding-observer.cc.
if ! command -v nm >/dev/null 2>&1; then
    fail "nm introuvable (paquet binutils) : impossible de vérifier les symboles"
else
    SYMBOLS="GetTransmissionsInspected GetSkippedLastHop GetSkippedNoRoute \
GetSkippedControlPlane GetSkippedNonUnicast GetWindowsOpened GetWindowsMatched"
    MISSING=""
    EXPORTED="$(nm -DC "$LIB" 2>/dev/null)"
    for symbol in $SYMBOLS; do
        case "$EXPORTED" in
            *"ForwardingObserver::$symbol"*) ;;
            *) MISSING="$MISSING $symbol" ;;
        esac
    done
    if [ -n "$MISSING" ]; then
        fail "symboles absents de la bibliothèque :$MISSING"
        printf '      => objet périmé. Correction :\n'
        printf '         find build -name "forwarding-observer.cc.o" -delete\n'
        printf '         touch contrib/mtcaodv/model/forwarding-observer.{cc,h}\n'
        printf '         ./ns3 build\n'
    else
        pass "les 7 accesseurs STEP 3 sont exportés par la bibliothèque"
    fi
fi

# --- 3. Aucune source n'est plus récente que la bibliothèque -------------
# Une source plus récente que la bibliothèque signifie une modification non
# compilée. C'est le symptôme inverse du cas 2, et tout aussi silencieux.
NEWER="$(find "$ROOT/contrib/mtcaodv" -name '*.cc' -o -name '*.h' 2>/dev/null \
         | while read -r f; do [ "$f" -nt "$LIB" ] && echo "  $f"; done)"
if [ -n "$NEWER" ]; then
    fail "sources plus récentes que la bibliothèque (non compilées) :"
    printf '%s\n' "$NEWER"
    printf '      => lancez ./ns3 build\n'
else
    pass "aucune source du module n'est plus récente que la bibliothèque"
fi

# --- 4. Examples et tests sont-ils activés ? ------------------------------
# Vérifié par la présence des artefacts, pas par la lecture d'un fichier de
# configuration : ce sont les artefacts qui décident si la commande marchera.
if [ -x "$ROOT/build/contrib/mtcaodv/examples/ns3.48-mtcaodv-pilot-attack-default" ]; then
    pass "l'exécutable du pilote existe (examples: ON)"
else
    fail "exécutable du pilote absent (examples: OFF)"
    printf '      => ./ns3 configure --enable-examples --enable-tests && ./ns3 build\n'
fi

if ls "$ROOT"/build/lib/libns3.48-test-*.so >/dev/null 2>&1; then
    pass "la bibliothèque de test existe (tests: ON)"
else
    fail "bibliothèque de test absente (tests: OFF)"
    printf '      => ./ns3 configure --enable-examples --enable-tests && ./ns3 build\n'
fi

printf '\n'
if [ "$FAILURES" -eq 0 ]; then
    printf 'BUILD COHERENT -- le scénario STEP 3 peut être exécuté.\n'
    exit 0
fi
printf '%d VERIFICATION(S) EN ECHEC -- NE LANCEZ PAS LA SIMULATION.\n' "$FAILURES"
printf 'Un run sur un build incohérent produit des chiffres qui ne correspondent\n'
printf 'à aucune version du code. Corrigez, relancez cette garde, puis exécutez.\n'
exit 1
