#!/usr/bin/env python3
"""Standard-library unit tests for validate_step03.py (no ns-3 required)."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

import validate_step03 as v

_HEADER = (
    "protocol,nodes,simTime,minSpeed,maxSpeed,seed,run,attackerRatio,attackerCount,"
    "attackStart,appTxPackets,appRxPackets,appTxBytes,appRxBytes,pdr,plr,throughput_bps,"
    "goodput_bps,meanDelay_s,networkRxBytes,evaluationDuration_s,flowCount,packetPayloadBytes,"
    "dataRate,areaSize_m,maxRange_m,appStart_s,appStop_s,ipv4Network,ipv4Mask,mobilityStreamBase,"
    "wifiStreamBase,aodvStreamBase,trafficStreamBase,mobilityStreamsConsumed,wifiStreamsConsumed,"
    "aodvStreamsConsumed,trafficStreamsConsumed,monitoredApplicationFlows,pauseTime_s,"
    "sourceStartStagger_s,wifiStandard,wifiMac,propagationModel,forgedRrepCount,blackholeDropCount,"
    "attackStream,attackerSelectionStreamsConsumed,screeningEnabled,watchThreshold,watchCount,"
    "watchTruePositives,watchFalsePositives,"
    # C-19 append-only WATCH-lifecycle columns.
    "watchTruePositivesCurrent,watchFalsePositivesCurrent,watchWindowSize,"
    "watchMinimumAnomalies,watchAnomalyFraction,watchExpiry_s,maxTrackedNeighbors,"
    # STEP 3 append-only forwarding-observation columns.
    "observationEnabled,windowsOpened,windowsMatched,windowsDeadline,"
    "windowsNeighborLost,windowsEvicted,fingerprintCollisions,"
    "fragmentedPacketsExcluded,promiscuousFramesInspected,observationWindow_s,"
    "observationSweep_s,maxActiveWindows,"
    "transmissionsInspected,skippedLastHop,skippedNoRoute,skippedControlPlane,"
    "skippedNonUnicast"
)


def _row(nodes=30, ratio=0.20, rx=1500, tx=2936, screening=1,
         watch_count=6, tp=3, fp=2, tp_current=None, fp_current=None,
         window=20, min_anomalies=3, fraction=0.20, expiry=15.0, max_tracked=256,
         obs_enabled=1, opened=100, matched=70, deadline=25, lost=3, evicted=2,
         collisions=0, fragmented=0, frames=5000, obs_window=0.150,
         obs_sweep=0.050, max_active=256, transmissions=500, skip_last=300,
         skip_route=50, skip_control=40, skip_nonunicast=10):
    # By default the live (C-19) counters equal the cumulative ones, which is the
    # degenerate case "nothing expired before t_end"; individual tests override
    # them to exercise the subset invariant.
    tp_current = tp if tp_current is None else tp_current
    fp_current = fp if fp_current is None else fp_current
    attacker_count = v.round_half_up(ratio * nodes)
    pdr = rx / tx
    vals = {
        "protocol": "MTC-AODV", "nodes": nodes, "simTime": 60, "minSpeed": 1, "maxSpeed": 20,
        "seed": 1, "run": 1, "attackerRatio": ratio, "attackerCount": attacker_count,
        "attackStart": 10, "appTxPackets": tx, "appRxPackets": rx, "appTxBytes": tx * 512,
        "appRxBytes": rx * 512, "pdr": pdr, "plr": 1 - pdr, "throughput_bps": 1.0,
        "goodput_bps": 1.0, "meanDelay_s": 0.01, "networkRxBytes": rx * 512 + 100,
        "evaluationDuration_s": 49, "flowCount": 4, "packetPayloadBytes": 512, "dataRate": "64kbps",
        "areaSize_m": 600, "maxRange_m": 200, "appStart_s": 10, "appStop_s": 59,
        "ipv4Network": "10.1.0.0", "ipv4Mask": "255.255.255.0", "mobilityStreamBase": 10000,
        "wifiStreamBase": 30000, "aodvStreamBase": 20000, "trafficStreamBase": 40000,
        "mobilityStreamsConsumed": 4 * nodes, "wifiStreamsConsumed": 5, "aodvStreamsConsumed": 3,
        "trafficStreamsConsumed": 8, "monitoredApplicationFlows": 4, "pauseTime_s": 0,
        "sourceStartStagger_s": 0.1, "wifiStandard": "802.11b", "wifiMac": "ns3::AdhocWifiMac",
        "propagationModel": "ns3::RangePropagationLossModel", "forgedRrepCount": 20,
        "blackholeDropCount": 500, "attackStream": 73001, "attackerSelectionStreamsConsumed": 1,
        "screeningEnabled": screening, "watchThreshold": 0.5, "watchCount": watch_count,
        "watchTruePositives": tp, "watchFalsePositives": fp,
        "watchTruePositivesCurrent": tp_current, "watchFalsePositivesCurrent": fp_current,
        "watchWindowSize": window, "watchMinimumAnomalies": min_anomalies,
        "watchAnomalyFraction": fraction, "watchExpiry_s": expiry,
        "maxTrackedNeighbors": max_tracked,
        "observationEnabled": obs_enabled, "windowsOpened": opened,
        "windowsMatched": matched, "windowsDeadline": deadline,
        "windowsNeighborLost": lost, "windowsEvicted": evicted,
        "fingerprintCollisions": collisions,
        "fragmentedPacketsExcluded": fragmented,
        "promiscuousFramesInspected": frames,
        "observationWindow_s": obs_window, "observationSweep_s": obs_sweep,
        "maxActiveWindows": max_active,
        "transmissionsInspected": transmissions, "skippedLastHop": skip_last,
        "skippedNoRoute": skip_route, "skippedControlPlane": skip_control,
        "skippedNonUnicast": skip_nonunicast,
    }
    cols = _HEADER.split(",")
    return ",".join(str(vals[c]) for c in cols)


class Step3ValidatorTests(unittest.TestCase):
    def _write(self, row_line, manifest=None):
        tmp = Path(tempfile.mkdtemp())
        csv_path = tmp / "r.csv"
        csv_path.write_text(_HEADER + "\n" + row_line + "\n", encoding="utf-8")
        man_path = None
        if manifest is not None:
            man_path = tmp / "m.json"
            man_path.write_text(json.dumps(manifest), encoding="utf-8")
        return csv_path, man_path

    def test_valid_row_passes(self):
        csv_path, _ = self._write(_row())
        v.validate(csv_path, None)

    def test_tp_cannot_exceed_attacker_count(self):
        csv_path, _ = self._write(_row(ratio=0.20, tp=99))  # attacker_count=6
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv_path, None)

    def test_screening_off_forbids_watch(self):
        csv_path, _ = self._write(_row(screening=0, watch_count=3, tp=1, fp=1))
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv_path, None)
        # screening off with zero activity is fine
        csv_ok, _ = self._write(_row(screening=0, watch_count=0, tp=0, fp=0))
        v.validate(csv_ok, None)

    def test_zero_ratio_forbids_true_positive(self):
        csv_path, _ = self._write(_row(ratio=0.0, tp=1, fp=2))
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv_path, None)
        # zero ratio with false positives only is a legitimate false-alarm baseline
        csv_ok, _ = self._write(_row(ratio=0.0, tp=0, fp=2))
        v.validate(csv_ok, None)

    def test_detected_without_watchcount_rejected(self):
        csv_path, _ = self._write(_row(watch_count=0, tp=1, fp=0))
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv_path, None)

    def test_manifest_defence_cross_check(self):
        row = _row(watch_count=6, tp=3, fp=2)
        c19 = {"watchTruePositivesCurrent": 3, "watchFalsePositivesCurrent": 2,
               "watchWindowSize": 20, "watchMinimumAnomalies": 3}
        good = {"schemaVersion": "mtcaodv-step01-v1",
                "defence": {"watchCount": 6, "watchTruePositives": 3,
                            "watchFalsePositives": 2, **c19}}
        csv_path, man = self._write(row, good)
        v.validate(csv_path, man)
        bad = {"schemaVersion": "mtcaodv-step01-v1",
               "defence": {"watchCount": 5, "watchTruePositives": 3,
                           "watchFalsePositives": 2, **c19}}
        csv2, man2 = self._write(row, bad)
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv2, man2)


class Step3C19LifecycleTests(unittest.TestCase):
    """C-19: the WATCH lifecycle counters and parameters are checked, not trusted."""

    def _write(self, row_line):
        tmp = Path(tempfile.mkdtemp())
        csv_path = tmp / "r.csv"
        csv_path.write_text(_HEADER + "\n" + row_line + "\n", encoding="utf-8")
        return csv_path

    def test_expired_watch_is_accepted(self):
        """The normal C-19 outcome: some flags expired, so Current < cumulative."""
        csv_path = self._write(_row(tp=3, fp=5, tp_current=3, fp_current=1))
        summary = v.validate(csv_path, None)
        self.assertEqual(summary["watchFPCurrent"], 1)
        self.assertEqual(summary["watchTPCurrent"], 3)

    def test_current_cannot_exceed_cumulative(self):
        """A node still watched at t_end must have been watched at least once."""
        csv_path = self._write(_row(tp=3, fp=2, fp_current=4))
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv_path, None)
        csv2 = self._write(_row(tp=3, fp=2, tp_current=4))
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv2, None)

    def test_screening_off_forbids_live_watch(self):
        csv_path = self._write(
            _row(screening=0, watch_count=0, tp=0, fp=0, tp_current=0, fp_current=1)
        )
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv_path, None)

    def test_unreachable_rule_rejected(self):
        """minAnomalies > window can never fire: that is a silent disabled defence."""
        csv_path = self._write(_row(window=5, min_anomalies=6))
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv_path, None)

    def test_non_clearing_watch_rejected(self):
        """WATCH is reinforced surveillance, not a quarantine: it must be able to clear."""
        csv_path = self._write(_row(expiry=0.0))
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv_path, None)

    def test_fraction_out_of_range_rejected(self):
        csv_path = self._write(_row(fraction=1.5))
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv_path, None)

    def test_unbounded_neighbour_map_rejected(self):
        csv_path = self._write(_row(max_tracked=0))
        with self.assertRaises(v.Step3ValidationError):
            v.validate(csv_path, None)


class Step3ObservationTests(unittest.TestCase):
    """A3.2 : la comptabilite des fenetres est verifiee, jamais supposee."""

    def _write(self, row_line):
        tmp = Path(tempfile.mkdtemp())
        csv_path = tmp / "r.csv"
        csv_path.write_text(_HEADER + "\n" + row_line + "\n", encoding="utf-8")
        return csv_path

    def test_consistent_bookkeeping_passes(self):
        summary = v.validate(self._write(_row()), None)
        self.assertEqual(summary["windowsMatched"], 70)

    def test_more_closures_than_openings_rejected(self):
        """Une fenetre close deux fois, ou jamais ouverte, est un bug."""
        with self.assertRaises(v.Step3ValidationError):
            v.validate(self._write(_row(opened=50, matched=40, deadline=20,
                                        lost=0, evicted=0)), None)

    def test_disabled_observation_must_be_inert(self):
        with self.assertRaises(v.Step3ValidationError):
            v.validate(self._write(_row(obs_enabled=0)), None)
        v.validate(self._write(_row(obs_enabled=0, opened=0, matched=0, deadline=0,
                                    lost=0, evicted=0, frames=0, transmissions=0,
                                    skip_last=0, skip_route=0, skip_control=0,
                                    skip_nonunicast=0)), None)

    def test_last_hop_must_be_recognised(self):
        """L'invariant que la premiere version de cette etape violait.

        Sur un reseau majoritairement a deux sauts, le dernier saut
        relais->destination domine, et une destination ne retransmet jamais.
        Ouvrir une fenetre dessus transforme chaque livraison honnete en
        non-observation. Un `skippedLastHop` nul avec des fenetres ouvertes est
        donc la signature d'un observateur accroche au mauvais bout.
        """
        with self.assertRaises(v.Step3ValidationError):
            v.validate(self._write(_row(opened=100, skip_last=0)), None)

    def test_accounting_cannot_exceed_inspected(self):
        with self.assertRaises(v.Step3ValidationError):
            v.validate(self._write(_row(opened=100, transmissions=50)), None)

    def test_zero_window_rejected(self):
        """Une fenetre nulle transformerait chaque transfert honnete en silence."""
        with self.assertRaises(v.Step3ValidationError):
            v.validate(self._write(_row(obs_window=0.0)), None)

    def test_sweep_longer_than_window_rejected(self):
        """Un balayage plus lent que la fenetre gonfle la latence mesuree."""
        with self.assertRaises(v.Step3ValidationError):
            v.validate(self._write(_row(obs_window=0.050, obs_sweep=0.150)), None)

    def test_unbounded_window_map_rejected(self):
        with self.assertRaises(v.Step3ValidationError):
            v.validate(self._write(_row(max_active=0)), None)


if __name__ == "__main__":
    unittest.main()
