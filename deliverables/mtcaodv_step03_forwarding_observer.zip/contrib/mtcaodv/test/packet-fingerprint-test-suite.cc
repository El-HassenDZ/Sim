/* SPDX-License-Identifier: GPL-2.0-only */

/**
 * @file
 * @ingroup mtcaodv-tests
 * @brief Tests de `ComputePacketFingerprint` — Algorithme A3.2, appariement.
 *
 * Les valeurs attendues ci-dessous ont été calculées INDEPENDAMMENT en Python
 * avant d'être encodées ici, exactement comme les oracles des Éq. (3)–(5) à
 * STEP 2. Un test qui se contenterait de constater ce que le code produit ne
 * vérifierait rien.
 */

#include "ns3/packet-fingerprint.h"
#include "ns3/test.h"

using namespace ns3;
using namespace ns3::mtcaodv;

namespace
{

/** @brief Construit une adresse IPv4 en entier hôte, comme Ipv4Address::Get(). */
constexpr uint32_t
MakeIpv4(uint8_t a, uint8_t b, uint8_t c, uint8_t d)
{
    return (static_cast<uint32_t>(a) << 24) | (static_cast<uint32_t>(b) << 16) |
           (static_cast<uint32_t>(c) << 8) | static_cast<uint32_t>(d);
}

/** @brief Jeu de champs de référence : 10.1.0.1 -> 10.1.0.3, UDP, 512 octets. */
PacketFingerprintFields
ReferenceFields()
{
    PacketFingerprintFields fields;
    fields.sourceAddress = MakeIpv4(10, 1, 0, 1);
    fields.destinationAddress = MakeIpv4(10, 1, 0, 3);
    fields.identification = 4242;
    fields.payloadLength = 512;
    fields.protocol = 17; // UDP
    return fields;
}

} // namespace

/**
 * @brief L'empreinte reproduit l'oracle Python, bit pour bit.
 *
 * Fige la fonction de mélange ET l'ordre des octets. Si l'un ou l'autre changeait,
 * deux nœuds calculeraient des empreintes différentes pour le même paquet et
 * l'appariement échouerait toujours — panne silencieuse, jamais bruyante.
 */
class FingerprintOracleTestCase : public TestCase
{
  public:
    FingerprintOracleTestCase()
        : TestCase("La valeur d'empreinte reproduit l'oracle Python independant")
    {
    }

  private:
    void DoRun() override
    {
        // Oracle calcule en Python : FNV-1a 64 bits, octets en gros-boutiste.
        const uint64_t expected = 4731973103441115218ULL;
        NS_TEST_ASSERT_MSG_EQ(ComputePacketFingerprint(ReferenceFields()),
                              expected,
                              "l'empreinte differe de l'oracle calcule independamment");

        PacketFingerprintFields zero;
        NS_TEST_ASSERT_MSG_EQ(ComputePacketFingerprint(zero),
                              8977388880535415087ULL,
                              "l'empreinte du jeu nul differe de l'oracle");
    }
};

/**
 * @brief Le MEME paquet à deux sauts donne la MEME empreinte.
 *
 * C'est la propriété dont dépend tout A3.2. Elle tient parce que le TTL et la
 * somme de contrôle — les deux seuls champs que le routage réécrit — ne figurent
 * pas dans la structure. Ce test protège cette exclusion : si quelqu'un ajoutait
 * le TTL aux champs « pour plus de précision », chaque transfert honnête
 * deviendrait une non-observation, et le système accuserait des nœuds honnêtes.
 */
class FingerprintStableAcrossHopsTestCase : public TestCase
{
  public:
    FingerprintStableAcrossHopsTestCase()
        : TestCase("L'empreinte est identique au saut suivant (TTL/checksum exclus)")
    {
    }

  private:
    void DoRun() override
    {
        // Les champs sont, par construction, ceux que le routage ne touche pas.
        // Reconstruire la structure a l'identique modelise l'observation du meme
        // paquet un saut plus loin.
        NS_TEST_ASSERT_MSG_EQ(ComputePacketFingerprint(ReferenceFields()),
                              ComputePacketFingerprint(ReferenceFields()),
                              "le meme paquet doit donner la meme empreinte");
    }
};

/**
 * @brief Chaque champ retenu change effectivement l'empreinte.
 *
 * Un champ qui n'influencerait pas le résultat serait du poids mort et, pire,
 * rendrait indiscernables deux paquets qui ne diffèrent que par lui.
 * L'identification est le cas critique : sans son influence, deux paquets
 * consécutifs d'un même flux seraient confondus.
 */
class FingerprintDiscriminatesEachFieldTestCase : public TestCase
{
  public:
    FingerprintDiscriminatesEachFieldTestCase()
        : TestCase("Chaque champ retenu modifie l'empreinte")
    {
    }

  private:
    void DoRun() override
    {
        const uint64_t reference = ComputePacketFingerprint(ReferenceFields());

        PacketFingerprintFields identification = ReferenceFields();
        identification.identification = 4243;
        NS_TEST_ASSERT_MSG_EQ(ComputePacketFingerprint(identification),
                              9154378159011527387ULL,
                              "identification : oracle non reproduit");
        NS_TEST_ASSERT_MSG_NE(ComputePacketFingerprint(identification),
                              reference,
                              "deux paquets consecutifs d'un flux seraient confondus");

        PacketFingerprintFields source = ReferenceFields();
        source.sourceAddress = MakeIpv4(10, 1, 0, 2);
        NS_TEST_ASSERT_MSG_EQ(ComputePacketFingerprint(source),
                              3512615603679063553ULL,
                              "source : oracle non reproduit");

        PacketFingerprintFields destination = ReferenceFields();
        destination.destinationAddress = MakeIpv4(10, 1, 0, 4);
        NS_TEST_ASSERT_MSG_EQ(ComputePacketFingerprint(destination),
                              13920490210686684073ULL,
                              "destination : oracle non reproduit");

        PacketFingerprintFields length = ReferenceFields();
        length.payloadLength = 513;
        NS_TEST_ASSERT_MSG_EQ(ComputePacketFingerprint(length),
                              4731053911720120047ULL,
                              "taille : oracle non reproduit");

        PacketFingerprintFields protocol = ReferenceFields();
        protocol.protocol = 6;
        NS_TEST_ASSERT_MSG_EQ(ComputePacketFingerprint(protocol),
                              4731985198069025539ULL,
                              "protocole : oracle non reproduit");
    }
};

/**
 * @brief L'empreinte est déterministe et indépendante de l'ordre d'appel.
 *
 * Deux nœuds différents, à des instants différents, doivent obtenir la même
 * valeur. La fonction ne doit donc porter aucun état.
 */
class FingerprintIsPureTestCase : public TestCase
{
  public:
    FingerprintIsPureTestCase()
        : TestCase("La fonction est pure : aucun etat, aucun effet d'ordre")
    {
    }

  private:
    void DoRun() override
    {
        const PacketFingerprintFields fields = ReferenceFields();
        PacketFingerprintFields other = ReferenceFields();
        other.identification = 1;

        const uint64_t first = ComputePacketFingerprint(fields);
        (void)ComputePacketFingerprint(other);
        (void)ComputePacketFingerprint(other);
        const uint64_t second = ComputePacketFingerprint(fields);

        NS_TEST_ASSERT_MSG_EQ(first, second, "des appels intercales ont change le resultat");
    }
};

/** @brief Suite de tests de l'empreinte de paquet (STEP 3, A3.2). */
class PacketFingerprintTestSuite : public TestSuite
{
  public:
    PacketFingerprintTestSuite()
        : TestSuite("mtcaodv-packet-fingerprint", Type::UNIT)
    {
        AddTestCase(new FingerprintOracleTestCase, TestCase::Duration::QUICK);
        AddTestCase(new FingerprintStableAcrossHopsTestCase, TestCase::Duration::QUICK);
        AddTestCase(new FingerprintDiscriminatesEachFieldTestCase, TestCase::Duration::QUICK);
        AddTestCase(new FingerprintIsPureTestCase, TestCase::Duration::QUICK);
    }
};

static PacketFingerprintTestSuite g_packetFingerprintTestSuite;
