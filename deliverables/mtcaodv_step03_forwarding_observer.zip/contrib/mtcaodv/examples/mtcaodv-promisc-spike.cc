/*
 * MTC-AODV — STEP 3, spike C-17 : que voit réellement un nœud ns-3.48 des trames
 * qu'il n'a pas reçues pour lui ?
 *
 * ============================================================================
 * POURQUOI CE FICHIER EXISTE
 * ============================================================================
 * La spécification marque l'algorithme A3.2 (fenêtre locale d'observation du
 * prochain saut) comme « Proposé, spike API nécessaire », et la note C-17 exige
 * que les champs visibles par écoute passive soient VÉRIFIÉS par compilation, et
 * non supposés. Tout le `ForwardingObserver` de STEP 3 repose sur une seule
 * hypothèse : un nœud i, après avoir remis un paquet à son voisin j, peut
 * ENTENDRE la retransmission de j vers k et l'ATTRIBUER à j.
 *
 * Si cette hypothèse est fausse, l'architecture entière change (repli sur un
 * en-tête d'observation explicite, dont chaque octet devra être compté en
 * surcharge de contrôle). Écrire le `ForwardingObserver` avant de le savoir
 * serait construire sur une supposition.
 *
 * Ce programme ne fait donc RIEN d'autre que répondre à trois questions par une
 * trace vérifiable. Il n'implémente aucun composant MTC-AODV, ne mesure aucune
 * métrique de performance et ne doit jamais servir de scénario d'évaluation.
 *
 * ============================================================================
 * LES TROIS QUESTIONS (§3 de STEP3_SPECIFICATION.md)
 * ============================================================================
 * Q1. Le callback promiscuité est-il invoqué pour une trame NON destinée au
 *     nœud observateur ?
 * Q2. L'argument `from` porte-t-il l'adresse MAC de l'ÉMETTEUR DU SAUT COURANT
 *     (le relais j) et non celle de la source d'origine ?
 * Q3. Le paquet remis contient-il encore un en-tête IPv4 complet et analysable ?
 *
 * ============================================================================
 * TOPOLOGIE : UNE CHAÎNE DE TROIS NŒUDS, POSITIONS FIXES
 * ============================================================================
 *
 *      N0 ------------- N1 ------------- N2
 *      0 m            150 m            300 m
 *      |                                 |
 *      +------------ 300 m --------------+
 *
 * Avec RangePropagationLossModel et une portée de 200 m :
 *   - N0 et N1 s'entendent           (150 m < 200 m)
 *   - N1 et N2 s'entendent           (150 m < 200 m)
 *   - N0 et N2 ne s'entendent PAS    (300 m > 200 m)
 *
 * C'est exactement la configuration d'observation de A3.2 : N0 envoie à N2 via
 * N1, puis N0 doit pouvoir entendre la retransmission de N1 vers N2. La
 * mobilité est volontairement absente — ce spike teste une API, pas un scénario.
 *
 * ============================================================================
 * COMMENT LIRE LA SORTIE
 * ============================================================================
 * Chaque ligne PROMISC décrit une trame entendue par N0 sans lui être destinée.
 * Le verdict final répond aux trois questions. Un « VOIE A CONFIRMEE » autorise
 * l'écoute passive ; tout autre verdict impose la voie B (en-tête explicite) et
 * doit être rapporté tel quel.
 *
 * Aucune connaissance oracle n'est employée : le spike n'utilise aucune liste
 * d'attaquants et n'a d'ailleurs aucun attaquant.
 */

#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/mtc-aodv-helper.h"
#include "ns3/network-module.h"
#include "ns3/wifi-module.h"

// Inclusions EXPLICITES des trois en-têtes dont ce fichier dépend sans que le
// pilote en atteste l'usage. Les modules ci-dessus les tirent normalement, mais
// s'appuyer sur une inclusion transitive non vérifiée est précisément le genre
// de supposition que ce spike existe pour éliminer.
#include "ns3/ipv4-header.h"      // Ipv4Header, analysé par le callback
#include "ns3/position-allocator.h" // ListPositionAllocator, positions fixes
#include "ns3/vector.h"           // Vector, coordonnées de la chaîne N0-N1-N2

#include <iomanip>
#include <iostream>
#include <map>
#include <string>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("MtcAodvPromiscSpike");

namespace
{

/** @brief Port UDP applicatif ; identique au pilote pour rester cohérent. */
constexpr uint16_t APPLICATION_DESTINATION_PORT = 9000;

/** @brief Portée radio en mètres ; fixe la topologie ci-dessus. */
constexpr double MAXIMUM_RANGE_METERS = 200.0;

/**
 * @brief Ce que le spike a observé, agrégé pour produire le verdict.
 *
 * Chaque champ répond à une question précise ; aucun n'est supposé, tous sont
 * incrémentés par le callback lui-même.
 */
struct SpikeObservations
{
    /** @brief Q1 : trames entendues alors qu'elles ne nous étaient pas destinées. */
    uint32_t otherHostFrames{0};

    /** @brief Q2 : trames dont l'émetteur MAC est le RELAIS N1 (et non la source). */
    uint32_t framesFromRelay{0};

    /** @brief Q2, contrôle négatif : trames dont l'émetteur MAC est N2. */
    uint32_t framesFromDestination{0};

    /** @brief Q3 : trames dont l'en-tête IPv4 a pu être extrait et analysé. */
    uint32_t framesWithParsableIpv4{0};

    /**
     * @brief Q2+Q3 combinés : LA trame que le ForwardingObserver doit voir —
     * émise par le relais N1, portant un datagramme IPv4 de N0 vers N2.
     *
     * C'est le seul compteur qui valide réellement l'écoute passive : il exige
     * simultanément la bonne attribution d'émetteur et un en-tête exploitable.
     */
    uint32_t relayForwardsOfOurPacket{0};

    /** @brief Total de trames promiscuité, tous cas confondus. */
    uint32_t totalPromiscFrames{0};

    /** @brief Lignes déjà imprimées ; borne la sortie (Invariant 20.4.2). */
    uint32_t printedLines{0};
};

/** @brief Correspondance adresse MAC -> nom lisible, pour une trace intelligible. */
std::map<Address, std::string> g_macToName;

/** @brief Adresses IPv4 attendues, pour vérifier l'analyse de l'en-tête. */
Ipv4Address g_sourceIpv4;
Ipv4Address g_destinationIpv4;

/**
 * @brief Nom lisible d'une adresse MAC, ou sa forme brute si inconnue.
 * @param address Adresse à traduire.
 * @return Chaîne du type "N1" ou la représentation brute.
 */
std::string
NameOf(const Address& address)
{
    const auto found = g_macToName.find(address);
    if (found != g_macToName.end())
    {
        return found->second;
    }
    std::ostringstream stream;
    stream << address;
    return "?" + stream.str();
}

/**
 * @brief Nom lisible d'un type de paquet ns-3.
 * @param type Type remonté par le callback promiscuité.
 * @return Libellé court.
 *
 * `PACKET_OTHERHOST` est la réponse à Q1 : elle signifie que la trame ne nous
 * était pas destinée et qu'elle nous est remontée quand même.
 */
std::string
NameOfPacketType(NetDevice::PacketType type)
{
    switch (type)
    {
    case NetDevice::PACKET_HOST:
        return "HOST";
    case NetDevice::PACKET_BROADCAST:
        return "BROADCAST";
    case NetDevice::PACKET_MULTICAST:
        return "MULTICAST";
    case NetDevice::PACKET_OTHERHOST:
        return "OTHERHOST";
    default:
        return "UNKNOWN";
    }
}

/**
 * @brief Callback promiscuité installé sur N0 : le cœur du spike.
 *
 * @param observations Accumulateur (argument lié).
 * @param device Interface ayant reçu la trame.
 * @param packet Paquet remonté, après retrait de l'en-tête LLC/SNAP.
 * @param protocol EtherType ; 0x0800 pour IPv4.
 * @param from Adresse MAC source de la trame — c'est l'objet de Q2.
 * @param to Adresse MAC destination de la trame.
 * @param packetType Classification ns-3 ; c'est l'objet de Q1.
 * @return Toujours false : le spike n'intercepte rien et ne modifie rien.
 *
 * Le paquet est COPIÉ avant analyse. `RemoveHeader` mute son argument, et muter
 * un paquet en cours de traitement par la pile serait une intrusion — exactement
 * ce que l'invariant de non-intrusion de STEP 3 interdit.
 */
bool
OnPromiscuousReceive(SpikeObservations* observations,
                     Ptr<NetDevice> device,
                     Ptr<const Packet> packet,
                     uint16_t protocol,
                     const Address& from,
                     const Address& to,
                     NetDevice::PacketType packetType)
{
    ++observations->totalPromiscFrames;

    // ---- Q1 : la trame nous est-elle étrangère ? ----
    const bool isForeign = (packetType == NetDevice::PACKET_OTHERHOST);
    if (isForeign)
    {
        ++observations->otherHostFrames;
    }

    // ---- Q2 : qui a émis ce saut ? ----
    const std::string senderName = NameOf(from);
    if (senderName == "N1")
    {
        ++observations->framesFromRelay;
    }
    else if (senderName == "N2")
    {
        ++observations->framesFromDestination;
    }

    // ---- Q3 : l'en-tête IPv4 est-il exploitable ? ----
    // 0x0800 = EtherType IPv4. Un autre protocole (ARP par exemple) n'est pas
    // une anomalie ; il est simplement hors sujet pour l'observation IP.
    bool ipv4Parsed = false;
    Ipv4Address ipv4Source;
    Ipv4Address ipv4Destination;
    uint8_t ipv4Protocol = 0;
    if (protocol == 0x0800)
    {
        Ptr<Packet> copy = packet->Copy(); // ne jamais muter le paquet de la pile
        Ipv4Header header;
        if (copy->GetSize() >= header.GetSerializedSize())
        {
            copy->RemoveHeader(header);
            ipv4Source = header.GetSource();
            ipv4Destination = header.GetDestination();
            ipv4Protocol = header.GetProtocol();
            ipv4Parsed = true;
            ++observations->framesWithParsableIpv4;
        }
    }

    // ---- Q2 + Q3 : la trame que le ForwardingObserver devra reconnaître ----
    const bool isRelayForwardingOurPacket =
        isForeign && senderName == "N1" && ipv4Parsed &&
        ipv4Source == g_sourceIpv4 && ipv4Destination == g_destinationIpv4;
    if (isRelayForwardingOurPacket)
    {
        ++observations->relayForwardsOfOurPacket;
    }

    // Sortie bornée : la trace sert à convaincre, pas à noyer.
    if (observations->printedLines < 12)
    {
        ++observations->printedLines;
        std::cout << "PROMISC t=" << std::fixed << std::setprecision(4)
                  << Simulator::Now().GetSeconds() << "s"
                  << "  type=" << NameOfPacketType(packetType)
                  << "  from=" << senderName << "  to=" << NameOf(to)
                  << "  proto=0x" << std::hex << protocol << std::dec;
        if (ipv4Parsed)
        {
            std::cout << "  ipv4 " << ipv4Source << " -> " << ipv4Destination
                      << " (proto " << static_cast<uint32_t>(ipv4Protocol) << ")";
        }
        else
        {
            std::cout << "  [pas d'en-tete IPv4 analysable]";
        }
        std::cout << (isRelayForwardingOurPacket ? "   <== RELAIS OBSERVE" : "")
                  << std::endl;
    }

    return false; // n'intercepte rien
}

} // namespace

int
main(int argc, char* argv[])
{
    // Le spike n'a aucun paramètre scientifique : il teste une API, pas un
    // scénario. Seule la durée est exposée, pour pouvoir l'allonger si la trace
    // est trop courte pour conclure.
    double simulationTimeSeconds = 10.0;
    CommandLine commandLine(__FILE__);
    commandLine.AddValue("simTime", "Duree de la simulation en secondes",
                         simulationTimeSeconds);
    commandLine.Parse(argc, argv);

    // ---- 1. Trois nœuds, positions FIXES ----
    NodeContainer nodes;
    nodes.Create(3);

    MobilityHelper mobility;
    Ptr<ListPositionAllocator> positions = CreateObject<ListPositionAllocator>();
    positions->Add(Vector(0.0, 0.0, 0.0));   // N0 : source et observateur
    positions->Add(Vector(150.0, 0.0, 0.0)); // N1 : relais
    positions->Add(Vector(300.0, 0.0, 0.0)); // N2 : destination, hors de portee de N0
    mobility.SetPositionAllocator(positions);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(nodes);

    // ---- 2. Pile Wi-Fi identique au pilote, pour que le résultat transfère ----
    YansWifiChannelHelper channel;
    channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    channel.AddPropagationLoss("ns3::RangePropagationLossModel",
                               "MaxRange",
                               DoubleValue(MAXIMUM_RANGE_METERS));
    YansWifiPhyHelper phy;
    phy.SetChannel(channel.Create());

    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211b);
    wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                 "DataMode",
                                 StringValue("DsssRate11Mbps"),
                                 "ControlMode",
                                 StringValue("DsssRate1Mbps"));
    WifiMacHelper mac;
    mac.SetType("ns3::AdhocWifiMac");
    NetDeviceContainer devices = wifi.Install(phy, mac, nodes);

    // ---- 3. Routage MTC-AODV, pour que le relais soit réel et non forcé ----
    // Une route statique aurait pu suffire, mais utiliser le protocole du projet
    // garantit que ce que le spike observe est bien ce que STEP 3 observera.
    // MtcAodvHelper vit dans ns3::mtcaodv, pas ns3 : le fork est volontairement
    // isolé dans son propre espace de noms pour ne pas entrer en collision avec
    // le module AODV officiel, et le pilote le qualifie de la même façon.
    mtcaodv::MtcAodvHelper mtcAodv;
    InternetStackHelper internet;
    internet.SetRoutingHelper(mtcAodv);
    internet.Install(nodes);

    Ipv4AddressHelper ipv4;
    ipv4.SetBase("10.1.0.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);
    g_sourceIpv4 = interfaces.GetAddress(0);
    g_destinationIpv4 = interfaces.GetAddress(2);

    // ---- 4. Table MAC -> nom, pour une trace lisible ----
    for (uint32_t i = 0; i < devices.GetN(); ++i)
    {
        g_macToName[devices.Get(i)->GetAddress()] = "N" + std::to_string(i);
    }

    // ---- 5. Trafic N0 -> N2, forcément relayé par N1 ----
    PacketSinkHelper sink("ns3::UdpSocketFactory",
                          InetSocketAddress(Ipv4Address::GetAny(),
                                            APPLICATION_DESTINATION_PORT));
    ApplicationContainer sinkApplication = sink.Install(nodes.Get(2));
    sinkApplication.Start(Seconds(1.0));
    sinkApplication.Stop(Seconds(simulationTimeSeconds));

    OnOffHelper source("ns3::UdpSocketFactory",
                       InetSocketAddress(g_destinationIpv4,
                                         APPLICATION_DESTINATION_PORT));
    // Idiome repris VERBATIM du pilote : une periode ON effectivement infinie et
    // une periode OFF nulle donnent une source reellement continue. Un OnTime de
    // 1 s produirait des interruptions periodiques, donc des trous dans la trace
    // d'observation -- exactement ce que ce spike ne doit pas introduire.
    source.SetAttribute("OnTime",
                        StringValue("ns3::ConstantRandomVariable[Constant=1000000000.0]"));
    source.SetAttribute("OffTime",
                        StringValue("ns3::ConstantRandomVariable[Constant=0.0]"));
    source.SetAttribute("DataRate", DataRateValue(DataRate("32kbps")));
    source.SetAttribute("PacketSize", UintegerValue(512));
    ApplicationContainer sourceApplication = source.Install(nodes.Get(0));
    sourceApplication.Start(Seconds(2.0));
    sourceApplication.Stop(Seconds(simulationTimeSeconds - 1.0));

    // ---- 6. L'écoute passive sur N0 : l'objet du spike ----
    SpikeObservations observations;
    devices.Get(0)->SetPromiscReceiveCallback(
        MakeBoundCallback(&OnPromiscuousReceive, &observations));

    std::cout << "=== Spike C-17 : ecoute passive en ad hoc 802.11b ===\n"
              << "N0=" << g_sourceIpv4 << " (source + observateur), "
              << "N1=" << interfaces.GetAddress(1) << " (relais), "
              << "N2=" << g_destinationIpv4 << " (destination)\n"
              << "Portee " << MAXIMUM_RANGE_METERS << " m : N0-N1 150 m, N1-N2 150 m, "
              << "N0-N2 300 m (hors de portee)\n\n";

    Simulator::Stop(Seconds(simulationTimeSeconds));
    Simulator::Run();
    Simulator::Destroy();

    // ---- 7. Verdict, sans interprétation complaisante ----
    std::cout << "\n=== Compteurs ===\n"
              << "tramesPromiscuiteTotal      = " << observations.totalPromiscFrames << '\n'
              << "Q1 tramesNonDestineesANous  = " << observations.otherHostFrames << '\n'
              << "Q2 tramesEmisesParLeRelais  = " << observations.framesFromRelay << '\n'
              << "Q2 tramesEmisesParN2        = " << observations.framesFromDestination << '\n'
              << "Q3 tramesAvecIPv4Analysable = " << observations.framesWithParsableIpv4 << '\n'
              << "RELAIS OBSERVE (Q2 et Q3)   = " << observations.relayForwardsOfOurPacket
              << "\n\n=== Verdict ===\n";

    const bool q1 = observations.otherHostFrames > 0;
    const bool q2 = observations.framesFromRelay > 0;
    const bool q3 = observations.framesWithParsableIpv4 > 0;
    const bool decisive = observations.relayForwardsOfOurPacket > 0;

    std::cout << "Q1 callback invoque pour une trame etrangere : " << (q1 ? "OUI" : "NON")
              << '\n'
              << "Q2 'from' porte l'emetteur du saut courant   : " << (q2 ? "OUI" : "NON")
              << '\n'
              << "Q3 en-tete IPv4 complet et analysable        : " << (q3 ? "OUI" : "NON")
              << "\n\n";

    if (decisive)
    {
        std::cout << "VOIE A CONFIRMEE : l'ecoute passive suffit. Le ForwardingObserver\n"
                  << "peut associer une retransmission a son emetteur sans en-tete ajoute,\n"
                  << "donc sans surcharge de controle et sans modifier le format des paquets.\n";
        return 0;
    }

    std::cout << "VOIE A NON CONFIRMEE : l'ecoute passive ne fournit pas l'attribution\n"
              << "requise dans cette configuration. Ne pas contourner ce resultat.\n"
              << "Consequence : repli sur la VOIE B (en-tete d'observation explicite borne),\n"
              << "dont chaque octet devra etre compte en surcharge de controle et dont la\n"
              << "nature differente -- etre notifie plutot qu'observer -- devra etre declaree\n"
              << "dans l'article.\n";
    if (observations.totalPromiscFrames == 0)
    {
        std::cout << "\nNOTE : aucune trame promiscuite du tout. Verifier d'abord que le\n"
                  << "callback est bien installe et que le MAC passe en mode promiscuite,\n"
                  << "avant de conclure quoi que ce soit sur l'API.\n";
    }
    return 1; // fail closed : un verdict negatif n'est pas un succes
}
