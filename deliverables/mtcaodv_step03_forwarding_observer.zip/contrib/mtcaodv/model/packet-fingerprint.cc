/* SPDX-License-Identifier: GPL-2.0-only */
#include "packet-fingerprint.h"

namespace ns3
{
namespace mtcaodv
{

namespace
{

/** @brief Décalage initial FNV-1a 64 bits (constante publiée de l'algorithme). */
constexpr uint64_t FNV_OFFSET_BASIS = 14695981039346656037ULL;

/** @brief Premier de multiplication FNV-1a 64 bits (constante publiée). */
constexpr uint64_t FNV_PRIME = 1099511628211ULL;

/**
 * @brief Absorbe un octet dans l'état de hachage.
 * @param state État courant, modifié sur place.
 * @param byte Octet absorbé.
 *
 * FNV-1a : XOR puis multiplication. L'ordre importe — FNV-1 fait l'inverse et
 * disperse moins bien les entrées courtes, ce qui est exactement notre cas.
 */
inline void
MixByte(uint64_t& state, uint8_t byte)
{
    state ^= static_cast<uint64_t>(byte);
    state *= FNV_PRIME;
}

/**
 * @brief Absorbe un entier en gros-boutiste, taille fixe.
 * @param state État courant.
 * @param value Valeur à absorber.
 * @param byteCount Nombre d'octets à absorber (1, 2 ou 4).
 *
 * L'ordre des octets est imposé explicitement : deux nœuds calculent la même
 * empreinte quelle que soit l'architecture. Laisser cela à `memcpy` d'un entier
 * rendrait l'empreinte dépendante du boutisme de la machine — sans effet en
 * simulation, mais faux en principe et invisible jusqu'au jour où ça compte.
 */
inline void
MixInteger(uint64_t& state, uint32_t value, unsigned byteCount)
{
    for (unsigned index = byteCount; index > 0; --index)
    {
        MixByte(state, static_cast<uint8_t>((value >> (8 * (index - 1))) & 0xFFu));
    }
}

} // namespace

uint64_t
ComputePacketFingerprint(const PacketFingerprintFields& fields)
{
    uint64_t state = FNV_OFFSET_BASIS;
    MixInteger(state, fields.sourceAddress, 4);
    MixInteger(state, fields.destinationAddress, 4);
    MixInteger(state, fields.identification, 2);
    MixInteger(state, fields.payloadLength, 2);
    MixInteger(state, fields.protocol, 1);
    return state;
}

} // namespace mtcaodv
} // namespace ns3
