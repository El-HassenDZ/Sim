/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef MTCAODV_FORWARDING_OBSERVATION_H
#define MTCAODV_FORWARDING_OBSERVATION_H

#include "ns3/ipv4-address.h"

#include <cstdint>

namespace ns3
{
namespace mtcaodv
{

/**
 * @ingroup mtcaodv
 * @brief Pourquoi une fenêtre d'observation s'est refermée.
 *
 * La distinction est SCIENTIFIQUE, pas décorative. `DEADLINE` et `NEIGHBOR_LOST`
 * produisent tous deux `z_e = 0`, mais l'Éq. (8) leur attribuera des
 * vraisemblances de perte bénigne très différentes : un voisin disparu est une
 * explication bénigne forte, un silence sur lien stable ne l'est pas. `EVICTED`
 * n'est pas une observation du tout et ne doit jamais alimenter une masse.
 */
enum class ForwardingClosureReason : uint8_t
{
    /** @brief Retransmission positivement appariée : `z_e = 1` (Éq. 9). */
    MATCHED = 0,

    /** @brief Échéance atteinte sans appariement : `z_e = 0` (Éq. 10). */
    DEADLINE = 1,

    /** @brief Le voisin a disparu avant qu'une opportunité existe (A3.2 ligne 10). */
    NEIGHBOR_LOST = 2,

    /** @brief Évincée par la borne de fenêtres actives : NON INTERPRETABLE. */
    EVICTED = 3
};

/**
 * @brief Libellé court d'une raison de clôture, pour traces et CSV.
 * @param reason Raison à nommer.
 * @return Chaîne stable, utilisable comme valeur de colonne.
 */
const char* ForwardingClosureReasonName(ForwardingClosureReason reason);

/**
 * @ingroup mtcaodv
 * @brief Une fenêtre d'observation close — la sortie de l'Algorithme A3.2.
 *
 * CE QUE CETTE STRUCTURE CONTIENT, ET CE QU'ELLE NE CONTIENT PAS
 * --------------------------------------------------------------
 * Elle contient un FAIT observé localement (`forwardingObserved`) et les
 * CARACTERISTIQUES disponibles au moment de l'observation, chacune accompagnée
 * de son drapeau de disponibilité.
 *
 * Elle ne contient AUCUNE masse OCEA, AUCUN jugement, AUCUNE étiquette
 * « malveillant ». L'Algorithme A3.2 se termine explicitement par « do not label
 * it malicious here » : l'attribution est le rôle d'A3.3, à STEP 4. Cette
 * séparation n'est pas cosmétique — elle garantit que l'observation reste
 * valable même si les poids d'attribution changent.
 *
 * POURQUOI CHAQUE CARACTERISTIQUE PORTE UN DRAPEAU
 * ------------------------------------------------
 * Les Éq. (6) et (8) somment les poids des caractéristiques DISPONIBLES et
 * déclarent l'événement non interprétable quand la couverture est nulle. Une
 * valeur par défaut substituée à une donnée absente ferait passer une
 * observation partielle pour complète — exactement l'erreur commise à STEP 2
 * avec `epsilon = 1e-6`, qui avait saturé le score sur des nœuds honnêtes.
 * Ici, absent signifie absent.
 */
struct ForwardingObservation
{
    // ---- Identité de l'événement ----
    /** @brief Nœud qui observe (l'observateur `i`). */
    uint32_t observerNodeId{0};

    /** @brief Voisin observé (le prochain saut `j`) — adresse IPv4. */
    Ipv4Address watchedNeighbor;

    /** @brief Empreinte du paquet suivi. */
    uint64_t fingerprint{0};

    /** @brief Instant d'ouverture de la fenêtre. Unité : s. */
    double openTimeSeconds{0.0};

    /** @brief Instant de clôture. Unité : s. */
    double closeTimeSeconds{0.0};

    // ---- Le fait observé ----
    /** @brief `z_e` : la retransmission a-t-elle été positivement observée ? */
    bool forwardingObserved{false};

    /** @brief Comment la fenêtre s'est refermée. */
    ForwardingClosureReason closureReason{ForwardingClosureReason::DEADLINE};

    /**
     * @brief L'émetteur de la trame appariée a-t-il pu être attribué à `j` ?
     *
     * Sur appariement, l'observateur connaît l'adresse MAC émettrice. Encore
     * faut-il savoir qu'elle appartient bien à `j`. La correspondance est apprise
     * PASSIVEMENT (voir ForwardingObserver) et peut être absente. Dans ce cas ce
     * drapeau est faux et l'attribution reste incomplète — ce qui doit être
     * reporté, non supposé.
     */
    bool senderAttributedToNeighbor{false};

    // ---- Caractéristiques d'opportunité x_k, entrées de l'Éq. (6)-(7) ----
    /** @brief Fiabilité observateur-voisin estimée, dans [0,1]. */
    double linkReliability{0.0};
    /** @brief `a_k` associé à linkReliability. */
    bool linkReliabilityAvailable{false};

    /** @brief Persistance de contact prévue pendant la fenêtre, dans [0,1]. */
    double predictedContactPersistence{0.0};
    /** @brief `a_k` associé à predictedContactPersistence. */
    bool predictedContactPersistenceAvailable{false};

    /** @brief Visibilité par écoute passive, dans [0,1]. */
    double passiveVisibility{0.0};
    /** @brief `a_k` associé à passiveVisibility. */
    bool passiveVisibilityAvailable{false};

    // ---- Diagnostics de perte bénigne y_l, entrées de l'Éq. (8) ----
    /** @brief Indice de rupture de lien ou de mobilité, dans [0,1]. */
    double mobilityBreak{0.0};
    /** @brief `a_l` associé à mobilityBreak. */
    bool mobilityBreakAvailable{false};

    /** @brief Indice de pression de file d'attente, dans [0,1]. */
    double queuePressure{0.0};
    /** @brief `a_l` associé à queuePressure. */
    bool queuePressureAvailable{false};

    /** @brief Un RERR cohérent a-t-il été observé pour cette route ? */
    double coherentRerr{0.0};
    /** @brief `a_l` associé à coherentRerr. */
    bool coherentRerrAvailable{false};
};

} // namespace mtcaodv
} // namespace ns3

#endif // MTCAODV_FORWARDING_OBSERVATION_H
