/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef MTCAODV_FORWARDING_OBSERVER_H
#define MTCAODV_FORWARDING_OBSERVER_H

#include "forwarding-observation.h"
#include "packet-fingerprint.h"

#include "ns3/address.h"
#include "ns3/event-id.h"
#include "ns3/ipv4-address.h"
#include "ns3/ipv4-header.h"
#include "ns3/net-device.h"
#include "ns3/nstime.h"
#include "ns3/object.h"
#include "ns3/packet.h"
#include "ns3/traced-callback.h"

#include <cstdint>
#include <map>

namespace ns3
{

class Node;

namespace mtcaodv
{

class RoutingProtocol;

/**
 * @ingroup mtcaodv
 * @brief Algorithme A3.2 — fenêtre locale d'observation du prochain saut.
 *
 * CE QUE FAIT CETTE CLASSE
 * ------------------------
 * Quand le protocole de routage remet un paquet au voisin `j`, il appelle
 * OpenWindow(). L'observateur écoute alors passivement le canal ; s'il entend
 * `j` retransmettre le MEME paquet avant l'échéance, la fenêtre se referme avec
 * `z_e = 1`. Sinon elle se referme avec `z_e = 0` et les indices de perte
 * bénigne disponibles.
 *
 * CE QU'ELLE NE FAIT PAS, ET C'EST ESSENTIEL
 * ------------------------------------------
 * 1. Elle n'attribue AUCUNE masse et ne qualifie rien de malveillant. A3.2 se
 *    termine par « do not label it malicious here » ; l'attribution est A3.3,
 *    livrée à STEP 4.
 * 2. Elle ne consulte AUCUNE vérité terrain. Elle ne reçoit jamais la liste des
 *    attaquants et n'a aucun moyen de la lire. L'appariement attaquant/honnête
 *    se fait hors ligne, sur le manifeste, comme pour le criblage RREP.
 * 3. Elle ne modifie NI ne retarde AUCUN paquet. Le rappel promiscuité renvoie
 *    toujours false et travaille sur des copies. La preuve exigée à STEP 3 est
 *    `PDR(observateur actif) == PDR(observateur inactif)` au même germe.
 *
 * ATTRIBUTION DE L'EMETTEUR — APPRISE, PAS SUPPOSEE
 * -------------------------------------------------
 * Entendre la retransmission ne suffit pas : encore faut-il savoir qu'elle vient
 * bien de `j`. La trame fournit une adresse MAC ; la fenêtre connaît une adresse
 * IPv4. La correspondance est apprise **passivement** : toute trame diffusée
 * portant un en-tête IPv4 révèle que son adresse MAC émettrice appartient au
 * nœud dont l'adresse IP figure en source (le spike C-17 l'a vérifié — les
 * diffusions de contrôle AODV portent bien l'adresse du saut courant).
 *
 * Quand la correspondance est inconnue, `senderAttributedToNeighbor` reste faux
 * et l'observation le déclare. Supposer l'attribution serait fabriquer une
 * donnée.
 *
 * STRUCTURES BORNEES (Invariant 20.4.2)
 * -------------------------------------
 * `MaxActiveWindows` borne les fenêtres ouvertes ; au-delà, la plus ancienne est
 * évincée avec `EVICTED` — une raison distincte, jamais confondue avec une
 * non-observation. `MaxLearnedAddresses` borne la table MAC→IPv4.
 */
class ForwardingObserver : public Object
{
  public:
    /**
     * @brief Enregistre le TypeId de cette classe.
     * @return TypeId enregistré.
     */
    static TypeId GetTypeId();

    ForwardingObserver();
    ~ForwardingObserver() override;

    /**
     * @brief Attache l'observateur à un nœud et installe l'écoute passive.
     * @param node Nœud observateur.
     *
     * L'écoute est posée sur CHAQUE interface non-loopback via
     * NetDevice::SetPromiscReceiveCallback, dont le spike C-17 a confirmé qu'elle
     * remonte les trames étrangères avec l'émetteur du saut courant et un
     * en-tête IPv4 intact.
     *
     * @warning À n'appeler qu'une fois par nœud. Poser deux rappels promiscuité
     *          écraserait le premier ; ns-3 n'en conserve qu'un par interface.
     */
    void Install(Ptr<Node> node);

    /**
     * @brief Ouvre une fenêtre : « je viens de remettre ce paquet à `j` ».
     * @param header En-tête IPv4 COMPLET du paquet remis.
     * @param payloadLengthBytes Taille utile en octets.
     * @param nextHop Adresse IPv4 du prochain saut `j`.
     *
     * Publique pour être testable directement. En fonctionnement, elle est
     * appelée par OnIpv4Transmit() et non par le protocole de routage.
     */
    void OpenWindow(const Ipv4Header& header,
                    uint16_t payloadLengthBytes,
                    Ipv4Address nextHop);

    /** @brief Active ou désactive l'observation (preuve de non-intrusion). */
    void SetEnabled(bool enabled);

    /** @brief L'observation est-elle active ? */
    bool IsEnabled() const;

    // ---- Compteurs, tous mesurés, aucun supposé ----
    /** @brief Fenêtres ouvertes depuis le début. */
    uint64_t GetWindowsOpened() const;
    /** @brief Fenêtres closes par appariement positif (`z_e = 1`). */
    uint64_t GetWindowsMatched() const;
    /** @brief Fenêtres closes par échéance (`z_e = 0`). */
    uint64_t GetWindowsDeadline() const;
    /** @brief Fenêtres closes parce que le voisin avait disparu. */
    uint64_t GetWindowsNeighborLost() const;
    /** @brief Fenêtres évincées par la borne : NON interprétables. */
    uint64_t GetWindowsEvicted() const;
    /** @brief Empreintes en collision détectées (jamais supposées nulles). */
    uint64_t GetFingerprintCollisions() const;
    /** @brief Paquets fragmentés rencontrés, exclus du suivi. */
    uint64_t GetFragmentedPacketsExcluded() const;
    /** @brief Trames promiscuité inspectées, tous types confondus. */
    uint64_t GetPromiscuousFramesInspected() const;

    // ---- Pourquoi une fenêtre n'a PAS été ouverte ----
    // Ces compteurs sont aussi informatifs que les fenêtres elles-mêmes : sans
    // eux, « peu de fenêtres » serait indiscernable de « l'accrochage ne se
    // déclenche pas », qui est exactement le défaut ayant motivé cette refonte.
    /** @brief Émissions où le prochain saut EST la destination finale. */
    uint64_t GetSkippedLastHop() const;
    /** @brief Émissions sans route valide au moment de l'observation. */
    uint64_t GetSkippedNoRoute() const;
    /** @brief Émissions de contrôle AODV, exclues du plan de données. */
    uint64_t GetSkippedControlPlane() const;
    /** @brief Émissions vers une adresse diffusée ou multicast. */
    uint64_t GetSkippedNonUnicast() const;
    /** @brief Total des émissions IPv4 examinées par l'observateur. */
    uint64_t GetTransmissionsInspected() const;

    /**
     * @brief Signature de la TraceSource émise à chaque fenêtre close.
     * @param observation Événement clos, sans aucune masse ni étiquette.
     */
    typedef void (*ObservationClosedTracedCallback)(
        const ForwardingObservation& observation);

  protected:
    void DoDispose() override;

  private:
    /** @brief Une fenêtre ouverte, en attente d'appariement ou d'échéance. */
    struct OpenWindowRecord
    {
        Ipv4Address nextHop;      //!< Voisin `j` auquel le paquet a été remis.
        double openTimeSeconds;   //!< Instant d'ouverture, en secondes.
        uint32_t sourceAddress;   //!< Conservé pour détecter les collisions.
        uint32_t destinationAddress; //!< Idem.
        uint16_t identification;  //!< Idem.
    };

    /**
     * @brief Rappel promiscuité : le cœur de l'observation.
     * @param device Interface réceptrice.
     * @param packet Trame reçue, en-tête LLC déjà retiré.
     * @param protocol EtherType.
     * @param from MAC de l'émetteur du saut courant.
     * @param to MAC destinataire.
     * @param packetType Classification ns-3.
     * @return Toujours false — l'observateur n'intercepte rien.
     */
    bool OnPromiscuousReceive(Ptr<NetDevice> device,
                              Ptr<const Packet> packet,
                              uint16_t protocol,
                              const Address& from,
                              const Address& to,
                              NetDevice::PacketType packetType);

    /**
     * @brief Une trame IPv4 vient d'être émise par ce nœud (source OU relais).
     * @param header En-tête IPv4 complet, tel que la couche 3 l'a construit.
     * @param packet Paquet sans son en-tête IPv4.
     * @param interface Index de l'interface sortante.
     *
     * POURQUOI CE POINT D'ACCROCHE, ET PAS LE PROTOCOLE DE ROUTAGE
     * ------------------------------------------------------------
     * Une première version accrochait `RoutingProtocol::Forwarding()`. C'était
     * faux : `Forwarding()` ne traite que le trafic EN TRANSIT, donc une source
     * ne l'appelle jamais pour ses propres paquets. Sur un chemin à deux sauts
     * — le cas dominant du scénario gelé, mesuré à 1,73 saut — cela accrochait
     * exactement le mauvais bout :
     *
     *   SOURCE → RELAIS → DESTINATION
     *     la SOURCE peut entendre le RELAIS retransmettre   → observable
     *     le RELAIS remet à la DESTINATION, qui CONSOMME    → rien à observer
     *
     * L'ancien accrochage n'ouvrait de fenêtre que chez le relais, c'est-à-dire
     * dans le seul cas sans rien à voir, et manquait le seul cas observable.
     * Toute clôture honnête serait devenue une non-observation.
     *
     * Les TraceSources `SendOutgoing` et `UnicastForward` d'`Ipv4L3Protocol`
     * couvrent les deux cas uniformément et fournissent l'en-tête COMPLET —
     * `RouteOutput()` ne le pourrait pas, le champ d'identification n'y étant
     * pas encore assigné, ce qui aurait rendu toute empreinte incomparable.
     */
    void OnIpv4Transmit(const Ipv4Header& header,
                        Ptr<const Packet> packet,
                        uint32_t interface);

    /** @brief Ferme toutes les fenêtres dont l'échéance est dépassée. */
    void SweepExpiredWindows();

    /** @brief Programme le prochain balayage périodique. */
    void ScheduleNextSweep();

    /**
     * @brief Clôt une fenêtre et émet la TraceSource.
     * @param fingerprint Empreinte de la fenêtre.
     * @param record Enregistrement à clore.
     * @param reason Raison de clôture.
     * @param observedSenderMac MAC appariée, si la clôture est un appariement.
     */
    void CloseWindow(uint64_t fingerprint,
                     const OpenWindowRecord& record,
                     ForwardingClosureReason reason,
                     const Address& observedSenderMac);

    /** @brief Enregistre passivement une correspondance MAC -> IPv4. */
    void LearnAddressMapping(const Address& mac, Ipv4Address ipv4);

    /** @brief Nœud observateur ; non possédé. */
    Ptr<Node> m_node;

    /** @brief Identifiant du nœud, mémorisé pour les traces. */
    uint32_t m_observerNodeId{0};

    /** @brief Interrupteur d'observation. */
    bool m_enabled{true};

    /** @brief Durée de la fenêtre d'observation. */
    Time m_observationWindow;

    /** @brief Période du balayage des échéances. */
    Time m_sweepInterval;

    /** @brief Borne dure sur les fenêtres actives. */
    uint32_t m_maxActiveWindows{256};

    /** @brief Borne dure sur la table MAC -> IPv4 apprise. */
    uint32_t m_maxLearnedAddresses{256};

    /**
     * @brief Port UDP du plan de contrôle AODV, exclu de l'observation.
     *
     * Un Blackhole complet DOIT relayer le contrôle pour rester attractif :
     * inclure ces paquets diluerait le signal du plan de données avec des
     * transferts que même un attaquant effectue fidèlement.
     */
    uint16_t m_controlPlanePort{654};

    /** @brief Protocole de routage, consulté pour le prochain saut uniquement. */
    Ptr<RoutingProtocol> m_routing;

    /** @brief Fenêtres ouvertes, indexées par empreinte. */
    std::map<uint64_t, OpenWindowRecord> m_openWindows;

    /** @brief Correspondances MAC -> IPv4 apprises passivement. */
    std::map<Address, Ipv4Address> m_learnedAddresses;

    /**
     * @brief Dernier instant où chaque voisin a été entendu. Unité : s.
     *
     * Alimente `passiveVisibility` : un silence alors que le voisin est audible
     * par ailleurs n'a pas la même signification qu'un silence total. C'est la
     * seule caractéristique d'opportunité que STEP 3 mesure réellement.
     */
    std::map<Ipv4Address, double> m_lastHeardFromNeighbor;

    /** @brief Événement du balayage périodique. */
    EventId m_sweepEvent;

    // ---- Compteurs ----
    uint64_t m_windowsOpened{0};
    uint64_t m_windowsMatched{0};
    uint64_t m_windowsDeadline{0};
    uint64_t m_windowsNeighborLost{0};
    uint64_t m_windowsEvicted{0};
    uint64_t m_fingerprintCollisions{0};
    uint64_t m_fragmentedPacketsExcluded{0};
    uint64_t m_promiscuousFramesInspected{0};
    uint64_t m_transmissionsInspected{0};
    uint64_t m_skippedLastHop{0};
    uint64_t m_skippedNoRoute{0};
    uint64_t m_skippedControlPlane{0};
    uint64_t m_skippedNonUnicast{0};

    /** @brief Émise à chaque fenêtre close ; entrée de l'attribution STEP 4. */
    TracedCallback<const ForwardingObservation&> m_observationClosedTrace;
};

} // namespace mtcaodv
} // namespace ns3

#endif // MTCAODV_FORWARDING_OBSERVER_H
