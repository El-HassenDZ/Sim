/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef MTCAODV_PACKET_FINGERPRINT_H
#define MTCAODV_PACKET_FINGERPRINT_H

#include <cstdint>

namespace ns3
{
namespace mtcaodv
{

/**
 * @ingroup mtcaodv
 * @brief Champs IPv4 immuables d'un saut à l'autre, dont on dérive l'empreinte.
 *
 * ROLE DANS L'ARCHITECTURE (Algorithme A3.2)
 * ------------------------------------------
 * Un observateur `i` remet un paquet à son voisin `j`, puis entend `j`
 * retransmettre « un » paquet. Pour savoir s'il s'agit du MEME paquet, il faut
 * une empreinte calculable des deux côtés sans état partagé et sans horloge
 * commune. C'est le rôle de cette structure.
 *
 * POURQUOI CES CHAMPS ET PAS D'AUTRES
 * -----------------------------------
 * Le critère est l'immuabilité au passage d'un routeur IP :
 *
 * | Champ                | Retenu | Motif                                      |
 * |----------------------|--------|--------------------------------------------|
 * | adresse source       | oui    | immuable de bout en bout                   |
 * | adresse destination  | oui    | immuable de bout en bout                   |
 * | identification IPv4  | oui    | posée par la source, jamais réécrite        |
 * | protocole            | oui    | immuable                                   |
 * | taille utile         | oui    | immuable hors fragmentation                |
 * | **TTL**              | NON    | **décrémenté à chaque saut**               |
 * | **somme de contrôle**| NON    | **recalculée à chaque saut**               |
 *
 * Inclure le TTL ou la somme de contrôle rendrait l'empreinte différente des
 * deux côtés, donc l'appariement toujours négatif — un transfert honnête
 * apparaîtrait alors systématiquement comme une non-retransmission. C'est le
 * mode de défaillance le plus insidieux de STEP 3, et il est écarté ici par
 * construction, pas par vigilance.
 *
 * LE CHAMP D'IDENTIFICATION PORTE LE POUVOIR DISCRIMINANT
 * -------------------------------------------------------
 * Source, destination, protocole et taille sont identiques pour tous les
 * paquets d'un même flux. Seule l'identification IPv4 les distingue : elle est
 * incrémentée par paquet à l'émission. Sans elle, deux paquets consécutifs d'un
 * même flux seraient indiscernables et un unique transfert observé pourrait
 * clore la fenêtre d'un autre paquet.
 *
 * FRAGMENTATION — LIMITE DECLAREE
 * -------------------------------
 * La fragmentation IP invalide à la fois l'identification (partagée par tous
 * les fragments) et la taille utile. Le pilote émet 512 octets utiles, très en
 * dessous du MTU, donc le cas ne devrait pas se produire ; s'il se produit, il
 * est COMPTE et EXCLU, jamais traité silencieusement.
 */
struct PacketFingerprintFields
{
    /** @brief Adresse IPv4 source, en entier hôte. */
    uint32_t sourceAddress{0};

    /** @brief Adresse IPv4 destination, en entier hôte. */
    uint32_t destinationAddress{0};

    /** @brief Champ « Identification » de l'en-tête IPv4 (16 bits). */
    uint16_t identification{0};

    /** @brief Taille utile en octets, hors en-tête IPv4. */
    uint16_t payloadLength{0};

    /** @brief Numéro de protocole IPv4 (17 = UDP, 6 = TCP). */
    uint8_t protocol{0};
};

/**
 * @brief Empreinte 64 bits d'un paquet, stable d'un saut à l'autre.
 *
 * Fonction de mélange : FNV-1a 64 bits sur la sérialisation des champs. Le choix
 * est délibérément banal — aucun algorithme cryptographique n'est inventé
 * (hypothèse 4.2 de la spécification), et rien ici n'a besoin de résister à un
 * adversaire : un attaquant qui forgerait une empreinte devrait retransmettre le
 * paquet, ce qui est précisément le comportement honnête que l'on cherche à
 * observer.
 *
 * @param fields Champs immuables extraits de l'en-tête IPv4.
 * @return Empreinte 64 bits.
 *
 * @note Le taux de collision est MESURE par le `ForwardingObserver` et exporté,
 *       jamais supposé nul. Avec 64 bits et moins d'une centaine de paquets
 *       coexistants dans une fenêtre de quelques centaines de millisecondes, une
 *       collision reste hautement improbable — mais « improbable » n'est pas
 *       « impossible », et un résultat scientifique ne repose pas sur un espoir.
 */
uint64_t ComputePacketFingerprint(const PacketFingerprintFields& fields);

} // namespace mtcaodv
} // namespace ns3

#endif // MTCAODV_PACKET_FINGERPRINT_H
