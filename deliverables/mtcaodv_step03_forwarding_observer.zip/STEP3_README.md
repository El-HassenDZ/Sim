# MTC-AODV — STEP 3 : `ForwardingObserver` (Algorithme A3.2)

**Statut :** `À compiler et tester sur le PC utilisateur.`
ns-3.48 n'est pas disponible dans l'environnement de génération. Les 27 tests
Python passent ici ; le C++ n'a **pas** été compilé.

---

## 1. Ce que fait cette étape, et ce qu'elle ne fait pas

STEP 3 implémente **A3.2 seulement** : ouvrir, suivre et refermer des fenêtres
locales d'observation du prochain saut. Sortie : des `ForwardingObservation`
closes portant `z_e ∈ {0,1}` et les **drapeaux de disponibilité** des
caractéristiques.

**Hors périmètre, délibérément :** l'attribution OCEA (Éq. 6–10, A3.3) reste à
STEP 4 ; MOBeta-Trust à STEP 5 ; quarantaine, certificats et PTMB à STEP 6+.
**Aucune route n'est jamais exclue à cette étape.**

## 2. Le critère de succès est que le PDR NE CHANGE PAS

Rien ici n'exclut de route, donc rien ne peut relever le PDR. **Un gain de PDR
serait un bug** — la preuve que l'observateur a interféré avec le routage. Le
test d'intégration vérifie l'égalité stricte observateur actif / inactif.

## 3. La mesure qui porte la valeur scientifique de l'étape

> **À quel taux un voisin HONNÊTE apparaît-il comme n'ayant pas retransmis ?**

Cette baseline bénigne détermine si les poids `ν_ℓ` de l'Éq. (8) pourront être
calibrés sur des données plutôt que posés arbitrairement — l'erreur exacte
commise à STEP 2 avec `ε = 1e-6`. Si un voisin honnête est non observé aussi
souvent qu'un blackhole, aucune pondération ne sauvera l'attribution.

Aucune valeur n'est prédite. `analyze_forwarding.py` la mesure et la rapporte
telle quelle, élevée ou non.

## 3bis. Correction majeure : l'observateur était accroché au mauvais bout

La première version accrochait `RoutingProtocol::Forwarding()`. **C'était faux**,
et le test d'intégration l'a révélé.

`Forwarding()` n'est atteint que depuis `RouteInput()`, donc **uniquement pour le
trafic en transit** : une source ne l'appelle jamais pour ses propres paquets.
Sur un chemin à deux sauts — le cas dominant du scénario gelé, mesuré à
**1,73 saut** — cela accrochait exactement le mauvais bout :

```
SOURCE ──────────▶ RELAIS ──────────▶ DESTINATION
   │                  │
   │                  └─ remet à la DESTINATION, qui CONSOMME
   │                     et ne retransmet JAMAIS      → RIEN À OBSERVER
   │
   └─ peut entendre le RELAIS retransmettre           → OBSERVABLE
```

L'ancien accrochage n'ouvrait de fenêtre que **chez le relais**, c'est-à-dire dans
le seul cas où il n'y a rien à voir, et manquait le seul cas observable. Sur le
scénario gelé il aurait produit une **baseline de non-observation honnête proche
de 1,00** — précisément le mode de défaillance que le §10 de ce document
annonçait comme « le plus insidieux ». Je l'avais écrit, puis construit.

**Deux corrections, pas une :**

**(a) Observer depuis la source aussi.** L'observateur ne dépend plus du
protocole de routage : il se branche sur les TraceSources `SendOutgoing` et
`UnicastForward` d'`Ipv4L3Protocol`, qui couvrent **source et relais**
uniformément et portent l'en-tête IPv4 **complet**. `RouteOutput()` ne pouvait
pas convenir : le champ d'identification n'y est pas encore assigné, donc toute
empreinte y aurait été incomparable avec celle observée sur le fil.

**(b) Ne jamais ouvrir de fenêtre quand le prochain saut EST la destination.**
La destination consomme le paquet ; ouvrir une fenêtre garantirait `z_e = 0` sur
un nœud parfaitement honnête, à chaque paquet du dernier saut.

**Bénéfice collatéral :** le protocole de routage ne connaît plus l'observateur.
Le chemin de décision de `Forwarding()` redevient identique octet pour octet à
l'AODV ns-3.48. La seule surface exposée est `LookupNextHopForObservation()`,
une consultation pure. L'égalité `PDR(ON) == PDR(OFF)` devient **structurelle**
et non plus promise.

**Nouveaux compteurs, parce que l'absence de fenêtre est une information :**
`transmissionsInspected`, `skippedLastHop`, `skippedNoRoute`,
`skippedControlPlane`, `skippedNonUnicast`. Sans eux, « peu de fenêtres » serait
indiscernable de « l'accrochage ne se déclenche pas » — le défaut exact qui vient
d'être corrigé. Le validateur **rejette** désormais un run où des fenêtres
s'ouvrent alors que `skippedLastHop = 0`.

**Le plan de contrôle AODV (UDP 654) est exclu** de l'observation : un Blackhole
complet doit relayer fidèlement le contrôle pour rester attractif, donc l'inclure
diluerait le signal du plan de données avec des transferts que même un attaquant
effectue.

## 4. Décisions de conception, et leur raison

**Empreinte de paquet.** Champs retenus : source, destination, identification
IPv4, protocole, taille utile. **TTL et somme de contrôle exclus** — ils sont
réécrits à chaque saut, et les inclure ferait échouer *tous* les appariements,
donc accuser des nœuds honnêtes. L'identification porte le pouvoir discriminant :
sans elle, deux paquets consécutifs d'un flux seraient confondus. Oracles FNV-1a
vérifiés en Python avant d'être encodés en C++.

**Attribution de l'émetteur — apprise, jamais supposée.** La trame donne une MAC,
la fenêtre connaît une IPv4. La correspondance est apprise **passivement** depuis
les diffusions de contrôle AODV, dont le spike C-17 a vérifié qu'elles portent
l'adresse du saut courant. Correspondance inconnue ⇒ `senderAttributed = false`,
et c'est déclaré.

**Quatre raisons de clôture distinctes.** `MATCHED` (z=1), `DEADLINE` (z=0),
`NEIGHBOR_LOST` (z=0, explication bénigne forte) et `EVICTED` — qui n'a **rien
observé du tout** et ne doit jamais être lu comme une non-observation.

**Un seul balayage périodique** plutôt qu'un minuteur par fenêtre : coût O(1) par
fenêtre au lieu d'un événement par fenêtre.

**Point d'accroche minimal.** Six lignes dans `Forwarding()`, juste avant `ucb`,
au moment exact où le paquet devient la responsabilité du prochain saut. Ouvrir
la fenêtre *après* `ucb` courserait la retransmission du voisin, qui en IBSS
rapide peut précéder notre retour. Aucune branche ne dépend de l'observateur ; un
observateur nul ne change rien — c'est ce qui rend l'égalité de PDR démontrable.

## 5. Installation

```bash
cd /home/hassen/res/ns-3.48 && unzip -o /home/hassen/Downloads/mtcaodv_step03_forwarding_observer.zip -d .
```
```bash
cd /home/hassen/res/ns-3.48 && find contrib/mtcaodv experiments -type f -exec touch {} + && ./ns3 configure --enable-examples --enable-tests && ./ns3 build
```

`configure` est obligatoire : trois fichiers source sont nouveaux.

## 6. Tests

```bash
cd /home/hassen/res/ns-3.48 && ./test.py -s mtcaodv-packet-fingerprint && ./test.py -s mtcaodv-forwarding-observer
```
```bash
cd /home/hassen/res/ns-3.48 && for s in mtcaodv-attack-manager mtcaodv-blackhole-behavior mtcaodv-step00-baseline-metrics mtcaodv-routing-protocol mtcaodv-rrep-anomaly-detector; do ./test.py -s $s; done
```
```bash
cd /home/hassen/res/ns-3.48/experiments && python3 test_validate_step03.py -q && python3 test_analyze_forwarding.py -q
```

## 7. Exécution sur le scénario gelé

```bash
cd /home/hassen/res/ns-3.48 && ./ns3 run "mtcaodv-pilot-attack --nodes=30 --areaSize=600 --maxRange=200 --minSpeed=1 --maxSpeed=5 --simTime=300 --flowCount=5 --dataRate=51.2kbps --attackerRatio=0.20 --seed=1 --run=1 --observationsCsv=obs-atk.csv"
```
```bash
cd /home/hassen/res/ns-3.48 && cp mtcaodv-step01-manifest.json man-atk.json && cp mtcaodv-step01-results.csv res-atk.csv && python3 experiments/validate_step03.py --csv res-atk.csv --manifest man-atk.json
```
```bash
cd /home/hassen/res/ns-3.48 && python3 experiments/analyze_forwarding.py --observations obs-atk.csv --manifest man-atk.json --after-attack-start
```

**Preuve de non-intrusion** (le PDR doit être identique au chiffre près) :

```bash
cd /home/hassen/res/ns-3.48 && ./ns3 run "mtcaodv-pilot-attack --nodes=30 --areaSize=600 --maxRange=200 --minSpeed=1 --maxSpeed=5 --simTime=300 --flowCount=5 --dataRate=51.2kbps --attackerRatio=0.20 --seed=1 --run=1 --enableObservation=false" 2>&1 | grep -E "^pdr|^windowsOpened"
```

## 8. Critères PASS / FAIL préenregistrés

**PASS** exige les cinq :
1. compilation et suites `mtcaodv-packet-fingerprint` + `mtcaodv-forwarding-observer` vertes ;
2. non-régression : toutes les suites STEP 0–2 vertes ;
3. **`PDR(observation ON) == PDR(observation OFF)`** au même seed ;
4. `windowsOpened > 0` **et** `windowsMatched > 0` — l'observation fonctionne réellement ;
5. `validate_step03.py` PASS, dont la conservation
   `matched + deadline + neighborLost + evicted ≤ opened`.

**FAIL :** l'observation change le PDR ; une fuite de vérité terrain ; colonnes
STEP 0–2 cassées ; une fenêtre `EVICTED` comptée comme `z_e = 0`.

**Rapporté sans seuil** (aucune valeur n'est prédictible) : la baseline de
non-observation honnête.

## 8bis. Une erreur commise deux fois, et sa prévention

Le module est **isolé dans `ns3::mtcaodv`** pour que ses TypeIds n'entrent pas en
collision avec le module AODV officiel. Or `mtcaodv-pilot-attack.cc` et
`mtcaodv-promisc-spike.cc` déclarent `using namespace ns3;` **sans**
`using namespace ns3::mtcaodv;` : tout type du module doit y être qualifié
explicitement, comme le fait déjà `mtcaodv::RoutingProtocol` partout dans le
pilote.

J'ai commis l'oubli dans le spike, l'ai corrigé, puis **je l'ai refait dans le
pilote** — même erreur, fichier suivant. Le correctif ponctuel ne vaut rien sans
la règle.

**Règle :** seuls les fichiers qui ne sont **pas** eux-mêmes dans
`namespace mtcaodv` sont exposés. Aujourd'hui : les deux exemples ci-dessus et
`packet-fingerprint-test-suite.cc` (qui, lui, ajoute
`using namespace ns3::mtcaodv;`). Les `model/`, les `test/` placés dans le
namespace et le fork n'ont rien à qualifier.

## 9. Le risque d'API qui subsiste

**Résolu :** le build est passé, donc `GetIdentification()`, `IsLastFragment()`
et `GetFragmentOffset()` existent bien.

**Nouveau risque introduit par la correction §3bis :** les noms des TraceSources
`"SendOutgoing"` et `"UnicastForward"` d'`Ipv4L3Protocol` ne sont attestés par
**aucune source dont je dispose**. Ce sont les noms standard de ns-3 et leur
signature est `void(const Ipv4Header&, Ptr<const Packet>, uint32_t)`, mais je ne
les ai pas vus se connecter.

L'échec serait **bruyant, pas silencieux** : `Install()` porte un
`NS_ASSERT_MSG` sur le résultat des deux connexions, précisément pour qu'un nom
erroné arrête la simulation au lieu de produire zéro fenêtre sans explication.

## 10. Ce qui pourrait faire échouer cette étape, dit d'avance

1. **Fenêtre mal dimensionnée.** Un `--observationWindow` trop court produirait un
   `z_e = 0` massif sur des voisins honnêtes, indiscernable d'une attaque. C'est
   le risque le plus insidieux, et la raison pour laquelle
   `analyze_forwarding.py` rapporte la **distribution des latences
   d'appariement** : c'est elle qui doit fixer la fenêtre, pas l'intuition. La
   valeur pilote de 150 ms est une hypothèse à corriger sur mesure.
2. **Trop peu de relais.** Le scénario gelé mesure 1,73 saut, soit ~0,73 relais
   par chemin. Les fenêtres existeront (~12 700 relais attendus, ~423 par nœud)
   mais chaque couple (observateur, voisin) en verra peu.
3. **Mode promiscuité non gratuit.** Si le seul passage du MAC en promiscuité
   changeait la livraison, l'assertion de non-intrusion échouerait. Ce serait un
   **résultat à rapporter**, pas un obstacle à contourner.
