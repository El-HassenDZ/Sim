# STEP 3 — `ForwardingObserver` : spécification d'implémentation

**Statut :** spécification soumise à validation **avant** écriture de code.
**Source normative :** `MTCAODV_Mathematical_Algorithms_Specification.md`, §5.4, A3.2, A3.3.
**Cible :** Linux, ns-3.48, C++17 — `/home/hassen/res/ns-3.48/contrib/mtcaodv/`.

---

## 1. Périmètre : ce que STEP 3 fait, et ce qu'il ne fait pas

STEP 3 implémente **A3.2 uniquement** — l'ouverture, le suivi et la clôture de
fenêtres locales d'observation du prochain saut. Il produit des
`ForwardingObservation` closes portant `z_e ∈ {0,1}` et les **indicateurs de
disponibilité** des caractéristiques.

**Hors périmètre, explicitement :**

| Composant | Étape | Raison du report |
|---|---|---|
| Attribution OCEA, Éq. (6)–(10) (A3.3) | STEP 4 | Fonction pure et testable hors ns-3 ; la séparer permet de la valider sur des oracles analytiques |
| MOBeta-Trust, Éq. (11)–(19) | STEP 5 | Dépend des masses de STEP 4 |
| `ACCUSED`, quarantaine, certificats, PTMB | STEP 6+ | — |
| Toute influence sur le routage | jamais à cette étape | STEP 3 est **strictement observationnel** |

**Découpage justifié par le risque.** A3.3 est déterministe et vérifiable sur
papier. A3.2 dépend d'une API ns-3 non confirmée (C-17). Les séparer évite que
l'incertitude API contamine la validation des équations.

---

## 2. La question que STEP 3 doit trancher, et qui décide de la suite

> **Un observateur voit-il réellement quelque chose, et à quel taux un voisin
> HONNÊTE apparaît-il comme non observé ?**

C'est la mesure décisive, pas un sous-produit. Elle détermine :

- si OCEA a une matière statistique (masses `m` et `b` non dégénérées) ;
- la **base de référence de non-observation bénigne** qui servira à calibrer les
  poids `ν_ℓ` de l'Éq. (8) — sans elle, ces poids seraient posés arbitrairement ;
- si l'écart d'observation entre voisins honnêtes et attaquants existe **avant**
  toute pondération, exactement comme l'AUC a tranché pour STEP 2.

Si un voisin honnête est non observé aussi souvent qu'un blackhole, aucune
pondération ne sauvera l'attribution, et il faudra le dire.

---

## 2bis. Aucune amélioration de PDR n'est attendue avant STEP 6

**Principe posé par l'utilisateur, et je le partage :** l'objectif de métriques
plus élevées (PDR, goodput) ne se juge qu'**une fois le cadre complet** — PTMB,
consensus, certificat de quarantaine. STEP 3, 4 et 5 n'excluent aucune route :
`WATCH` n'est pas une quarantaine, `ACCUSED` non plus, et seul un certificat
autorise `QUARANTINED`. Un composant qui n'exclut rien ne peut pas relever le PDR.

Conséquence directe et non négociable pour cette étape : **le critère de succès
de STEP 3 est que le PDR ne change PAS**, au bit près. Une amélioration de PDR à
STEP 3 serait un **symptôme de bug** — la preuve que l'observateur a interféré
avec le routage.

**Le risque de ce principe, et la discipline qui le rend honnête.** Reporter le
jugement à la fin peut devenir un permis de différer indéfiniment tout résultat
décevant : « ce sera réglé quand la blockchain sera là ». La protection est que
**chaque étape porte son propre critère falsifiable, indépendant du PDR** :

| Étape | Critère propre, jugé à l'étape même | Jugé sur PDR ? |
|---|---|---|
| STEP 2 | AUC du score `A_RREP`, FAR sur voisins honnêtes | non |
| **STEP 3** | rendement d'observation ; **baseline de non-observation honnête** | **non — PDR doit être identique** |
| STEP 4 | séparation des masses `m` entre voisins honnêtes et attaquants | non |
| STEP 5 | séparation de la confiance MOBeta ; stabilité sous mobilité | non |
| STEP 6+ | exclusion certifiée effective | **oui, enfin** |

Si l'un de ces critères intermédiaires échoue, l'échec est constaté **à cette
étape**, pas reporté. C'est ce qui distingue une architecture incrémentale d'un
report indéfini.

## 3. C-17 — le risque bloquant, à lever en premier

La spécification marque A3.2 **« Proposé, spike API nécessaire »**. La question
est : *que voit exactement un nœud ns-3.48 des trames qu'il n'a pas émises, et
peut-il en attribuer l'émetteur ?*

**Voie A — écoute passive (préférée).**
`NetDevice::SetPromiscReceiveCallback` remonte les trames décodées par la radio.
À vérifier par compilation, sans deviner :
1. le callback est-il invoqué pour une trame **non destinée** au nœud ?
2. l'argument `from` porte-t-il l'adresse MAC de l'**émetteur du saut courant**
   (et non de la source d'origine) ?
3. le `Ptr<const Packet>` remis contient-il l'en-tête IPv4 complet, ou a-t-il
   déjà été dépouillé ?

**Voie B — repli, en-tête d'observation explicite borné.**
Si A échoue, un en-tête borné est ajouté. **Tous ses octets sont alors comptés
dans la surcharge de contrôle** et rapportés ; aucune mesure de débit ne peut
l'ignorer. Cette voie change la nature du résultat (on n'observe plus, on se
fait notifier) et doit être déclarée comme telle dans l'article.

**Livrable préalable :** un exécutable `mtcaodv-promisc-spike` de ~80 lignes qui
répond aux trois questions par une trace, et rien d'autre. Coût ~1 h. Il détermine
si l'on écrit A ou B, et il est le premier code de STEP 3.

---

## 4. Fichiers ajoutés

```
contrib/mtcaodv/model/packet-fingerprint.{h,cc}       // empreinte bornée, sans ns-3
contrib/mtcaodv/model/forwarding-observation.h        // structure d'événement clos
contrib/mtcaodv/model/forwarding-observer.{h,cc}      // A3.2, couplé ns-3
contrib/mtcaodv/test/packet-fingerprint-test-suite.cc
contrib/mtcaodv/test/forwarding-observer-test-suite.cc
contrib/mtcaodv/examples/mtcaodv-promisc-spike.cc     // spike C-17
experiments/validate_step03.py + test_validate_step03.py
experiments/analyze_forwarding.py + test_analyze_forwarding.py
```

`packet-fingerprint` et `forwarding-observation` sont **sans dépendance ns-3**,
donc testables au même titre que `rrep-anomaly-detector`.

---

## 5. `PacketFingerprint` — identifier le même paquet à deux sauts

Le paquet observé chez `j` doit être reconnu comme celui remis par `i`. Les champs
retenus sont ceux **immuables d'un saut à l'autre** :

| Champ | Retenu | Motif |
|---|---|---|
| IP source, IP destination | oui | immuables |
| Identification IPv4 (16 bits) | oui | posée par la source, immuable hors fragmentation |
| Protocole | oui | immuable |
| Ports UDP source/destination | oui | immuables |
| Longueur utile | oui | immuable hors fragmentation |
| **TTL** | **non** | décrémenté à chaque saut |
| **Somme de contrôle IP** | **non** | recalculée à chaque saut |

Empreinte = condensat 64 bits des champs retenus. **Collisions :** avec ~62 paquets/s
et une fenêtre de quelques centaines de ms, moins de 100 paquets coexistent ;
64 bits rendent la collision négligeable, mais le taux de collision **observé**
sera exporté, jamais supposé nul.

**Limite déclarée :** la fragmentation IP invalide `identification` et la longueur.
Le pilote utilise 512 octets utiles, très en dessous du MTU ; les paquets fragmentés
seront **comptés et exclus**, non traités silencieusement.

---

## 6. `ForwardingObservation` — la structure d'événement clos

```
observerNodeId, watchedNeighbor        // qui observe qui
fingerprint, openTimeSeconds, closeTimeSeconds
forwardingObserved  z_e ∈ {0,1}
closureReason       ∈ {MATCHED, DEADLINE, NEIGHBOR_LOST, EVICTED}

// Caractéristiques d'opportunité x_k et leurs drapeaux a_k  -> Éq. (6)-(7)
linkReliability            + available
receptionSupport           + available
predictedContactPersistence+ available
passiveVisibility          + available

// Diagnostics de perte bénigne y_l et leurs drapeaux a_l  -> Éq. (8)
mobilityBreak              + available
channelBusy                + available
queuePressure              + available
coherentRerr               + available
```

**Point non négociable.** STEP 3 remplit `x_k`, `y_ℓ` et **leurs drapeaux de
disponibilité**, mais **ne calcule aucune masse**. Un drapeau absent est `false`,
jamais une valeur par défaut : c'est précisément ce que l'Éq. (8) exige quand
`d_e = 0` (« événement déclaré non interprétable »). Substituer une valeur
conventionnelle à une donnée manquante violerait la règle *fail closed*.

---

## 7. Invariants imposés

| Invariant | Mise en œuvre |
|---|---|
| **Aucune connaissance oracle** | `ForwardingObserver` ne reçoit ni ne consulte la liste d'attaquants. L'appariement attaquant/honnête est fait **hors ligne** par `analyze_forwarding.py` depuis le manifeste, comme pour STEP 2. |
| **Structures bornées** (20.4.2) | `MaxActiveWindows` (défaut 256) avec éviction LRU ; index d'empreintes borné ; export de traces borné par `--maxObservationRows`. |
| **Aucun impact routage** | L'observateur ne modifie ni ne retarde aucun paquet. **Preuve exigée :** `PDR(observer ON) == PDR(observer OFF)` au bit près, même seed — le même test qui a validé STEP 2. |
| **Reproductibilité** | La politique d'échantillonnage utilise `UniformRandomVariable` avec flux dédié `OBSERVER_STREAM_BASE` et `AssignStreams()`. Jamais `std::rand()`. Flux consommés reportés au manifeste. |
| **AODV préservé** | Aucune modification de `RecvRequest`, `RecvReply`, `Forwarding`, table de routage, précurseurs, séquences. |
| **Fail closed** | Une fenêtre non interprétable est comptée comme telle, jamais convertie en `z_e = 0` exploitable. |

---

## 8. Paramètres (tous configurables, aucun gelé à ce stade)

| Attribut | Défaut pilote | Rôle |
|---|---|---|
| `EnableForwardingObservation` | `true` | interrupteur, pour la preuve de non-intrusion |
| `ObservationWindow` | 150 ms | délai avant clôture ; **à calibrer** sur le délai MAC mesuré |
| `SamplingProbability` | 1.0 | fraction des paquets relayés suivis ; abaisser si le coût le impose |
| `MaxActiveWindows` | 256 | borne dure par nœud |
| `ObserverStreamBase` | 50000 | flux RNG dédié |

`ObservationWindow` est le paramètre sensible : trop court, un transfert honnête
est manqué ; trop long, la fenêtre déborde sur la mobilité. Il sera calibré sur le
**délai de bout en bout mesuré** du scénario gelé (7,6 ms de moyenne à 45/750),
pas posé par intuition — l'erreur commise avec le proxy de délai ne sera pas répétée.

---

## 9. Sorties et métriques

Colonnes **append-only** ajoutées au CSV existant :

```
observationEnabled, windowsOpened, windowsMatched, windowsDeadline,
windowsNeighborLost, windowsEvicted, fingerprintCollisions,
fragmentedPacketsExcluded, observationWindow_s, samplingProbability,
maxActiveWindows, observerStream, observerStreamsConsumed
```

Export brut optionnel `--observationsCsv` : une ligne par fenêtre close, avec
`x_k`, `y_ℓ` et leurs drapeaux — l'équivalent de `--scoresCsv` pour STEP 2, qui
permettra de calibrer OCEA **hors ligne** sans recompiler.

---

## 10. Critères PASS / FAIL préenregistrés

**PASS** exige les cinq :
1. Compilation et suites `mtcaodv-packet-fingerprint` et `mtcaodv-forwarding-observer` vertes ;
2. Non-régression : toutes les suites STEP 0–2 vertes ;
3. **`PDR(ON) == PDR(OFF)`** au même seed, à la précision d'impression ;
4. `windowsOpened > 0` et `windowsMatched > 0` — l'observation fonctionne réellement ;
5. `validate_step03.py` PASS, dont `windowsMatched + windowsDeadline +
   windowsNeighborLost + windowsEvicted == windowsOpened` (conservation).

**FAIL :** l'observateur change le PDR ; fuite de vérité terrain ; colonnes
STEP 0–2 cassées ; une fenêtre non interprétable comptée comme `z_e = 0`.

**Mesure rapportée sans seuil préenregistré** (car aucune valeur n'est prédictible) :
le taux de non-observation sur voisins **honnêtes**. C'est la baseline bénigne. Elle
sera rapportée telle quelle, élevée ou non.

**Aucun critère de PDR à cette étape**, sinon l'égalité stricte ON/OFF (§2bis).
Un gain de PDR observé ici serait traité comme un **échec**, pas comme un succès.

---

## 11. Ce qui pourrait faire échouer STEP 3, dit d'avance

1. **C-17 négatif** — `MacPromiscRx` n'attribue pas l'émetteur. Repli sur l'en-tête
   explicite, avec sa surcharge comptée et sa nature déclarée.
2. **Trop peu de relais** — à ~2,1 sauts prédits pour 30/600, environ 1,0 relais par
   chemin. Les fenêtres existeront, mais chaque nœud en ouvrira peu. Si
   `windowsOpened` par nœud est faible, l'étape reste valide mais MOBeta-Trust
   manquera de matière, et il faudra l'écrire.
3. **Fenêtre mal dimensionnée** — un `ObservationWindow` trop court produirait un
   `z_e = 0` massif sur des voisins honnêtes, indiscernable d'une attaque. C'est le
   risque le plus insidieux, et la raison pour laquelle la baseline honnête est la
   mesure centrale de cette étape.
