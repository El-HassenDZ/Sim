# STEP 3 — Spike C-17 : instructions et lecture du résultat

**Statut :** `À compiler et tester sur le PC utilisateur.`
ns-3.48 n'est pas disponible dans l'environnement de génération. Le code n'a
**pas** été compilé ici ; sa géométrie et sa logique ont été vérifiées, son API
non. C'est précisément l'objet du spike.

## Ce que ce spike décide

Tout le `ForwardingObserver` de STEP 3 repose sur une hypothèse unique : un nœud
`i`, après avoir remis un paquet à son voisin `j`, peut **entendre** la
retransmission de `j` vers `k` et l'**attribuer** à `j`. Si c'est faux,
l'architecture change entièrement.

Trois questions, une trace :

1. le callback promiscuité est-il invoqué pour une trame **non destinée** au nœud ?
2. l'argument `from` porte-t-il l'émetteur du **saut courant**, ou la source d'origine ?
3. le paquet remonté contient-il encore un **en-tête IPv4 complet** ?

## Installation et exécution

```bash
cd /home/hassen/res/ns-3.48 && unzip -o /home/hassen/Downloads/mtcaodv_step03_spike_c17.zip -d .
```
```bash
cd /home/hassen/res/ns-3.48 && find contrib/mtcaodv -type f -exec touch {} + && ./ns3 configure --enable-examples --enable-tests && ./ns3 build
```

`./ns3 configure` est **obligatoire** : `mtcaodv-promisc-spike.cc` est un fichier
source nouveau. Le `touch` l'est tout autant — `unzip` restaure les horodatages de
l'archive, donc les sources extraites peuvent paraître plus anciennes que les
objets déjà compilés et ninja ne recompilerait rien. Ce piège a déjà coûté deux
cycles à ce projet.

```bash
cd /home/hassen/res/ns-3.48 && ./ns3 run mtcaodv-promisc-spike
```

## Topologie, et pourquoi elle est fixe

```
   N0 ------------- N1 ------------- N2
   0 m            150 m            300 m
```

Portée 200 m : N0↔N1 et N1↔N2 s'entendent, N0↔N2 non. N0 envoie donc à N2 **via
N1**, et doit pouvoir entendre la retransmission de N1. Aucune mobilité, aucun
aléa : ce spike teste une API, pas un scénario, et un résultat d'API ne doit pas
dépendre d'un tirage.

## Lecture de la sortie

Ligne attendue si l'écoute passive fonctionne :

```
PROMISC t=2.0123s  type=OTHERHOST  from=N1  to=N2  proto=0x800  ipv4 10.1.0.1 -> 10.1.0.3 (proto 17)   <== RELAIS OBSERVE
```

Le compteur qui tranche est **`RELAIS OBSERVE (Q2 et Q3)`** : il n'est incrémenté
que si la trame est étrangère **et** attribuée au relais **et** porte un IPv4
analysable de N0 vers N2. Les trois conditions ensemble, sinon rien.

| Verdict | Conséquence |
|---|---|
| **VOIE A CONFIRMEE** (code de sortie 0) | Écoute passive suffisante. Le `ForwardingObserver` s'écrit sans en-tête ajouté, donc sans surcharge de contrôle et sans modifier le format des paquets. |
| **VOIE A NON CONFIRMEE** (code 1) | Repli sur la **voie B** : en-tête d'observation explicite borné. Chaque octet compté en surcharge, et la nature différente du mécanisme — être *notifié* plutôt qu'*observer* — déclarée dans l'article. |

Si `tramesPromiscuiteTotal = 0`, ne concluez rien sur l'API : vérifiez d'abord que
le callback est installé et que le MAC bascule en mode promiscuité. Le programme
le signale explicitement dans ce cas.

**Le code de sortie est 1 en cas de verdict négatif.** Un résultat négatif n'est
pas un succès et ne doit pas être contourné : il oriente l'architecture, ce qui
est exactement le rôle d'un spike.

## Ce que ce spike ne fait pas

Il n'implémente aucun composant MTC-AODV, ne mesure aucune métrique de
performance, n'utilise aucune connaissance oracle (il n'a d'ailleurs aucun
attaquant) et **ne doit jamais servir de scénario d'évaluation**. Il ne touche ni
au scénario gelé, ni au pilote, ni à `src/aodv/`.

## À me renvoyer

La sortie complète, quel que soit le verdict. C'est elle qui détermine si j'écris
`ForwardingObserver` en voie A ou en voie B — et il serait absurde d'écrire
~1 500 lignes de C++ avant de savoir ce qu'un nœud voit réellement.
