# Commandes de test et d'exécution

Racine ns-3 supposée : `/home/hassen/res/ns-3.48`. Adaptez si nécessaire.

---

## 0. Installation — vérifier l'empreinte AVANT d'extraire

Les archives sont **numérotées** (`_r7`, `_r8`, …) parce qu'un navigateur
n'écrase pas un téléchargement homonyme : il écrit `...(1).zip`. Avec un nom
fixe, on ré-extrait toujours la **première** archive et l'arbre source régresse
silencieusement. C'est arrivé deux fois.

```bash
md5sum ~/Downloads/mtcaodv_step03_r*.zip
```

Comparez au md5 annoncé dans le message de livraison. **Puis seulement** :

```bash
cd /home/hassen/res/ns-3.48 && unzip -o ~/Downloads/mtcaodv_step03_rN.zip -d . && find contrib/mtcaodv experiments -type f -exec touch {} +
```

Le `touch` n'est pas décoratif : `unzip` restaure les horodatages de l'archive,
une source peut se retrouver plus ancienne que son objet déjà compilé, et ninja
ne la recompile alors jamais.

---

## 1. Tout, en une commande

```bash
cd /home/hassen/res/ns-3.48 && bash run_all.sh
```

Enchaîne : construction → garde de cohérence → 11 suites ns-3 → tests Python →
vérification que `src/aodv` est intact → les deux bras d'exécution → comparaison
automatique des PDR → validation → analyse.

**Fail closed** : arrêt à la première anomalie, aucune simulation lancée sur un
arbre incohérent. Un chiffre produit par un build qui ne correspond pas aux
sources n'appartient à aucune version du code — c'est pire qu'une erreur
franche, car cela ressemble à une donnée.

---

## 2. Les mêmes étapes, séparément

### Construction

```bash
cd /home/hassen/res/ns-3.48 && ./ns3 configure --enable-examples --enable-tests && ./ns3 build
```

`configure` est **obligatoire**, jamais optionnel : tout changement de
`CMakeLists.txt` fait ré-exécuter CMake au premier `build`, et cette
ré-exécution remet les options aux défauts — `Examples: OFF`, `Tests: OFF`.

### Garde de cohérence du build

```bash
cd /home/hassen/res/ns-3.48 && bash experiments/check_step03_build.sh
```

Interroge les **artefacts**, pas les sources. Bloque sur les pannes silencieuses
(arbre source périmé, objet périmé, source non compilée) ; avertit seulement sur
celles qu'une commande ultérieure signalerait franchement.

### Suites ns-3 — les onze noms exacts

```bash
cd /home/hassen/res/ns-3.48 && for s in \
  routing-aodv routing-aodv-loopback routing-aodv-regression aodv-routing-id-cache \
  mtcaodv-routing-protocol mtcaodv-attack-manager mtcaodv-blackhole-behavior \
  mtcaodv-step00-baseline-metrics mtcaodv-rrep-anomaly-detector \
  mtcaodv-packet-fingerprint mtcaodv-forwarding-observer ; do ./test.py -s $s; done
```

Les quatre premières sont **AODV amont**. Deux pièges de nommage : la suite
amont s'appelle `routing-aodv`, **pas** `aodv` ; et `mtcaodv-rrep-screening`
**n'existe pas** — les tests de dépistage STEP 2 sont dans
`mtcaodv-rrep-anomaly-detector`.

### Tests Python

```bash
cd /home/hassen/res/ns-3.48/experiments && python3 -m unittest test_validate_step03 test_analyze_forwarding test_analyze_features -q
```

Attendu : `Ran 57 tests ... OK`.

### Contrainte « préserver AODV »

```bash
cd /home/hassen/res/ns-3.48 && find src/aodv -type f -newer src/olsr/CMakeLists.txt
```

**Sortie vide = contrainte respectée.** `olsr` sert de témoin non touché. Le
passage des suites amont prouve que le module se comporte bien ; il ne prouve
pas que ses sources sont intactes. Deux affirmations différentes, et seule la
seconde est la contrainte.

### Exécution — bras ON

```bash
cd /home/hassen/res/ns-3.48 && ./ns3 run "mtcaodv-pilot-attack --nodes=30 --areaSize=600 --maxRange=200 --minSpeed=1 --maxSpeed=5 --simTime=300 --flowCount=5 --dataRate=51.2kbps --attackerRatio=0.20 --attackStart=10 --seed=1 --run=1 --observationsCsv=obs-atk.csv"
```

### Exécution — bras OFF (preuve de non-intrusion)

```bash
cd /home/hassen/res/ns-3.48 && ./ns3 run "mtcaodv-pilot-attack --nodes=30 --areaSize=600 --maxRange=200 --minSpeed=1 --maxSpeed=5 --simTime=300 --flowCount=5 --dataRate=51.2kbps --attackerRatio=0.20 --attackStart=10 --seed=1 --run=1 --enableObservation=false" 2>&1 | grep -E "^pdr|^windowsOpened|^transmissionsInspected"
```

Le `pdr` doit être **identique au dernier chiffre** à celui du bras ON. Le
pilote n'installe aucun observateur dans ce bras : l'égalité prouve donc que
l'appareil complet — mise en promiscuité de chaque MAC comprise — est sans effet
sur la livraison. Un gain serait un **bug**, pas un succès.

### Validation

```bash
cd /home/hassen/res/ns-3.48 && cp mtcaodv-step01-manifest.json man-atk.json && cp mtcaodv-step01-results.csv res-atk.csv && python3 experiments/validate_step03.py --csv res-atk.csv --manifest man-atk.json
```

### La mesure qui porte l'étape

```bash
cd /home/hassen/res/ns-3.48 && python3 experiments/analyze_forwarding.py --observations obs-atk.csv --manifest man-atk.json --after-attack-start
```

**Aucun seuil n'est préenregistré** pour la baseline de non-observation honnête.
Elle est rapportée, jamais comparée à une valeur attendue. Une baseline absente
reste indéfinie (`NaN`), jamais 0.

### Mesure préalable STEP 4 — le plafond d'attribution

```bash
cd /home/hassen/res/ns-3.48 && python3 experiments/analyze_features.py --observations obs-atk.csv --manifest man-atk.json
```

Mesure, sur les données **déjà produites**, ce qu'OCEA pourra attribuer au
maximum avec l'instrumentation actuelle. L'Éq. (7) étant une moyenne
géométrique, une visibilité nulle donne \(O_e = 0\) donc \(I_e = 0\) — quels
que soient les diagnostics ajoutés ensuite. Le nombre de non-observations
d'attaquant **avec** visibilité non nulle est donc une **borne dure**, pas une
estimation.

Si ce plafond est faible, instrumenter les \(y_\ell\) sans corriger d'abord la
caractéristique d'opportunité serait sans effet. Cette mesure décide l'ordre des
travaux de STEP 4.

Aucun seuil n'est préenregistré pour l'écart entre
\(P(\text{visible} \mid z_e{=}1)\) et \(P(\text{visible} \mid z_e{=}0)\) :
un voisin physiquement joignable a plus de chances des deux côtés, donc un écart
est **attendu** et ne prouve pas une circularité. Le script rapporte, il ne juge
pas.

---

## 3. Diagnostic si quelque chose casse

| symptôme | cause | correction |
|---|---|---|
| `unknown test suite name` | `Tests: OFF`, ou nom de suite faux | `./ns3 configure --enable-examples --enable-tests` ; vérifier les noms au § 2 |
| `Couldn't find the specified program` | `Examples: OFF` | idem |
| `undefined reference` que les sources contredisent | objet périmé | `find build -name '*.cc.o' -newer <source> -delete` puis `touch` + `./ns3 build` |
| erreurs de compilation sur du code déjà corrigé | **archive périmée extraite** | `md5sum ~/Downloads/mtcaodv_step03_r*.zip`, extraire celle dont l'empreinte correspond |
| `ninja: no work to do` après extraction | horodatages restaurés | `find contrib/mtcaodv experiments -type f -exec touch {} +` |

Dans tous les cas, `bash experiments/check_step03_build.sh` nomme la panne et sa
correction avant que vous ne lanciez quoi que ce soit.
