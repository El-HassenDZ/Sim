#!/usr/bin/env python3
# MTCAODV_DELIVERY_REVISION: r23
"""Tests de ocea_reference.py — l'implementation de reference d'A3.3.

Bibliotheque standard uniquement.  Ces tests portent sur le MODELE, pas sur son
encodage C++ : ils verifient que la reference elle-meme respecte les proprietes
que la specification prescrit (T-13, fail-closed, veto), afin qu'elle puisse
servir d'oracle de confiance.
"""

import itertools
import math
import unittest

from ocea_reference import (
    CONSERVATION_TOLERANCE,
    ORACLES,
    Attribution,
    Feature,
    attribute,
    masses_are_conserved,
    validate_values,
    validate_weights,
)


def _pair(w0, v0, a0, w1, v1, a1):
    return [Feature(w0, v0, a0), Feature(w1, v1, a1)]


class ConservationTestCase(unittest.TestCase):
    """T-13, le test prescrit par la specification."""

    def test_grid_conserves_mass(self):
        """Sur une grille exhaustive, les masses sont dans [0,1] et somment a 1.

        La grille croise valeurs, disponibilites et z_e.  Elle inclut 0.0 et 1.0
        aux bornes : ce sont precisement les valeurs ou une implementation
        naive casse (log(0), pow(0,0), 1 - I < 0).
        """
        values = (0.0, 0.25, 0.5, 1.0)
        flags = (False, True)
        checked = 0
        for z, x0, x1, a0, a1, y0, y1, b0, b1 in itertools.product(
            flags, values, values, flags, flags, values, values, flags, flags
        ):
            opportunity = _pair(0.5, x0, a0, 0.5, x1, a1)
            diagnostic = _pair(0.5, y0, b0, 0.5, y1, b1)
            result = attribute(z, opportunity, diagnostic)
            for name, value in zip(
                ("g", "m", "b", "u"), result.masses
            ):
                self.assertGreaterEqual(
                    value, -CONSERVATION_TOLERANCE, f"{name} negatif"
                )
                self.assertLessEqual(
                    value, 1.0 + CONSERVATION_TOLERANCE, f"{name} > 1"
                )
            self.assertAlmostEqual(math.fsum(result.masses), 1.0, delta=CONSERVATION_TOLERANCE)
            checked += 1
        # Une grille qui ne parcourrait qu'un point passerait aussi : on fige sa taille.
        self.assertEqual(checked, 2 * 4 * 4 * 2 * 2 * 4 * 4 * 2 * 2)

    def test_asymmetric_weights_conserve_mass(self):
        """Meme propriete avec des poids non uniformes."""
        for w in (0.0, 0.1, 0.5, 0.9, 1.0):
            opportunity = _pair(w, 0.3, True, 1.0 - w, 0.8, True)
            diagnostic = _pair(w, 0.2, True, 1.0 - w, 0.6, True)
            result = attribute(False, opportunity, diagnostic)
            self.assertAlmostEqual(math.fsum(result.masses), 1.0, delta=CONSERVATION_TOLERANCE)


class ConservationPredicateTestCase(unittest.TestCase):
    """Le pendant des lignes 13-14 d'A3.3, expose comme predicat."""

    def test_accepts_a_real_attribution(self):
        result = attribute(
            False,
            _pair(0.5, 0.81, True, 0.5, 0.49, True),
            _pair(0.5, 0.25, True, 0.5, 0.75, True),
        )
        self.assertTrue(masses_are_conserved(result))

    def test_rejects_a_broken_attribution(self):
        """Un predicat qui ne peut pas echouer ne verifie rien : on le fait echouer."""
        good = attribute(
            False,
            _pair(0.5, 0.81, True, 0.5, 0.49, True),
            _pair(0.5, 0.25, True, 0.5, 0.75, True),
        )
        for field, value in (
            ("uncertain", good.uncertain + 0.5),  # somme != 1
            ("malicious", -0.25),                 # masse negative
            ("benign_loss", 1.5),                 # masse > 1
            ("uncertain", float("nan")),          # non finie
        ):
            with self.subTest(field=field, value=value):
                broken = Attribution(**{**good.__dict__, field: value})
                self.assertFalse(masses_are_conserved(broken))


class ComputedFlagTestCase(unittest.TestCase):
    """Distinguer « intermediaire nul mesure » de « intermediaire non calcule »."""

    def test_short_circuit_and_refusal_are_not_computed(self):
        observed = attribute(
            True,
            _pair(0.5, 1.0, True, 0.5, 1.0, True),
            _pair(0.5, 1.0, True, 0.5, 1.0, True),
        )
        self.assertFalse(observed.computed)
        refused = attribute(
            False,
            _pair(0.5, 2.0, True, 0.5, 1.0, True),
            _pair(0.5, 1.0, True, 0.5, 1.0, True),
        )
        self.assertFalse(refused.computed)

    def test_fail_closed_branches_are_computed(self):
        """c_e = 0 et d_e = 0 sont des MESURES : la couverture a bien ete evaluee."""
        no_coverage = attribute(
            False,
            _pair(0.5, 1.0, False, 0.5, 1.0, False),
            _pair(0.5, 1.0, True, 0.5, 1.0, True),
        )
        self.assertTrue(no_coverage.computed)
        no_diagnostic = attribute(
            False,
            _pair(0.5, 1.0, True, 0.5, 1.0, True),
            _pair(0.5, 1.0, False, 0.5, 1.0, False),
        )
        self.assertTrue(no_diagnostic.computed)


class OracleTestCase(unittest.TestCase):
    """Les huit oracles transcrits dans le test C++."""

    def test_oracles_are_self_consistent(self):
        for name, z, opp, diag, _note in ORACLES:
            with self.subTest(name):
                result = attribute(z, opp, diag)
                self.assertAlmostEqual(
                    math.fsum(result.masses), 1.0, delta=CONSERVATION_TOLERANCE
                )

    def test_nominal_values(self):
        """O = sqrt(0,81 x 0,49) = 0,63, calcule a la main."""
        result = attribute(
            False,
            _pair(0.5, 0.81, True, 0.5, 0.49, True),
            _pair(0.5, 0.25, True, 0.5, 0.75, True),
        )
        self.assertAlmostEqual(result.opportunity_coverage, 1.0, delta=1e-15)
        self.assertAlmostEqual(result.forwarding_opportunity, 0.63, delta=1e-12)
        self.assertAlmostEqual(result.benign_likelihood, 0.5, delta=1e-15)
        self.assertAlmostEqual(result.interpretable, 0.63, delta=1e-12)
        self.assertAlmostEqual(result.malicious, 0.315, delta=1e-12)
        self.assertAlmostEqual(result.benign_loss, 0.315, delta=1e-12)
        self.assertAlmostEqual(result.uncertain, 0.37, delta=1e-12)


class FailClosedTestCase(unittest.TestCase):
    def test_no_opportunity_feature_gives_full_uncertainty(self):
        """A3.3 ligne 4."""
        result = attribute(
            False,
            _pair(0.5, 0.9, False, 0.5, 0.9, False),
            _pair(0.5, 0.5, True, 0.5, 0.5, True),
        )
        self.assertEqual(result.masses, (0.0, 0.0, 0.0, 1.0))

    def test_no_diagnostic_gives_full_uncertainty(self):
        """A3.3 ligne 7 — la branche empruntee aujourd'hui par TOUS les evenements."""
        result = attribute(
            False,
            _pair(0.5, 1.0, True, 0.5, 1.0, True),
            _pair(0.5, 0.5, False, 0.5, 0.5, False),
        )
        self.assertEqual(result.masses, (0.0, 0.0, 0.0, 1.0))
        # L'opportunite reste calculee et rapportee : c'est une mesure, pas un
        # zero structurel.  Sans elle on ne saurait pas que seul d_e manque.
        self.assertAlmostEqual(result.forwarding_opportunity, 1.0, delta=1e-15)

    def test_invalid_value_is_refused_not_clipped(self):
        result = attribute(
            False,
            _pair(0.5, 1.5, True, 0.5, 0.5, True),
            _pair(0.5, 0.5, True, 0.5, 0.5, True),
        )
        self.assertFalse(result.inputs_valid)
        self.assertEqual(result.masses, (0.0, 0.0, 0.0, 1.0))

    def test_nan_value_is_refused(self):
        result = attribute(
            False,
            _pair(0.5, float("nan"), True, 0.5, 0.5, True),
            _pair(0.5, 0.5, True, 0.5, 0.5, True),
        )
        self.assertFalse(result.inputs_valid)

    def test_unavailable_value_is_not_examined(self):
        """Une valeur indisponible n'a pas de sens ; on ne lui impose rien."""
        result = attribute(
            False,
            _pair(0.5, 42.0, False, 0.5, 0.5, True),
            _pair(0.5, 0.5, True, 0.5, 0.5, True),
        )
        self.assertTrue(result.inputs_valid)

    def test_weights_must_partition_unity(self):
        self.assertFalse(validate_weights([Feature(0.5), Feature(0.6)]))
        self.assertFalse(validate_weights([Feature(0.5), Feature(0.4)]))
        self.assertFalse(validate_weights([Feature(-0.5), Feature(1.5)]))
        self.assertFalse(validate_weights([]))
        self.assertTrue(validate_weights([Feature(0.5), Feature(0.5)]))

    def test_unnormalised_weights_are_refused(self):
        result = attribute(
            False,
            _pair(0.9, 1.0, True, 0.9, 1.0, True),
            _pair(0.5, 0.0, True, 0.5, 0.0, True),
        )
        self.assertFalse(result.inputs_valid)
        self.assertEqual(result.masses, (0.0, 0.0, 0.0, 1.0))


class VetoTestCase(unittest.TestCase):
    """Le point le plus glissant de l'Eq. (7)."""

    def test_available_zero_vetoes_whatever_its_weight(self):
        """0^(w/c) = 0 pour tout w > 0 : un poids minuscule annule tout."""
        result = attribute(
            False,
            _pair(1e-6, 0.0, True, 1.0 - 1e-6, 1.0, True),
            _pair(0.5, 0.0, True, 0.5, 0.0, True),
        )
        self.assertTrue(result.vetoed)
        self.assertEqual(result.forwarding_opportunity, 0.0)
        self.assertEqual(result.masses, (0.0, 0.0, 0.0, 1.0))

    def test_unavailable_zero_does_not_veto(self):
        """`available=False` et `value=0` ne sont PAS interchangeables."""
        result = attribute(
            False,
            _pair(0.5, 0.0, False, 0.5, 1.0, True),
            _pair(0.5, 0.0, True, 0.5, 0.0, True),
        )
        self.assertFalse(result.vetoed)
        self.assertAlmostEqual(result.opportunity_coverage, 0.5, delta=1e-15)
        self.assertAlmostEqual(result.forwarding_opportunity, 0.5, delta=1e-15)

    def test_zero_weight_feature_is_excluded_not_vetoing(self):
        """Regle d'implementation (statut Propose) : w_k = 0 -> hors produit."""
        result = attribute(
            False,
            _pair(0.0, 0.0, True, 1.0, 0.8, True),
            _pair(0.5, 0.0, True, 0.5, 0.0, True),
        )
        self.assertFalse(result.vetoed)
        self.assertAlmostEqual(result.opportunity_coverage, 1.0, delta=1e-15)
        self.assertAlmostEqual(result.forwarding_opportunity, 0.8, delta=1e-12)

    def test_veto_needs_exact_zero(self):
        """Une valeur tres petite mais non nulle ne vetoe pas : elle attenue."""
        result = attribute(
            False,
            _pair(0.5, 1e-12, True, 0.5, 1.0, True),
            _pair(0.5, 0.0, True, 0.5, 0.0, True),
        )
        self.assertFalse(result.vetoed)
        self.assertGreater(result.forwarding_opportunity, 0.0)
        self.assertAlmostEqual(result.forwarding_opportunity, 1e-6, delta=1e-15)


class PositiveEvidenceTestCase(unittest.TestCase):
    def test_observed_forwarding_short_circuits(self):
        """Eq. (9) : z_e = 1 sort AVANT toute couverture, meme couverture nulle."""
        result = attribute(
            True,
            _pair(0.5, 0.0, False, 0.5, 0.0, False),
            _pair(0.5, 0.0, False, 0.5, 0.0, False),
        )
        self.assertEqual(result.masses, (1.0, 0.0, 0.0, 0.0))

    def test_observed_forwarding_reports_no_intermediates(self):
        """Les intermediaires ne sont pas calcules : ils valent 0 par CONVENTION.

        Ce zero-la est une non-application, pas une mesure.  Le distinguer
        importe : un exportateur qui l'agregerait avec les c_e reellement
        calcules ferait chuter la moyenne de couverture sans qu'aucune
        couverture n'ait baisse.
        """
        result = attribute(
            True,
            _pair(0.5, 1.0, True, 0.5, 1.0, True),
            _pair(0.5, 1.0, True, 0.5, 1.0, True),
        )
        self.assertEqual(result.opportunity_coverage, 0.0)
        self.assertEqual(result.diagnostic_coverage, 0.0)


class MonotonicityTestCase(unittest.TestCase):
    """Proprietes de sens, au-dela de l'arithmetique."""

    def test_malicious_mass_grows_when_benign_causes_recede(self):
        previous = -1.0
        for y in (1.0, 0.75, 0.5, 0.25, 0.0):
            result = attribute(
                False,
                _pair(0.5, 1.0, True, 0.5, 1.0, True),
                _pair(0.5, y, True, 0.5, y, True),
            )
            self.assertGreater(result.malicious, previous)
            previous = result.malicious

    def test_uncertainty_grows_when_opportunity_falls(self):
        previous = -1.0
        for x in (1.0, 0.75, 0.5, 0.25, 0.0):
            result = attribute(
                False,
                _pair(0.5, x, True, 0.5, x, True),
                _pair(0.5, 0.5, True, 0.5, 0.5, True),
            )
            self.assertGreater(result.uncertain, previous)
            previous = result.uncertain


if __name__ == "__main__":
    unittest.main()
