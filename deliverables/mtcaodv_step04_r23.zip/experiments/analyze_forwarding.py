#!/usr/bin/env python3
# MTCAODV_DELIVERY_REVISION: r23
"""STEP 3 : mesurer la BASELINE DE NON-OBSERVATION D'UN VOISIN HONNETE.

Pourquoi cet outil est le livrable scientifique de l'etape
----------------------------------------------------------
STEP 3 n'ameliore aucune metrique reseau et ne le doit pas : rien n'y exclut de
route. Sa valeur tient a une seule mesure, impossible a obtenir autrement :

    a quel taux un voisin HONNETE apparait-il comme n'ayant pas retransmis ?

Ce taux est la reference bénigne. Il determine :

  * si les poids nu_l de l'Eq. (8) peuvent etre calibres sur des donnees plutot
    que poses arbitrairement -- l'erreur exacte commise a STEP 2 avec
    epsilon = 1e-6, qui avait sature le score sur des noeuds honnetes ;
  * si l'ecart d'observation entre voisins honnetes et attaquants existe AVANT
    toute ponderation, comme l'AUC l'avait tranche pour le criblage RREP.

Si un voisin honnete est non observe aussi souvent qu'un blackhole, aucune
ponderation ne sauvera l'attribution, et il faut le dire.

L'etiquetage attaquant/honnete est applique ICI, hors ligne, depuis le manifeste.
Le simulateur n'a jamais etiquete quoi que ce soit.

Bibliotheque standard uniquement.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path
from typing import Sequence


class ForwardingAnalysisError(ValueError):
    """Entrees inutilisables : on refuse de conclure plutot que d'inventer."""


def load_observations(path: Path) -> list[dict]:
    """Lit le CSV des observations closes produit par --observationsCsv."""
    try:
        with path.open("r", encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
    except OSError as error:
        raise ForwardingAnalysisError(f"lecture impossible de {path}: {error}") from error
    if not rows:
        raise ForwardingAnalysisError(
            f"{path} ne contient aucune observation : soit l'observation etait "
            "desactivee, soit AUCUN paquet n'a ete relaye. Ces deux cas sont "
            "differents et le manifeste permet de les distinguer."
        )
    parsed = []
    for row in rows:
        try:
            parsed.append({
                "open": float(row["openTime_s"]),
                "close": float(row["closeTime_s"]),
                "observer": int(row["observerNodeId"]),
                "neighbor": int(row["neighborNodeId"]),
                "observed": int(row["forwardingObserved"]) == 1,
                "reason": row["closureReason"],
                "attributed": int(row["senderAttributed"]) == 1,
                # DIAGNOSTIC : l'emetteur apparie etait-il l'observateur ?
                # Colonne absente d'un CSV anterieur a r20 : on ne suppose rien.
                "senderIsSelf": int(row.get("senderIsSelf", 0) or 0) == 1,
                "hasSelfColumn": "senderIsSelf" in row,
                # DIAGNOSTIC : fenetre ouverte par un RELAIS (UnicastForward)
                # plutot que par une emission LOCALE (SendOutgoing).
                "openedByRelay": int(row.get("openedByRelay", 0) or 0) == 1,
                "hasRelayColumn": "openedByRelay" in row,
                "visibility": float(row["passiveVisibility"]),
            })
        except (KeyError, ValueError) as error:
            raise ForwardingAnalysisError(f"ligne malformee: {error}") from error
    return parsed


def load_manifest(path: Path) -> tuple[set[int], int, float]:
    """Retourne (attaquants, nombre de noeuds, instant de debut d'attaque)."""
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ForwardingAnalysisError(f"manifeste illisible {path}: {error}") from error
    attackers = manifest.get("attack", {}).get("attackerNodeIds", [])
    configuration = manifest.get("configuration", {})
    if not isinstance(attackers, list):
        raise ForwardingAnalysisError("attackerNodeIds doit etre une liste")
    observation = manifest.get("observation")
    if isinstance(observation, dict):
        dropped = int(observation.get("observationRowsDropped", 0))
        if dropped > 0:
            raise ForwardingAnalysisError(
                f"{dropped} observations ont ete abandonnees a la borne : le flux "
                "est tronque et l'analyse porterait sur un echantillon biaise"
            )
    return (set(int(a) for a in attackers),
            int(configuration.get("nodes", 0)),
            float(configuration.get("attackStart", 0.0)))


def summarise(rows: Sequence[dict], label: str) -> dict:
    """Agrege un ensemble d'observations en taux interpretables."""
    total = len(rows)
    if total == 0:
        return {"label": label, "total": 0, "observed": 0, "rate": float("nan"),
                "attributed": 0, "attributionRate": float("nan"),
                "latencyMedian": float("nan"), "reasons": {}}
    observed = sum(1 for r in rows if r["observed"])
    attributed = sum(1 for r in rows if r["attributed"])
    reasons: dict[str, int] = defaultdict(int)
    for r in rows:
        reasons[r["reason"]] += 1
    # Latence d'appariement : elle CALIBRE la fenetre d'observation. Une fenetre
    # plus courte que cette distribution transformerait des transferts honnetes
    # en non-observations -- le mode de defaillance le plus insidieux de l'etape.
    latencies = sorted(r["close"] - r["open"] for r in rows if r["observed"])
    median = (latencies[len(latencies) // 2] if latencies else float("nan"))
    return {
        "label": label,
        "total": total,
        "observed": observed,
        "rate": observed / total,
        "attributed": attributed,
        "attributionRate": attributed / observed if observed else float("nan"),
        "latencyMedian": median,
        "latencyMax": latencies[-1] if latencies else float("nan"),
        "latencyMin": latencies[0] if latencies else float("nan"),
        "matchedFromSelf": sum(1 for r in rows if r["senderIsSelf"]),
        # LATENCE STRICTEMENT NULLE. Physiquement impossible pour une
        # retransmission radio : il faut une duree de trame et un SIFS, soit
        # des dizaines de microsecondes. Comparaison EXACTE, sans seuil : un
        # plancher arbitraire deciderait par avance de ce que la mesure montre.
        "zeroLatency": sum(1 for r in rows if r["observed"] and r["close"] == r["open"]),
        "zeroLatencyByRelay": sum(
            1 for r in rows
            if r["observed"] and r["close"] == r["open"] and r["openedByRelay"]),
        "zeroLatencyAttributed": sum(
            1 for r in rows
            if r["observed"] and r["close"] == r["open"] and r["attributed"]),
        "matchedByRelay": sum(1 for r in rows if r["observed"] and r["openedByRelay"]),
        "hasRelayColumn": any(r["hasRelayColumn"] for r in rows),
        "hasSelfColumn": any(r["hasSelfColumn"] for r in rows),
        "reasons": dict(reasons),
    }


def print_summary(summary: dict) -> None:
    """Affiche un agregat ; NaN reste NaN, jamais remplace par 0."""
    print(f"  {summary['label']:<22} n={summary['total']:<7} "
          f"observes={summary['observed']:<7} "
          f"taux={summary['rate']:.4f}" if summary["total"] else
          f"  {summary['label']:<22} n=0  (aucune observation)")
    if summary["total"]:
        print(f"    non-observation           = {1 - summary['rate']:.4f}")
        print(f"    emetteur attribue au voisin = {summary['attributionRate']:.4f} "
              f"({summary['attributed']}/{summary['observed']})")
        # EN MICROSECONDES. En millisecondes, les 1 272 appariements
        # d'attaquant du run r19 s'affichaient tous « 0.00 ms » -- un chiffre
        # arrondi qui cachait precisement ce qu'il fallait voir : aucune
        # retransmission radio ne s'entend en moins de 5 us. Une unite trop
        # grossiere ne fait pas qu'imprecise : elle efface le signal.
        print(f"    latence d'appariement       : min {summary['latencyMin']*1e6:.1f} us, "
              f"mediane {summary['latencyMedian']*1e6:.1f} us, "
              f"max {summary['latencyMax']*1e6:.1f} us")
        if not summary["hasSelfColumn"]:
            print( "    emetteur = observateur ?     : COLONNE ABSENTE (CSV < r20)")
        elif summary["matchedFromSelf"]:
            print(f"    /!\\ EMETTEUR = OBSERVATEUR   : {summary['matchedFromSelf']} "
                  f"appariements sur SA PROPRE emission")
            print( "        z_e est FABRIQUE sur ces evenements : l'Eq. (9) leur")
            print( "        accorde (1,0,0,0), preuve positive pleine, alors que")
            print( "        le voisin n'a rien relaye. DEFAUT, pas une mesure.")
        else:
            print( "    emetteur = observateur ?     : 0 (aucun auto-appariement)")
        # LE croisement qui departage les deux hypotheses sur l'anomalie.
        if not summary["hasRelayColumn"]:
            print( "    appariements a dt = 0        : COLONNE ABSENTE (CSV < r21)")
        elif summary["zeroLatency"]:
            print(f"    /!\\ APPARIEMENTS A dt = 0    : {summary['zeroLatency']} "
                  f"sur {summary['observed']}")
            print(f"        dont ouverts par RELAIS  : {summary['zeroLatencyByRelay']}")
            print(f"        dont ATTRIBUES a j       : {summary['zeroLatencyAttributed']}")
            print( "        Aucune retransmission radio ne s'entend a dt = 0 :")
            print( "        il faut une duree de trame et un SIFS. Ces z_e = 1")
            print( "        ne sont PAS des preuves de relais.")
            if summary["zeroLatency"] == summary["zeroLatencyByRelay"]:
                print( "        TOUS viennent d'un RELAIS : la fenetre est fermee")
                print( "        par la trame ENTRANTE du paquet lui-meme.")
        else:
            print( "    appariements a dt = 0        : 0")
        print(f"    raisons de cloture          : {summary['reasons']}")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--observations", required=True, type=Path,
                        help="CSV produit par --observationsCsv")
    parser.add_argument("--manifest", required=True, type=Path, help="manifeste du run")
    parser.add_argument("--after-attack-start", action="store_true",
                        help="ne garder que les observations closes apres attackStart")
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)

    try:
        rows = load_observations(arguments.observations)
        attackers, nodes, attack_start = load_manifest(arguments.manifest)
    except ForwardingAnalysisError as error:
        print(f"ANALYSE FAIL: {error}", file=sys.stderr)
        return 1

    if arguments.after_attack_start:
        rows = [r for r in rows if r["close"] >= attack_start]
        if not rows:
            print("ANALYSE FAIL: aucune observation apres attackStart", file=sys.stderr)
            return 1

    honest = [r for r in rows if r["neighbor"] >= 0 and r["neighbor"] not in attackers]
    malicious = [r for r in rows if r["neighbor"] in attackers]
    unknown = [r for r in rows if r["neighbor"] < 0]

    print("=== STEP 3 : observation du transfert au prochain saut (A3.2) ===")
    print(f"  noeuds={nodes}  attaquants={sorted(attackers)}  observations={len(rows)}")
    if unknown:
        print(f"  {len(unknown)} observations sur un voisin hors scenario, exclues")
    print()

    honest_summary = summarise(honest, "voisin HONNETE")
    malicious_summary = summarise(malicious, "voisin ATTAQUANT")
    print_summary(honest_summary)
    print()
    print_summary(malicious_summary)

    print("\n=== La mesure qui compte ===")
    if honest_summary["total"] == 0:
        print("  Aucune observation sur voisin honnete : la baseline benigne est")
        print("  INDEFINIE. Sans elle, les poids nu_l de l'Eq. (8) ne peuvent pas")
        print("  etre calibres sur des donnees. Ce n'est pas un detail a contourner.")
        return 2

    benign_non_observation = 1 - honest_summary["rate"]
    print(f"  Baseline de non-observation BENIGNE = {benign_non_observation:.4f}")
    print("  C'est le taux auquel un voisin honnete parait ne pas avoir retransmis,")
    print("  pour cause de collision, terminal cache, mobilite, file pleine ou")
    print("  fenetre trop courte. C'est ce que l'Eq. (8) doit expliquer.")

    if malicious_summary["total"] == 0:
        print("\n  Run SANS attaquant observe : pas de comparaison possible.")
        print("  La baseline ci-dessus reste la sortie utile de ce run.")
        return 0

    malicious_non_observation = 1 - malicious_summary["rate"]
    print(f"  Non-observation chez un ATTAQUANT   = {malicious_non_observation:.4f}")
    separation = malicious_non_observation - benign_non_observation
    print(f"  Ecart                                = {separation:+.4f}")

    print("\n=== Verdict (regle preenregistree) ===")
    if separation <= 0.0:
        print("  Un attaquant n'est PAS moins observe qu'un noeud honnete.")
        print("  L'observation ne porte aucune information exploitable dans ce")
        print("  scenario ; aucune ponderation OCEA ne le corrigera. A rapporter tel")
        print("  quel, et a diagnostiquer avant STEP 4.")
        return 0
    print(f"  L'attaquant est moins observe de {separation:.4f}. L'observation porte")
    print("  du signal AVANT toute ponderation. L'attribution OCEA (STEP 4) est")
    print("  justifiee, et sa calibration doit se faire sur des seeds DISTINCTS.")
    print()
    print("  RESERVE : cet ecart est une condition NECESSAIRE, pas suffisante. Un")
    print("  attaquant qui relaierait le controle tout en jetant les donnees")
    print("  produirait le meme ecart pour une autre raison. STEP 4 devra le")
    print("  distinguer, pas le supposer.")

    print("\n=== Calibration de la fenetre d'observation ===")
    if math.isfinite(honest_summary["latencyMax"]):
        print(f"  Latence d'appariement chez un voisin honnete : mediane "
              f"{honest_summary['latencyMedian']*1e6:.1f} us, max "
              f"{honest_summary['latencyMax']*1e6:.1f} us.")
        print("  La fenetre doit couvrir largement ce maximum, sinon des transferts")
        print("  honnetes seront comptes comme des non-observations. C'est cette")
        print("  distribution qui fixe --observationWindow, jamais l'intuition.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
