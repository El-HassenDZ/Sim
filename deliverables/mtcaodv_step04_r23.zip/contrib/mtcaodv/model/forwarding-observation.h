/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef MTCAODV_FORWARDING_OBSERVATION_H
#define MTCAODV_FORWARDING_OBSERVATION_H

#include "ns3/ipv4-address.h"

#include <cstdint>

namespace ns3
{
namespace mtcaodv
{

/**
 * @ingroup mtcaodv
 * @brief Pourquoi une fenêtre d'observation s'est refermée.
 *
 * La distinction est SCIENTIFIQUE, pas décorative. `DEADLINE` produit
 * `z_e = 0`, et c'est à l'Éq. (8) — via les diagnostics `y_l` — d'établir si
 * une cause bénigne l'explique. `EVICTED` n'est pas une observation du tout et
 * ne doit jamais alimenter une masse.
 */
enum class ForwardingClosureReason : uint8_t
{
    /** @brief Retransmission positivement appariée : `z_e = 1` (Éq. 9). */
    MATCHED = 0,

    /** @brief Échéance atteinte sans appariement : `z_e = 0` (Éq. 10). */
    DEADLINE = 1,

    /**
     * @brief Évincée par la borne de fenêtres actives : NON INTERPRETABLE.
     *
     * @note Une quatrième raison NEIGHBOR_LOST a existé ici, et a été RETIRÉE.
     *       Aucun appelant ne l'émettait : les trois sites d'appel de
     *       CloseWindow() passent MATCHED, DEADLINE ou EVICTED. Son compteur
     *       valait donc structurellement zéro, ce qui se lisait comme « la
     *       mobilité n'a rompu aucun lien » alors que c'était une absence de
     *       code.
     *
     *       Elle ne correspondait à rien dans la spécification. A3.2 ligne 10
     *       dit « if j disappeared before a meaningful opportunity existed then
     *       LOWER COVERAGE » : agir sur les drapeaux de disponibilité a_k de
     *       l'Éq. (6), et NON classer une clôture. Cette exigence reste
     *       OUVERTE — la retirer d'ici ne l'a pas satisfaite.
     *
     *       Elle serait de toute façon inatteignable à cette échelle de temps :
     *       la table de voisinage AODV conserve un voisin pendant
     *       AllowedHelloLoss x HelloInterval = 2 s, treize fois la fenêtre
     *       d'observation de 150 ms. Une clôture pour disparition surviendrait
     *       donc environ 2 s après la cause qu'elle prétend expliquer.
     */
    EVICTED = 2
};

/**
 * @brief Libellé court d'une raison de clôture, pour traces et CSV.
 * @param reason Raison à nommer.
 * @return Chaîne stable, utilisable comme valeur de colonne.
 */
const char* ForwardingClosureReasonName(ForwardingClosureReason reason);

/**
 * @ingroup mtcaodv
 * @brief Une fenêtre d'observation close — la sortie de l'Algorithme A3.2.
 *
 * CE QUE CETTE STRUCTURE CONTIENT, ET CE QU'ELLE NE CONTIENT PAS
 * --------------------------------------------------------------
 * Elle contient un FAIT observé localement (`forwardingObserved`) et les
 * CARACTERISTIQUES disponibles au moment de l'observation, chacune accompagnée
 * de son drapeau de disponibilité.
 *
 * Elle ne contient AUCUNE masse OCEA, AUCUN jugement, AUCUNE étiquette
 * « malveillant ». L'Algorithme A3.2 se termine explicitement par « do not label
 * it malicious here » : l'attribution est le rôle d'A3.3, à STEP 4. Cette
 * séparation n'est pas cosmétique — elle garantit que l'observation reste
 * valable même si les poids d'attribution changent.
 *
 * POURQUOI CHAQUE CARACTERISTIQUE PORTE UN DRAPEAU
 * ------------------------------------------------
 * Les Éq. (6) et (8) somment les poids des caractéristiques DISPONIBLES et
 * déclarent l'événement non interprétable quand la couverture est nulle. Une
 * valeur par défaut substituée à une donnée absente ferait passer une
 * observation partielle pour complète — exactement l'erreur commise à STEP 2
 * avec `epsilon = 1e-6`, qui avait saturé le score sur des nœuds honnêtes.
 * Ici, absent signifie absent.
 */
struct ForwardingObservation
{
    // ---- Identité de l'événement ----
    /** @brief Nœud qui observe (l'observateur `i`). */
    uint32_t observerNodeId{0};

    /** @brief Voisin observé (le prochain saut `j`) — adresse IPv4. */
    Ipv4Address watchedNeighbor;

    /** @brief Empreinte du paquet suivi. */
    uint64_t fingerprint{0};

    /** @brief Instant d'ouverture de la fenêtre. Unité : s. */
    double openTimeSeconds{0.0};

    /** @brief Instant de clôture. Unité : s. */
    double closeTimeSeconds{0.0};

    // ---- Le fait observé ----
    /** @brief `z_e` : la retransmission a-t-elle été positivement observée ? */
    bool forwardingObserved{false};

    /** @brief Comment la fenêtre s'est refermée. */
    ForwardingClosureReason closureReason{ForwardingClosureReason::DEADLINE};

    /**
     * @brief L'émetteur de la trame appariée a-t-il pu être attribué à `j` ?
     *
     * Sur appariement, l'observateur connaît l'adresse MAC émettrice. Encore
     * faut-il savoir qu'elle appartient bien à `j`. La correspondance est apprise
     * PASSIVEMENT (voir ForwardingObserver) et peut être absente. Dans ce cas ce
     * drapeau est faux et l'attribution reste incomplète — ce qui doit être
     * reporté, non supposé.
     */
    bool senderAttributedToNeighbor{false};

    /**
     * @brief L'émetteur de la trame appariée était-il l'OBSERVATEUR LUI-MÊME ?
     *        DIAGNOSTIC UNIQUEMENT — n'entre dans aucune équation.
     *
     * POURQUOI CE CHAMP EXISTE. Sur le run r19, les 1 272 appariements de
     * voisin attaquant présentaient une latence médiane ET maximale de
     * 0,00 ms — c'est-à-dire moins de 5 µs entre l'ouverture de la fenêtre et
     * l'appariement. Aucune retransmission radio ne peut être entendue en 5 µs :
     * il faut au minimum une durée de trame et un SIFS.
     *
     * Deux hypothèses restent ouvertes, et ce champ les départage :
     *  - l'observateur apparie sa PROPRE émission, ce qui serait un défaut
     *    GRAVE : l'Éq. (9) accorderait \f$(1,0,0,0)\f$ — preuve positive
     *    pleine — à un trou noir qui n'a rien relayé ;
     *  - l'appariement vient d'un tiers, et la latence quasi nulle a une autre
     *    cause qu'il faudra chercher.
     *
     * @warning AUCUN COMPORTEMENT N'EST MODIFIÉ dans ce lot. Changer la règle
     *          d'appariement déplacerait \f$z_e\f$ sur TOUS les événements en
     *          même temps qu'on cherche à comprendre pourquoi. On compte
     *          d'abord ; on décide ensuite, sur le chiffre.
     */
    bool observedSenderIsSelf{false};

    /**
     * @brief La fenêtre a-t-elle été ouverte par un RELAIS (`UnicastForward`)
     *        plutôt que par une émission LOCALE (`SendOutgoing`) ?
     *        DIAGNOSTIC UNIQUEMENT — n'entre dans aucune équation.
     *
     * POURQUOI CE CHAMP EXISTE. Le run r20 a réfuté l'auto-appariement
     * (`matchedFromSelf = 0`) mais confirmé l'anomalie : les 1 272 appariements
     * de voisin attaquant ont une latence **min = médiane = max = 0,0 µs**.
     * Aucune retransmission radio ne s'entend en moins de 50 ns — il faut une
     * durée de trame et un SIFS.
     *
     * L'hypothèse restante est que la fenêtre est fermée par la trame ENTRANTE
     * du paquet lui-même : \c i reçoit le paquet de \c h, l'IP le relaie, la
     * fenêtre s'ouvre, et le rappel promiscuité de CETTE MÊME trame apparie
     * l'empreinte qui vient d'être enregistrée. L'émetteur serait alors \c h —
     * ni \c j, ni nous-mêmes, ce qui est exactement le profil mesuré.
     *
     * Ce champ départage : si les appariements à latence nulle sont TOUS des
     * fenêtres de relais, le mécanisme est établi. S'il y en a sur des
     * émissions locales, l'hypothèse tombe et il faut chercher ailleurs.
     */
    bool openedByRelay{false};

    // ---- Caractéristiques d'opportunité x_k, entrées de l'Éq. (6)-(7) ----
    /** @brief Fiabilité observateur-voisin estimée, dans [0,1]. */
    /**
     * @brief \f$x_{link}(e) = \hat R_{ij}(t_e^-)\f$ — GELÉ à l'ouverture.
     *
     * Fiabilité estimée du lien \c i->j à partir du **seul** historique
     * disponible AVANT l'ouverture de la fenêtre. Répond à : « avant d'observer
     * le résultat de cet événement, avions-nous de bonnes raisons de penser que
     * le paquet pouvait atteindre \c j ? »
     *
     * @warning INVARIANT NORMATIF. Cette valeur ne doit JAMAIS incorporer
     *          l'issue de l'événement \c e. Elle est capturée dans
     *          OpenWindow() et n'est plus recalculée. La calculer à la clôture
     *          ferait entrer l'ACK — ou l'échec — de la transmission qui a
     *          ouvert la fenêtre : un échec MAC vers \c j implique que \c j
     *          n'a jamais reçu le paquet, donc \f$z_e = 0\f$ FORCÉ. La
     *          caractéristique prédirait alors son propre résultat.
     */
    double linkReliability{0.0};
    /** @brief `a_k` associé à linkReliability. */
    bool linkReliabilityAvailable{false};

    /**
     * @brief Même quantité recalculée à la CLÔTURE. DIAGNOSTIC UNIQUEMENT.
     *
     * N'entre dans AUCUNE équation, ni (7) ni (8). Exportée dans le seul but de
     * mesurer sur traces l'ampleur de la fuite temporelle que le gel supprime :
     * l'écart entre les deux colonnes est la contamination qui existait avant.
     *
     * @warning Toute utilisation de ce champ dans un calcul de masse serait la
     *          réintroduction exacte du défaut corrigé.
     */
    double linkReliabilityAtClose{0.0};
    /** @brief Disponibilité de la valeur de clôture. DIAGNOSTIC UNIQUEMENT. */
    bool linkReliabilityAtCloseAvailable{false};

    /** @brief Persistance de contact prévue pendant la fenêtre, dans [0,1]. */
    double predictedContactPersistence{0.0};
    /** @brief `a_k` associé à predictedContactPersistence. */
    bool predictedContactPersistenceAvailable{false};

    /** @brief Visibilité par écoute passive, dans [0,1]. */
    double passiveVisibility{0.0};
    /** @brief `a_k` associé à passiveVisibility. */
    bool passiveVisibilityAvailable{false};

    // ---- Diagnostics de perte bénigne y_l, entrées de l'Éq. (8) ----
    /**
     * @brief \f$y_{lien}(e)\f$ — une issue MAC vers \c j a-t-elle ECHOUE
     *        PENDANT la fenêtre ? Binaire : 1 = oui, 0 = non.
     *
     * PREMIER DIAGNOSTIC INSTRUMENTÉ (STEP 4 partie B).
     *
     * CE QU'IL AFFIRME
     * ----------------
     * Un échec MAC vers \c j pendant la fenêtre est l'explication BÉNIGNE
     * archétypale d'une non-observation : si le paquet n'a jamais atteint
     * \c j, l'absence de retransmission ne dit rien de ses intentions.
     * Inversement, un ACK observé pendant la fenêtre ÉCARTE cette explication.
     * C'est une MESURE, pas une valeur par défaut : \c value = 0 avec
     * \c available = true signifie « la cause bénigne « le paquet n'est pas
     * arrivé » est écartée », ce que l'Éq. (8) doit précisément savoir.
     *
     * @warning SÉPARATION TEMPORELLE AVEC #linkReliability. Les deux portent
     *          sur le même lien \c i->j, et c'est exactement pourquoi elles
     *          doivent rester disjointes :
     *          - #linkReliability est GELÉE à \f$t_e^-\f$ : historique
     *            ANTÉRIEUR à l'ouverture, uniquement ;
     *          - ce champ n'utilise que les issues survenues DANS
     *            \f$[t_{ouverture}, t_{clôture}]\f$.
     *          Aucune issue MAC ne peut donc alimenter les deux. C'est l'objet
     *          même de l'arbitrage « option (1) avec séparation temporelle
     *          stricte » : la même information des deux côtés de l'Éq. (7) et
     *          de l'Éq. (8) serait un double comptage.
     *
     * PAS DE VETO ICI. Contrairement à l'Éq. (7), l'Éq. (8) est une moyenne
     * ARITHMÉTIQUE pondérée : une valeur nulle y atténue, elle n'annule pas.
     * Un \c y_l = 0 est donc sans danger, là où un \c x_k = 0 disponible est
     * un veto absolu. Les deux équations ne se lisent pas de la même façon.
     *
     * PORTÉE RÉELLE, ÉNONCÉE. L'attribution est PAR PAIR, non PAR PAQUET :
     * l'observateur constate qu'une issue vers \c j est survenue pendant la
     * fenêtre, sans prouver qu'elle concernait CE paquet. Sur 150 ms une
     * seconde émission vers \c j est possible ; le compteur
     * \c windowsMultipleLinkOutcomes MESURE cette ambiguïté au lieu de la
     * supposer négligeable. Une attribution par paquet exigerait de retrouver
     * l'en-tête IPv4 dans le \c WifiMpdu — faisable, non fait ici, et à
     * n'entreprendre que si la mesure d'ambiguïté le justifie.
     */
    double linkFailureDuringWindow{0.0};

    /**
     * @brief \c a_l associé à #linkFailureDuringWindow.
     *
     * Vrai si et seulement si la MAC de \c j était connue À L'OUVERTURE **et**
     * qu'au moins une issue MAC vers \c j a été observée pendant la fenêtre.
     *
     * La résolution IPv4 -> MAC est GELÉE à l'ouverture, comme la fiabilité :
     * l'apprendre en cours de fenêtre ferait dépendre la DISPONIBILITÉ du
     * diagnostic d'un événement postérieur à l'ouverture, et une disponibilité
     * qui varie avec l'issue observée est le premier pas vers une grandeur qui
     * prédit son propre résultat.
     */
    bool linkFailureDuringWindowAvailable{false};

    /**
     * @brief Nombre d'issues MAC vers \c j attribuées à cette fenêtre.
     *        DIAGNOSTIC UNIQUEMENT — n'entre dans AUCUNE équation.
     *
     * MESURE LA CONFIANCE qu'on peut accorder à #linkFailureDuringWindow sur
     * CET événement. À 1, l'issue attribuée est nécessairement celle du paquet
     * suivi et le diagnostic est exact. Au-delà, l'attribution est par PAIR et
     * non par PAQUET : l'échec constaté peut concerner un autre paquet, et le
     * diagnostic peut alors EXCUSER à tort.
     *
     * Le compteur agrégé \c windowsMultipleLinkOutcomes donne le taux global
     * (mesuré : 66,7 % des fenêtres évaluables). Ce champ-ci permet le
     * croisement qui manquait : parmi les événements où \f$y_\ell = 1\f$,
     * combien étaient ambigus ? C'est CE chiffre, et non le taux global, qui
     * dit si les attributions bénignes sont fiables.
     */
    uint16_t linkOutcomesDuringWindow{0};

    /** @brief Indice de rupture de lien ou de mobilité, dans [0,1]. */
    double mobilityBreak{0.0};
    /** @brief `a_l` associé à mobilityBreak. */
    bool mobilityBreakAvailable{false};

    /** @brief Indice de pression de file d'attente, dans [0,1]. */
    double queuePressure{0.0};
    /** @brief `a_l` associé à queuePressure. */
    bool queuePressureAvailable{false};

    /** @brief Un RERR cohérent a-t-il été observé pour cette route ? */
    double coherentRerr{0.0};
    /** @brief `a_l` associé à coherentRerr. */
    bool coherentRerrAvailable{false};
};

} // namespace mtcaodv
} // namespace ns3

#endif // MTCAODV_FORWARDING_OBSERVATION_H
