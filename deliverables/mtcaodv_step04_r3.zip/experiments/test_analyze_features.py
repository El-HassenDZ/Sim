#!/usr/bin/env python3
"""Tests de analyze_features.py. Bibliotheque standard uniquement."""

import contextlib
import io
import json
import math
import tempfile
import unittest
from pathlib import Path

import analyze_features as f
from analyze_forwarding import ForwardingAnalysisError

HEADER = ("openTime_s,closeTime_s,observerNodeId,neighborNodeId,neighborIp,"
          "forwardingObserved,closureReason,senderAttributed,passiveVisibility,"
          "passiveVisibilityAvailable")


def _row(neighbor=1, observed=1, attributed=1, visibility=1.0, available=1,
         reason="MATCHED"):
    return (f"1.0,1.1,0,{neighbor},10.1.0.2,{observed},{reason},{attributed},"
            f"{visibility},{available}")


def _write(lines):
    path = Path(tempfile.mkdtemp()) / "obs.csv"
    path.write_text(HEADER + "\n" + "\n".join(lines) + "\n", encoding="utf-8")
    return path


def _manifest(attackers=(5,), nodes=30):
    path = Path(tempfile.mkdtemp()) / "man.json"
    path.write_text(json.dumps({
        "nodes": nodes,
        "attack": {"attackerNodeIds": list(attackers), "attackStart_s": 10.0},
    }), encoding="utf-8")
    return path



# Les tests bout-en-bout appellent main(), qui ECRIT son rapport sur stdout. Sans
# capture, `python3 -m unittest -q` deverse plusieurs ecrans de rapport et la
# ligne « Ran N tests OK » devient introuvable. On capture donc la sortie : ces
# tests verifient le CODE DE RETOUR, pas la mise en page.
def _silent(callable_, *args):
    """Execute en capturant stdout ; renvoie le code de retour."""
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        return callable_(*args)


class LoadTests(unittest.TestCase):
    def test_empty_file_is_refused(self):
        """Un fichier vide n'est pas une mesure nulle : on refuse de conclure."""
        path = Path(tempfile.mkdtemp()) / "obs.csv"
        path.write_text(HEADER + "\n", encoding="utf-8")
        with self.assertRaises(ForwardingAnalysisError):
            f.load_rows(path)

    def test_reads_availability_flag(self):
        rows = f.load_rows(_write([_row(available=0)]))
        self.assertFalse(rows[0]["visibilityAvailable"])


class CeilingTests(unittest.TestCase):
    def test_ceiling_counts_only_visible_non_observations(self):
        """Le plafond est le nombre de non-observations AVEC visibilite.

        Une non-observation sans visibilite donne O_e = 0 par l'Eq. (7), donc
        I_e = 0 : elle ne peut recevoir aucune masse malveillante, quels que
        soient les diagnostics ajoutes ensuite.
        """
        rows = f.load_rows(_write([
            _row(observed=0, visibility=1.0, reason="DEADLINE"),   # comptee
            _row(observed=0, visibility=0.0, reason="DEADLINE"),   # exclue
            _row(observed=0, visibility=0.0, reason="DEADLINE"),   # exclue
            _row(observed=1, visibility=1.0),                      # pas une non-obs
        ]))
        summary = f.summarise(rows, "test")
        self.assertEqual(summary["missed"], 3)
        self.assertEqual(summary["attributableCeiling"], 1)
        self.assertAlmostEqual(summary["attributableCeilingRate"], 1 / 3)

    def test_no_non_observation_gives_nan_not_zero(self):
        """Aucune non-observation : le plafond est INDEFINI, jamais 0."""
        rows = f.load_rows(_write([_row(observed=1), _row(observed=1)]))
        summary = f.summarise(rows, "test")
        self.assertEqual(summary["missed"], 0)
        self.assertTrue(math.isnan(summary["attributableCeilingRate"]))

    def test_unavailable_feature_excluded_from_visible_rate(self):
        """Une caracteristique indisponible n'est ni visible ni non visible."""
        rows = f.load_rows(_write([
            _row(visibility=1.0, available=1),
            _row(visibility=0.0, available=0),
        ]))
        summary = f.summarise(rows, "test")
        self.assertEqual(summary["available"], 1)
        self.assertAlmostEqual(summary["visibleRate"], 1.0)

    def test_conditional_rates_are_separate(self):
        """visible|vue et visible|non-vue sont mesures separement, jamais melanges."""
        rows = f.load_rows(_write([
            _row(observed=1, visibility=1.0),
            _row(observed=1, visibility=1.0),
            _row(observed=0, visibility=0.0, reason="DEADLINE"),
        ]))
        summary = f.summarise(rows, "test")
        self.assertAlmostEqual(summary["visibleGivenMatched"], 1.0)
        self.assertAlmostEqual(summary["visibleGivenMissed"], 0.0)


class EncodingTests(unittest.TestCase):
    def test_old_encoding_is_detected(self):
        """Disponible avec valeur 0 = CSV anterieur a la correction d'encodage.

        Une caracteristique DISPONIBLE valant 0 est un veto absolu dans
        l'Eq. (7) : 0^(w/c) = 0 quel que soit le poids. L'encodage correct pour
        « je ne sais pas si le voisin etait audible » est INDISPONIBLE. Le
        script doit signaler un tel fichier plutot que d'en tirer des taux
        interpretes comme s'ils venaient de l'encodage corrige.
        """
        rows = f.load_rows(_write([
            _row(visibility=0.0, available=1),
            _row(visibility=1.0, available=1),
        ]))
        self.assertEqual(f.summarise(rows, "test")["availableAndZero"], 1)

    def test_corrected_encoding_reports_none(self):
        rows = f.load_rows(_write([
            _row(visibility=1.0, available=1),
            _row(visibility=0.0, available=0),
        ]))
        self.assertEqual(f.summarise(rows, "test")["availableAndZero"], 0)


class MainTests(unittest.TestCase):
    def test_runs_end_to_end(self):
        csv_path = _write([
            _row(neighbor=1, observed=1, visibility=1.0),
            _row(neighbor=5, observed=0, visibility=1.0, reason="DEADLINE"),
            _row(neighbor=5, observed=0, visibility=0.0, reason="DEADLINE"),
        ])
        self.assertEqual(_silent(f.main, ["--observations", str(csv_path),
                                 "--manifest", str(_manifest())]), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
