/* SPDX-License-Identifier: GPL-2.0-only */
#include "forwarding-observer.h"

#include "mtc-aodv-routing-protocol.h"

#include "ns3/boolean.h"
#include "ns3/double.h"
#include "ns3/log.h"
#include "ns3/ipv4.h"
#include "ns3/ipv4-l3-protocol.h"
#include "ns3/node.h"
#include "ns3/udp-header.h"
#include "ns3/simulator.h"
#include "ns3/uinteger.h"

namespace ns3
{

NS_LOG_COMPONENT_DEFINE("MtcAodvForwardingObserver");

namespace mtcaodv
{

NS_OBJECT_ENSURE_REGISTERED(ForwardingObserver);

namespace
{
/** @brief EtherType IPv4 ; seules ces trames portent un en-tête analysable. */
constexpr uint16_t ETHERTYPE_IPV4 = 0x0800;

/** @brief Numero de protocole IPv4 pour UDP. */
constexpr uint8_t IPV4_PROTOCOL_UDP = 17;
} // namespace

TypeId
ForwardingObserver::GetTypeId()
{
    static TypeId tid =
        TypeId("ns3::mtcaodv::ForwardingObserver")
            .SetParent<Object>()
            .SetGroupName("Mtcaodv")
            .AddConstructor<ForwardingObserver>()
            .AddAttribute("ObservationWindow",
                          "Delai avant cloture d'une fenetre sans appariement. "
                          "Trop court, un transfert honnete est manque et compte "
                          "comme non-observation ; trop long, la fenetre deborde "
                          "sur la mobilite. A CALIBRER sur la distribution des "
                          "latences d'appariement mesurees, jamais par intuition.",
                          TimeValue(MilliSeconds(150)),
                          MakeTimeAccessor(&ForwardingObserver::m_observationWindow),
                          MakeTimeChecker(MilliSeconds(1)))
            .AddAttribute("SweepInterval",
                          "Periode du balayage des echeances. Un seul evenement "
                          "periodique remplace un minuteur par fenetre : le cout "
                          "reste O(1) par fenetre au lieu de O(1) evenement par "
                          "fenetre.",
                          TimeValue(MilliSeconds(50)),
                          MakeTimeAccessor(&ForwardingObserver::m_sweepInterval),
                          MakeTimeChecker(MilliSeconds(1)))
            .AddAttribute("MaxActiveWindows",
                          "Borne dure sur les fenetres ouvertes (Invariant 20.4.2).",
                          UintegerValue(256),
                          MakeUintegerAccessor(&ForwardingObserver::m_maxActiveWindows),
                          MakeUintegerChecker<uint32_t>(1))
            .AddAttribute("MaxLearnedAddresses",
                          "Borne dure sur la table MAC -> IPv4 apprise passivement.",
                          UintegerValue(256),
                          MakeUintegerAccessor(&ForwardingObserver::m_maxLearnedAddresses),
                          MakeUintegerChecker<uint32_t>(1))
            .AddAttribute("Enabled",
                          "Active l'observation. La mettre a false doit laisser le "
                          "PDR RIGOUREUSEMENT inchange : c'est la preuve de "
                          "non-intrusion exigee par STEP 3.",
                          BooleanValue(true),
                          MakeBooleanAccessor(&ForwardingObserver::m_enabled),
                          MakeBooleanChecker())
            .AddTraceSource("ObservationClosed",
                            "Une fenetre d'observation s'est refermee. L'evenement "
                            "porte z_e et les drapeaux de disponibilite, JAMAIS une "
                            "masse ni une etiquette : l'attribution est A3.3.",
                            MakeTraceSourceAccessor(
                                &ForwardingObserver::m_observationClosedTrace),
                            "ns3::mtcaodv::ForwardingObserver::"
                            "ObservationClosedTracedCallback");
    return tid;
}

ForwardingObserver::ForwardingObserver()
    : m_observationWindow(MilliSeconds(150)),
      m_sweepInterval(MilliSeconds(50))
{
    NS_LOG_FUNCTION(this);
}

ForwardingObserver::~ForwardingObserver()
{
    NS_LOG_FUNCTION(this);
}

void
ForwardingObserver::DoDispose()
{
    // Le balayage est un evenement periodique auto-reprogramme : sans annulation
    // explicite il maintiendrait l'objet vivant jusqu'a la fin de la simulation.
    Simulator::Cancel(m_sweepEvent);
    m_openWindows.clear();
    m_learnedAddresses.clear();
    m_lastHeardFromNeighbor.clear();
    m_routing = nullptr;
    m_node = nullptr;
    Object::DoDispose();
}

void
ForwardingObserver::Install(Ptr<Node> node)
{
    NS_LOG_FUNCTION(this << node);
    NS_ASSERT_MSG(node, "ForwardingObserver::Install requires a node");
    NS_ASSERT_MSG(!m_node, "ForwardingObserver::Install called twice on one node; "
                           "ns-3 keeps a single promiscuous callback per device, "
                           "so the second install would silently replace the first");
    m_node = node;
    m_observerNodeId = node->GetId();

    // Agreger l'observateur au noeud lie sa duree de vie a celle du noeud. Sans
    // cela, le rappel promiscuite installe ci-dessous detiendrait un pointeur nu
    // vers un objet que plus rien ne maintient en vie, et le pilote n'aurait
    // aucun moyen de retrouver l'observateur pour lire ses compteurs.
    node->AggregateObject(this);

    for (uint32_t index = 0; index < node->GetNDevices(); ++index)
    {
        Ptr<NetDevice> device = node->GetDevice(index);
        // La boucle locale n'entend rien et n'a pas de voisin a observer.
        if (device->IsPointToPoint() || !device->IsBroadcast())
        {
            continue;
        }
        device->SetPromiscReceiveCallback(
            MakeCallback(&ForwardingObserver::OnPromiscuousReceive, this));
    }

    // ---- Le protocole de routage, pour la SEULE consultation du prochain saut --
    Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
    NS_ASSERT_MSG(ipv4, "ForwardingObserver::Install requires an IPv4 stack");
    m_routing = DynamicCast<RoutingProtocol>(ipv4->GetRoutingProtocol());
    NS_ASSERT_MSG(m_routing,
                  "ForwardingObserver requires the mtcaodv fork: without a next-hop "
                  "lookup it could open a window without knowing which neighbour to "
                  "watch, which would make every observation unattributable");

    // ---- Les deux traces qui couvrent SOURCE et RELAIS uniformement ----
    // SendOutgoing  : paquets originaires de ce noeud (le cas DOMINANT a 1,73 saut)
    // UnicastForward: paquets relayes par ce noeud
    // Les deux portent l'en-tete IPv4 COMPLET, identification comprise, ce que
    // RouteOutput() ne pourrait pas fournir.
    Ptr<Ipv4L3Protocol> layer3 = node->GetObject<Ipv4L3Protocol>();
    NS_ASSERT_MSG(layer3, "ForwardingObserver::Install requires Ipv4L3Protocol");
    const bool sendConnected = layer3->TraceConnectWithoutContext(
        "SendOutgoing", MakeCallback(&ForwardingObserver::OnIpv4Transmit, this));
    const bool forwardConnected = layer3->TraceConnectWithoutContext(
        "UnicastForward", MakeCallback(&ForwardingObserver::OnIpv4Transmit, this));
    NS_ASSERT_MSG(sendConnected && forwardConnected,
                  "Could not connect the Ipv4L3Protocol traces; without them the "
                  "observer would silently open no window at all");

    ScheduleNextSweep();
}

void
ForwardingObserver::SetEnabled(bool enabled)
{
    m_enabled = enabled;
}

bool
ForwardingObserver::IsEnabled() const
{
    return m_enabled;
}

void
ForwardingObserver::ScheduleNextSweep()
{
    m_sweepEvent = Simulator::Schedule(m_sweepInterval,
                                       &ForwardingObserver::SweepExpiredWindows,
                                       this);
}

void
ForwardingObserver::OnIpv4Transmit(const Ipv4Header& header,
                                   Ptr<const Packet> packet,
                                   uint32_t interface)
{
    if (!m_enabled)
    {
        return;
    }
    ++m_transmissionsInspected;

    const Ipv4Address destination = header.GetDestination();

    // Diffusion et multicast : il n'y a pas de "prochain saut" a surveiller.
    if (destination.IsBroadcast() || destination.IsMulticast() ||
        destination.IsLocalMulticast())
    {
        ++m_skippedNonUnicast;
        return;
    }

    // Plan de controle AODV : exclu. Un Blackhole complet relaie fidelement le
    // controle pour rester attractif, donc l'inclure diluerait le signal du plan
    // de donnees avec des transferts que meme un attaquant effectue.
    if (header.GetProtocol() == IPV4_PROTOCOL_UDP)
    {
        UdpHeader udpHeader;
        Ptr<Packet> copy = packet->Copy();
        if (copy->PeekHeader(udpHeader) > 0 &&
            (udpHeader.GetDestinationPort() == m_controlPlanePort ||
             udpHeader.GetSourcePort() == m_controlPlanePort))
        {
            ++m_skippedControlPlane;
            return;
        }
    }

    Ipv4Address nextHop;
    if (!m_routing || !m_routing->LookupNextHopForObservation(destination, nextHop))
    {
        // Pas de route valide a cet instant : on ne sait pas QUI surveiller.
        // Compte, jamais devine.
        ++m_skippedNoRoute;
        return;
    }

    // ---- LE CAS QUI COMPTE : le prochain saut EST la destination finale ----
    // La destination consomme le paquet et ne le retransmet JAMAIS. Ouvrir une
    // fenetre ici garantirait z_e = 0 sur un noeud parfaitement honnete, a
    // chaque paquet du dernier saut. C'est le mode de defaillance qui rendrait
    // la baseline benigne egale a 1 et l'attribution OCEA inexploitable.
    if (nextHop == destination)
    {
        ++m_skippedLastHop;
        return;
    }

    OpenWindow(header, static_cast<uint16_t>(packet->GetSize()), nextHop);
}

void
ForwardingObserver::OpenWindow(const Ipv4Header& header,
                               uint16_t payloadLengthBytes,
                               Ipv4Address nextHop)
{
    if (!m_enabled)
    {
        return;
    }

    // Un paquet fragmente invalide a la fois l'identification (partagee par tous
    // les fragments) et la taille utile. Il est COMPTE puis EXCLU : le suivre
    // produirait des appariements faux dans les deux sens.
    if (header.IsLastFragment() == false || header.GetFragmentOffset() != 0)
    {
        ++m_fragmentedPacketsExcluded;
        return;
    }

    PacketFingerprintFields fields;
    fields.sourceAddress = header.GetSource().Get();
    fields.destinationAddress = header.GetDestination().Get();
    fields.identification = header.GetIdentification();
    fields.payloadLength = payloadLengthBytes;
    fields.protocol = header.GetProtocol();
    const uint64_t fingerprint = ComputePacketFingerprint(fields);

    // Collision : une fenetre existe deja pour cette empreinte alors que les
    // champs different. Mesuree et rapportee, jamais supposee impossible.
    const auto existing = m_openWindows.find(fingerprint);
    if (existing != m_openWindows.end())
    {
        if (existing->second.sourceAddress != fields.sourceAddress ||
            existing->second.destinationAddress != fields.destinationAddress ||
            existing->second.identification != fields.identification)
        {
            ++m_fingerprintCollisions;
        }
        // Dans les deux cas la fenetre precedente est remplacee : un paquet
        // reemis porte la meme empreinte, et suivre le plus recent est la
        // lecture correcte.
        m_openWindows.erase(existing);
    }

    // Borne dure : evincer la fenetre la plus ancienne. EVICTED est une raison
    // distincte, jamais confondue avec une non-observation, car une fenetre
    // evincee n'a rien observe du tout.
    while (m_openWindows.size() >= m_maxActiveWindows)
    {
        auto oldest = m_openWindows.begin();
        for (auto it = m_openWindows.begin(); it != m_openWindows.end(); ++it)
        {
            if (it->second.openTimeSeconds < oldest->second.openTimeSeconds)
            {
                oldest = it;
            }
        }
        const uint64_t evictedFingerprint = oldest->first;
        const OpenWindowRecord evictedRecord = oldest->second;
        m_openWindows.erase(oldest);
        CloseWindow(evictedFingerprint,
                    evictedRecord,
                    ForwardingClosureReason::EVICTED,
                    Address());
    }

    OpenWindowRecord record;
    record.nextHop = nextHop;
    record.openTimeSeconds = Simulator::Now().GetSeconds();
    record.sourceAddress = fields.sourceAddress;
    record.destinationAddress = fields.destinationAddress;
    record.identification = fields.identification;
    m_openWindows[fingerprint] = record;
    ++m_windowsOpened;

    NS_LOG_DEBUG("Observation window opened for " << header.GetSource() << "->"
                                                  << header.GetDestination()
                                                  << " via " << nextHop);
}

bool
ForwardingObserver::OnPromiscuousReceive(Ptr<NetDevice> device,
                                         Ptr<const Packet> packet,
                                         uint16_t protocol,
                                         const Address& from,
                                         const Address& to,
                                         NetDevice::PacketType packetType)
{
    // Non-intrusion : quoi qu'il arrive ci-dessous, la valeur de retour est
    // false et aucun paquet de la pile n'est modifie. Les analyses portent sur
    // des COPIES ; RemoveHeader mute son argument, et muter un paquet en vol
    // serait exactement l'intrusion que STEP 3 interdit.
    if (!m_enabled)
    {
        return false;
    }
    ++m_promiscuousFramesInspected;

    if (protocol != ETHERTYPE_IPV4)
    {
        return false; // ARP et consorts : hors sujet, non comptes comme observation
    }

    Ptr<Packet> copy = packet->Copy();
    Ipv4Header header;
    if (copy->GetSize() < header.GetSerializedSize())
    {
        return false;
    }
    copy->RemoveHeader(header);

    // ---- Apprentissage passif de la correspondance MAC -> IPv4 ----
    // Une trame DIFFUSEE est necessairement emise par le noeud dont l'adresse
    // figure en source IP : AODV envoie ses diffusions depuis sa propre socket.
    // Le spike C-17 l'a verifie sur trace. Une trame unicast, elle, peut etre un
    // RELAIS, dont la source IP est un tiers : l'utiliser pour apprendre
    // associerait la MAC du relais a l'IP de la source d'origine.
    if (packetType == NetDevice::PACKET_BROADCAST)
    {
        LearnAddressMapping(from, header.GetSource());
    }

    // ---- Tentative d'appariement ----
    PacketFingerprintFields fields;
    fields.sourceAddress = header.GetSource().Get();
    fields.destinationAddress = header.GetDestination().Get();
    fields.identification = header.GetIdentification();
    fields.payloadLength = static_cast<uint16_t>(copy->GetSize());
    fields.protocol = header.GetProtocol();
    const uint64_t fingerprint = ComputePacketFingerprint(fields);

    const auto found = m_openWindows.find(fingerprint);
    if (found == m_openWindows.end())
    {
        return false; // rien a apparier : ce n'est ni un succes ni un echec
    }

    const OpenWindowRecord record = found->second;
    m_openWindows.erase(found);
    CloseWindow(fingerprint, record, ForwardingClosureReason::MATCHED, from);
    return false;
}

void
ForwardingObserver::LearnAddressMapping(const Address& mac, Ipv4Address ipv4)
{
    if (ipv4 == Ipv4Address::GetAny() || ipv4.IsBroadcast())
    {
        return;
    }
    // Toute trame entendue de ce noeud atteste sa visibilite radio A CET INSTANT.
    // La table est bornee par le meme plafond que les correspondances apprises.
    if (m_lastHeardFromNeighbor.size() < m_maxLearnedAddresses ||
        m_lastHeardFromNeighbor.count(ipv4) > 0)
    {
        m_lastHeardFromNeighbor[ipv4] = Simulator::Now().GetSeconds();
    }

    const auto existing = m_learnedAddresses.find(mac);
    if (existing != m_learnedAddresses.end())
    {
        existing->second = ipv4; // la plus recente fait foi
        return;
    }
    // Borne dure : au-dela, on n'apprend plus. Ne PAS evincer au hasard — une
    // correspondance perdue rendrait une observation non attribuable, ce qui est
    // rapporte comme tel ; une correspondance fausse produirait une attribution
    // erronee, ce qui est bien pire.
    if (m_learnedAddresses.size() >= m_maxLearnedAddresses)
    {
        return;
    }
    m_learnedAddresses[mac] = ipv4;
}

void
ForwardingObserver::SweepExpiredWindows()
{
    const double now = Simulator::Now().GetSeconds();
    const double windowSeconds = m_observationWindow.GetSeconds();

    for (auto it = m_openWindows.begin(); it != m_openWindows.end();)
    {
        if ((now - it->second.openTimeSeconds) >= windowSeconds)
        {
            const uint64_t fingerprint = it->first;
            const OpenWindowRecord record = it->second;
            it = m_openWindows.erase(it);
            CloseWindow(fingerprint,
                        record,
                        ForwardingClosureReason::DEADLINE,
                        Address());
        }
        else
        {
            ++it;
        }
    }
    ScheduleNextSweep();
}

void
ForwardingObserver::CloseWindow(uint64_t fingerprint,
                                const OpenWindowRecord& record,
                                ForwardingClosureReason reason,
                                const Address& observedSenderMac)
{
    ForwardingObservation observation;
    observation.observerNodeId = m_observerNodeId;
    observation.watchedNeighbor = record.nextHop;
    observation.fingerprint = fingerprint;
    observation.openTimeSeconds = record.openTimeSeconds;
    observation.closeTimeSeconds = Simulator::Now().GetSeconds();
    observation.closureReason = reason;
    observation.forwardingObserved = (reason == ForwardingClosureReason::MATCHED);

    // Attribution de l'emetteur : verifiee contre la table apprise, jamais
    // supposee. Une correspondance absente laisse le drapeau a faux, ce qui est
    // une information et non un echec silencieux.
    if (reason == ForwardingClosureReason::MATCHED)
    {
        const auto learned = m_learnedAddresses.find(observedSenderMac);
        observation.senderAttributedToNeighbor =
            (learned != m_learnedAddresses.end() && learned->second == record.nextHop);
    }

    // ---- Caracteristiques x_k et diagnostics y_l ----
    // STEP 3 ne renseigne que ce qu'il MESURE reellement. Les autres restent
    // indisponibles (drapeau faux), ce que les Eq. (6) et (8) savent traiter :
    // elles somment les poids des caracteristiques disponibles et declarent
    // l'evenement non interpretable quand la couverture est nulle. Remplir une
    // valeur par defaut ferait passer une observation partielle pour complete.
    //
    // `passiveVisibility` : preuve POSITIVE que le voisin etait audible pendant
    // la fenetre, jamais une affirmation du contraire.
    //
    // CORRECTION D'UNE ERREUR DE CONCEPTION. La version precedente ecrivait
    // `available = true` dans TOUS les cas, avec `value = 0` quand le voisin
    // n'avait rien diffuse, au motif que « la reponse est toujours connue ».
    // Elle ne l'est pas. On sait si l'on A ENTENDU j ; on ne sait pas si j
    // ETAIT AUDIBLE. Un silence signifie soit que le lien j->i est coupe,
    // soit simplement que j n'avait rien a emettre -- AODV ne diffuse des RREQ
    // que pendant la decouverte, donc un voisin parfaitement audible peut se
    // taire plusieurs secondes en regime etabli.
    //
    // POURQUOI C'EST GRAVE, et non un detail de codage. Dans l'Eq. (7),
    //
    //     O_e = c_e * PRODUIT x_k^(w_k a_k / c_e)
    //
    // une caracteristique DISPONIBLE valant exactement 0 est un VETO ABSOLU,
    // quel que soit son poids : 0^(w/c) = 0 pour tout w > 0. Baisser w_pv ne
    // corrigerait rien. Mesure sur le run STEP 3 : 9 343 des 10 962 evenements
    // (85,2 %) etaient ainsi annules, et le taux de visibilite valait 0.1466
    // chez l'honnete contre 0.1484 chez l'attaquant (z = +0.26) -- donc AUCUN
    // pouvoir discriminant, pour un veto sur 85 % des donnees.
    //
    // C'est le miroir exact de la faute que le commentaire ci-dessus enonce :
    // remplir une valeur par defaut fait passer une observation partielle pour
    // complete. Ici la valeur par defaut affirmait une opportunite NULLE la ou
    // il n'y avait qu'une absence de preuve.
    //
    // REGLE. `available = 0` et `value = 0` ne sont pas interchangeables :
    // le premier avoue une ignorance et reduit seulement la couverture c_e,
    // le second affirme l'absence d'opportunite et annule l'evenement. Ne
    // declarer disponible que ce que l'on sait reellement.
    const auto lastHeard = m_lastHeardFromNeighbor.find(record.nextHop);
    const bool heardWithinWindow =
        (lastHeard != m_lastHeardFromNeighbor.end() &&
         (observation.closeTimeSeconds - lastHeard->second) <=
             m_observationWindow.GetSeconds());
    if (heardWithinWindow)
    {
        observation.passiveVisibility = 1.0;
        observation.passiveVisibilityAvailable = true;
    }
    else
    {
        // Rien entendu : on ignore si le voisin etait audible. INDISPONIBLE.
        observation.passiveVisibility = 0.0;
        observation.passiveVisibilityAvailable = false;
    }

    // linkReliability, predictedContactPersistence, mobilityBreak,
    // queuePressure et coherentRerr exigent respectivement un historique de
    // lien, un modele de contact, la table de voisinage, l'etat des files et le
    // flux RERR. Aucun n'est cable a STEP 3 : ils seront renseignes a STEP 4,
    // avec leur poids. Ici ils restent explicitement INDISPONIBLES.

    switch (reason)
    {
    case ForwardingClosureReason::MATCHED:
        ++m_windowsMatched;
        break;
    case ForwardingClosureReason::DEADLINE:
        ++m_windowsDeadline;
        break;
    case ForwardingClosureReason::NEIGHBOR_LOST:
        ++m_windowsNeighborLost;
        break;
    case ForwardingClosureReason::EVICTED:
        ++m_windowsEvicted;
        break;
    }

    m_observationClosedTrace(observation);
}

uint64_t ForwardingObserver::GetWindowsOpened() const { return m_windowsOpened; }
uint64_t ForwardingObserver::GetWindowsMatched() const { return m_windowsMatched; }
uint64_t ForwardingObserver::GetWindowsDeadline() const { return m_windowsDeadline; }
uint64_t ForwardingObserver::GetWindowsNeighborLost() const { return m_windowsNeighborLost; }
uint64_t ForwardingObserver::GetWindowsEvicted() const { return m_windowsEvicted; }
uint64_t ForwardingObserver::GetFingerprintCollisions() const { return m_fingerprintCollisions; }
uint64_t ForwardingObserver::GetFragmentedPacketsExcluded() const
{
    return m_fragmentedPacketsExcluded;
}
uint64_t ForwardingObserver::GetPromiscuousFramesInspected() const
{
    return m_promiscuousFramesInspected;
}
uint64_t ForwardingObserver::GetSkippedLastHop() const { return m_skippedLastHop; }
uint64_t ForwardingObserver::GetSkippedNoRoute() const { return m_skippedNoRoute; }
uint64_t ForwardingObserver::GetSkippedControlPlane() const
{
    return m_skippedControlPlane;
}
uint64_t ForwardingObserver::GetSkippedNonUnicast() const { return m_skippedNonUnicast; }
uint64_t ForwardingObserver::GetTransmissionsInspected() const
{
    return m_transmissionsInspected;
}

} // namespace mtcaodv
} // namespace ns3
