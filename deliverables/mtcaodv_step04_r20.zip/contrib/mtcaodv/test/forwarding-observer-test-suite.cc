/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * STEP 3 integration test — Algorithme A3.2, ForwardingObserver.
 *
 * TOPOLOGIE : la chaîne validée par le spike C-17, reprise à l'identique.
 *
 *      N0 ------------- N1 ------------- N2
 *      0 m            150 m            300 m
 *
 * Portée 200 m : N0 et N2 ne s'entendent pas, N0 doit passer par N1, et N0 est
 * en position d'entendre la retransmission de N1. Positions fixes, aucun aléa :
 * un test d'observation ne doit pas dépendre d'un tirage.
 *
 * CE QUE CE TEST ETABLIT
 *   1. Un relais honnête produit des fenêtres closes par APPARIEMENT (z_e = 1).
 *   2. Un relais Blackhole produit des fenêtres closes par ECHEANCE (z_e = 0) —
 *      sans que l'observateur ait jamais accès à la liste des attaquants.
 *   3. La conservation des compteurs : chaque fenêtre ouverte se referme.
 *   4. La NON-INTRUSION : l'observation ne change pas la livraison.
 */

#include "ns3/applications-module.h"
#include "ns3/blackhole-behavior.h"
#include "ns3/core-module.h"
#include "ns3/forwarding-observer.h"
#include "ns3/internet-module.h"
#include "ns3/ipv4-address-generator.h"
#include "ns3/mobility-module.h"
#include "ns3/mtc-aodv-helper.h"
#include "ns3/mtc-aodv-routing-protocol.h"
#include "ns3/network-module.h"
#include "ns3/test.h"
#include "ns3/wifi-module.h"

#include <cstdint>

namespace ns3
{
namespace mtcaodv
{

/** @brief Résultat observable d'une réalisation de la chaîne. */
struct ChainOutcome
{
    uint64_t deliveredBytes{0};   ///< Octets acceptés par le puits en N2.
    uint64_t windowsOpened{0};    ///< Fenêtres ouvertes par l'observateur en N0.
    uint64_t windowsMatched{0};   ///< Closes par appariement (z_e = 1).
    uint64_t windowsDeadline{0};  ///< Closes par échéance (z_e = 0).
    uint64_t windowsEvicted{0};   ///< Évincées : non interprétables.
    uint64_t collisions{0};       ///< Collisions d'empreinte mesurées.
    uint64_t tracedClosures{0};   ///< Clôtures reçues via la TraceSource.
    uint64_t tracedObserved{0};   ///< Dont z_e = 1, comptées côté trace.
    uint64_t tracedAttributed{0}; ///< Dont l'émetteur a pu être attribué à N1.
    uint64_t skippedLastHop{0};   ///< Émissions écartées comme dernier saut, EN N0.
    uint64_t transmissions{0};    ///< Émissions IPv4 examinées, en N0.

    // Compteurs de l'observateur installé sur le RELAIS N1. Ils sont séparés,
    // et non agrégés, parce que les deux rôles ont des propriétés structurelles
    // OPPOSÉES et que c'est précisément ce contraste que l'on veut tester :
    //   * N0 est à deux sauts de N2, donc son prochain saut n'est JAMAIS la
    //     destination : il ouvre des fenêtres, et n'écarte aucun dernier saut ;
    //   * N1 est à un saut de N2, donc son prochain saut est TOUJOURS la
    //     destination : il n'ouvre aucune fenêtre, et écarte tout.
    // Sommer les deux masquerait exactement le défaut que ce test doit attraper.
    uint64_t relayTransmissions{0};   ///< Émissions IPv4 examinées, en N1.
    uint64_t relayWindowsOpened{0};   ///< Fenêtres ouvertes par N1 : doit valoir 0.
    uint64_t relaySkippedLastHop{0};  ///< Derniers sauts écartés par N1 : doit être > 0.

    /// Événements où `passiveVisibilityAvailable` est vrai.
    uint64_t visibilityAvailable{0};
    /// Événements DISPONIBLES avec une valeur nulle : doit rester à 0.
    /// Dans l'Éq. (7) une caractéristique disponible valant exactement 0 est un
    /// veto absolu quel que soit son poids (0^(w/c) = 0). Déclarer disponible
    /// une opportunité qu'on ignore annulerait l'événement au lieu d'avouer
    /// l'ignorance. `available = 0` et `value = 0` ne sont pas interchangeables.
    uint64_t visibilityAvailableAndZero{0};

    /// Événements où `linkReliability` était disponible (mesure ACTIVE).
    uint64_t linkReliabilityAvailable{0};
    /// Somme des fiabilités disponibles, pour vérifier qu'elles sont plausibles.
    double linkReliabilitySum{0.0};
};

/**
 * @brief Test d'intégration de l'observateur de transfert (A3.2).
 */
class ForwardingObserverTestCase : public TestCase
{
  public:
    ForwardingObserverTestCase()
        : TestCase("A3.2 : un relais honnete est observe, un Blackhole ne l'est pas")
    {
    }

  private:
    /** @brief Accumulateur de la TraceSource ; lié par MakeBoundCallback. */
    static void OnObservationClosed(ChainOutcome* outcome,
                                    const ForwardingObservation& observation)
    {
        ++outcome->tracedClosures;
        if (observation.forwardingObserved)
        {
            ++outcome->tracedObserved;
        }
        if (observation.senderAttributedToNeighbor)
        {
            ++outcome->tracedAttributed;
        }
        if (observation.linkReliabilityAvailable)
        {
            ++outcome->linkReliabilityAvailable;
            outcome->linkReliabilitySum += observation.linkReliability;
        }
        if (observation.passiveVisibilityAvailable)
        {
            ++outcome->visibilityAvailable;
            if (observation.passiveVisibility == 0.0)
            {
                ++outcome->visibilityAvailableAndZero;
            }
        }
    }

    /**
     * @brief Exécute la chaîne une fois.
     * @param attackerNodeId Nœud à rendre Blackhole, ou -1 pour tout honnête.
     * @param observationEnabled Active l'observateur (preuve de non-intrusion).
     * @return Livraison et compteurs d'observation.
     */
    ChainOutcome RunChain(int32_t attackerNodeId, bool observationEnabled)
    {
        RngSeedManager::SetSeed(12345);
        RngSeedManager::SetRun(1);
        RngSeedManager::ResetNextStreamIndex();
        Ipv4AddressGenerator::Reset();

        NodeContainer nodes;
        nodes.Create(3);

        Ptr<ListPositionAllocator> positions = CreateObject<ListPositionAllocator>();
        positions->Add(Vector(0.0, 0.0, 0.0));   // N0 : source et observateur
        positions->Add(Vector(150.0, 0.0, 0.0)); // N1 : relais
        positions->Add(Vector(300.0, 0.0, 0.0)); // N2 : destination
        MobilityHelper mobility;
        mobility.SetPositionAllocator(positions);
        mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
        mobility.Install(nodes);

        YansWifiChannelHelper channel;
        channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
        channel.AddPropagationLoss("ns3::RangePropagationLossModel",
                                   "MaxRange",
                                   DoubleValue(200.0));
        YansWifiPhyHelper phy;
        phy.SetChannel(channel.Create());
        WifiHelper wifi;
        wifi.SetStandard(WIFI_STANDARD_80211b);
        wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                     "DataMode",
                                     StringValue("DsssRate11Mbps"),
                                     "ControlMode",
                                     StringValue("DsssRate1Mbps"));
        WifiMacHelper mac;
        mac.SetType("ns3::AdhocWifiMac");
        NetDeviceContainer devices = wifi.Install(phy, mac, nodes);
        WifiHelper::AssignStreams(devices, 85000);

        MtcAodvHelper mtcAodv;
        InternetStackHelper internet;
        internet.SetRoutingHelper(mtcAodv);
        internet.Install(nodes);
        mtcAodv.AssignStreams(nodes, 86000);

        Ipv4AddressHelper ipv4;
        ipv4.SetBase("10.1.0.0", "255.255.255.0");
        Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);

        if (attackerNodeId >= 0)
        {
            Ptr<BlackholeBehavior> behavior = CreateObject<BlackholeBehavior>();
            behavior->SetAttribute("AttackStartTime", TimeValue(Seconds(1.0)));
            mtcAodv.InstallAttackBehavior(nodes.Get(attackerNodeId), behavior);
        }

        ChainOutcome outcome;

        // Observateur sur N0 uniquement : c'est lui qui remet le paquet à N1 et
        // qui doit entendre la retransmission. L'observateur ne reçoit AUCUNE
        // information sur l'identité de l'attaquant.
        Ptr<ForwardingObserver> observer = CreateObject<ForwardingObserver>();
        observer->SetAttribute("Enabled", BooleanValue(observationEnabled));
        observer->TraceConnectWithoutContext(
            "ObservationClosed",
            MakeBoundCallback(&ForwardingObserverTestCase::OnObservationClosed, &outcome));
        // Install() resout lui-meme le protocole de routage et se branche sur
        // les traces Ipv4L3Protocol. Le protocole de routage ignore totalement
        // l'existence de l'observateur.
        observer->Install(nodes.Get(0));

        // Observateur sur le RELAIS N1. Sans lui, `skippedLastHop` est
        // insatisfiable par construction : seul un nœud dont le prochain saut
        // EST la destination peut l'incrémenter, et N0 n'est jamais dans ce cas
        // (N2 est hors portée, la route passe toujours par N1). Il ne reçoit,
        // lui non plus, aucune information sur l'identité de l'attaquant.
        Ptr<ForwardingObserver> relayObserver = CreateObject<ForwardingObserver>();
        relayObserver->SetAttribute("Enabled", BooleanValue(observationEnabled));
        relayObserver->Install(nodes.Get(1));

        const uint16_t port = 9100;
        Ipv4Address destinationAddress = interfaces.GetAddress(2);
        PacketSinkHelper sinkHelper("ns3::UdpSocketFactory",
                                    InetSocketAddress(Ipv4Address::GetAny(), port));
        ApplicationContainer sinkApps = sinkHelper.Install(nodes.Get(2));
        sinkApps.Start(Seconds(0.5));
        sinkApps.Stop(Seconds(10.0));

        OnOffHelper source("ns3::UdpSocketFactory",
                           InetSocketAddress(destinationAddress, port));
        source.SetAttribute("DataRate", DataRateValue(DataRate("16kbps")));
        source.SetAttribute("PacketSize", UintegerValue(512));
        source.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1e9]"));
        source.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0.0]"));
        ApplicationContainer sourceApps = source.Install(nodes.Get(0));
        sourceApps.Start(Seconds(3.0));
        sourceApps.Stop(Seconds(9.0));

        Simulator::Stop(Seconds(10.0));
        Simulator::Run();

        Ptr<PacketSink> sink = DynamicCast<PacketSink>(sinkApps.Get(0));
        outcome.deliveredBytes = sink ? sink->GetTotalRx() : 0;
        outcome.windowsOpened = observer->GetWindowsOpened();
        outcome.windowsMatched = observer->GetWindowsMatched();
        outcome.windowsDeadline = observer->GetWindowsDeadline();
        outcome.windowsEvicted = observer->GetWindowsEvicted();
        outcome.collisions = observer->GetFingerprintCollisions();
        outcome.skippedLastHop = observer->GetSkippedLastHop();
        outcome.transmissions = observer->GetTransmissionsInspected();
        outcome.relayTransmissions = relayObserver->GetTransmissionsInspected();
        outcome.relayWindowsOpened = relayObserver->GetWindowsOpened();
        outcome.relaySkippedLastHop = relayObserver->GetSkippedLastHop();

        Simulator::Destroy();
        return outcome;
    }

    void DoRun() override
    {
        // ---- 1. Relais honnête : l'observation doit aboutir ----
        const ChainOutcome honest = RunChain(-1, true);

        // N0 est la SOURCE. Une premiere version accrochait Forwarding(), qui ne
        // traite que le transit : une source ne l'appelle jamais pour ses propres
        // paquets, donc aucune fenetre ne s'ouvrait. Cette assertion protege
        // desormais le cas DOMINANT d'un chemin a deux sauts.
        NS_TEST_ASSERT_MSG_GT(honest.transmissions,
                              0u,
                              "aucune emission IPv4 examinee : les traces "
                              "Ipv4L3Protocol ne sont pas branchees");
        NS_TEST_ASSERT_MSG_GT(honest.windowsOpened,
                              0u,
                              "aucune fenetre ouverte alors que N0 est la source "
                              "d'un chemin a deux sauts : l'observation ne se "
                              "declenche pas la ou il y a quelque chose a voir");
        NS_TEST_ASSERT_MSG_GT(honest.windowsMatched,
                              0u,
                              "un relais honnete n'a produit aucun appariement : "
                              "l'ecoute passive ou l'empreinte est cassee");
        NS_TEST_ASSERT_MSG_EQ(honest.tracedObserved,
                              honest.windowsMatched,
                              "la TraceSource et les compteurs internes divergent");

        // Conservation : toute fenetre ouverte finit close. Une fuite signalerait
        // des fenetres restees ouvertes en fin de simulation, donc des
        // observations perdues sans que rien ne le signale.
        const uint64_t closed = honest.windowsMatched + honest.windowsDeadline +
                                honest.windowsEvicted;
        NS_TEST_ASSERT_MSG_LT_OR_EQ(closed,
                                    honest.windowsOpened,
                                    "plus de clotures que d'ouvertures : comptabilite fausse");
        NS_TEST_ASSERT_MSG_EQ(honest.tracedClosures,
                              closed,
                              "des clotures n'ont pas emis la TraceSource");

        NS_TEST_ASSERT_MSG_EQ(honest.collisions,
                              0u,
                              "collision d'empreinte sur un flux unique : "
                              "l'identification IPv4 ne discrimine pas");

        // ---- 1bis. LE DERNIER SAUT, teste la ou il existe ----
        // Le dernier saut N1->N2 doit etre RECONNU et ecarte : N2 consomme le
        // paquet et ne le retransmettra jamais. Ouvrir une fenetre dessus
        // transformerait chaque livraison honnete en non-observation -- le
        // defaut exact de la premiere version de cette etape.
        //
        // Une version anterieure de CE TEST assertait skippedLastHop > 0 sur
        // l'observateur de N0. C'etait insatisfiable par construction : N2 est
        // hors portee de N0, donc le prochain saut de N0 est TOUJOURS N1 et
        // jamais la destination. L'assertion etait juste sur le fond et fausse
        // sur le lieu. Elle porte desormais sur chaque role la ou sa propriete
        // peut exister.
        NS_TEST_ASSERT_MSG_EQ(honest.skippedLastHop,
                              0u,
                              "N0 a ecarte un dernier saut alors que sa destination "
                              "est hors de portee : la resolution du prochain saut "
                              "est fausse");
        NS_TEST_ASSERT_MSG_GT(honest.relayTransmissions,
                              0u,
                              "le relais N1 n'a examine aucune emission : la trace "
                              "UnicastForward n'est pas branchee sur le transit");
        NS_TEST_ASSERT_MSG_GT(honest.relaySkippedLastHop,
                              0u,
                              "aucune emission ecartee comme dernier saut en N1 : "
                              "l'observateur ouvrirait des fenetres sur des "
                              "paquets que personne ne relaiera jamais");

        // L'ANTI-REGRESSION PROPREMENT DITE. La version defectueuse ouvrait des
        // fenetres exactement ici -- au relais, sur le saut final -- et nulle
        // part ailleurs. Un seul window ouvert en N1 signe son retour.
        NS_TEST_ASSERT_MSG_EQ(honest.relayWindowsOpened,
                              0u,
                              "le relais a ouvert une fenetre sur le saut final : "
                              "la destination ne retransmet jamais, chaque livraison "
                              "honnete serait comptee comme une non-observation");

        // ---- 1ter. `available` n'est pas `value = 0` ----
        // Une version anterieure declarait passiveVisibility TOUJOURS disponible,
        // avec la valeur 0 quand le voisin n'avait rien diffuse, au motif que
        // « la reponse est toujours connue ». Elle ne l'est pas : on sait si l'on
        // a ENTENDU le voisin, pas s'il ETAIT AUDIBLE. AODV ne diffuse que
        // periodiquement, donc un voisin parfaitement audible peut se taire.
        //
        // Or dans l'Eq. (7) une caracteristique DISPONIBLE valant exactement 0
        // est un veto absolu, quel que soit son poids : 0^(w/c) = 0. Mesure sur
        // le run STEP 3 : 85,2 % des evenements etaient ainsi annules, pour une
        // caracteristique sans aucun pouvoir discriminant (0.1466 chez
        // l'honnete contre 0.1484 chez l'attaquant, z = +0.26).
        //
        // L'invariant ne depend d'aucun alea de calendrier : disponible IMPLIQUE
        // valeur non nulle. Le cas « rien entendu » se code INDISPONIBLE.
        NS_TEST_ASSERT_MSG_EQ(honest.visibilityAvailableAndZero,
                              0u,
                              "passiveVisibility declaree disponible avec la valeur 0 : "
                              "c'est un veto dans l'Eq. (7), alors qu'un silence "
                              "signifie seulement qu'on ignore si le voisin etait audible");

        // ---- 1quater. La mesure ACTIVE du lien doit exister ----
        // `passiveVisibility` s'est revelee sans pouvoir discriminant : 0.1466
        // chez l'honnete contre 0.1484 chez l'attaquant (z = +0.26), parce
        // qu'elle mesurait la probabilite qu'un HELLO AODV tombe dans la
        // fenetre (1 s d'intervalle, fenetre de 150 ms, soit 0.15) et non
        // l'audibilite du voisin. `linkReliability` la remplace : un ACK MAC
        // prouve que j a recu, donc qu'il y avait une opportunite de le voir
        // relayer. Sans cette assertion, une trace mal branchee laisserait la
        // caracteristique silencieusement indisponible et OCEA n'aurait de
        // nouveau aucune entree exploitable.
        NS_TEST_ASSERT_MSG_GT(honest.linkReliabilityAvailable,
                              0u,
                              "linkReliability n'est disponible sur aucun evenement : "
                              "les traces AckedMpdu/NAckedMpdu ne sont pas branchees, "
                              "ou la MAC du voisin n'a jamais ete apprise");

        // L'ASSERTION RETIREE ICI, et pourquoi. Elle exigeait une fiabilite
        // moyenne > 0.5 vers un relais honnete a portee. Elle ne pouvait PAS
        // echouer : la premiere instrumentation ne branchait que `AckedMpdu`,
        // donc chaque bit valait 1 et la fiabilite valait structurellement 1.0.
        // Mesure sur le run reel : 1.0000 partout, moyenne et mediane, honnete
        // et attaquant. Une assertion qui ne peut pas echouer est PIRE que pas
        // d'assertion -- elle donne l'illusion d'une verification.
        //
        // L'arithmetique de la fenetre glissante est desormais verifiee par
        // LinkReliabilityArithmeticTestCase, sans simulation : une chaine aux
        // liens parfaits ne peut pas exercer le chemin d'echec.

        // ---- 1quinquies. Le GEL de x_link doit reellement s'executer ----
        // Si le gel etait branche mais toujours indisponible, la caracteristique
        // disparaitrait silencieusement de l'Eq. (7) sans qu'aucune autre
        // assertion ne bronche -- le meme mode de defaillance que
        // l'instrumentation borgne des ACK.
        NS_TEST_ASSERT_MSG_GT(honest.linkReliabilityAvailable,
                              0u,
                              "x_link gelee indisponible sur TOUS les evenements : "
                              "le gel a l'ouverture ne s'execute pas, ou la MAC du "
                              "voisin n'est jamais apprise avant la premiere fenetre");

        // ---- 2. Relais Blackhole : les fenetres doivent expirer ----
        // L'observateur n'a AUCUN acces a l'identite de l'attaquant ; il ne peut
        // que constater l'absence de retransmission.
        const ChainOutcome attacked = RunChain(1, true);

        NS_TEST_ASSERT_MSG_GT(attacked.windowsDeadline,
                              0u,
                              "un Blackhole n'a produit aucune non-observation : "
                              "l'observateur ne detecte pas l'absence de transfert");
        NS_TEST_ASSERT_MSG_GT(honest.windowsMatched,
                              attacked.windowsMatched,
                              "le relais honnete doit etre observe strictement plus "
                              "souvent que le Blackhole ; sinon l'observation ne "
                              "porte aucune information");

        // ---- 3. NON-INTRUSION : l'observation ne change pas la livraison ----
        // L'observateur est INSTALLE dans les deux cas ; seul son interrupteur
        // change. C'est deliberement plus exigeant que de ne pas l'installer du
        // tout : si le simple passage du MAC en mode promiscuite modifiait la
        // livraison, cette assertion echouerait, et ce serait un RESULTAT a
        // rapporter -- pas un obstacle a contourner en retirant l'installation.
        const ChainOutcome honestWithoutObserver = RunChain(-1, false);
        NS_TEST_ASSERT_MSG_EQ(honestWithoutObserver.deliveredBytes,
                              honest.deliveredBytes,
                              "l'observation a change la livraison : STEP 3 doit etre "
                              "STRICTEMENT observationnel, un gain serait un bug");
        NS_TEST_ASSERT_MSG_EQ(honestWithoutObserver.windowsOpened,
                              0u,
                              "l'observateur desactive a quand meme ouvert des fenetres");
        NS_TEST_ASSERT_MSG_EQ(honestWithoutObserver.transmissions,
                              0u,
                              "l'observateur desactive a quand meme inspecte des emissions");
        NS_TEST_ASSERT_MSG_EQ(honestWithoutObserver.relayTransmissions,
                              0u,
                              "l'observateur desactive du relais a inspecte des emissions");
        NS_TEST_ASSERT_MSG_EQ(honestWithoutObserver.relaySkippedLastHop,
                              0u,
                              "l'observateur desactive du relais a ecarte des emissions");
    }
};

/**
 * @brief Arithmetique de la fiabilite de lien, SANS simulation.
 *
 * Une chaine aux liens parfaits ne peut pas exercer le chemin d'echec : c'est
 * ainsi qu'une instrumentation ne branchant que `AckedMpdu` a produit une
 * fiabilite structurellement egale a 1.0 sur 10 962 evenements sans qu'aucune
 * assertion ne bronche. Ce cas de test alimente donc directement les issues.
 */
class LinkReliabilityArithmeticTestCase : public TestCase
{
  public:
    LinkReliabilityArithmeticTestCase()
        : TestCase("Fiabilite de lien : fenetre glissante bornee de 32 issues")
    {
    }

  private:
    void DoRun() override
    {
        const Mac48Address peer("00:00:00:00:00:01");
        const Mac48Address other("00:00:00:00:00:02");
        double value = 0.0;

        Ptr<ForwardingObserver> observer = CreateObject<ForwardingObserver>();
        observer->SetAttribute("Enabled", BooleanValue(true));

        // Pair inconnu : INDISPONIBLE, jamais une valeur par defaut.
        NS_TEST_ASSERT_MSG_EQ(observer->TryGetLinkReliabilityForPeer(peer, value),
                              false,
                              "un pair sans historique doit etre INDISPONIBLE");

        // Sous le minimum (4 par defaut) : toujours indisponible. Publier une
        // fraction calculee sur une ou deux emissions donnerait 0 ou 1 sur
        // presque rien, et une valeur nulle DISPONIBLE est un veto dans l'Eq. (7).
        observer->RecordLinkOutcome(peer, true);
        observer->RecordLinkOutcome(peer, true);
        NS_TEST_ASSERT_MSG_EQ(observer->TryGetLinkReliabilityForPeer(peer, value),
                              false,
                              "2 issues < LinkReliabilityMinSamples : doit rester indisponible");

        // 2 succes + 2 echecs = 0.5. C'EST le test que l'assertion retiree
        // aurait du etre : il echoue si le chemin d'echec n'est pas cable.
        observer->RecordLinkOutcome(peer, false);
        observer->RecordLinkOutcome(peer, false);
        NS_TEST_ASSERT_MSG_EQ(observer->TryGetLinkReliabilityForPeer(peer, value),
                              true,
                              "4 issues : la fiabilite doit devenir disponible");
        NS_TEST_ASSERT_MSG_EQ_TOL(value, 0.5, 1e-12,
                                  "2 succes sur 4 issues doivent donner exactement 0.5");

        NS_TEST_ASSERT_MSG_EQ(observer->GetLinkSuccesses(), 2u, "succes mal comptes");
        NS_TEST_ASSERT_MSG_EQ(observer->GetLinkFailures(), 2u, "echecs mal comptes");
        NS_TEST_ASSERT_MSG_EQ(observer->GetLinkOutcomesRecorded(), 4u, "total incoherent");

        // Que des echecs : 0.0 DISPONIBLE. Ce zero est LEGITIME -- si aucune
        // emission recente vers j n'a abouti, il n'y avait reellement aucune
        // opportunite d'observer un transfert, et le veto de l'Eq. (7) est la
        // bonne reponse. C'est le seul cas ou la valeur 0 doit etre publiee.
        for (int i = 0; i < 4; ++i)
        {
            observer->RecordLinkOutcome(other, false);
        }
        NS_TEST_ASSERT_MSG_EQ(observer->TryGetLinkReliabilityForPeer(other, value),
                              true,
                              "4 echecs suffisent : la valeur 0 est CONNUE, pas ignoree");
        NS_TEST_ASSERT_MSG_EQ_TOL(value, 0.0, 1e-12,
                                  "que des echecs doit donner exactement 0.0");

        // Borne dure : au-dela de 32 issues, les plus anciennes sortent du mot.
        // 32 echecs puis 32 succes doivent rendre 1.0, et non 0.5.
        const Mac48Address third("00:00:00:00:00:03");
        for (int i = 0; i < 32; ++i)
        {
            observer->RecordLinkOutcome(third, false);
        }
        for (int i = 0; i < 32; ++i)
        {
            observer->RecordLinkOutcome(third, true);
        }
        NS_TEST_ASSERT_MSG_EQ(observer->TryGetLinkReliabilityForPeer(third, value), true,
                              "64 issues : disponible");
        NS_TEST_ASSERT_MSG_EQ_TOL(value, 1.0, 1e-12,
                                  "la fenetre ne retient que les 32 dernieres issues ; "
                                  "obtenir 0.5 signifierait que les anciennes persistent");

        // ---- Le filtrage par RAISON de rejet ----
        // Une seule des quatre raisons atteste d'une defaillance de LIEN. Les
        // deux raisons de congestion decrivent l'etat local de i : les compter
        // ici ferait de linkReliability une mesure de congestion deguisee,
        // portant deux phenomenes distincts sous un seul nom.
        NS_TEST_ASSERT_MSG_EQ(ForwardingObserver::IsLinkFailureReason(
                                  WIFI_MAC_DROP_REACHED_RETRY_LIMIT),
                              true,
                              "l'epuisement des retransmissions EST une defaillance de lien");
        NS_TEST_ASSERT_MSG_EQ(ForwardingObserver::IsLinkFailureReason(
                                  WIFI_MAC_DROP_FAILED_ENQUEUE),
                              false,
                              "une file pleine chez i n'est pas une defaillance du lien i-j");
        NS_TEST_ASSERT_MSG_EQ(ForwardingObserver::IsLinkFailureReason(
                                  WIFI_MAC_DROP_EXPIRED_LIFETIME),
                              false,
                              "une expiration en file chez i n'est pas une defaillance de lien");
        NS_TEST_ASSERT_MSG_EQ(ForwardingObserver::IsLinkFailureReason(
                                  WIFI_MAC_DROP_QOS_OLD_PACKET),
                              false,
                              "un rejet d'ordonnancement QoS n'est pas une defaillance de lien");

        // Une adresse de groupe n'est jamais acquittee : la compter melerait des
        // emissions dont l'absence d'ACK ne dit rien du lien.
        const uint64_t before = observer->GetLinkOutcomesRecorded();
        observer->RecordLinkOutcome(Mac48Address::GetBroadcast(), false);
        NS_TEST_ASSERT_MSG_EQ(observer->GetLinkOutcomesRecorded(), before,
                              "une adresse de groupe ne doit pas entrer dans l'historique");
    }
};

/**
 * @brief \f$y_\ell\f$ : le diagnostic n'existe que si la MAC de \c j est
 *        connue A L'OUVERTURE.
 *
 * SANS SIMULATION. La fenêtre est ouverte à la main, puis évincée en abaissant
 * \c MaxActiveWindows à 1 : la clôture émet l'observation, qui porte les
 * drapeaux du diagnostic. On vérifie ainsi le GEL de la résolution IPv4 -> MAC
 * sans dépendre d'un scénario radio.
 *
 * POURQUOI CE GEL. Apprendre la correspondance EN COURS de fenêtre ferait
 * dépendre la DISPONIBILITÉ du diagnostic d'un fait postérieur à l'ouverture.
 * Une disponibilité qui varie avec ce qui est observé ensuite est le premier
 * pas vers une grandeur qui prédit son propre résultat — le défaut exact
 * corrigé sur \c linkReliability par le gel de \f$x_{link}\f$.
 */
class BenignDiagnosticAvailabilityTestCase : public TestCase
{
  public:
    BenignDiagnosticAvailabilityTestCase()
        : TestCase("Diagnostic y_l : indisponible quand la MAC du voisin est inconnue")
    {
    }

  private:
    /** @brief Dernière observation close, capturée depuis la trace. */
    struct Captured
    {
        bool seen{false};
        bool available{false};
        double value{-1.0};
    };

    static void OnClosed(Captured* captured, const ForwardingObservation& observation)
    {
        captured->seen = true;
        captured->available = observation.linkFailureDuringWindowAvailable;
        captured->value = observation.linkFailureDuringWindow;
    }

    /** @brief En-tête IPv4 minimal, identifié par son champ identification. */
    static Ipv4Header MakeHeader(uint16_t identification)
    {
        Ipv4Header header;
        header.SetSource(Ipv4Address("10.1.0.1"));
        header.SetDestination(Ipv4Address("10.1.0.3"));
        header.SetIdentification(identification);
        header.SetProtocol(17); // UDP
        header.SetPayloadSize(512);
        return header;
    }

    void DoRun() override
    {
        Captured captured;
        Ptr<ForwardingObserver> observer = CreateObject<ForwardingObserver>();
        observer->SetAttribute("Enabled", BooleanValue(true));
        // Une seule fenêtre active : la seconde ouverture évince la première,
        // ce qui force une clôture sans faire tourner le simulateur.
        observer->SetAttribute("MaxActiveWindows", UintegerValue(1));
        observer->TraceConnectWithoutContext(
            "ObservationClosed",
            MakeBoundCallback(&BenignDiagnosticAvailabilityTestCase::OnClosed, &captured));

        const Ipv4Address nextHop("10.1.0.2");
        observer->OpenWindow(MakeHeader(1), 512, nextHop);
        NS_TEST_ASSERT_MSG_EQ(observer->GetWindowsOpened(),
                              1,
                              "la premiere fenetre aurait du s'ouvrir");
        // La MAC de `j` n'a jamais été apprise : la cause n°1 d'indisponibilité
        // doit être COMPTÉE, jamais silencieuse.
        NS_TEST_ASSERT_MSG_EQ(observer->GetWindowsPeerMacUnknownAtOpen(),
                              1,
                              "une MAC inconnue a l'ouverture doit etre comptee");

        // Une issue MAC arrive pendant la fenêtre. Elle NE DOIT PAS rendre le
        // diagnostic disponible : le pont IPv4 -> MAC était absent à
        // l'ouverture, et le reconstituer après coup violerait le gel.
        observer->RecordLinkOutcome(Mac48Address("00:00:00:00:00:02"), false);

        observer->OpenWindow(MakeHeader(2), 512, nextHop); // évince la première

        NS_TEST_ASSERT_MSG_EQ(captured.seen, true, "la fenetre evincee doit etre close");
        NS_TEST_ASSERT_MSG_EQ(captured.available,
                              false,
                              "MAC inconnue a l'ouverture : le diagnostic doit rester "
                              "INDISPONIBLE, jamais une valeur par defaut");
        NS_TEST_ASSERT_MSG_EQ(observer->GetWindowsWithLinkOutcome(),
                              0,
                              "aucune fenetre ne doit compter d'issue attribuee");
        NS_TEST_ASSERT_MSG_EQ(observer->GetWindowsWithLinkFailure(),
                              0,
                              "aucune cause benigne ne doit etre constatee");

        // INVARIANTS DE COMPTAGE. Ils tiennent quelles que soient les données :
        // les écrire ici les rend vérifiables sur tout scénario ultérieur.
        NS_TEST_ASSERT_MSG_EQ(observer->GetWindowsWithLinkFailure() <=
                                  observer->GetWindowsWithLinkOutcome(),
                              true,
                              "y_l = 1 ne peut pas depasser a_l = 1");
        NS_TEST_ASSERT_MSG_EQ(observer->GetWindowsMultipleLinkOutcomes() <=
                                  observer->GetWindowsWithLinkOutcome(),
                              true,
                              "l'ambiguite ne peut pas depasser les fenetres evaluees");
    }
};

/** @brief Suite d'intégration de l'observateur de transfert (STEP 3). */
class ForwardingObserverTestSuite : public TestSuite
{
  public:
    ForwardingObserverTestSuite()
        : TestSuite("mtcaodv-forwarding-observer", Type::UNIT)
    {
        AddTestCase(new LinkReliabilityArithmeticTestCase, TestCase::Duration::QUICK);
        AddTestCase(new ForwardingObserverTestCase, TestCase::Duration::QUICK);
        AddTestCase(new BenignDiagnosticAvailabilityTestCase, TestCase::Duration::QUICK);
    }
};

static ForwardingObserverTestSuite g_forwardingObserverTestSuite;

} // namespace mtcaodv
} // namespace ns3
