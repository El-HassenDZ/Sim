#!/usr/bin/env python3
# MTCAODV_DELIVERY_REVISION: r20
"""Tests de analyze_features.py. Bibliotheque standard uniquement."""

import contextlib
import io
import json
import math
import tempfile
import unittest
from pathlib import Path

import analyze_features as f
from analyze_forwarding import ForwardingAnalysisError

HEADER = ("openTime_s,closeTime_s,observerNodeId,neighborNodeId,neighborIp,"
          "forwardingObserved,closureReason,senderAttributed,passiveVisibility,"
          "passiveVisibilityAvailable")


def _row(neighbor=1, observed=1, attributed=1, visibility=1.0, available=1,
         reason="MATCHED"):
    return (f"1.0,1.1,0,{neighbor},10.1.0.2,{observed},{reason},{attributed},"
            f"{visibility},{available}")


def _write(lines):
    path = Path(tempfile.mkdtemp()) / "obs.csv"
    path.write_text(HEADER + "\n" + "\n".join(lines) + "\n", encoding="utf-8")
    return path


def _manifest(attackers=(5,), nodes=30):
    path = Path(tempfile.mkdtemp()) / "man.json"
    path.write_text(json.dumps({
        "nodes": nodes,
        "attack": {"attackerNodeIds": list(attackers), "attackStart_s": 10.0},
    }), encoding="utf-8")
    return path



# Les tests bout-en-bout appellent main(), qui ECRIT son rapport sur stdout. Sans
# capture, `python3 -m unittest -q` deverse plusieurs ecrans de rapport et la
# ligne « Ran N tests OK » devient introuvable. On capture donc la sortie : ces
# tests verifient le CODE DE RETOUR, pas la mise en page.
def _silent(callable_, *args):
    """Execute en capturant stdout ; renvoie le code de retour."""
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        return callable_(*args)


class LoadTests(unittest.TestCase):
    def test_empty_file_is_refused(self):
        """Un fichier vide n'est pas une mesure nulle : on refuse de conclure."""
        path = Path(tempfile.mkdtemp()) / "obs.csv"
        path.write_text(HEADER + "\n", encoding="utf-8")
        with self.assertRaises(ForwardingAnalysisError):
            f.load_rows(path)

    def test_reads_availability_flag(self):
        rows = f.load_rows(_write([_row(available=0)]))
        self.assertFalse(rows[0]["visibilityAvailable"])


class CeilingTests(unittest.TestCase):
    def test_ceiling_counts_only_visible_non_observations(self):
        """Le plafond est le nombre de non-observations AVEC visibilite.

        Une non-observation sans visibilite donne O_e = 0 par l'Eq. (7), donc
        I_e = 0 : elle ne peut recevoir aucune masse malveillante, quels que
        soient les diagnostics ajoutes ensuite.
        """
        rows = f.load_rows(_write([
            _row(observed=0, visibility=1.0, reason="DEADLINE"),   # comptee
            _row(observed=0, visibility=0.0, reason="DEADLINE"),   # exclue
            _row(observed=0, visibility=0.0, reason="DEADLINE"),   # exclue
            _row(observed=1, visibility=1.0),                      # pas une non-obs
        ]))
        summary = f.summarise(rows, "test")
        self.assertEqual(summary["missed"], 3)
        self.assertEqual(summary["attributableCeiling"], 1)
        self.assertAlmostEqual(summary["attributableCeilingRate"], 1 / 3)

    def test_no_non_observation_gives_nan_not_zero(self):
        """Aucune non-observation : le plafond est INDEFINI, jamais 0."""
        rows = f.load_rows(_write([_row(observed=1), _row(observed=1)]))
        summary = f.summarise(rows, "test")
        self.assertEqual(summary["missed"], 0)
        self.assertTrue(math.isnan(summary["attributableCeilingRate"]))

    def test_unavailable_feature_excluded_from_visible_rate(self):
        """Une caracteristique indisponible n'est ni visible ni non visible."""
        rows = f.load_rows(_write([
            _row(visibility=1.0, available=1),
            _row(visibility=0.0, available=0),
        ]))
        summary = f.summarise(rows, "test")
        self.assertEqual(summary["available"], 1)
        self.assertAlmostEqual(summary["visibleRate"], 1.0)

    def test_conditional_rates_are_separate(self):
        """visible|vue et visible|non-vue sont mesures separement, jamais melanges."""
        rows = f.load_rows(_write([
            _row(observed=1, visibility=1.0),
            _row(observed=1, visibility=1.0),
            _row(observed=0, visibility=0.0, reason="DEADLINE"),
        ]))
        summary = f.summarise(rows, "test")
        self.assertAlmostEqual(summary["visibleGivenMatched"], 1.0)
        self.assertAlmostEqual(summary["visibleGivenMissed"], 0.0)


HEADER_V2 = HEADER + ",linkReliability,linkReliabilityAvailable"


def _row2(neighbor=1, observed=1, attributed=1, visibility=1.0, available=1,
          reason="MATCHED", link=1.0, link_available=1):
    """Ligne au format ETENDU, avec la mesure active du lien."""
    return (f"1.0,1.1,0,{neighbor},10.1.0.2,{observed},{reason},{attributed},"
            f"{visibility},{available},{link},{link_available}")


def _write2(lines):
    path = Path(tempfile.mkdtemp()) / "obs.csv"
    path.write_text(HEADER_V2 + "\n" + "\n".join(lines) + "\n", encoding="utf-8")
    return path


class CoverageTests(unittest.TestCase):
    def test_old_csv_without_link_columns_is_readable(self):
        """Un CSV anterieur reste lisible : lien declare INDISPONIBLE, jamais suppose."""
        rows = f.load_rows(_write([_row()]))
        self.assertFalse(rows[0]["linkAvailable"])
        self.assertEqual(f.summarise(rows, "t")["linkAvailable"], 0)

    def test_zero_link_reliability_vetoes_the_event(self):
        """linkReliability = 0 DISPONIBLE annule O_e : zero legitime, veto correct.

        Si aucune emission recente vers j n'a ete acquittee, il n'y avait
        reellement aucune opportunite d'observer un transfert. Le veto de
        l'Eq. (7) est alors la bonne reponse, contrairement au cas ou l'on
        ignore simplement si le voisin etait audible.
        """
        rows = f.load_rows(_write2([
            _row2(observed=0, reason="DEADLINE", visibility=0.0, available=0,
                  link=0.0, link_available=1),
        ]))
        summary = f.summarise(rows, "t")
        self.assertEqual(summary["vetoedByZeroLink"], 1)
        self.assertEqual(summary["realCeiling"], 0)

    def test_link_alone_gives_coverage(self):
        """La visibilite indisponible n'empeche plus l'interpretation."""
        rows = f.load_rows(_write2([
            _row2(observed=0, reason="DEADLINE", visibility=0.0, available=0,
                  link=0.9, link_available=1),
        ]))
        summary = f.summarise(rows, "t")
        self.assertAlmostEqual(summary["coverageRate"], 1.0)
        self.assertEqual(summary["realCeiling"], 1)
        # L'ancien plafond, fonde sur la seule visibilite, aurait compte 0.
        self.assertEqual(summary["attributableCeiling"], 0)

    def test_no_feature_available_gives_no_coverage(self):
        rows = f.load_rows(_write2([
            _row2(observed=0, reason="DEADLINE", visibility=0.0, available=0,
                  link=0.0, link_available=0),
        ]))
        summary = f.summarise(rows, "t")
        self.assertAlmostEqual(summary["coverageRate"], 0.0)
        self.assertEqual(summary["realCeiling"], 0)


class ValueStatisticsTests(unittest.TestCase):
    """La VALEUR de la caracteristique, pas seulement sa disponibilite.

    Erreur de methode commise avec `passiveVisibility` : mesurer si la
    caracteristique existe et oublier ce qu'elle contient.
    """

    def test_mean_split_by_observation(self):
        rows = f.load_rows(_write2([
            _row2(observed=1, link=1.0),
            _row2(observed=1, link=0.8),
            _row2(observed=0, reason="DEADLINE", link=0.4),
            _row2(observed=0, reason="DEADLINE", link=0.6),
        ]))
        s = f.summarise(rows, "t")
        self.assertAlmostEqual(s["linkMeanMatched"], 0.9)
        self.assertAlmostEqual(s["linkMeanMissed"], 0.5)
        self.assertAlmostEqual(s["linkMedianMissed"], 0.5)
        self.assertAlmostEqual(s["linkMean"], 0.7)

    def test_unavailable_values_are_excluded_not_counted_as_zero(self):
        """Une caracteristique indisponible n'entre pas dans la moyenne."""
        rows = f.load_rows(_write2([
            _row2(observed=1, link=1.0, link_available=1),
            _row2(observed=1, link=0.0, link_available=0),
        ]))
        self.assertAlmostEqual(f.summarise(rows, "t")["linkMean"], 1.0)

    def test_no_available_value_gives_nan_not_zero(self):
        rows = f.load_rows(_write2([_row2(link=0.0, link_available=0)]))
        self.assertTrue(math.isnan(f.summarise(rows, "t")["linkMean"]))

    def test_median_of_even_sample(self):
        self.assertAlmostEqual(f._median([0.2, 0.4, 0.6, 0.8]), 0.5)
        self.assertTrue(math.isnan(f._median([])))


class DegradedLinkTests(unittest.TestCase):
    """La FRACTION degradee, mesuree directement et non deduite d'une moyenne.

    Sur une plage dynamique de 0.9928 a 1.0000, la moyenne ecrase le signal :
    une fraction de 23 % d'evenements a 0.969 et une moyenne de 0.993 decrivent
    la meme chose, mais seule la premiere est lisible.
    """

    def test_degraded_fraction_split_by_observation(self):
        rows = f.load_rows(_write2([
            _row2(observed=1, link=1.0),
            _row2(observed=1, link=0.96875),
            _row2(observed=0, reason="DEADLINE", link=0.96875),
            _row2(observed=0, reason="DEADLINE", link=1.0),
            _row2(observed=0, reason="DEADLINE", link=1.0),
            _row2(observed=0, reason="DEADLINE", link=1.0),
        ]))
        s = f.summarise(rows, "t")
        self.assertAlmostEqual(s["degradedRateMatched"], 0.5)
        self.assertAlmostEqual(s["degradedRateMissed"], 0.25)
        self.assertEqual(s["degradedCountMissed"], 1)

    def test_perfect_links_give_zero_not_nan(self):
        """Aucun lien degrade est une MESURE (0), pas une absence de mesure."""
        rows = f.load_rows(_write2([_row2(observed=0, reason="DEADLINE", link=1.0)]))
        self.assertAlmostEqual(f.summarise(rows, "t")["degradedRateMissed"], 0.0)

    def test_no_available_link_gives_nan_not_zero(self):
        """Sans aucune mesure disponible, la fraction est INDEFINIE."""
        rows = f.load_rows(_write2([_row2(observed=0, reason="DEADLINE",
                                          link=0.0, link_available=0)]))
        self.assertTrue(math.isnan(f.summarise(rows, "t")["degradedRateMissed"]))

    def test_unavailable_rows_excluded_from_denominator(self):
        rows = f.load_rows(_write2([
            _row2(observed=0, reason="DEADLINE", link=0.5, link_available=1),
            _row2(observed=0, reason="DEADLINE", link=0.0, link_available=0),
        ]))
        self.assertAlmostEqual(f.summarise(rows, "t")["degradedRateMissed"], 1.0)


HEADER_V3 = HEADER_V2 + ",linkReliabilityAtClose,linkReliabilityAtCloseAvailable"


def _row3(neighbor=1, observed=1, link=1.0, link_available=1,
          at_close=1.0, at_close_available=1, reason="MATCHED"):
    """Ligne au format ETENDU + colonnes diagnostic de fuite temporelle."""
    return (f"1.0,1.1,0,{neighbor},10.1.0.2,{observed},{reason},1,"
            f"1.0,1,{link},{link_available},{at_close},{at_close_available}")


def _write3(lines):
    path = Path(tempfile.mkdtemp()) / "obs.csv"
    path.write_text(HEADER_V3 + "\n" + "\n".join(lines) + "\n", encoding="utf-8")
    return path


class TemporalLeakTests(unittest.TestCase):
    """L'ecart entre x_link gelee et la meme valeur recalculee a la cloture.

    Un ecart non nul prouve que la version precedente faisait entrer dans
    l'Eq. (7) des informations posterieures a l'ouverture -- dont l'issue MAC
    de la transmission qui a ouvert la fenetre. Le couplage est causal : un
    echec MAC vers j implique que j n'a jamais recu le paquet, donc z_e = 0.
    """

    def test_leak_counted_when_values_differ(self):
        rows = f.load_rows(_write3([
            _row3(observed=0, reason="DEADLINE", link=1.0, at_close=0.96875),
            _row3(observed=1, link=1.0, at_close=1.0),
        ]))
        s = f.summarise(rows, "t")
        self.assertEqual(s["leakedCount"], 1)
        self.assertEqual(s["leakedCountMissed"], 1)

    def test_no_leak_when_values_match(self):
        rows = f.load_rows(_write3([_row3(link=1.0, at_close=1.0)]))
        self.assertEqual(f.summarise(rows, "t")["leakedCount"], 0)

    def test_unavailable_close_value_is_not_a_leak(self):
        """Une valeur de cloture indisponible ne peut pas etre comparee."""
        rows = f.load_rows(_write3([_row3(link=1.0, at_close=0.0,
                                          at_close_available=0)]))
        self.assertEqual(f.summarise(rows, "t")["leakedCount"], 0)

    def test_direction_is_split(self):
        """Baisse et hausse ne sont pas la meme chose.

        La fenetre glissante change aussi quand un echec ANCIEN en SORT : la
        valeur MONTE, ce qui est inoffensif. Seule la BAISSE traduit un echec
        qui vient d'entrer, et c'est le cas causalement dangereux. Les
        confondre surestimerait la contamination.
        """
        rows = f.load_rows(_write3([
            _row3(observed=0, reason="DEADLINE", link=1.0, at_close=0.96875),  # baisse
            _row3(observed=1, link=0.96875, at_close=1.0),                     # hausse
            _row3(observed=1, link=1.0, at_close=1.0),                         # stable
        ]))
        s = f.summarise(rows, "t")
        self.assertEqual(s["leakedCount"], 2)
        self.assertEqual(s["leakedDown"], 1)
        self.assertEqual(s["leakedDownMissed"], 1)
        self.assertEqual(s["leakedUp"], 1)

    def test_old_csv_without_diagnostic_columns_reports_no_leak(self):
        """Un CSV anterieur n'a pas les colonnes : 0, jamais une erreur."""
        rows = f.load_rows(_write2([_row2()]))
        self.assertEqual(f.summarise(rows, "t")["leakedCount"], 0)


class EncodingTests(unittest.TestCase):
    def test_old_encoding_is_detected(self):
        """Disponible avec valeur 0 = CSV anterieur a la correction d'encodage.

        Une caracteristique DISPONIBLE valant 0 est un veto absolu dans
        l'Eq. (7) : 0^(w/c) = 0 quel que soit le poids. L'encodage correct pour
        « je ne sais pas si le voisin etait audible » est INDISPONIBLE. Le
        script doit signaler un tel fichier plutot que d'en tirer des taux
        interpretes comme s'ils venaient de l'encodage corrige.
        """
        rows = f.load_rows(_write([
            _row(visibility=0.0, available=1),
            _row(visibility=1.0, available=1),
        ]))
        self.assertEqual(f.summarise(rows, "test")["availableAndZero"], 1)

    def test_corrected_encoding_reports_none(self):
        rows = f.load_rows(_write([
            _row(visibility=1.0, available=1),
            _row(visibility=0.0, available=0),
        ]))
        self.assertEqual(f.summarise(rows, "test")["availableAndZero"], 0)


HEADER_V4 = HEADER_V3 + ",linkFailureDuringWindow,linkFailureDuringWindowAvailable"


def _row4(neighbor=1, observed=1, link=1.0, link_available=1,
          benign=0.0, benign_available=1, reason="MATCHED", attributed=1):
    """Ligne au format ETENDU + le premier diagnostic y_l (Eq. 8).

    La colonne `linkOutcomesDuringWindow` est concatenee par l'appelant quand
    le test en a besoin (`_write4(..., outcomes=True)`), afin que les tests
    anterieurs restent lisibles sans elle.
    """
    return (f"1.0,1.1,0,{neighbor},10.1.0.2,{observed},{reason},{attributed},"
            f"1.0,1,{link},{link_available},1.0,1,{benign},{benign_available}")


def _write4(lines, outcomes=False):
    header = HEADER_V4 + (",linkOutcomesDuringWindow" if outcomes else "")
    path = Path(tempfile.mkdtemp()) / "obs.csv"
    path.write_text(header + "\n" + "\n".join(lines) + "\n", encoding="utf-8")
    return path


class DiagnosticCoverageTests(unittest.TestCase):
    """d_e, le facteur limitant de STEP 4.

    Sans un seul y_l disponible, l'Eq. (8) renvoie (0,0,0,1) pour TOUS les
    evenements : l'attribution ne dit rien. Ces tests portent sur la mesure de
    cette couverture, et surtout sur la distinction entre les trois etats que
    les masses seules ne separent pas.
    """

    def test_missing_column_is_not_a_measured_zero(self):
        """Un CSV SANS la colonne n'est pas un run SANS diagnostic.

        Le confondre ferait lire une propriete du FICHIER comme une mesure du
        RUN -- exactement le motif de defaut recense cinq fois dans ce projet.
        """
        rows = f.load_rows(_write3([_row3(observed=0, reason="DEADLINE")]))
        summary = f.summarise(rows, "t")
        self.assertFalse(summary["benignColumnPresent"])
        self.assertEqual(summary["benignAvailable"], 0)

    def test_present_column_is_reported_as_present(self):
        rows = f.load_rows(_write4([_row4()]))
        self.assertTrue(f.summarise(rows, "t")["benignColumnPresent"])

    def test_availability_and_value_are_counted_separately(self):
        """`available` et `value` ne sont pas interchangeables, ici non plus.

        Trois lignes : diagnostic evaluable et negatif, evaluable et positif,
        non evaluable. Les trois comptent differemment.
        """
        rows = f.load_rows(_write4([
            _row4(benign=0.0, benign_available=1),
            _row4(benign=1.0, benign_available=1),
            _row4(benign=0.0, benign_available=0),
        ]))
        summary = f.summarise(rows, "t")
        self.assertEqual(summary["benignAvailable"], 2)
        self.assertEqual(summary["benignPositive"], 1)
        self.assertAlmostEqual(summary["benignAvailableRate"], 2 / 3)
        self.assertAlmostEqual(summary["benignPositiveRate"], 0.5)

    def test_unexplained_non_observations_are_counted(self):
        """LE chiffre de l'etape : les non-observations sans cause benigne.

        Quatre non-observations evaluables, dont une expliquee par un echec de
        lien. Les trois autres recevront une masse malveillante.
        """
        rows = f.load_rows(_write4([
            _row4(observed=0, reason="DEADLINE", benign=1.0),
            _row4(observed=0, reason="DEADLINE", benign=0.0),
            _row4(observed=0, reason="DEADLINE", benign=0.0),
            _row4(observed=0, reason="DEADLINE", benign=0.0),
            _row4(observed=1, benign=0.0),  # appariee : hors du compte
        ]))
        summary = f.summarise(rows, "t")
        self.assertEqual(summary["attributableMissed"], 4)
        self.assertEqual(summary["unexplainedMissed"], 3)
        self.assertAlmostEqual(summary["unexplainedMissedRate"], 0.75)

    def test_unevaluable_diagnostic_leaves_event_out_of_the_count(self):
        """Un diagnostic NON evaluable ne rend pas l'evenement inexplique.

        Il le rend NON ATTRIBUABLE. Compter les deux ensemble gonflerait la
        masse malveillante d'evenements sur lesquels on n'a rien mesure.
        """
        rows = f.load_rows(_write4([
            _row4(observed=0, reason="DEADLINE", benign=0.0, benign_available=0),
            _row4(observed=0, reason="DEADLINE", benign=0.0, benign_available=1),
        ]))
        summary = f.summarise(rows, "t")
        self.assertEqual(summary["attributableMissed"], 1)
        self.assertEqual(summary["unexplainedMissed"], 1)

    def test_veto_removes_the_event_before_the_diagnostic_applies(self):
        """Un veto de l'Eq. (7) sort l'evenement avant que l'Eq. (8) ne compte.

        I_e = O_e d_e : si O_e = 0, aucun diagnostic ne peut rendre l'evenement
        attribuable. L'ordre des deux equations n'est pas commutatif.
        """
        rows = f.load_rows(_write4([
            _row4(observed=0, reason="DEADLINE", link=0.0, link_available=1,
                  benign=0.0, benign_available=1),
        ]))
        summary = f.summarise(rows, "t")
        self.assertEqual(summary["attributableMissed"], 0)
        self.assertEqual(summary["unexplainedMissed"], 0)


class AmbiguityCrossTabTests(unittest.TestCase):
    """Le croisement qui decide si les attributions benignes sont fiables."""

    def test_exact_and_ambiguous_are_restricted_to_non_observations(self):
        """Une attribution benigne sur une fenetre APPARIEE ne compte pas.

        A3.3 ligne 2 court-circuite des z_e = 1 : y_l n'entre alors dans aucune
        equation. La compter melangerait au chiffre utile des evenements qui
        n'influencent rien -- exactement ce qui rendait le resultat r18
        indeterminable entre deux conclusions opposees.
        """
        rows = f.load_rows(_write4([
            # Non-observations : 1 exacte, 2 ambigues.
            _row4(observed=0, reason="DEADLINE", benign=1.0) + ",1",
            _row4(observed=0, reason="DEADLINE", benign=1.0) + ",4",
            _row4(observed=0, reason="DEADLINE", benign=1.0) + ",7",
            # Appariee avec y_l = 1 : NE DOIT PAS entrer dans le compte.
            _row4(observed=1, benign=1.0) + ",1",
        ], outcomes=True))
        summary = f.summarise(rows, "t")
        self.assertEqual(summary["benignPositiveExactMissed"], 1)
        self.assertEqual(summary["benignPositiveAmbiguousMissed"], 2)

    def test_cross_tab_detects_identical_sets(self):
        """Deux hors-diagonales nulles = ensembles identiques, a instruire."""
        rows = f.load_rows(_write4([
            _row4(observed=1, benign=0.0, benign_available=1) + ",1",
            _row4(observed=1, benign=0.0, benign_available=1) + ",1",
        ], outcomes=True))
        summary = f.summarise(rows, "t")
        self.assertEqual(summary["attributedAndAvailable"], 2)
        self.assertEqual(summary["attributedNotAvailable"], 0)
        self.assertEqual(summary["notAttributedButAvailable"], 0)

    def test_cross_tab_separates_distinct_sets(self):
        """Des effectifs egaux mais des ensembles distincts se voient ici."""
        rows = f.load_rows(_write4([
            _row4(observed=1, benign_available=1, attributed=1) + ",1",
            _row4(observed=1, benign_available=0, attributed=1) + ",0",
            _row4(observed=1, benign_available=1, attributed=0) + ",1",
        ], outcomes=True))
        summary = f.summarise(rows, "t")
        self.assertEqual(summary["attributedNotAvailable"], 1)
        self.assertEqual(summary["notAttributedButAvailable"], 1)


class MainTests(unittest.TestCase):
    def test_runs_end_to_end(self):
        csv_path = _write([
            _row(neighbor=1, observed=1, visibility=1.0),
            _row(neighbor=5, observed=0, visibility=1.0, reason="DEADLINE"),
            _row(neighbor=5, observed=0, visibility=0.0, reason="DEADLINE"),
        ])
        self.assertEqual(_silent(f.main, ["--observations", str(csv_path),
                                 "--manifest", str(_manifest())]), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
