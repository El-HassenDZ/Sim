#!/usr/bin/env python3
"""Tests de analyze_baseline_seeds.py. Bibliotheque standard uniquement."""

import contextlib
import io
import json
import math
import tempfile
import unittest
from pathlib import Path

import analyze_baseline_seeds as b
from analyze_forwarding import ForwardingAnalysisError

HEADER = ("openTime_s,closeTime_s,observerNodeId,neighborNodeId,neighborIp,"
          "forwardingObserved,closureReason,senderAttributed,passiveVisibility,"
          "passiveVisibilityAvailable,linkReliability,linkReliabilityAvailable")


def _row(neighbor=1, observed=1, reason="MATCHED"):
    return (f"1.0,1.1,0,{neighbor},10.1.0.2,{observed},{reason},1,1.0,1,1.0,1")


def _obs(lines):
    path = Path(tempfile.mkdtemp()) / "obs.csv"
    path.write_text(HEADER + "\n" + "\n".join(lines) + "\n", encoding="utf-8")
    return path


def _man(attackers=(5,), nodes=30, seed=2):
    path = Path(tempfile.mkdtemp()) / "man.json"
    path.write_text(json.dumps({
        "seed": seed, "nodes": nodes,
        "attack": {"attackerNodeIds": list(attackers), "attackStart_s": 10.0},
    }), encoding="utf-8")
    return path


def _silent(callable_, *args):
    """Execute en capturant stdout ET stderr ; renvoie le code de retour.

    Les chemins de REFUS ecrivent sur stderr : sans capture, `unittest -q`
    afficherait les messages d'erreur des tests qui verifient precisement que
    ces refus surviennent, et la ligne « Ran N tests » deviendrait illisible.
    Ces tests verifient le CODE DE RETOUR, pas la mise en page.
    """
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        return callable_(*args)


class SeedSummaryTests(unittest.TestCase):
    def test_counts_only_honest_neighbours(self):
        obs = _obs([_row(neighbor=1, observed=1),
                    _row(neighbor=5, observed=0, reason="DEADLINE"),
                    _row(neighbor=2, observed=0, reason="DEADLINE")])
        s = b.summarise_seed(obs, _man(attackers=(5,)))
        self.assertEqual(s["honest"], 2)
        self.assertEqual(s["missed"], 1)
        self.assertAlmostEqual(s["rate"], 0.5)

    def test_seed_without_honest_observation_is_refused(self):
        """Une baseline indefinie ne peut pas entrer dans une agregation."""
        obs = _obs([_row(neighbor=5, observed=0, reason="DEADLINE")])
        with self.assertRaises(ForwardingAnalysisError):
            b.summarise_seed(obs, _man(attackers=(5,)))

    def test_seed_is_read_from_manifest(self):
        s = b.summarise_seed(_obs([_row()]), _man(seed=7))
        self.assertEqual(s["seed"], 7)


class PoolTests(unittest.TestCase):
    def test_pooled_rate_is_ratio_of_totals_not_mean_of_rates(self):
        """Des seeds de volumes tres inegaux separent les deux estimateurs.

        Seed A : 1 non-obs sur 100 (0.01). Seed B : 1 sur 2 (0.5).
        Taux groupe = 2/102 = 0.0196. Moyenne des taux = 0.255.
        L'estimateur correct de la baseline est le rapport des totaux.
        """
        summaries = [{"honest": 100, "missed": 1, "rate": 0.01},
                     {"honest": 2, "missed": 1, "rate": 0.5}]
        p = b.pool(summaries)
        self.assertAlmostEqual(p["pooledRate"], 2 / 102)
        self.assertAlmostEqual(p["meanOfRates"], 0.255)
        self.assertNotAlmostEqual(p["pooledRate"], p["meanOfRates"])

    def test_between_seed_sd_is_nan_with_one_seed(self):
        """Avec un seul seed la dispersion est INDEFINIE, jamais zero."""
        p = b.pool([{"honest": 100, "missed": 1, "rate": 0.01}])
        self.assertTrue(math.isnan(p["betweenSeedSd"]))

    def test_between_seed_sd_computed_with_several(self):
        p = b.pool([{"honest": 100, "missed": 1, "rate": 0.01},
                    {"honest": 100, "missed": 3, "rate": 0.03}])
        self.assertGreater(p["betweenSeedSd"], 0.0)
        self.assertAlmostEqual(p["minRate"], 0.01)
        self.assertAlmostEqual(p["maxRate"], 0.03)

    def test_calibration_sample_size_is_the_missed_total(self):
        p = b.pool([{"honest": 100, "missed": 30, "rate": 0.3},
                    {"honest": 100, "missed": 28, "rate": 0.28}])
        self.assertEqual(p["totalMissed"], 58)


class SeparationTests(unittest.TestCase):
    def test_evaluation_seed_is_refused(self):
        """Calibrer sur le seed d'evaluation invaliderait la separation."""
        obs = _obs([_row()])
        code = _silent(b.main, ["--observations", str(obs),
                                "--manifests", str(_man(seed=1)),
                                "--evaluation-seed", "1"])
        self.assertEqual(code, 1)

    def test_other_seed_is_accepted(self):
        obs = _obs([_row(neighbor=1, observed=1),
                    _row(neighbor=2, observed=0, reason="DEADLINE")])
        code = _silent(b.main, ["--observations", str(obs),
                                "--manifests", str(_man(seed=2)),
                                "--evaluation-seed", "1"])
        self.assertEqual(code, 0)

    def test_mismatched_list_lengths_are_refused(self):
        """L'appariement est positionnel : des longueurs differentes melangeraient
        les seeds et leurs listes d'attaquants."""
        obs = _obs([_row()])
        code = _silent(b.main, ["--observations", str(obs), str(obs),
                                "--manifests", str(_man())])
        self.assertEqual(code, 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
