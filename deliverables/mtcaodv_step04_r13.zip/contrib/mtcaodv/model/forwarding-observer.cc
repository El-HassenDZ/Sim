/* SPDX-License-Identifier: GPL-2.0-only */
#include "forwarding-observer.h"

#include "mtc-aodv-routing-protocol.h"

#include "ns3/boolean.h"
#include "ns3/double.h"
#include "ns3/log.h"
#include "ns3/ipv4.h"
#include "ns3/ipv4-l3-protocol.h"
#include "ns3/node.h"
#include "ns3/udp-header.h"
#include "ns3/simulator.h"
#include "ns3/uinteger.h"
#include "ns3/wifi-mac.h"
#include "ns3/wifi-net-device.h"

#include <bit>

namespace ns3
{

NS_LOG_COMPONENT_DEFINE("MtcAodvForwardingObserver");

namespace mtcaodv
{

NS_OBJECT_ENSURE_REGISTERED(ForwardingObserver);

namespace
{
/** @brief EtherType IPv4 ; seules ces trames portent un en-tête analysable. */
constexpr uint16_t ETHERTYPE_IPV4 = 0x0800;

/** @brief Numero de protocole IPv4 pour UDP. */
constexpr uint8_t IPV4_PROTOCOL_UDP = 17;
} // namespace

TypeId
ForwardingObserver::GetTypeId()
{
    static TypeId tid =
        TypeId("ns3::mtcaodv::ForwardingObserver")
            .SetParent<Object>()
            .SetGroupName("Mtcaodv")
            .AddConstructor<ForwardingObserver>()
            .AddAttribute("ObservationWindow",
                          "Delai avant cloture d'une fenetre sans appariement. "
                          "Trop court, un transfert honnete est manque et compte "
                          "comme non-observation ; trop long, la fenetre deborde "
                          "sur la mobilite. A CALIBRER sur la distribution des "
                          "latences d'appariement mesurees, jamais par intuition.",
                          TimeValue(MilliSeconds(150)),
                          MakeTimeAccessor(&ForwardingObserver::m_observationWindow),
                          MakeTimeChecker(MilliSeconds(1)))
            .AddAttribute("SweepInterval",
                          "Periode du balayage des echeances. Un seul evenement "
                          "periodique remplace un minuteur par fenetre : le cout "
                          "reste O(1) par fenetre au lieu de O(1) evenement par "
                          "fenetre.",
                          TimeValue(MilliSeconds(50)),
                          MakeTimeAccessor(&ForwardingObserver::m_sweepInterval),
                          MakeTimeChecker(MilliSeconds(1)))
            .AddAttribute("MaxActiveWindows",
                          "Borne dure sur les fenetres ouvertes (Invariant 20.4.2).",
                          UintegerValue(256),
                          MakeUintegerAccessor(&ForwardingObserver::m_maxActiveWindows),
                          MakeUintegerChecker<uint32_t>(1))
            .AddAttribute("MaxLearnedAddresses",
                          "Borne dure sur la table MAC -> IPv4 apprise passivement.",
                          UintegerValue(256),
                          MakeUintegerAccessor(&ForwardingObserver::m_maxLearnedAddresses),
                          MakeUintegerChecker<uint32_t>(1))
            .AddAttribute("LinkReliabilityMinSamples",
                          "Nombre minimal d'issues MAC avant que linkReliability soit "
                          "declaree DISPONIBLE. En deca, la caracteristique est "
                          "indisponible : publier une fraction calculee sur une ou deux "
                          "emissions donnerait 0 ou 1 sur presque rien, et une valeur "
                          "nulle DISPONIBLE est un veto dans l'Eq. (7).",
                          UintegerValue(4),
                          MakeUintegerAccessor(
                              &ForwardingObserver::m_linkReliabilityMinSamples),
                          MakeUintegerChecker<uint32_t>(1, 32))
            .AddAttribute("Enabled",
                          "Active l'observation. La mettre a false doit laisser le "
                          "PDR RIGOUREUSEMENT inchange : c'est la preuve de "
                          "non-intrusion exigee par STEP 3.",
                          BooleanValue(true),
                          MakeBooleanAccessor(&ForwardingObserver::m_enabled),
                          MakeBooleanChecker())
            .AddTraceSource("ObservationClosed",
                            "Une fenetre d'observation s'est refermee. L'evenement "
                            "porte z_e et les drapeaux de disponibilite, JAMAIS une "
                            "masse ni une etiquette : l'attribution est A3.3.",
                            MakeTraceSourceAccessor(
                                &ForwardingObserver::m_observationClosedTrace),
                            "ns3::mtcaodv::ForwardingObserver::"
                            "ObservationClosedTracedCallback");
    return tid;
}

ForwardingObserver::ForwardingObserver()
    : m_observationWindow(MilliSeconds(150)),
      m_sweepInterval(MilliSeconds(50))
{
    NS_LOG_FUNCTION(this);
}

ForwardingObserver::~ForwardingObserver()
{
    NS_LOG_FUNCTION(this);
}

void
ForwardingObserver::DoDispose()
{
    // Le balayage est un evenement periodique auto-reprogramme : sans annulation
    // explicite il maintiendrait l'objet vivant jusqu'a la fin de la simulation.
    Simulator::Cancel(m_sweepEvent);
    m_openWindows.clear();
    m_learnedAddresses.clear();
    m_lastHeardFromNeighbor.clear();
    m_neighborMac.clear();
    m_linkHistory.clear();
    m_routing = nullptr;
    m_node = nullptr;
    Object::DoDispose();
}

void
ForwardingObserver::Install(Ptr<Node> node)
{
    NS_LOG_FUNCTION(this << node);
    NS_ASSERT_MSG(node, "ForwardingObserver::Install requires a node");
    NS_ASSERT_MSG(!m_node, "ForwardingObserver::Install called twice on one node; "
                           "ns-3 keeps a single promiscuous callback per device, "
                           "so the second install would silently replace the first");
    m_node = node;
    m_observerNodeId = node->GetId();

    // Agreger l'observateur au noeud lie sa duree de vie a celle du noeud. Sans
    // cela, le rappel promiscuite installe ci-dessous detiendrait un pointeur nu
    // vers un objet que plus rien ne maintient en vie, et le pilote n'aurait
    // aucun moyen de retrouver l'observateur pour lire ses compteurs.
    node->AggregateObject(this);

    for (uint32_t index = 0; index < node->GetNDevices(); ++index)
    {
        Ptr<NetDevice> device = node->GetDevice(index);
        // La boucle locale n'entend rien et n'a pas de voisin a observer.
        if (device->IsPointToPoint() || !device->IsBroadcast())
        {
            continue;
        }
        device->SetPromiscReceiveCallback(
            MakeCallback(&ForwardingObserver::OnPromiscuousReceive, this));

        // ---- Mesure ACTIVE du lien i -> j (caracteristique x_k) ----
        // L'ecoute passive ne peut pas distinguer « j est inaudible » de « j est
        // silencieux » : c'est une limite d'information, pas un manque
        // d'implementation. Mesure sur le run STEP 3 : `passiveVisibility`
        // valait 0.1466 chez l'honnete contre 0.1484 chez l'attaquant
        // (z = +0.26), soit AUCUN pouvoir discriminant -- et l'explication est
        // mecanique, AODV diffusant un HELLO par seconde pour une fenetre de
        // 150 ms, soit 0.15.
        //
        // La seule sortie est d'interroger nos PROPRES emissions : un ACK MAC
        // prouve que j a recu, donc qu'il y avait une opportunite de le voir
        // relayer. Un Blackhole acquitte normalement -- l'acquittement est
        // materiel -- donc il presentera une fiabilite ELEVEE tout en ne
        // relayant rien. C'est exactement ce que l'Eq. (7) doit capter :
        // opportunite forte + aucune retransmission = evidence, alors que
        // `passiveVisibility` n'en fournissait aucune.
        //
        // LIMITE ENONCEE, non masquee : ceci mesure le lien i -> j, alors que
        // l'ecoute depend du lien j -> i. Correles en canal reciproque, non
        // identiques. C'est une hypothese de modelisation, elle doit etre citee
        // comme telle dans tout texte publie.
        Ptr<WifiNetDevice> wifiDevice = DynamicCast<WifiNetDevice>(device);
        if (!wifiDevice || !wifiDevice->GetMac())
        {
            // Interface non Wifi : la caracteristique restera INDISPONIBLE pour
            // ce noeud. Aucune valeur par defaut n'est inventee.
            continue;
        }
        const bool ackedConnected = wifiDevice->GetMac()->TraceConnectWithoutContext(
            "AckedMpdu", MakeCallback(&ForwardingObserver::OnMpduAcked, this));
        const bool nackedConnected = wifiDevice->GetMac()->TraceConnectWithoutContext(
            "NAckedMpdu", MakeCallback(&ForwardingObserver::OnMpduNacked, this));
        // `DroppedMpdu` est la trace qui manquait. `NAckedMpdu` reste branchee
        // -- elle est correcte pour les standards a block ack -- mais en
        // 802.11b elle ne se declenche jamais, ce qui a laisse la fiabilite
        // epinglee a 1.0 sur 10 962 evenements : 23 284 succes, 0 echec.
        const bool droppedConnected = wifiDevice->GetMac()->TraceConnectWithoutContext(
            "DroppedMpdu", MakeCallback(&ForwardingObserver::OnMpduDropped, this));
        NS_ASSERT_MSG(droppedConnected,
                      "Could not connect DroppedMpdu; only successes would be counted "
                      "and linkReliability would be structurally 1.0, measuring nothing");
        NS_ASSERT_MSG(ackedConnected && nackedConnected,
                      "Could not connect AckedMpdu/NAckedMpdu; linkReliability would "
                      "stay silently unavailable and OCEA would lose its only "
                      "discriminating opportunity feature");
    }

    // ---- Le protocole de routage, pour la SEULE consultation du prochain saut --
    Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
    NS_ASSERT_MSG(ipv4, "ForwardingObserver::Install requires an IPv4 stack");
    m_routing = DynamicCast<RoutingProtocol>(ipv4->GetRoutingProtocol());
    NS_ASSERT_MSG(m_routing,
                  "ForwardingObserver requires the mtcaodv fork: without a next-hop "
                  "lookup it could open a window without knowing which neighbour to "
                  "watch, which would make every observation unattributable");

    // ---- Les deux traces qui couvrent SOURCE et RELAIS uniformement ----
    // SendOutgoing  : paquets originaires de ce noeud (le cas DOMINANT a 1,73 saut)
    // UnicastForward: paquets relayes par ce noeud
    // Les deux portent l'en-tete IPv4 COMPLET, identification comprise, ce que
    // RouteOutput() ne pourrait pas fournir.
    Ptr<Ipv4L3Protocol> layer3 = node->GetObject<Ipv4L3Protocol>();
    NS_ASSERT_MSG(layer3, "ForwardingObserver::Install requires Ipv4L3Protocol");
    const bool sendConnected = layer3->TraceConnectWithoutContext(
        "SendOutgoing", MakeCallback(&ForwardingObserver::OnIpv4Transmit, this));
    const bool forwardConnected = layer3->TraceConnectWithoutContext(
        "UnicastForward", MakeCallback(&ForwardingObserver::OnIpv4Transmit, this));
    NS_ASSERT_MSG(sendConnected && forwardConnected,
                  "Could not connect the Ipv4L3Protocol traces; without them the "
                  "observer would silently open no window at all");

    ScheduleNextSweep();
}

void
ForwardingObserver::SetEnabled(bool enabled)
{
    m_enabled = enabled;
}

bool
ForwardingObserver::IsEnabled() const
{
    return m_enabled;
}

void
ForwardingObserver::ScheduleNextSweep()
{
    m_sweepEvent = Simulator::Schedule(m_sweepInterval,
                                       &ForwardingObserver::SweepExpiredWindows,
                                       this);
}

void
ForwardingObserver::OnIpv4Transmit(const Ipv4Header& header,
                                   Ptr<const Packet> packet,
                                   uint32_t interface)
{
    if (!m_enabled)
    {
        return;
    }
    ++m_transmissionsInspected;

    const Ipv4Address destination = header.GetDestination();

    // Diffusion et multicast : il n'y a pas de "prochain saut" a surveiller.
    if (destination.IsBroadcast() || destination.IsMulticast() ||
        destination.IsLocalMulticast())
    {
        ++m_skippedNonUnicast;
        return;
    }

    // Plan de controle AODV : exclu. Un Blackhole complet relaie fidelement le
    // controle pour rester attractif, donc l'inclure diluerait le signal du plan
    // de donnees avec des transferts que meme un attaquant effectue.
    if (header.GetProtocol() == IPV4_PROTOCOL_UDP)
    {
        UdpHeader udpHeader;
        Ptr<Packet> copy = packet->Copy();
        if (copy->PeekHeader(udpHeader) > 0 &&
            (udpHeader.GetDestinationPort() == m_controlPlanePort ||
             udpHeader.GetSourcePort() == m_controlPlanePort))
        {
            ++m_skippedControlPlane;
            return;
        }
    }

    Ipv4Address nextHop;
    if (!m_routing || !m_routing->LookupNextHopForObservation(destination, nextHop))
    {
        // Pas de route valide a cet instant : on ne sait pas QUI surveiller.
        // Compte, jamais devine.
        ++m_skippedNoRoute;
        return;
    }

    // ---- LE CAS QUI COMPTE : le prochain saut EST la destination finale ----
    // La destination consomme le paquet et ne le retransmet JAMAIS. Ouvrir une
    // fenetre ici garantirait z_e = 0 sur un noeud parfaitement honnete, a
    // chaque paquet du dernier saut. C'est le mode de defaillance qui rendrait
    // la baseline benigne egale a 1 et l'attribution OCEA inexploitable.
    if (nextHop == destination)
    {
        ++m_skippedLastHop;
        return;
    }

    OpenWindow(header, static_cast<uint16_t>(packet->GetSize()), nextHop);
}

void
ForwardingObserver::OpenWindow(const Ipv4Header& header,
                               uint16_t payloadLengthBytes,
                               Ipv4Address nextHop)
{
    if (!m_enabled)
    {
        return;
    }

    // Un paquet fragmente invalide a la fois l'identification (partagee par tous
    // les fragments) et la taille utile. Il est COMPTE puis EXCLU : le suivre
    // produirait des appariements faux dans les deux sens.
    if (header.IsLastFragment() == false || header.GetFragmentOffset() != 0)
    {
        ++m_fragmentedPacketsExcluded;
        return;
    }

    PacketFingerprintFields fields;
    fields.sourceAddress = header.GetSource().Get();
    fields.destinationAddress = header.GetDestination().Get();
    fields.identification = header.GetIdentification();
    fields.payloadLength = payloadLengthBytes;
    fields.protocol = header.GetProtocol();
    const uint64_t fingerprint = ComputePacketFingerprint(fields);

    // Collision : une fenetre existe deja pour cette empreinte alors que les
    // champs different. Mesuree et rapportee, jamais supposee impossible.
    const auto existing = m_openWindows.find(fingerprint);
    if (existing != m_openWindows.end())
    {
        if (existing->second.sourceAddress != fields.sourceAddress ||
            existing->second.destinationAddress != fields.destinationAddress ||
            existing->second.identification != fields.identification)
        {
            ++m_fingerprintCollisions;
        }
        // Dans les deux cas la fenetre precedente est remplacee : un paquet
        // reemis porte la meme empreinte, et suivre le plus recent est la
        // lecture correcte.
        m_openWindows.erase(existing);
    }

    // Borne dure : evincer la fenetre la plus ancienne. EVICTED est une raison
    // distincte, jamais confondue avec une non-observation, car une fenetre
    // evincee n'a rien observe du tout.
    while (m_openWindows.size() >= m_maxActiveWindows)
    {
        auto oldest = m_openWindows.begin();
        for (auto it = m_openWindows.begin(); it != m_openWindows.end(); ++it)
        {
            if (it->second.openTimeSeconds < oldest->second.openTimeSeconds)
            {
                oldest = it;
            }
        }
        const uint64_t evictedFingerprint = oldest->first;
        const OpenWindowRecord evictedRecord = oldest->second;
        m_openWindows.erase(oldest);
        CloseWindow(evictedFingerprint,
                    evictedRecord,
                    ForwardingClosureReason::EVICTED,
                    Address());
    }

    OpenWindowRecord record;
    record.nextHop = nextHop;
    // ---- GEL de x_link(e) = R_ij(t_e^-) ----
    // INVARIANT NORMATIF. La fiabilite est capturee ICI, avant que la
    // transmission qui ouvre cette fenetre n'ait pu produire son ACK ou son
    // echec. OpenWindow() est appelee depuis la trace Ipv4L3Protocol, donc au
    // niveau IP, avant que le paquet n'atteigne le MAC : l'issue de CET
    // evenement ne peut structurellement pas figurer dans l'historique.
    //
    // Calculer cette valeur a la CLOTURE -- ce que faisait la version
    // precedente -- y faisait entrer l'issue de la transmission elle-meme. Le
    // couplage est causal et non statistique : un echec MAC vers j implique que
    // j n'a jamais recu le paquet, donc z_e = 0 FORCE. La caracteristique
    // d'opportunite predisait alors son propre resultat.
    record.linkReliabilityAvailableAtOpen =
        TryGetLinkReliability(nextHop, record.linkReliabilityAtOpen);
    record.openTimeSeconds = Simulator::Now().GetSeconds();
    record.sourceAddress = fields.sourceAddress;
    record.destinationAddress = fields.destinationAddress;
    record.identification = fields.identification;
    m_openWindows[fingerprint] = record;
    ++m_windowsOpened;

    NS_LOG_DEBUG("Observation window opened for " << header.GetSource() << "->"
                                                  << header.GetDestination()
                                                  << " via " << nextHop);
}

bool
ForwardingObserver::OnPromiscuousReceive(Ptr<NetDevice> device,
                                         Ptr<const Packet> packet,
                                         uint16_t protocol,
                                         const Address& from,
                                         const Address& to,
                                         NetDevice::PacketType packetType)
{
    // Non-intrusion : quoi qu'il arrive ci-dessous, la valeur de retour est
    // false et aucun paquet de la pile n'est modifie. Les analyses portent sur
    // des COPIES ; RemoveHeader mute son argument, et muter un paquet en vol
    // serait exactement l'intrusion que STEP 3 interdit.
    if (!m_enabled)
    {
        return false;
    }
    ++m_promiscuousFramesInspected;

    if (protocol != ETHERTYPE_IPV4)
    {
        return false; // ARP et consorts : hors sujet, non comptes comme observation
    }

    Ptr<Packet> copy = packet->Copy();
    Ipv4Header header;
    if (copy->GetSize() < header.GetSerializedSize())
    {
        return false;
    }
    copy->RemoveHeader(header);

    // ---- Apprentissage passif de la correspondance MAC -> IPv4 ----
    // Une trame DIFFUSEE est necessairement emise par le noeud dont l'adresse
    // figure en source IP : AODV envoie ses diffusions depuis sa propre socket.
    // Le spike C-17 l'a verifie sur trace. Une trame unicast, elle, peut etre un
    // RELAIS, dont la source IP est un tiers : l'utiliser pour apprendre
    // associerait la MAC du relais a l'IP de la source d'origine.
    if (packetType == NetDevice::PACKET_BROADCAST)
    {
        LearnAddressMapping(from, header.GetSource());
    }

    // ---- Tentative d'appariement ----
    PacketFingerprintFields fields;
    fields.sourceAddress = header.GetSource().Get();
    fields.destinationAddress = header.GetDestination().Get();
    fields.identification = header.GetIdentification();
    fields.payloadLength = static_cast<uint16_t>(copy->GetSize());
    fields.protocol = header.GetProtocol();
    const uint64_t fingerprint = ComputePacketFingerprint(fields);

    const auto found = m_openWindows.find(fingerprint);
    if (found == m_openWindows.end())
    {
        return false; // rien a apparier : ce n'est ni un succes ni un echec
    }

    const OpenWindowRecord record = found->second;
    m_openWindows.erase(found);
    CloseWindow(fingerprint, record, ForwardingClosureReason::MATCHED, from);
    return false;
}

void
ForwardingObserver::OnMpduAcked(Ptr<const WifiMpdu> mpdu)
{
    if (!m_enabled || !mpdu)
    {
        return;
    }
    RecordLinkOutcome(mpdu->GetHeader().GetAddr1(), true);
}

void
ForwardingObserver::OnMpduNacked(Ptr<const WifiMpdu> mpdu)
{
    if (!m_enabled || !mpdu)
    {
        return;
    }
    RecordLinkOutcome(mpdu->GetHeader().GetAddr1(), false);
}

bool
ForwardingObserver::IsLinkFailureReason(WifiMacDropReason reason)
{
    // SEULE l'epuisement des retransmissions atteste que le pair n'a pas
    // repondu. FAILED_ENQUEUE et EXPIRED_LIFETIME decrivent la congestion
    // LOCALE de i : les inclure ferait de linkReliability une mesure de
    // congestion deguisee, portant deux phenomenes distincts sous un seul nom.
    // Ces deux raisons sont en revanche le proxy local honnete envisage pour un
    // futur diagnostic de congestion -- sous un nom DISTINCT, jamais celui-ci.
    return reason == WIFI_MAC_DROP_REACHED_RETRY_LIMIT;
}

void
ForwardingObserver::OnMpduDropped(WifiMacDropReason reason, Ptr<const WifiMpdu> mpdu)
{
    if (!m_enabled || !mpdu)
    {
        return;
    }
    // Ventilation par raison : aucune n'est supposee nulle. Sans ces compteurs,
    // « 0 echec » serait indiscernable de « la trace n'est pas branchee ».
    switch (reason)
    {
    case WIFI_MAC_DROP_REACHED_RETRY_LIMIT:
        ++m_macDropsRetryLimit;
        break;
    case WIFI_MAC_DROP_FAILED_ENQUEUE:
        ++m_macDropsFailedEnqueue;
        break;
    case WIFI_MAC_DROP_EXPIRED_LIFETIME:
        ++m_macDropsExpiredLifetime;
        break;
    default:
        ++m_macDropsOther;
        break;
    }
    if (IsLinkFailureReason(reason))
    {
        RecordLinkOutcome(mpdu->GetHeader().GetAddr1(), false);
    }
}

void
ForwardingObserver::RecordLinkOutcome(const Mac48Address& peer, bool success)
{
    // Une adresse de groupe n'est jamais acquittee : la compter fausserait la
    // fraction en y melant des emissions dont l'absence d'ACK ne dit rien.
    if (peer.IsGroup())
    {
        return;
    }
    // Borne dure, comme les autres tables apprises : la structure ne croit pas
    // avec la duree de la simulation.
    if (m_linkHistory.size() >= m_maxLearnedAddresses && m_linkHistory.count(peer) == 0)
    {
        return;
    }
    LinkHistory& history = m_linkHistory[peer];
    // Decalage : le bit de poids faible est l'issue la plus recente, les issues
    // au-dela de la 32e sortent du mot d'elles-memes. Aucune allocation, aucun
    // elagage periodique a oublier -- la borne est structurelle.
    history.outcomes = (history.outcomes << 1) | (success ? 1u : 0u);
    if (history.samples < 32)
    {
        ++history.samples;
    }
    ++m_linkOutcomesRecorded;
    if (success)
    {
        ++m_linkSuccesses;
    }
    else
    {
        ++m_linkFailures;
    }
}

bool
ForwardingObserver::TryGetLinkReliability(Ipv4Address neighbor, double& reliability) const
{
    const auto mac = m_neighborMac.find(neighbor);
    if (mac == m_neighborMac.end())
    {
        return false; // MAC du voisin encore inconnue : on ne devine pas.
    }
    return TryGetLinkReliabilityForPeer(mac->second, reliability);
}

bool
ForwardingObserver::TryGetLinkReliabilityForPeer(const Mac48Address& peer,
                                                 double& reliability) const
{
    const auto history = m_linkHistory.find(peer);
    if (history == m_linkHistory.end() ||
        history->second.samples < m_linkReliabilityMinSamples)
    {
        // Historique trop court. INDISPONIBLE, jamais une valeur par defaut :
        // `available = 0` avoue l'ignorance et ne fait que reduire c_e, alors
        // qu'une valeur nulle DISPONIBLE opposerait un veto dans l'Eq. (7).
        return false;
    }
    const uint8_t samples = history->second.samples;
    // Ne compter que les `samples` bits reellement renseignes. Sans ce masque,
    // les bits de tete jamais ecrits compteraient comme des echecs et
    // sous-estimeraient la fiabilite d'un lien jeune.
    const uint32_t mask =
        (samples >= 32) ? 0xFFFFFFFFu : ((1u << samples) - 1u);
    const int successes = std::popcount(history->second.outcomes & mask);
    reliability = static_cast<double>(successes) / static_cast<double>(samples);
    return true;
}

void
ForwardingObserver::LearnAddressMapping(const Address& mac, Ipv4Address ipv4)
{
    if (ipv4 == Ipv4Address::GetAny() || ipv4.IsBroadcast())
    {
        return;
    }
    // Toute trame entendue de ce noeud atteste sa visibilite radio A CET INSTANT.
    // La table est bornee par le meme plafond que les correspondances apprises.
    if (m_lastHeardFromNeighbor.size() < m_maxLearnedAddresses ||
        m_lastHeardFromNeighbor.count(ipv4) > 0)
    {
        m_lastHeardFromNeighbor[ipv4] = Simulator::Now().GetSeconds();
    }

    // Table inverse IPv4 -> MAC : les issues MAC arrivent indexees par MAC,
    // alors qu'une fenetre est indexee par l'IPv4 du prochain saut.
    Mac48Address mac48 = Mac48Address::ConvertFrom(mac);
    if (m_neighborMac.size() < m_maxLearnedAddresses || m_neighborMac.count(ipv4) > 0)
    {
        m_neighborMac[ipv4] = mac48;
    }

    const auto existing = m_learnedAddresses.find(mac);
    if (existing != m_learnedAddresses.end())
    {
        existing->second = ipv4; // la plus recente fait foi
        return;
    }
    // Borne dure : au-dela, on n'apprend plus. Ne PAS evincer au hasard — une
    // correspondance perdue rendrait une observation non attribuable, ce qui est
    // rapporte comme tel ; une correspondance fausse produirait une attribution
    // erronee, ce qui est bien pire.
    if (m_learnedAddresses.size() >= m_maxLearnedAddresses)
    {
        return;
    }
    m_learnedAddresses[mac] = ipv4;
}

void
ForwardingObserver::SweepExpiredWindows()
{
    const double now = Simulator::Now().GetSeconds();
    const double windowSeconds = m_observationWindow.GetSeconds();

    for (auto it = m_openWindows.begin(); it != m_openWindows.end();)
    {
        if ((now - it->second.openTimeSeconds) >= windowSeconds)
        {
            const uint64_t fingerprint = it->first;
            const OpenWindowRecord record = it->second;
            it = m_openWindows.erase(it);
            CloseWindow(fingerprint,
                        record,
                        ForwardingClosureReason::DEADLINE,
                        Address());
        }
        else
        {
            ++it;
        }
    }
    ScheduleNextSweep();
}

void
ForwardingObserver::CloseWindow(uint64_t fingerprint,
                                const OpenWindowRecord& record,
                                ForwardingClosureReason reason,
                                const Address& observedSenderMac)
{
    ForwardingObservation observation;
    observation.observerNodeId = m_observerNodeId;
    observation.watchedNeighbor = record.nextHop;
    observation.fingerprint = fingerprint;
    observation.openTimeSeconds = record.openTimeSeconds;
    observation.closeTimeSeconds = Simulator::Now().GetSeconds();
    observation.closureReason = reason;
    observation.forwardingObserved = (reason == ForwardingClosureReason::MATCHED);

    // Attribution de l'emetteur : verifiee contre la table apprise, jamais
    // supposee. Une correspondance absente laisse le drapeau a faux, ce qui est
    // une information et non un echec silencieux.
    if (reason == ForwardingClosureReason::MATCHED)
    {
        const auto learned = m_learnedAddresses.find(observedSenderMac);
        observation.senderAttributedToNeighbor =
            (learned != m_learnedAddresses.end() && learned->second == record.nextHop);
    }

    // ---- Caracteristiques x_k et diagnostics y_l ----
    // STEP 3 ne renseigne que ce qu'il MESURE reellement. Les autres restent
    // indisponibles (drapeau faux), ce que les Eq. (6) et (8) savent traiter :
    // elles somment les poids des caracteristiques disponibles et declarent
    // l'evenement non interpretable quand la couverture est nulle. Remplir une
    // valeur par defaut ferait passer une observation partielle pour complete.
    //
    // `passiveVisibility` : preuve POSITIVE que le voisin etait audible pendant
    // la fenetre, jamais une affirmation du contraire.
    //
    // CORRECTION D'UNE ERREUR DE CONCEPTION. La version precedente ecrivait
    // `available = true` dans TOUS les cas, avec `value = 0` quand le voisin
    // n'avait rien diffuse, au motif que « la reponse est toujours connue ».
    // Elle ne l'est pas. On sait si l'on A ENTENDU j ; on ne sait pas si j
    // ETAIT AUDIBLE. Un silence signifie soit que le lien j->i est coupe,
    // soit simplement que j n'avait rien a emettre -- AODV ne diffuse des RREQ
    // que pendant la decouverte, donc un voisin parfaitement audible peut se
    // taire plusieurs secondes en regime etabli.
    //
    // POURQUOI C'EST GRAVE, et non un detail de codage. Dans l'Eq. (7),
    //
    //     O_e = c_e * PRODUIT x_k^(w_k a_k / c_e)
    //
    // une caracteristique DISPONIBLE valant exactement 0 est un VETO ABSOLU,
    // quel que soit son poids : 0^(w/c) = 0 pour tout w > 0. Baisser w_pv ne
    // corrigerait rien. Mesure sur le run STEP 3 : 9 343 des 10 962 evenements
    // (85,2 %) etaient ainsi annules, et le taux de visibilite valait 0.1466
    // chez l'honnete contre 0.1484 chez l'attaquant (z = +0.26) -- donc AUCUN
    // pouvoir discriminant, pour un veto sur 85 % des donnees.
    //
    // C'est le miroir exact de la faute que le commentaire ci-dessus enonce :
    // remplir une valeur par defaut fait passer une observation partielle pour
    // complete. Ici la valeur par defaut affirmait une opportunite NULLE la ou
    // il n'y avait qu'une absence de preuve.
    //
    // REGLE. `available = 0` et `value = 0` ne sont pas interchangeables :
    // le premier avoue une ignorance et reduit seulement la couverture c_e,
    // le second affirme l'absence d'opportunite et annule l'evenement. Ne
    // declarer disponible que ce que l'on sait reellement.
    const auto lastHeard = m_lastHeardFromNeighbor.find(record.nextHop);
    const bool heardWithinWindow =
        (lastHeard != m_lastHeardFromNeighbor.end() &&
         (observation.closeTimeSeconds - lastHeard->second) <=
             m_observationWindow.GetSeconds());
    if (heardWithinWindow)
    {
        observation.passiveVisibility = 1.0;
        observation.passiveVisibilityAvailable = true;
    }
    else
    {
        // Rien entendu : on ignore si le voisin etait audible. INDISPONIBLE.
        observation.passiveVisibility = 0.0;
        observation.passiveVisibilityAvailable = false;
    }

    // `linkReliability` : mesure ACTIVE du lien i -> j par les ACK MAC.
    // Disponible seulement si assez d'issues sont connues ; sinon INDISPONIBLE,
    // jamais une valeur par defaut. La valeur 0 y est en revanche LEGITIME :
    // si aucune des emissions recentes vers j n'a ete acquittee, il n'y avait
    // reellement aucune opportunite d'observer un transfert, et le veto de
    // l'Eq. (7) est alors la bonne reponse -- c'est precisement le cas auquel
    // la valeur 0 doit etre reservee.
    // x_k : la valeur GELEE a l'ouverture, jamais recalculee ici.
    observation.linkReliability = record.linkReliabilityAtOpen;
    observation.linkReliabilityAvailable = record.linkReliabilityAvailableAtOpen;
    if (record.linkReliabilityAvailableAtOpen)
    {
        ++m_linkReliabilityAvailableCount;
    }

    // DIAGNOSTIC UNIQUEMENT : la meme quantite recalculee maintenant. Elle
    // n'entre dans AUCUNE equation. Son seul role est de rendre MESURABLE sur
    // traces l'ampleur de la fuite temporelle que le gel supprime : l'ecart
    // entre les deux colonnes EST la contamination qui existait avant.
    double reliabilityNow = 0.0;
    observation.linkReliabilityAtCloseAvailable =
        TryGetLinkReliability(record.nextHop, reliabilityNow);
    observation.linkReliabilityAtClose = reliabilityNow;
    if (observation.linkReliabilityAvailable &&
        observation.linkReliabilityAtCloseAvailable &&
        observation.linkReliability != observation.linkReliabilityAtClose)
    {
        ++m_linkReliabilityChangedDuringWindow;
    }

    // predictedContactPersistence, mobilityBreak,
    // queuePressure et coherentRerr exigent respectivement un historique de
    // lien, un modele de contact, la table de voisinage, l'etat des files et le
    // flux RERR. Aucun n'est cable a STEP 3 : ils seront renseignes a STEP 4,
    // avec leur poids. Ici ils restent explicitement INDISPONIBLES.

    switch (reason)
    {
    case ForwardingClosureReason::MATCHED:
        ++m_windowsMatched;
        break;
    case ForwardingClosureReason::DEADLINE:
        ++m_windowsDeadline;
        break;
    case ForwardingClosureReason::EVICTED:
        ++m_windowsEvicted;
        break;
    }

    m_observationClosedTrace(observation);
}

uint64_t ForwardingObserver::GetWindowsOpened() const { return m_windowsOpened; }
uint64_t ForwardingObserver::GetWindowsMatched() const { return m_windowsMatched; }
uint64_t ForwardingObserver::GetWindowsDeadline() const { return m_windowsDeadline; }
uint64_t ForwardingObserver::GetWindowsEvicted() const { return m_windowsEvicted; }
uint64_t ForwardingObserver::GetFingerprintCollisions() const { return m_fingerprintCollisions; }
uint64_t ForwardingObserver::GetFragmentedPacketsExcluded() const
{
    return m_fragmentedPacketsExcluded;
}
uint64_t ForwardingObserver::GetPromiscuousFramesInspected() const
{
    return m_promiscuousFramesInspected;
}
uint64_t ForwardingObserver::GetSkippedLastHop() const { return m_skippedLastHop; }
uint64_t ForwardingObserver::GetSkippedNoRoute() const { return m_skippedNoRoute; }
uint64_t ForwardingObserver::GetSkippedControlPlane() const
{
    return m_skippedControlPlane;
}
uint64_t ForwardingObserver::GetSkippedNonUnicast() const { return m_skippedNonUnicast; }
uint64_t ForwardingObserver::GetTransmissionsInspected() const
{
    return m_transmissionsInspected;
}

uint64_t ForwardingObserver::GetLinkOutcomesRecorded() const
{
    return m_linkOutcomesRecorded;
}

uint64_t ForwardingObserver::GetLinkSuccesses() const
{
    return m_linkSuccesses;
}

uint64_t ForwardingObserver::GetLinkFailures() const
{
    return m_linkFailures;
}

uint64_t ForwardingObserver::GetMacDropsRetryLimit() const
{
    return m_macDropsRetryLimit;
}

uint64_t ForwardingObserver::GetMacDropsFailedEnqueue() const
{
    return m_macDropsFailedEnqueue;
}

uint64_t ForwardingObserver::GetMacDropsExpiredLifetime() const
{
    return m_macDropsExpiredLifetime;
}

uint64_t ForwardingObserver::GetMacDropsOther() const
{
    return m_macDropsOther;
}

uint64_t ForwardingObserver::GetLinkReliabilityChangedDuringWindow() const
{
    return m_linkReliabilityChangedDuringWindow;
}

uint64_t ForwardingObserver::GetLinkReliabilityAvailableCount() const
{
    return m_linkReliabilityAvailableCount;
}

} // namespace mtcaodv
} // namespace ns3
