/* SPDX-License-Identifier: GPL-2.0-only */
#include "forwarding-observation.h"

namespace ns3
{
namespace mtcaodv
{

const char*
ForwardingClosureReasonName(ForwardingClosureReason reason)
{
    switch (reason)
    {
    case ForwardingClosureReason::MATCHED:
        return "MATCHED";
    case ForwardingClosureReason::DEADLINE:
        return "DEADLINE";
    case ForwardingClosureReason::EVICTED:
        return "EVICTED";
    }
    // Aucune valeur d'énumération n'est laissée sans nom : une raison inconnue
    // apparaîtrait dans le CSV et serait rejetée par le validateur, plutôt que
    // de se confondre silencieusement avec DEADLINE.
    return "UNKNOWN";
}

} // namespace mtcaodv
} // namespace ns3
