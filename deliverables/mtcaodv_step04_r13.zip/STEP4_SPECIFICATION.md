# STEP 4 — Attribution OCEA en quatre masses (A3.3, Éq. 6–10)

**Révision 2** — intègre les arbitrages de l'utilisateur sur `queuePressure`,
`predictedContactPersistence`, \(\varepsilon\), et la séparation entre
`passiveVisibility` et \(z_e\).

Document de **spécification**. Source normative :
`MTCAODV_Mathematical_Algorithms_Specification.md`, § 5.4 et algorithme A3.3.

---

## 1. Le fait qui détermine le périmètre

L'observateur du STEP 3 renseigne **une seule** caractéristique d'opportunité,
`passiveVisibility` ; les cinq indicateurs \(y_\ell\) sont marqués indisponibles.
A3.3 ligne 7 : `if d = 0 then return (0,0,0,1)`.

**Sur le run validé, OCEA renverrait une incertitude totale pour les 10 962
observations.** Conforme à la spécification, mais cela ne démontrerait qu'une
chose : que le cas « diagnostics indisponibles » est correctement traité.

Le corps de STEP 4 est donc **l'instrumentation et la validation des observables
qui alimentent A3.3**, pas les trente lignes d'arithmétique des équations.

---

## 2. Arbitrages tranchés (verrouillés)

### 2.1 `queuePressure` — indisponible

La file pertinente pour expliquer une non-retransmission est celle de \(j\).
**Aucune lecture de l'état interne de \(j\) dans la voie déployable.** Son
indicateur de disponibilité reste à zéro.

La file locale de \(i\) **ne doit pas être présentée sous le même nom**. Si elle
est utilisée un jour, ce sera comme un **proxy distinct de congestion locale**,
portant son propre nom, avec sa propre validation. Confondre les deux dans le
code ou dans un texte publié serait une faute de méthode, pas un raccourci.

### 2.2 `predictedContactPersistence` — indisponible, non supprimée

Elle n'est **pas** retirée de la spécification. Elle reste indisponible tant
qu'un estimateur fondé **uniquement sur l'historique local observable du lien
\(i\!-\!j\)** n'a pas été défini **et validé**. En l'absence d'un tel estimateur,
\(a_k(e) = 0\) en permanence.

Aucune lecture de `MobilityModel` de \(j\) : techniquement triviale en
simulation, scientifiquement invalide.

### 2.3 \(\varepsilon\) — pas un plancher

\(\varepsilon\) **n'est pas** utilisé comme plancher arbitraire sur \(x_k\) dans
l'Éq. (7). La forme normative traite explicitement \(c_e = 0\), et un
\(x_k = 0\) **réellement disponible doit pouvoir produire \(O_e = 0\)** — c'est
une information, pas une singularité à masquer.

Implémentation : si la moyenne géométrique passe par le domaine logarithmique,
le cas \(x_k = 0\) est traité **explicitement avant tout appel à \(\log\)**,
jamais remplacé par \(\varepsilon\).

**C-06 reste ouvert** jusqu'à ce que les usages numériques exacts de
\(\varepsilon\) et de `numericalTolerance` soient **figés par les tests**.

### 2.4 `passiveVisibility` ≠ \(z_e\)

`passiveVisibility` doit mesurer la **capacité de l'observateur à écouter
pendant la fenêtre**, indépendamment du résultat de cette écoute. \(z_e\) reste
un résultat séparé.

Le raisonnement à interdire : si `passiveVisibility = 0` parce qu'aucune
retransmission n'a été entendue, alors toute non-observation donne \(O_e = 0\),
puis \(I_e = 0\), et **aucune évidence malveillante ne peut jamais être
produite**. Le mécanisme s'auto-annulerait.

---

## 3. État réel de `passiveVisibility` : vérifié, et insuffisant

### 3.1 Pas de circularité — vérifié dans le code

`m_lastHeardFromNeighbor` n'est écrit que dans `LearnAddressMapping`, appelée
**uniquement** sous `packetType == PACKET_BROADCAST`. La retransmission
surveillée est un relais **unicast** (`PACKET_OTHERHOST`) : elle ne met jamais
cette table à jour.

```
z_e                ← appariement d'empreinte, trame UNICAST
passiveVisibility  ← réception de trames BROADCAST de j
```

Classes de trames **disjointes**. L'indépendance est structurelle.

Cette séparation provient d'une décision du spike C-17 prise pour une raison
différente — une trame unicast peut être un relais dont l'IP source est un tiers
— et non d'une anticipation de cet argument. Elle est correcte ; elle n'était
pas intentionnelle.

### 3.2 Le défaut réel : ce n'est pas la bonne grandeur

`passiveVisibility` mesure **l'activité broadcast de \(j\)**, pas la capacité
d'écoute de \(i\). AODV ne diffuse des RREQ que pendant la découverte ; en régime
établi, un voisin parfaitement audible peut ne rien diffuser pendant plusieurs
secondes.

`passiveVisibility = 0` confond donc :

- « je ne peux pas entendre \(j\) » — l'information voulue ;
- « \(j\) n'avait rien à diffuser dans les 150 dernières ms » — un artefact du
  protocole de routage.

Ce n'est pas circulaire, mais ce n'est pas ce que l'Éq. (7) demande.

### 3.3 Redirection proposée, à valider par la mesure

Sources d'audibilité **indépendantes de \(z_e\) pour l'événement \(e\)** :

- **toute trame attribuable à \(j\)** reçue pendant la fenêtre **autre que celle
  qui clôt \(e\)** — y compris les relais unicast de \(j\) portant sur d'autres
  flux, qui prouvent que \(j\) est vivant et audible sans rien dire de \(e\) ;
- **activité du canal** : l'observateur a-t-il reçu la moindre trame pendant la
  fenêtre ? Un canal totalement silencieux ne prouve pas que \(j\) se tait, il
  prouve que \(i\) n'écoutait rien d'utile.

Ces deux pistes ne sont **pas** retenues par décret : elles seront mesurées
avant d'être adoptées. La réserve à instruire : utiliser les autres relais de
\(j\) crée, à travers les événements, une corrélation avec l'honnêteté de \(j\)
— nulle pour \(e\) pris isolément, non nulle en agrégat.

---

## 4. Mesure préalable, sur données déjà produites

`experiments/analyze_features.py` mesure le **plafond d'attribution** avant
qu'une seule ligne de C++ soit écrite.

L'Éq. (7) étant une moyenne géométrique, une visibilité nulle donne
\(O_e = 0\) donc \(I_e = 0\) — **quels que soient les diagnostics \(y_\ell\)
instrumentés ensuite**. Donc :

> Le nombre de non-observations d'attaquant **avec** visibilité non nulle est une
> **borne dure** sur ce qu'OCEA peut attribuer avec l'instrumentation actuelle.

Si ce plafond est nul ou faible, instrumenter les \(y_\ell\) sans corriger la
caractéristique d'opportunité serait **sans effet**. Cette mesure décide donc
l'ordre des travaux, et elle est disponible immédiatement.

Le script rapporte aussi \(P(\text{visible} \mid z_e{=}1)\) et
\(P(\text{visible} \mid z_e{=}0)\). **Aucun seuil n'est préenregistré pour leur
écart** : un voisin physiquement joignable a plus de chances des deux côtés, donc
un écart est attendu et ne prouve **pas** une circularité. Le script rapporte, il
ne juge pas.

---

## 4bis. RÉSULTATS DE LA MESURE (seed=1, 10 962 événements)

Exécutée sur les données du STEP 3. Elle devait décider l'ordre des travaux ;
elle le fait, et elle **inverse** la partie B ci-dessous.

### Indépendance : confirmée

| comparaison | écart | SE | z |
|---|---|---|---|
| attaquant : visible \| z=1 − visible \| z=0 | +0.0022 | 0.0111 | **+0.20** |
| honnête : visible \| z=1 − visible \| z=0 | −0.0873 | 0.0648 | −1.35 |

Sur la comparaison bien dotée (n = 1 272 et 5 467), l'écart vaut 0,2 écart-type :
indistinguable de zéro. Chez l'honnête le signe est négatif — l'inverse d'une
circularité — mais n(z=0) = 30 ne permet aucune conclusion. L'argument
structurel du § 3.1 est confirmé empiriquement.

### Pouvoir discriminant : NUL

| | taux de visibilité |
|---|---|
| voisin honnête | 0.1466 |
| voisin attaquant | 0.1484 |

Écart **+0.0018**, SE 0.0070, **z = +0.26**. `passiveVisibility` ne distingue pas
un attaquant d'un nœud honnête. Le § 3.2 l'annonçait ; la mesure est bien plus
brutale que la formulation.

### Destruction de l'interprétabilité

**9 343 des 10 962 événements (85,2 %)** donneraient \(O_e = 0\) donc
\(I_e = 0\), quels que soient les \(y_\ell\) instrumentés ensuite.

Plafond chez l'attaquant : **809 sur 6 739 événements, soit 12,0 %**. La
visibilité ne discriminant rien, ces 809 sont un sous-échantillon **arbitraire**,
pas les cas informatifs.

### L'erreur de conception du STEP 3

Dans l'Éq. (7), **une caractéristique disponible valant exactement 0 est un veto
absolu, quel que soit son poids** : \(0^{\omega/c} = 0\) pour tout
\(\omega > 0\). Baisser \(\omega_{pv}\) ne corrigerait rien.

Or le code du STEP 3 écrit `passiveVisibility = 0` **avec `available = 1`**
quand \(j\) n'a rien diffusé dans la fenêtre. C'est une **affirmation** qu'il
n'y a eu aucune opportunité d'observation, alors qu'on sait seulement que \(j\)
n'a pas diffusé.

C'est le miroir de la faute que l'Éq. (6) existe pour empêcher, et que le même
fichier énonce en commentaire : *« remplir une valeur par défaut ferait passer
une observation partielle pour complète »*. Le piège a été évité dans un sens et
commis dans l'autre — proclamer une opportunité nulle là où il n'y a qu'une
absence de preuve.

**L'encodage honnête est `available = 0`, pas `value = 0`.** Indisponible réduit
la couverture \(c_e\) ; disponible-et-nul oppose un veto.

**CORRIGÉ dans cette révision.** `forwarding-observer.cc` ne déclare plus
`passiveVisibility` disponible que lorsque le voisin a effectivement été entendu
dans la fenêtre ; sinon `available = 0`. La suite `mtcaodv-forwarding-observer`
assure l'invariant *disponible ⇒ valeur non nulle*, qui ne dépend d'aucun aléa de
calendrier. `analyze_features.py` détecte et signale un CSV produit sous
l'ancien encodage plutôt que d'en tirer des taux trompeurs.

**Explication mécanique du 0,147.** AODV diffuse des HELLO périodiques
(`HelloInterval` = 1 s par défaut) et la fenêtre d'observation vaut 150 ms :
\(0{,}150 / 1{,}0 = 0{,}15\), à comparer aux 0,1466 et 0,1484 mesurés. La
« visibilité » ne mesurait donc ni l'audibilité ni l'honnêteté, mais la
probabilité qu'un HELLO tombe dans la fenêtre — une pure cadence de protocole.
L'accord quantitatif confirme le diagnostic.

### Ordre des travaux imposé par la mesure

1. **La caractéristique d'opportunité d'abord.** Instrumenter les \(y_\ell\)
   en premier serait quasi sans effet : 85 % des événements resteraient à
   \(O_e = 0\).
2. **Candidat prioritaire : `linkReliability`** — historique des émissions de
   \(i\) vers \(j\). Local, légitime, disponible pour ~100 % des événements
   (une fenêtre ne s'ouvre qu'après une émission de \(i\) vers \(j\)), et
   **graduée** dans \([0,1]\) donc n'atteignant quasi jamais le veto exact.
   Limite énoncée : elle mesure le lien \(i \to j\) alors que l'écoute dépend
   du lien \(j \to i\) ; corrélés en canal réciproque, non identiques.
3. **Règle générale.** Une caractéristique **binaire** dans l'Éq. (7) est un veto
   déguisé. Préférer des grandeurs graduées, et réserver la valeur 0 aux cas où
   l'on sait réellement qu'il n'y avait aucune opportunité.

## 4ter. `linkReliability` : mesure ACTIVE, instrumentée

**Sources vérifiées dans l'arbre ns-3.48 de l'utilisateur**, non supposées :

| trace | signature | emplacement |
|---|---|---|
| `AckedMpdu` | `void(Ptr<const WifiMpdu>)` | `src/wifi/model/wifi-mac.cc:333` |
| `NAckedMpdu` | `void(Ptr<const WifiMpdu>)` | `src/wifi/model/wifi-mac.cc:338` |

`WifiMpdu::GetHeader().GetAddr1()` porte la MAC du destinataire.

**Pourquoi une mesure active est nécessaire.** L'écoute passive ne peut pas
distinguer « \(j\) est inaudible » de « \(j\) est silencieux » : c'est une
limite d'information, pas un manque d'implémentation. Le 0,147 en est la
démonstration chiffrée. Un ACK MAC, lui, prouve que \(j\) a reçu — donc qu'il y
avait une opportunité de le voir relayer.

**Pourquoi cela devrait discriminer là où `passiveVisibility` échouait.** Un
Blackhole **acquitte normalement** — l'acquittement est matériel, il ne relève
pas de la politique de transfert. Il présentera donc une fiabilité **élevée**
tout en ne relayant rien. C'est exactement le signal que l'Éq. (7) doit capter :
opportunité forte + aucune retransmission = évidence. À **vérifier par la
mesure**, non à supposer.

**Structure bornée par construction.** Les 32 dernières issues tiennent dans un
`uint32_t`, bit de poids faible = la plus récente ; au-delà, elles sortent du mot
d'elles-mêmes. Aucune allocation, aucun élagage périodique qu'on pourrait
oublier. Table plafonnée par `MaxLearnedAddresses`.

**Disponibilité.** `available` seulement si ≥ `LinkReliabilityMinSamples` (4 par
défaut) issues sont connues **et** si la MAC du voisin a été apprise. En deçà,
**indisponible** — une fraction calculée sur une ou deux émissions vaudrait 0 ou
1 sur presque rien.

**La valeur 0 y est LÉGITIME**, contrairement à `passiveVisibility` : si aucune
émission récente vers \(j\) n'a été acquittée, il n'y avait réellement aucune
opportunité, et le veto de l'Éq. (7) est la bonne réponse. C'est le cas auquel
la valeur 0 doit être réservée.

**LIMITE ÉNONCÉE.** Ceci mesure le lien \(i \to j\) alors que l'écoute dépend
du lien \(j \to i\). Corrélés en canal réciproque, non identiques. C'est une
hypothèse de modélisation ; elle est écrite dans le code et doit être citée
comme telle dans tout texte publié.

## 4quater. RÉSULTAT : la couverture passe de 14,7 % à 99,4 %

Mesuré sur le même run (seed=1, 10 962 événements) après instrumentation.

| | `passiveVisibility` | `linkReliability` | couverture \(c_e > 0\) | plafond réel | ancien |
|---|---|---|---|---|---|
| honnête | 0.1466 | **0.9905** | **0.9943** | 30 / 30 | 7 |
| attaquant | 0.1484 | **0.9933** | **0.9939** | **5 441 / 5 467** | 809 |

85,2 % des événements étaient annulés ; il en reste 0,6 %. **Aucun veto par
`linkReliability = 0`** : le chemin « valeur nulle légitime » n'est donc pas
exercé par ces données — il reste testé unitairement, pas empiriquement.

### Correction d'une confusion que j'avais introduite au § 4bis

J'y reprochais à `passiveVisibility` son absence de pouvoir discriminant
(z = +0.26). **Ce reproche était mal posé.**

> **Une caractéristique d'opportunité n'a pas à discriminer.** Son rôle est
> d'établir qu'observer *était possible*, pour qu'une non-observation devienne
> interprétable. La grandeur discriminante est \(z_e\), pas \(x_k\).

Des valeurs proches entre honnête et attaquant sont donc **attendues** pour une
bonne caractéristique d'opportunité. Ce qui condamnait `passiveVisibility`
n'était pas l'absence de discrimination mais le **veto sur 85 % des
événements** — l'absence de discrimination n'en était que le *symptôme*,
révélant qu'elle mesurait la cadence des HELLO et non l'opportunité.

Confondre les deux aurait conduit à rejeter `linkReliability` pour la même
raison, alors qu'elle se comporte correctement.

### Le facteur limitant a changé

L'instrumentation d'opportunité n'est plus le goulot. **Le facteur limitant est
désormais \(d_e\)** : sans aucun diagnostic \(y_\ell\), l'Éq. (8) renvoie
toujours \((0,0,0,1)\) via la ligne 7 d'A3.3. La partie B peut donc reprendre
son ordre initial — les diagnostics viennent maintenant.

### Défaut corrigé dans le script

`analyze_features.py` imprimait une conclusion contredite par ses propres
chiffres trois lignes plus haut (« `passiveVisibility` est la SEULE
caractéristique », « au plus 809 »). Le texte narratif n'avait pas suivi
l'ajout de la caractéristique. Corrigé, et la **valeur** de `linkReliability`
est désormais rapportée — moyenne globale, et ventilée selon \(z_e\) — car ne
mesurer que la disponibilité était exactement l'erreur commise avec
`passiveVisibility`.

## 4quinquies. `linkReliability` était borgne : mesuré, puis corrigé

**Mesure :** `linkSuccesses = 23 284`, `linkFailures = 0`. Exactement zéro, et
`linkReliability = 1.0000` partout — moyenne, médiane, ventilée selon \(z_e\),
honnête et attaquant.

**Cause :** seule `AckedMpdu` était branchée. En 802.11b avec ACK normal, une
émission qui épuise ses retransmissions part dans **`DroppedMpdu`**, pas dans
`NAckedMpdu` qui ne concerne que les NACK de *block ack*. Seuls les succès
étaient comptés, donc la fiabilité valait structurellement 1.

**Ce qui n'est pas remis en cause :** le gain de couverture, 14,7 % → 99,4 %.
**Ce qui l'est :** la valeur ne portait aucune information.

### Filtrage par raison, et pourquoi il est nécessaire

`WifiMacDropReason` (lu dans `wifi-mac.h:70`) compte quatre valeurs :

| raison | nature | défaillance de LIEN ? |
|---|---|---|
| `WIFI_MAC_DROP_REACHED_RETRY_LIMIT` | pair muet malgré retransmissions | **oui** |
| `WIFI_MAC_DROP_FAILED_ENQUEUE` | file pleine chez \(i\) | non — congestion locale |
| `WIFI_MAC_DROP_EXPIRED_LIFETIME` | attente en file trop longue | non — congestion locale |
| `WIFI_MAC_DROP_QOS_OLD_PACKET` | ordonnancement QoS | non |

Les compter toutes ferait de `linkReliability` une **mesure de congestion
déguisée**, portant deux phénomènes distincts sous un seul nom.

Les quatre compteurs sont rapportés séparément : sans eux, « 0 échec » resterait
indiscernable de « la trace n'est pas branchée » — l'ambiguïté même qui a permis
au défaut de survivre.

### Convergence pour un futur diagnostic

`FAILED_ENQUEUE` et `EXPIRED_LIFETIME` sont exactement le **proxy local de
congestion** autorisé en § 2.1, à condition qu'il porte un nom distinct. Une
seule trace fournit donc les deux signaux, séparés par leur raison. Ils ne sont
pas fondus dans `linkReliability` et ne le seront pas.

### Pré-enregistrement, pour ne pas rationaliser après coup

Après ce branchement, deux issues sont possibles et la conclusion est fixée
**d'avance** :

- **`macDropsRetryLimit > 0`** → la fiabilité varie, la caractéristique porte
  enfin de l'information, et sa distribution devient mesurable.
- **`macDropsRetryLimit = 0`** → les liens de ce scénario ne défaillent
  réellement jamais au niveau MAC. `linkReliability` reste alors constante à
  1,0 : **correcte mais muette**. Il faudra le dire ainsi, et non présenter une
  constante comme une mesure. La conséquence serait qu'à 200 m de portée avec
  `RangePropagationLossModel` — un modèle binaire tout-ou-rien, sans
  évanouissement — l'échec de lien n'existe pas par construction du canal, et
  la caractéristique d'opportunité devrait être cherchée ailleurs ou le modèle
  de propagation reconsidéré.

## 4sexies. `DroppedMpdu` branchée : cas A, mais l'intuition du cas B tenait

**Mesure :** `linkSuccesses = 23 284`, `linkFailures = 37`, tous en
`macDropsRetryLimit` ; les trois autres raisons valent 0. Le pré-enregistrement
désigne donc le **cas A** : la fiabilité varie.

**Mais l'intuition du cas B était juste sur le fond.** Plage dynamique observée :
**0,9928 à 1,0000**, pour un taux d'échec global de 0,159 %. Comparée à la
variation de la couverture (0,147 → 0,993), la contribution des *valeurs* à
\(O_e\) est négligeable : \(O_e \approx c_e\). `RangePropagationLossModel`
est bien un canal quasi binaire ; le compteur non nul ne le contredit pas.

| | moyenne | \| retransmission vue | \| AUCUNE retransmission |
|---|---|---|---|
| honnête | 0.9993 | 0.9994 | **0.9928** |
| attaquant | 0.9998 | 1.0000 | **0.9998** |

### Le signal est là, mais la moyenne l'écrase

Sur une plage de 0,993 à 1,000, une moyenne est illisible. Ré-exprimé en
**fraction d'événements dont le lien a récemment défailli**, le même fait
devient net. Les valeurs déduites des moyennes suggèrent ~23 % côté honnête
contre ~0,6 % côté attaquant, soit un facteur ~36.

**Ces chiffres sont INFÉRÉS des moyennes, pas mesurés.** `analyze_features.py`
mesure désormais la fraction **directement** — `LIEN DEGRADE (fiabilite < 1)`,
ventilée selon \(z_e\) — précisément pour ne pas fonder une conclusion sur une
déduction. Les valeurs mesurées remplaceront les valeurs déduites.

### Réserve de conception, non tranchée

Le raisonnement qui rend ce signal intéressant est le suivant : *une défaillance
récente du lien est une explication **bénigne** d'une non-observation — le voisin
n'a peut-être jamais reçu le paquet.*

Or c'est la définition d'un diagnostic \(y_\ell\) (Éq. 8), pas d'une
caractéristique d'opportunité \(x_k\) (Éq. 7), rôle sous lequel `linkReliability`
est actuellement instrumentée.

Employer la même grandeur dans les deux équations demande une **justification
explicite** : \(O_e\) faible réduit \(I_e\) donc augmente l'incertitude, tandis
que \(\bar B_e\) élevé déplace la masse vers le bénin. Les deux effets sont
distincts, mais adossés au même fait. Sans justification, le même événement
serait compté deux fois. **À trancher avant l'implémentation d'A3.3.**

## 4septies. ARBITRAGE : option (1) avec séparation temporelle stricte

Décision utilisateur, normative.

### La règle

\[
x_{\mathrm{link}}(e) = \widehat R_{ij}(t_e^-)
\]

`linkReliability` **reste** une caractéristique d'opportunité \(x_k\), calculée
**uniquement** à partir de l'historique disponible **avant** l'ouverture de la
fenêtre. Elle répond à : *avant d'observer le résultat de cet événement,
avions-nous de bonnes raisons de penser que le paquet pouvait atteindre \(j\) ?*

Le diagnostic bénin sera une variable **distincte**
\(y_{\mathrm{link\text{-}failure}}(e)\), construite à partir d'informations
observées **pendant** l'événement. Elle répond à une autre question : *avons-nous
observé pendant cet événement un mécanisme bénin susceptible d'expliquer la
non-retransmission ?*

**Rejeté** : \(x_{\mathrm{link}} = r,\; y_{\mathrm{link}} = 1-r\) depuis le
même \(r\). Cela appliquerait deux fois la même information sans modèle
probabiliste justifiant la factorisation.

**Invariant normatif** : \(x_{\mathrm{link}}(e)\) est **gelée à l'ouverture** et
ne doit jamais incorporer l'issue de \(e\) avant le calcul des masses.

### La fuite existait dans le code livré

`linkReliability` était calculée dans `CloseWindow()`, 0 à 150 ms après
l'ouverture. Dans cet intervalle, l'issue MAC de la transmission qui a **ouvert**
la fenêtre est enregistrée — l'ACK arrive en moins d'une milliseconde.

Le couplage est **causal**, pas statistique : un échec MAC vers \(j\) implique
que \(j\) n'a jamais reçu le paquet, donc \(z_e = 0\) **forcé**. La
caractéristique d'opportunité prédisait son propre résultat.

**Conséquence sur le § 4sexies.** L'écart honnête `0.9928` (non-observé) contre
`0.9994` (observé), présenté comme « causalement intéressant », est au moins en
partie cette contamination. L'inférence des ~23 % était en outre fragile pour une
seconde raison : elle confondait « échec de CETTE transmission » et « échec
quelque part dans les 32 dernières », un même échec dégradant jusqu'à 32
événements consécutifs. **Ce chiffre est retiré.**

### Correction et vérification sur traces

- `OpenWindowRecord` porte `linkReliabilityAtOpen`, capturée dans `OpenWindow()`.
  Celle-ci est appelée depuis la trace `Ipv4L3Protocol`, donc **au niveau IP,
  avant que le paquet n'atteigne le MAC** : l'issue de l'événement ne peut
  structurellement pas y figurer.
- `CloseWindow()` utilise la valeur gelée, sans recalcul.
- La valeur recalculée à la clôture est exportée comme
  `linkReliabilityAtClose` — **DIAGNOSTIC UNIQUEMENT, n'entre dans aucune
  équation**. L'écart entre les deux colonnes **est** la contamination
  supprimée, et le compteur `linkReliabilityChangedDuringWindow` la totalise.

C'est la vérification sur traces exigée au point 5 : elle mesure le défaut au
lieu de se contenter de l'avoir corrigé.

### Option (2) écartée comme modèle normatif

Si `linkReliability` devenait uniquement \(y_\ell\) sans autre \(x_k\) valide,
la formulation actuelle donne \(c_e = 0\) puis \(O_e = 0\), et non une
opportunité utile. Poser \(O_e = c_e\) serait une **modification supplémentaire
de l'Éq. (7)**, à évaluer séparément.

Le constat \(O_e \approx c_e\) justifie en revanche une **ablation
« coverage-only »** contre l'Éq. (7) complète. Simplification uniquement sur
preuve expérimentale : gain nul mesurable en calibration, en FQR ou en
discrimination, à performance de détection comparable.

### Reste à faire avant de déclarer A3.3 validé

1. ✅ `linkReliability(t⁻)` reste \(x_k\)
2. ✅ gelée avant l'événement courant
3. ⬜ diagnostic événementiel de rupture/livraison, instrumenté séparément
   comme \(y_\ell\)
4. ✅ aucune information du même événement des deux côtés
5. ⬜ vérification de la séparation **sur traces** — outillage livré, mesure à
   produire

## 4octies. MESURE DU GEL : le signal apparent était la fuite

Exécuté après le gel, même run (seed=1, 10 962 événements).

### Le résultat qui compte

| non-observations honnêtes | avant le gel | après le gel |
|---|---|---|
| `VALEUR linkReliability` | 0.9928 | **1.0000** |
| `LIEN DEGRADE` | ~23 % (inféré) | **0.0000 — 0 événement** |

**Le « ~23 % des non-observations honnêtes expliquées par une défaillance de
lien » était entièrement un artefact de la fuite temporelle.** Avec la
caractéristique causalement propre, **aucune** des 29 non-observations honnêtes
n'avait de lien dégradé, et le sens de l'écart s'inverse : honnête 1.0000 contre
attaquant 0.9998.

L'invariant n'a donc pas corrigé un défaut de forme : il a **supprimé un signal
qui n'existait pas**.

### La fuite, mesurée

`linkReliabilityChangedDuringWindow = 49` — honnête 31 (dont 5
non-observations), attaquant 18 (dont **18** non-observations).

**18 sur 18 côté attaquant** : chaque événement affecté était une
non-observation. C'est exactement le couplage causal — un échec MAC vers \(j\)
implique que \(j\) n'a jamais reçu le paquet, donc \(z_e = 0\) forcé.

### Deux réserves sur ma propre lecture

**Le compteur 49 est une borne supérieure, pas la fuite.** La fenêtre glissante
de 32 issues change aussi quand un échec **ancien en sort** : la valeur **monte**,
ce qui est inoffensif. Seule la **baisse** traduit un échec qui vient d'entrer.
Côté honnête, 26 des 31 événements affectés étaient appariés — vraisemblablement
des sorties de fenêtre. La ventilation par direction est désormais rapportée.

**`0/29` contre `30/5405` n'est pas une différence.** À un taux de 0,56 %,
l'espérance sur 29 événements vaut 0,16 : observer zéro n'a rien de remarquable.
Le script refuse maintenant d'imprimer un rapport quand l'espérance du petit
échantillon est inférieure à 5, plutôt que d'afficher un « 0.0x » qui se lirait
comme un résultat.

### Effet secondaire du gel, mineur et attendu

Disponibilité 0.9905 → 0.9877 (honnête), 0.9933 → 0.9878 (attaquant) : à
l'ouverture, moins d'issues sont accumulées qu'à la clôture, donc quelques
événements passent sous le seuil de 4. Couverture 0.9943 → 0.9922, plafond
attaquant 5 441 → 5 405.

### Conséquence pour l'Éq. (8)

La baseline bénigne de 0,0071 n'est **pas** expliquée par la qualité du lien.
Les 30 non-observations honnêtes viennent d'ailleurs : collisions sur le trajet
d'écoute, fenêtre de 150 ms, terminal caché, mobilité. Le diagnostic
\(y_\ell\) du point 3 devra chercher **ces** mécanismes, et non la défaillance
de lien que la mesure vient d'écarter.

## 4nonies. Fenêtre écartée par mesure ; un quatrième chemin mort trouvé

### Le levier de fenêtre fonctionne — vérifié par falsification

| | 150 ms | 300 ms | 1 ms |
|---|---|---|---|
| `windowsMatched` | 5 465 | 5 465 | **3 839** |
| `windowsDeadline` | 5 497 | 5 497 | **7 123** |
| `windowsOpened` | 10 962 | 10 962 | 10 962 |
| `pdr` | 0.5971558524 | idem | idem |

Le run à 300 ms, identique au dernier chiffre, aurait pu signifier « la fenêtre
n'y est pour rien » **ou** « le paramètre n'est pas appliqué ». Un run à la
valeur minimale autorisée (1 ms) départage : la perte de 30 % prouve que le
levier agit.

**Conclusion : les 30 non-observations honnêtes ne sont pas dues à la fenêtre.**
Elles sont réelles — \(j\) n'a pas retransmis dans les 150 ms, ni dans les
300 ms. Candidat écarté par mesure.

*Prédiction et réalité :* j'annonçais « environ la moitié » des appariements
perdus, la perte est de 30 %. Direction juste, quantité fausse — la fenêtre
effective est plus généreuse que mon estimation, l'appariement survenant à la
réception à tout instant avant le balayage.

### Comptabilité des 30 non-observations honnêtes

| cause | événements | statut |
|---|---|---|
| échec MAC pendant la fenêtre | 5 | cible de \(y_{\text{link-failure}}\) |
| fenêtre trop courte | 0 | **écarté par mesure** |
| collision d'écoute, mobilité | ~25 | à instrumenter |

### `NEIGHBOR_LOST` : un chemin déclaré, jamais atteint — depuis RETIRÉ

`CloseWindow()` n'est appelée qu'avec `MATCHED`, `DEADLINE` et `EVICTED`.
`NEIGHBOR_LOST` n'apparaît dans le `.cc` qu'au `case` du `switch` qui incrémente
son compteur. **Rien ne l'émet.**

`windowsNeighborLost = 0` n'est donc pas une mesure de la mobilité : c'est une
absence de code. Et `forwarding-observation.h` documente cette raison comme
« SCIENTIFIQUE, pas décorative ».

### Le motif, et la garde qui le rend systématique

Quatrième occurrence de la même erreur dans cette étape :

| | grandeur | valeur structurellement constante |
|---|---|---|
| 1 | `passiveVisibility` | mesurait la cadence des HELLO |
| 2 | `available=1, value=0` | veto sur 85 % des événements |
| 3 | `linkReliability` | 1,0 — `NAckedMpdu` inerte en 802.11b |
| 4 | `windowsNeighborLost` | 0 — jamais émis |

Toutes se lisent comme des mesures ; toutes ont été trouvées une par une.

`validate_step03.py` porte désormais `STRUCTURALLY_ZERO` et
`audit_zero_counters()` :

> **Un compteur valant exactement zéro est soit une mesure, soit un chemin non
> implémenté. Le code doit dire lequel.**

Tout compteur nul absent de la table déclenche un avertissement exigeant sa
classification. Les compteurs actuellement nuls y sont classés.

**Suite donnée à `windowsNeighborLost` : suppression, sur décision utilisateur.**
Le classer en « chemin non implémenté » aurait pérennisé un compteur qu'aucun
appelant n'incrémentait ; le retirer supprime l'ambiguïté à la source — il n'y a
plus rien à classer. La raison de clôture, son compteur, son accesseur, sa
colonne CSV et son entrée dans la conservation ont été retirés de six fichiers.

**Vérification préalable, décisive.** La spécification a été relue AVANT la
suppression : A3.2 ligne 10 dit *« if j disappeared before a meaningful
opportunity existed then LOWER COVERAGE »* — elle demande d'agir sur les drapeaux
de disponibilité \(a_k\) de l'Éq. (6), et ne spécifie **aucune** quatrième
raison de clôture. `NEIGHBOR_LOST` était donc une invention de l'implémentation,
et la retirer ne remplace aucune méthode spécifiée.

**Mais A3.2 ligne 10 reste NON IMPLÉMENTÉE**, sous sa forme réelle : abaisser
\(c_e\). Le commentaire du code désignait cette ligne pour justifier un
mécanisme qu'elle n'avait jamais demandé, ce qui masquait l'exigence au lieu de
la satisfaire. Elle est désormais suivie comme ouverte.

**Réserve.** Détecter la disparition de \(j\) reste soumis à la même contrainte
d'échelle de temps, quelle que soit la forme retenue : la table AODV est 13 fois
plus lente que la fenêtre. Satisfaire A3.2 ligne 10 demandera un détecteur plus
rapide que la table de voisinage, ou une fenêtre bien plus longue.

## 5. Périmètre en trois parties

**A — A3.3 exactement.** Fonction pure, sans ns-3, oracles calculés à la main.
Éq. (6) somme des poids disponibles ; Éq. (7) moyenne géométrique pondérée ×
couverture, avec \(x_k = 0\) traité avant tout \(\log\) ; Éq. (8) moyenne
arithmétique pondérée ; Éq. (9) \(z_e\) seul ; Éq. (10) \(I_e = O_e d_e\).

**B — Instrumentation.** Le corps de l'étape.

| grandeur | type | statut décidé |
|---|---|---|
| `passiveVisibility` | \(x_k\) | **`available = 0`** quand \(j\) n'a rien diffusé, jamais `value = 0` (§ 4bis) ; redéfinition § 3.3 à mesurer |
| `linkReliability` | \(x_k\) | **INSTRUMENTÉE** — traces MAC `AckedMpdu` / `NAckedMpdu`, historique borné de 32 issues, `available` si ≥ 4 issues |
| `predictedContactPersistence` | \(x_k\) | **indisponible** jusqu'à estimateur local validé |
| `mobilityBreak` | \(y_\ell\) | à instrumenter — table de voisinage de \(i\) |
| `coherentRerr` | \(y_\ell\) | à instrumenter — flux RERR reçu par \(i\) |
| `queuePressure` | \(y_\ell\) | **indisponible** (file de \(j\) non lisible) |

**C — Calibration de \(\omega_k, \nu_\ell\).** Marqués **À confirmer C-05**.
Seeds **distincts** de l'évaluation. Ne peut pas venir avant B.

---

## 6. Critères de fermeture (élargis sur demande utilisateur)

STEP 4 **ne peut pas** être fermé sur la seule implémentation de
`EvidenceAttributor`. PASS exige les huit :

1. **T-13**, test prescrit par la spécification : sur une grille de valeurs,
   toutes les masses dans \([0,1]\) et \(g+m+b+u = 1\) à la tolérance près.
2. **Fail closed** : \(c_e = 0 \Rightarrow (0,0,0,1)\) et
   \(d_e = 0 \Rightarrow (0,0,0,1)\), testés explicitement.
3. **Oracles calculés à la main** avant encodage, au moins trois attributions
   complètes.
4. **Instrumentation locale effective** des caractéristiques et diagnostics
   réellement accessibles (§ 5 partie B).
5. **Compteurs de disponibilité** rapportés par grandeur : combien d'événements
   avec \(a_k = 1\), combien avec \(a_\ell = 1\).
6. **Distributions rapportées** de \(c_e\), \(d_e\), \(O_e\), \(I_e\), \(u_e\).
7. **Fraction d'événements non interprétables** mesurée et rapportée.
   Si elle vaut 1, l'étape est **FAIL** — l'instrumentation n'aurait rien apporté.
8. **Non-intrusion et non-régression** : `PDR` inchangé au chiffre près, les 11
   suites vertes, `src/aodv` intact.

Les poids OCEA ne peuvent être **calibrés et gelés qu'après** cette validation.

**Rapporté sans seuil** : distributions des quatre masses chez un voisin honnête
et chez un attaquant ; écart entre l'Éq. (9) spécifiée et la variante
\(z_e \wedge \text{attribué}\).

**FAIL :** une masse hors \([0,1]\) ; une somme ≠ 1 ; une valeur par défaut
substituée à une caractéristique indisponible ; la lecture de l'état interne
d'un voisin ; l'usage de la liste des attaquants hors évaluation hors ligne ;
`passiveVisibility` dérivé de \(z_e\).

---

## 7. Le finding hérité du STEP 3

L'Éq. (9) accorde \((1,0,0,0)\) dès \(z_e = 1\). Le STEP 3 a mesuré **1 272 des
6 739 événements d'attaquant (18,9 %) avec \(z_e = 1\) et attribution nulle** :
la retransmission venait d'un **tiers**.

**Traitement :** l'Éq. (9) est implémentée telle que spécifiée. STEP 4 rapporte
**en parallèle**, en diagnostic séparé, les masses obtenues sous
\(z_e \wedge \text{attribué}\). Implémenter la spécification, instrumenter
l'alternative, mesurer l'écart.

---

## 8. Ce que STEP 4 ne fera PAS

- Pas de MOBeta-Trust : les Éq. (11)–(12) et le posterior Beta consomment les
  masses OCEA, étape suivante.
- Pas de calibration finale de \(\omega, \nu\) : après B, sur seeds distincts.
- Pas de changement de machine à états : WATCH reste une surveillance renforcée,
  ACCUSED n'est pas une quarantaine, QUARANTINED exige un certificat.
- Pas de correction de `IsBroadcast()` : faiblesse enregistrée au STEP 3, sans
  effet sur ce périmètre.
