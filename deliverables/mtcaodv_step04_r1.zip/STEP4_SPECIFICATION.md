# STEP 4 — Attribution OCEA en quatre masses (A3.3, Éq. 6–10)

**Révision 2** — intègre les arbitrages de l'utilisateur sur `queuePressure`,
`predictedContactPersistence`, \(\varepsilon\), et la séparation entre
`passiveVisibility` et \(z_e\).

Document de **spécification**. Source normative :
`MTCAODV_Mathematical_Algorithms_Specification.md`, § 5.4 et algorithme A3.3.

---

## 1. Le fait qui détermine le périmètre

L'observateur du STEP 3 renseigne **une seule** caractéristique d'opportunité,
`passiveVisibility` ; les cinq indicateurs \(y_\ell\) sont marqués indisponibles.
A3.3 ligne 7 : `if d = 0 then return (0,0,0,1)`.

**Sur le run validé, OCEA renverrait une incertitude totale pour les 10 962
observations.** Conforme à la spécification, mais cela ne démontrerait qu'une
chose : que le cas « diagnostics indisponibles » est correctement traité.

Le corps de STEP 4 est donc **l'instrumentation et la validation des observables
qui alimentent A3.3**, pas les trente lignes d'arithmétique des équations.

---

## 2. Arbitrages tranchés (verrouillés)

### 2.1 `queuePressure` — indisponible

La file pertinente pour expliquer une non-retransmission est celle de \(j\).
**Aucune lecture de l'état interne de \(j\) dans la voie déployable.** Son
indicateur de disponibilité reste à zéro.

La file locale de \(i\) **ne doit pas être présentée sous le même nom**. Si elle
est utilisée un jour, ce sera comme un **proxy distinct de congestion locale**,
portant son propre nom, avec sa propre validation. Confondre les deux dans le
code ou dans un texte publié serait une faute de méthode, pas un raccourci.

### 2.2 `predictedContactPersistence` — indisponible, non supprimée

Elle n'est **pas** retirée de la spécification. Elle reste indisponible tant
qu'un estimateur fondé **uniquement sur l'historique local observable du lien
\(i\!-\!j\)** n'a pas été défini **et validé**. En l'absence d'un tel estimateur,
\(a_k(e) = 0\) en permanence.

Aucune lecture de `MobilityModel` de \(j\) : techniquement triviale en
simulation, scientifiquement invalide.

### 2.3 \(\varepsilon\) — pas un plancher

\(\varepsilon\) **n'est pas** utilisé comme plancher arbitraire sur \(x_k\) dans
l'Éq. (7). La forme normative traite explicitement \(c_e = 0\), et un
\(x_k = 0\) **réellement disponible doit pouvoir produire \(O_e = 0\)** — c'est
une information, pas une singularité à masquer.

Implémentation : si la moyenne géométrique passe par le domaine logarithmique,
le cas \(x_k = 0\) est traité **explicitement avant tout appel à \(\log\)**,
jamais remplacé par \(\varepsilon\).

**C-06 reste ouvert** jusqu'à ce que les usages numériques exacts de
\(\varepsilon\) et de `numericalTolerance` soient **figés par les tests**.

### 2.4 `passiveVisibility` ≠ \(z_e\)

`passiveVisibility` doit mesurer la **capacité de l'observateur à écouter
pendant la fenêtre**, indépendamment du résultat de cette écoute. \(z_e\) reste
un résultat séparé.

Le raisonnement à interdire : si `passiveVisibility = 0` parce qu'aucune
retransmission n'a été entendue, alors toute non-observation donne \(O_e = 0\),
puis \(I_e = 0\), et **aucune évidence malveillante ne peut jamais être
produite**. Le mécanisme s'auto-annulerait.

---

## 3. État réel de `passiveVisibility` : vérifié, et insuffisant

### 3.1 Pas de circularité — vérifié dans le code

`m_lastHeardFromNeighbor` n'est écrit que dans `LearnAddressMapping`, appelée
**uniquement** sous `packetType == PACKET_BROADCAST`. La retransmission
surveillée est un relais **unicast** (`PACKET_OTHERHOST`) : elle ne met jamais
cette table à jour.

```
z_e                ← appariement d'empreinte, trame UNICAST
passiveVisibility  ← réception de trames BROADCAST de j
```

Classes de trames **disjointes**. L'indépendance est structurelle.

Cette séparation provient d'une décision du spike C-17 prise pour une raison
différente — une trame unicast peut être un relais dont l'IP source est un tiers
— et non d'une anticipation de cet argument. Elle est correcte ; elle n'était
pas intentionnelle.

### 3.2 Le défaut réel : ce n'est pas la bonne grandeur

`passiveVisibility` mesure **l'activité broadcast de \(j\)**, pas la capacité
d'écoute de \(i\). AODV ne diffuse des RREQ que pendant la découverte ; en régime
établi, un voisin parfaitement audible peut ne rien diffuser pendant plusieurs
secondes.

`passiveVisibility = 0` confond donc :

- « je ne peux pas entendre \(j\) » — l'information voulue ;
- « \(j\) n'avait rien à diffuser dans les 150 dernières ms » — un artefact du
  protocole de routage.

Ce n'est pas circulaire, mais ce n'est pas ce que l'Éq. (7) demande.

### 3.3 Redirection proposée, à valider par la mesure

Sources d'audibilité **indépendantes de \(z_e\) pour l'événement \(e\)** :

- **toute trame attribuable à \(j\)** reçue pendant la fenêtre **autre que celle
  qui clôt \(e\)** — y compris les relais unicast de \(j\) portant sur d'autres
  flux, qui prouvent que \(j\) est vivant et audible sans rien dire de \(e\) ;
- **activité du canal** : l'observateur a-t-il reçu la moindre trame pendant la
  fenêtre ? Un canal totalement silencieux ne prouve pas que \(j\) se tait, il
  prouve que \(i\) n'écoutait rien d'utile.

Ces deux pistes ne sont **pas** retenues par décret : elles seront mesurées
avant d'être adoptées. La réserve à instruire : utiliser les autres relais de
\(j\) crée, à travers les événements, une corrélation avec l'honnêteté de \(j\)
— nulle pour \(e\) pris isolément, non nulle en agrégat.

---

## 4. Mesure préalable, sur données déjà produites

`experiments/analyze_features.py` mesure le **plafond d'attribution** avant
qu'une seule ligne de C++ soit écrite.

L'Éq. (7) étant une moyenne géométrique, une visibilité nulle donne
\(O_e = 0\) donc \(I_e = 0\) — **quels que soient les diagnostics \(y_\ell\)
instrumentés ensuite**. Donc :

> Le nombre de non-observations d'attaquant **avec** visibilité non nulle est une
> **borne dure** sur ce qu'OCEA peut attribuer avec l'instrumentation actuelle.

Si ce plafond est nul ou faible, instrumenter les \(y_\ell\) sans corriger la
caractéristique d'opportunité serait **sans effet**. Cette mesure décide donc
l'ordre des travaux, et elle est disponible immédiatement.

Le script rapporte aussi \(P(\text{visible} \mid z_e{=}1)\) et
\(P(\text{visible} \mid z_e{=}0)\). **Aucun seuil n'est préenregistré pour leur
écart** : un voisin physiquement joignable a plus de chances des deux côtés, donc
un écart est attendu et ne prouve **pas** une circularité. Le script rapporte, il
ne juge pas.

---

## 5. Périmètre en trois parties

**A — A3.3 exactement.** Fonction pure, sans ns-3, oracles calculés à la main.
Éq. (6) somme des poids disponibles ; Éq. (7) moyenne géométrique pondérée ×
couverture, avec \(x_k = 0\) traité avant tout \(\log\) ; Éq. (8) moyenne
arithmétique pondérée ; Éq. (9) \(z_e\) seul ; Éq. (10) \(I_e = O_e d_e\).

**B — Instrumentation.** Le corps de l'étape.

| grandeur | type | statut décidé |
|---|---|---|
| `passiveVisibility` | \(x_k\) | à **redéfinir** (§ 3.3), mesure préalable § 4 |
| `linkReliability` | \(x_k\) | à instrumenter — local à \(i\), légitime |
| `predictedContactPersistence` | \(x_k\) | **indisponible** jusqu'à estimateur local validé |
| `mobilityBreak` | \(y_\ell\) | à instrumenter — table de voisinage de \(i\) |
| `coherentRerr` | \(y_\ell\) | à instrumenter — flux RERR reçu par \(i\) |
| `queuePressure` | \(y_\ell\) | **indisponible** (file de \(j\) non lisible) |

**C — Calibration de \(\omega_k, \nu_\ell\).** Marqués **À confirmer C-05**.
Seeds **distincts** de l'évaluation. Ne peut pas venir avant B.

---

## 6. Critères de fermeture (élargis sur demande utilisateur)

STEP 4 **ne peut pas** être fermé sur la seule implémentation de
`EvidenceAttributor`. PASS exige les huit :

1. **T-13**, test prescrit par la spécification : sur une grille de valeurs,
   toutes les masses dans \([0,1]\) et \(g+m+b+u = 1\) à la tolérance près.
2. **Fail closed** : \(c_e = 0 \Rightarrow (0,0,0,1)\) et
   \(d_e = 0 \Rightarrow (0,0,0,1)\), testés explicitement.
3. **Oracles calculés à la main** avant encodage, au moins trois attributions
   complètes.
4. **Instrumentation locale effective** des caractéristiques et diagnostics
   réellement accessibles (§ 5 partie B).
5. **Compteurs de disponibilité** rapportés par grandeur : combien d'événements
   avec \(a_k = 1\), combien avec \(a_\ell = 1\).
6. **Distributions rapportées** de \(c_e\), \(d_e\), \(O_e\), \(I_e\), \(u_e\).
7. **Fraction d'événements non interprétables** mesurée et rapportée.
   Si elle vaut 1, l'étape est **FAIL** — l'instrumentation n'aurait rien apporté.
8. **Non-intrusion et non-régression** : `PDR` inchangé au chiffre près, les 11
   suites vertes, `src/aodv` intact.

Les poids OCEA ne peuvent être **calibrés et gelés qu'après** cette validation.

**Rapporté sans seuil** : distributions des quatre masses chez un voisin honnête
et chez un attaquant ; écart entre l'Éq. (9) spécifiée et la variante
\(z_e \wedge \text{attribué}\).

**FAIL :** une masse hors \([0,1]\) ; une somme ≠ 1 ; une valeur par défaut
substituée à une caractéristique indisponible ; la lecture de l'état interne
d'un voisin ; l'usage de la liste des attaquants hors évaluation hors ligne ;
`passiveVisibility` dérivé de \(z_e\).

---

## 7. Le finding hérité du STEP 3

L'Éq. (9) accorde \((1,0,0,0)\) dès \(z_e = 1\). Le STEP 3 a mesuré **1 272 des
6 739 événements d'attaquant (18,9 %) avec \(z_e = 1\) et attribution nulle** :
la retransmission venait d'un **tiers**.

**Traitement :** l'Éq. (9) est implémentée telle que spécifiée. STEP 4 rapporte
**en parallèle**, en diagnostic séparé, les masses obtenues sous
\(z_e \wedge \text{attribué}\). Implémenter la spécification, instrumenter
l'alternative, mesurer l'écart.

---

## 8. Ce que STEP 4 ne fera PAS

- Pas de MOBeta-Trust : les Éq. (11)–(12) et le posterior Beta consomment les
  masses OCEA, étape suivante.
- Pas de calibration finale de \(\omega, \nu\) : après B, sur seeds distincts.
- Pas de changement de machine à états : WATCH reste une surveillance renforcée,
  ACCUSED n'est pas une quarantaine, QUARANTINED exige un certificat.
- Pas de correction de `IsBroadcast()` : faiblesse enregistrée au STEP 3, sans
  effet sur ce périmètre.
