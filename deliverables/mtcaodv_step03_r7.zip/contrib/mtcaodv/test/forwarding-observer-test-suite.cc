/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * STEP 3 integration test — Algorithme A3.2, ForwardingObserver.
 *
 * TOPOLOGIE : la chaîne validée par le spike C-17, reprise à l'identique.
 *
 *      N0 ------------- N1 ------------- N2
 *      0 m            150 m            300 m
 *
 * Portée 200 m : N0 et N2 ne s'entendent pas, N0 doit passer par N1, et N0 est
 * en position d'entendre la retransmission de N1. Positions fixes, aucun aléa :
 * un test d'observation ne doit pas dépendre d'un tirage.
 *
 * CE QUE CE TEST ETABLIT
 *   1. Un relais honnête produit des fenêtres closes par APPARIEMENT (z_e = 1).
 *   2. Un relais Blackhole produit des fenêtres closes par ECHEANCE (z_e = 0) —
 *      sans que l'observateur ait jamais accès à la liste des attaquants.
 *   3. La conservation des compteurs : chaque fenêtre ouverte se referme.
 *   4. La NON-INTRUSION : l'observation ne change pas la livraison.
 */

#include "ns3/applications-module.h"
#include "ns3/blackhole-behavior.h"
#include "ns3/core-module.h"
#include "ns3/forwarding-observer.h"
#include "ns3/internet-module.h"
#include "ns3/ipv4-address-generator.h"
#include "ns3/mobility-module.h"
#include "ns3/mtc-aodv-helper.h"
#include "ns3/mtc-aodv-routing-protocol.h"
#include "ns3/network-module.h"
#include "ns3/test.h"
#include "ns3/wifi-module.h"

#include <cstdint>

namespace ns3
{
namespace mtcaodv
{

/** @brief Résultat observable d'une réalisation de la chaîne. */
struct ChainOutcome
{
    uint64_t deliveredBytes{0};   ///< Octets acceptés par le puits en N2.
    uint64_t windowsOpened{0};    ///< Fenêtres ouvertes par l'observateur en N0.
    uint64_t windowsMatched{0};   ///< Closes par appariement (z_e = 1).
    uint64_t windowsDeadline{0};  ///< Closes par échéance (z_e = 0).
    uint64_t windowsEvicted{0};   ///< Évincées : non interprétables.
    uint64_t collisions{0};       ///< Collisions d'empreinte mesurées.
    uint64_t tracedClosures{0};   ///< Clôtures reçues via la TraceSource.
    uint64_t tracedObserved{0};   ///< Dont z_e = 1, comptées côté trace.
    uint64_t tracedAttributed{0}; ///< Dont l'émetteur a pu être attribué à N1.
    uint64_t skippedLastHop{0};   ///< Émissions écartées comme dernier saut, EN N0.
    uint64_t transmissions{0};    ///< Émissions IPv4 examinées, en N0.

    // Compteurs de l'observateur installé sur le RELAIS N1. Ils sont séparés,
    // et non agrégés, parce que les deux rôles ont des propriétés structurelles
    // OPPOSÉES et que c'est précisément ce contraste que l'on veut tester :
    //   * N0 est à deux sauts de N2, donc son prochain saut n'est JAMAIS la
    //     destination : il ouvre des fenêtres, et n'écarte aucun dernier saut ;
    //   * N1 est à un saut de N2, donc son prochain saut est TOUJOURS la
    //     destination : il n'ouvre aucune fenêtre, et écarte tout.
    // Sommer les deux masquerait exactement le défaut que ce test doit attraper.
    uint64_t relayTransmissions{0};   ///< Émissions IPv4 examinées, en N1.
    uint64_t relayWindowsOpened{0};   ///< Fenêtres ouvertes par N1 : doit valoir 0.
    uint64_t relaySkippedLastHop{0};  ///< Derniers sauts écartés par N1 : doit être > 0.
};

/**
 * @brief Test d'intégration de l'observateur de transfert (A3.2).
 */
class ForwardingObserverTestCase : public TestCase
{
  public:
    ForwardingObserverTestCase()
        : TestCase("A3.2 : un relais honnete est observe, un Blackhole ne l'est pas")
    {
    }

  private:
    /** @brief Accumulateur de la TraceSource ; lié par MakeBoundCallback. */
    static void OnObservationClosed(ChainOutcome* outcome,
                                    const ForwardingObservation& observation)
    {
        ++outcome->tracedClosures;
        if (observation.forwardingObserved)
        {
            ++outcome->tracedObserved;
        }
        if (observation.senderAttributedToNeighbor)
        {
            ++outcome->tracedAttributed;
        }
    }

    /**
     * @brief Exécute la chaîne une fois.
     * @param attackerNodeId Nœud à rendre Blackhole, ou -1 pour tout honnête.
     * @param observationEnabled Active l'observateur (preuve de non-intrusion).
     * @return Livraison et compteurs d'observation.
     */
    ChainOutcome RunChain(int32_t attackerNodeId, bool observationEnabled)
    {
        RngSeedManager::SetSeed(12345);
        RngSeedManager::SetRun(1);
        RngSeedManager::ResetNextStreamIndex();
        Ipv4AddressGenerator::Reset();

        NodeContainer nodes;
        nodes.Create(3);

        Ptr<ListPositionAllocator> positions = CreateObject<ListPositionAllocator>();
        positions->Add(Vector(0.0, 0.0, 0.0));   // N0 : source et observateur
        positions->Add(Vector(150.0, 0.0, 0.0)); // N1 : relais
        positions->Add(Vector(300.0, 0.0, 0.0)); // N2 : destination
        MobilityHelper mobility;
        mobility.SetPositionAllocator(positions);
        mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
        mobility.Install(nodes);

        YansWifiChannelHelper channel;
        channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
        channel.AddPropagationLoss("ns3::RangePropagationLossModel",
                                   "MaxRange",
                                   DoubleValue(200.0));
        YansWifiPhyHelper phy;
        phy.SetChannel(channel.Create());
        WifiHelper wifi;
        wifi.SetStandard(WIFI_STANDARD_80211b);
        wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                     "DataMode",
                                     StringValue("DsssRate11Mbps"),
                                     "ControlMode",
                                     StringValue("DsssRate1Mbps"));
        WifiMacHelper mac;
        mac.SetType("ns3::AdhocWifiMac");
        NetDeviceContainer devices = wifi.Install(phy, mac, nodes);
        WifiHelper::AssignStreams(devices, 85000);

        MtcAodvHelper mtcAodv;
        InternetStackHelper internet;
        internet.SetRoutingHelper(mtcAodv);
        internet.Install(nodes);
        mtcAodv.AssignStreams(nodes, 86000);

        Ipv4AddressHelper ipv4;
        ipv4.SetBase("10.1.0.0", "255.255.255.0");
        Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);

        if (attackerNodeId >= 0)
        {
            Ptr<BlackholeBehavior> behavior = CreateObject<BlackholeBehavior>();
            behavior->SetAttribute("AttackStartTime", TimeValue(Seconds(1.0)));
            mtcAodv.InstallAttackBehavior(nodes.Get(attackerNodeId), behavior);
        }

        ChainOutcome outcome;

        // Observateur sur N0 uniquement : c'est lui qui remet le paquet à N1 et
        // qui doit entendre la retransmission. L'observateur ne reçoit AUCUNE
        // information sur l'identité de l'attaquant.
        Ptr<ForwardingObserver> observer = CreateObject<ForwardingObserver>();
        observer->SetAttribute("Enabled", BooleanValue(observationEnabled));
        observer->TraceConnectWithoutContext(
            "ObservationClosed",
            MakeBoundCallback(&ForwardingObserverTestCase::OnObservationClosed, &outcome));
        // Install() resout lui-meme le protocole de routage et se branche sur
        // les traces Ipv4L3Protocol. Le protocole de routage ignore totalement
        // l'existence de l'observateur.
        observer->Install(nodes.Get(0));

        // Observateur sur le RELAIS N1. Sans lui, `skippedLastHop` est
        // insatisfiable par construction : seul un nœud dont le prochain saut
        // EST la destination peut l'incrémenter, et N0 n'est jamais dans ce cas
        // (N2 est hors portée, la route passe toujours par N1). Il ne reçoit,
        // lui non plus, aucune information sur l'identité de l'attaquant.
        Ptr<ForwardingObserver> relayObserver = CreateObject<ForwardingObserver>();
        relayObserver->SetAttribute("Enabled", BooleanValue(observationEnabled));
        relayObserver->Install(nodes.Get(1));

        const uint16_t port = 9100;
        Ipv4Address destinationAddress = interfaces.GetAddress(2);
        PacketSinkHelper sinkHelper("ns3::UdpSocketFactory",
                                    InetSocketAddress(Ipv4Address::GetAny(), port));
        ApplicationContainer sinkApps = sinkHelper.Install(nodes.Get(2));
        sinkApps.Start(Seconds(0.5));
        sinkApps.Stop(Seconds(10.0));

        OnOffHelper source("ns3::UdpSocketFactory",
                           InetSocketAddress(destinationAddress, port));
        source.SetAttribute("DataRate", DataRateValue(DataRate("16kbps")));
        source.SetAttribute("PacketSize", UintegerValue(512));
        source.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1e9]"));
        source.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0.0]"));
        ApplicationContainer sourceApps = source.Install(nodes.Get(0));
        sourceApps.Start(Seconds(3.0));
        sourceApps.Stop(Seconds(9.0));

        Simulator::Stop(Seconds(10.0));
        Simulator::Run();

        Ptr<PacketSink> sink = DynamicCast<PacketSink>(sinkApps.Get(0));
        outcome.deliveredBytes = sink ? sink->GetTotalRx() : 0;
        outcome.windowsOpened = observer->GetWindowsOpened();
        outcome.windowsMatched = observer->GetWindowsMatched();
        outcome.windowsDeadline = observer->GetWindowsDeadline();
        outcome.windowsEvicted = observer->GetWindowsEvicted();
        outcome.collisions = observer->GetFingerprintCollisions();
        outcome.skippedLastHop = observer->GetSkippedLastHop();
        outcome.transmissions = observer->GetTransmissionsInspected();
        outcome.relayTransmissions = relayObserver->GetTransmissionsInspected();
        outcome.relayWindowsOpened = relayObserver->GetWindowsOpened();
        outcome.relaySkippedLastHop = relayObserver->GetSkippedLastHop();

        Simulator::Destroy();
        return outcome;
    }

    void DoRun() override
    {
        // ---- 1. Relais honnête : l'observation doit aboutir ----
        const ChainOutcome honest = RunChain(-1, true);

        // N0 est la SOURCE. Une premiere version accrochait Forwarding(), qui ne
        // traite que le transit : une source ne l'appelle jamais pour ses propres
        // paquets, donc aucune fenetre ne s'ouvrait. Cette assertion protege
        // desormais le cas DOMINANT d'un chemin a deux sauts.
        NS_TEST_ASSERT_MSG_GT(honest.transmissions,
                              0u,
                              "aucune emission IPv4 examinee : les traces "
                              "Ipv4L3Protocol ne sont pas branchees");
        NS_TEST_ASSERT_MSG_GT(honest.windowsOpened,
                              0u,
                              "aucune fenetre ouverte alors que N0 est la source "
                              "d'un chemin a deux sauts : l'observation ne se "
                              "declenche pas la ou il y a quelque chose a voir");
        NS_TEST_ASSERT_MSG_GT(honest.windowsMatched,
                              0u,
                              "un relais honnete n'a produit aucun appariement : "
                              "l'ecoute passive ou l'empreinte est cassee");
        NS_TEST_ASSERT_MSG_EQ(honest.tracedObserved,
                              honest.windowsMatched,
                              "la TraceSource et les compteurs internes divergent");

        // Conservation : toute fenetre ouverte finit close. Une fuite signalerait
        // des fenetres restees ouvertes en fin de simulation, donc des
        // observations perdues sans que rien ne le signale.
        const uint64_t closed = honest.windowsMatched + honest.windowsDeadline +
                                honest.windowsEvicted;
        NS_TEST_ASSERT_MSG_LT_OR_EQ(closed,
                                    honest.windowsOpened,
                                    "plus de clotures que d'ouvertures : comptabilite fausse");
        NS_TEST_ASSERT_MSG_EQ(honest.tracedClosures,
                              closed,
                              "des clotures n'ont pas emis la TraceSource");

        NS_TEST_ASSERT_MSG_EQ(honest.collisions,
                              0u,
                              "collision d'empreinte sur un flux unique : "
                              "l'identification IPv4 ne discrimine pas");

        // ---- 1bis. LE DERNIER SAUT, teste la ou il existe ----
        // Le dernier saut N1->N2 doit etre RECONNU et ecarte : N2 consomme le
        // paquet et ne le retransmettra jamais. Ouvrir une fenetre dessus
        // transformerait chaque livraison honnete en non-observation -- le
        // defaut exact de la premiere version de cette etape.
        //
        // Une version anterieure de CE TEST assertait skippedLastHop > 0 sur
        // l'observateur de N0. C'etait insatisfiable par construction : N2 est
        // hors portee de N0, donc le prochain saut de N0 est TOUJOURS N1 et
        // jamais la destination. L'assertion etait juste sur le fond et fausse
        // sur le lieu. Elle porte desormais sur chaque role la ou sa propriete
        // peut exister.
        NS_TEST_ASSERT_MSG_EQ(honest.skippedLastHop,
                              0u,
                              "N0 a ecarte un dernier saut alors que sa destination "
                              "est hors de portee : la resolution du prochain saut "
                              "est fausse");
        NS_TEST_ASSERT_MSG_GT(honest.relayTransmissions,
                              0u,
                              "le relais N1 n'a examine aucune emission : la trace "
                              "UnicastForward n'est pas branchee sur le transit");
        NS_TEST_ASSERT_MSG_GT(honest.relaySkippedLastHop,
                              0u,
                              "aucune emission ecartee comme dernier saut en N1 : "
                              "l'observateur ouvrirait des fenetres sur des "
                              "paquets que personne ne relaiera jamais");

        // L'ANTI-REGRESSION PROPREMENT DITE. La version defectueuse ouvrait des
        // fenetres exactement ici -- au relais, sur le saut final -- et nulle
        // part ailleurs. Un seul window ouvert en N1 signe son retour.
        NS_TEST_ASSERT_MSG_EQ(honest.relayWindowsOpened,
                              0u,
                              "le relais a ouvert une fenetre sur le saut final : "
                              "la destination ne retransmet jamais, chaque livraison "
                              "honnete serait comptee comme une non-observation");

        // ---- 2. Relais Blackhole : les fenetres doivent expirer ----
        // L'observateur n'a AUCUN acces a l'identite de l'attaquant ; il ne peut
        // que constater l'absence de retransmission.
        const ChainOutcome attacked = RunChain(1, true);

        NS_TEST_ASSERT_MSG_GT(attacked.windowsDeadline,
                              0u,
                              "un Blackhole n'a produit aucune non-observation : "
                              "l'observateur ne detecte pas l'absence de transfert");
        NS_TEST_ASSERT_MSG_GT(honest.windowsMatched,
                              attacked.windowsMatched,
                              "le relais honnete doit etre observe strictement plus "
                              "souvent que le Blackhole ; sinon l'observation ne "
                              "porte aucune information");

        // ---- 3. NON-INTRUSION : l'observation ne change pas la livraison ----
        // L'observateur est INSTALLE dans les deux cas ; seul son interrupteur
        // change. C'est deliberement plus exigeant que de ne pas l'installer du
        // tout : si le simple passage du MAC en mode promiscuite modifiait la
        // livraison, cette assertion echouerait, et ce serait un RESULTAT a
        // rapporter -- pas un obstacle a contourner en retirant l'installation.
        const ChainOutcome honestWithoutObserver = RunChain(-1, false);
        NS_TEST_ASSERT_MSG_EQ(honestWithoutObserver.deliveredBytes,
                              honest.deliveredBytes,
                              "l'observation a change la livraison : STEP 3 doit etre "
                              "STRICTEMENT observationnel, un gain serait un bug");
        NS_TEST_ASSERT_MSG_EQ(honestWithoutObserver.windowsOpened,
                              0u,
                              "l'observateur desactive a quand meme ouvert des fenetres");
        NS_TEST_ASSERT_MSG_EQ(honestWithoutObserver.transmissions,
                              0u,
                              "l'observateur desactive a quand meme inspecte des emissions");
        NS_TEST_ASSERT_MSG_EQ(honestWithoutObserver.relayTransmissions,
                              0u,
                              "l'observateur desactive du relais a inspecte des emissions");
        NS_TEST_ASSERT_MSG_EQ(honestWithoutObserver.relaySkippedLastHop,
                              0u,
                              "l'observateur desactive du relais a ecarte des emissions");
    }
};

/** @brief Suite d'intégration de l'observateur de transfert (STEP 3). */
class ForwardingObserverTestSuite : public TestSuite
{
  public:
    ForwardingObserverTestSuite()
        : TestSuite("mtcaodv-forwarding-observer", Type::UNIT)
    {
        AddTestCase(new ForwardingObserverTestCase, TestCase::Duration::QUICK);
    }
};

static ForwardingObserverTestSuite g_forwardingObserverTestSuite;

} // namespace mtcaodv
} // namespace ns3
