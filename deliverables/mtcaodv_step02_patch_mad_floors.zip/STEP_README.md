# MTC-AODV — STEP 2 : RREP anomaly screening (WATCH)
### révision « MAD floors » — correction de calibration après le pilote

**Statut de livraison :** `À compiler et tester sur le PC utilisateur`
**Cible :** Linux, ns-3.48, C++17, Python 3 — `/home/hassen/res/ns-3.48`

> Aucune exécution ns-3.48 dans l'environnement de génération. Les oracles
> Python des équations (3)–(5) et les tests Python des validateurs ont été
> exécutés ici avec succès. Les résultats réseau se produisent sur votre PC.

## 1. Numéro de l'étape
**STEP 2 — Détection en 1ʳᵉ étape : screening robuste des RREP → WATCH.** Bâtie
sur le scénario **gelé** en STEP 1 : `nodes=30, area=600×600, portée=200, RWP
1–20 m/s, 4 flux, ratio∈{0,0.20}`.

## 2. Objectif scientifique
Produire, à partir des seuls RREP protocolaires observés, un score d'anomalie
robuste `A_RREP∈[0,1]` (fraîcheur, faible nombre de sauts, précocité) et lever
un état `WATCH` sur le voisin suspect. `WATCH` **n'exclut jamais** une route
(surveillance renforcée uniquement). Mesurer l'activité (`watchCount`) et, hors
ligne, sa précision face à la vérité terrain (TP/FP) — la base d'un futur FAR.

## 3. Objectif logiciel
- Détecteur pur et testable des Éq. (3)–(5), **avec ordre modulaire AODV**
  (wrap-around 2³²) pour la fraîcheur.
- Buffer borné de candidats RREP (fenêtre `W_R`, capacité par destination,
  nombre de destinations) — toutes structures bornées.
- Greffe **non-intrusive** dans `RecvReply()` du fork : observation seule, le
  routage est inchangé (invariant vérifiable : screening ON ≡ screening OFF en
  livraison, au même seed).
- Séparation stricte : le détecteur ne voit **jamais** `attackerNodeIds`.

## 4. Dépendances
STEP 1 validé (fork + attaque) ; scénario gelé STEP 1 ; modules ns-3.48 core,
network, internet, internet-apps, wifi, applications, mobility, flow-monitor.

## 5. Fichiers ajoutés
```
contrib/mtcaodv/model/mtc-security-state.h              (enum NORMAL/WATCH/…)
contrib/mtcaodv/model/rrep-anomaly-detector.{h,cc}      (Éq. 3–5, ordre modulaire)
contrib/mtcaodv/model/rrep-candidate-buffer.{h,cc}      (buffer borné, fenêtre W_R)
contrib/mtcaodv/test/rrep-anomaly-detector-test-suite.cc(T-09/T-10 + bornes)
experiments/validate_step02.py, experiments/test_validate_step02.py
experiments/schemas/step02_results_schema.json
experiments/configs/step02_pilot.json
```

## 6. Fichiers modifiés
- `model/mtc-aodv-routing-protocol.{h,cc}` — hook `RecvReply()`, `ScreenReceivedReply()`,
  état de sécurité par voisin, `watchCount`, Attributes + TraceSources.
- `examples/mtcaodv-pilot-attack.cc` — **défauts gelés** (30/600/200), activation
  du screening, agrégation `watchCount` + TP/FP hors ligne, colonnes CSV.
- `contrib/mtcaodv/CMakeLists.txt` — sources + test STEP 2.
Le fork AODV (hors les 3 greffes attaque/défense) et STEP 0/1 restent intacts.

## 7. Classes
- `mtcaodv::RrepAnomalyDetector` (pur) — Éq. (3)–(5), `Median`, `MedianAbsoluteDeviation`,
  `SignedSequenceDelta` (ordre AODV), `Score()`.
- `mtcaodv::RrepCandidateBuffer` (pur) — `Insert`, `GetCandidates`, bornes.
- `mtcaodv::SecurityState` (enum, §3.4).
- `mtcaodv::RoutingProtocol` — `ScreenReceivedReply`, `GetWatchCount`,
  `GetNeighborSecurityState`, `GetWatchedNeighbors`.

## 8. Méthodes importantes
| Méthode | Équation / rôle |
|---|---|
| `RrepAnomalyDetector::Score` | Éq. (3)–(5) → `A_RREP` ou `available=false` (D-07/C-16) |
| `SignedSequenceDelta` | ordre modulaire AODV (T-10, wrap-around 2³²) |
| `RoutingProtocol::ScreenReceivedReply` | A3.1 : buffer + score + `WATCH` (D-08) |
| `RrepCandidateBuffer::Insert` | fenêtre `W_R` + bornes de capacité |

## 9. Paramètres (Attributes du fork ; tous pilote, non gelés)
`EnableRrepScreening` (true) · `RrepWindow` (1 s, C-01) · `MinComparableReplies`
(**3**, C-02) · `SeqWeight`/`HopWeight`/`TimeWeight` (1/1/0.5, C-03) ·
`LogisticBias` (2.0, C-03) · `WatchThreshold` (0.5, C-04) ·
`RrepBufferCapacity` (16) · `MaxTrackedDestinations` (64).

**Planchers de dispersion (correction C-06) :** `SeqMadFloor` (2.0 incréments) ·
`HopMadFloor` (1.0 saut) · `TimeMadFloor` (10 ms) · `MaxAnomaly` (écrêtage des
`z` à 20) · `ScreeningEpsilon` (**1e-9**, simple garde anti-division-par-zéro).

CLI pilote : `--enableScreening`, `--watchThreshold`.

### Pourquoi cette correction (mesure du pilote STEP 2)

Le premier paramétrage utilisait un `epsilon = 1e-6` **adimensionnel** comme seul
plancher. Or `MAD = 0` est le cas **courant** (deux RREP honnêtes annonçant le
même nombre de sauts suffisent). Un écart d'un seul saut donnait alors
`z_h = 1/1e-6 = 1e6`, saturant le sigmoïde à 1,0 sur des nœuds honnêtes.
Mesures réelles (seed 1, scénario gelé) : **FAR = 0,958 sous attaque et 1,000
sans attaque** — 30 nœuds sur 30 mis en WATCH ; précision 0,207. Le rappel de
1,000 était un artefact de sur-détection, pas un succès.

Le correctif normalise chaque anomalie par `max(MAD, plancher)` où le plancher
est exprimé **dans l'unité physique** de la grandeur (1 saut, 10 ms,
2 incréments de séquence), et écrête les `z`. Oracle vérifié :
`hops {2,3,3}` (MAD = 0) passe de `A = 1,000000` (faux WATCH) à
`A = 0,377541` (pas de WATCH), tandis qu'un RREP réellement forgé reste à
`A = 1,000000`. Ces valeurs restent **pilote (C-02/C-03/C-04/C-06), non gelées**.

## 10. Équations implémentées
Éq. (3) `z_s`, (4a) `z_h`, (4b) `z_t`, (5) `A_RREP=σ(w_s z_s+w_h z_h+w_t z_t−b_R)`,
seuil `θ_R`. Fraîcheur en **ordre modulaire AODV** (pas de soustraction naïve).

## 11. TraceSources
`ns3::mtcaodv::RoutingProtocol::RrepAnomaly` (dst, voisin, score) ·
`ns3::mtcaodv::RoutingProtocol::Watch` (voisin, score). (+ STEP 1 `ForgedReply`,
`BlackholeDrop`.)

## 12. RNG streams
Inchangés (STEP 1). Le screening n'utilise **aucun** RNG ni scheduling → il ne
modifie pas les coordonnées exogènes ; l'appariement est préservé.

## 13. Compilation

**IMPORTANT — une reconfiguration est OBLIGATOIRE à cette étape.** STEP 2 ajoute
DEUX NOUVEAUX fichiers source (`rrep-anomaly-detector.cc`, `rrep-candidate-buffer.cc`)
à `contrib/mtcaodv/CMakeLists.txt`. ns-3 ne les intègre au graphe de build qu'après
`./ns3 configure` ; un simple `./ns3 build` peut relier l'exemple contre une
bibliothèque `mtcaodv` périmée et produire des `undefined reference`.

```bash
cd /home/hassen/res/ns-3.48
# 0) extraire en FORÇANT l'écrasement (sans -o, unzip saute silencieusement
#    les fichiers existants et model/ n'est pas mis à jour) :
unzip -o /chemin/vers/mtcaodv_step02_rrep_screening.zip -d /home/hassen/res/ns-3.48

# 1) reconfigurer (obligatoire : nouveaux fichiers source) puis compiler
# 1bis) OBLIGATOIRE : unzip restaure les horodatages DE L'ARCHIVE, donc les
#       sources extraites peuvent paraître PLUS ANCIENNES que les objets déjà
#       compilés — ninja ne recompile alors rien et l'édition de liens échoue.
touch contrib/mtcaodv/CMakeLists.txt contrib/mtcaodv/*/*.cc contrib/mtcaodv/*/*.h

./ns3 configure --enable-examples --enable-tests
./ns3 build

# 2) vérifier que les symboles STEP 2 sont bien dans la bibliothèque
nm -DC build/lib/libns3.48-mtcaodv-default.so | grep -E "GetWatchCount|GetWatchedNeighbors"
#    -> deux lignes en 'T' (définies) attendues
```

## 14. Tests
```bash
cd /home/hassen/res/ns-3.48
python3 experiments/test_validate_step02.py                 # Niveau 1 Python (6 tests)
./test.py -s mtcaodv-rrep-anomaly-detector                  # Éq. 3–5, T-09/T-10, bornes + régression MAD=0
# non-régression :
./test.py -s mtcaodv-attack-manager
./test.py -s mtcaodv-blackhole-behavior
./test.py -s mtcaodv-step00-baseline-metrics
./test.py -s mtcaodv-routing-protocol
```

## 15. Simulation pilote (scénario gelé)
```bash
cd /home/hassen/res/ns-3.48
# Défense active, attaque (les défauts SONT le scénario gelé 30/600/200) :
./ns3 run "mtcaodv-pilot-attack --attackerRatio=0.20 --attackStart=10 --seed=1 --run=1"
# Baseline de fausse alarme (screening actif, SANS attaque) :
./ns3 run "mtcaodv-pilot-attack --attackerRatio=0 --seed=1 --run=1"
# Preuve de non-intrusion (screening OFF, même seed → PDR identique) :
./ns3 run "mtcaodv-pilot-attack --attackerRatio=0.20 --enableScreening=false --seed=1 --run=1"

python3 experiments/validate_step02.py \
  --csv mtcaodv-step01-results.csv --manifest mtcaodv-step01-manifest.json \
  --expect-frozen-scenario
```

## 16. Fichiers de sortie
`mtcaodv-step01-results.csv` : préfixe STEP 0 + colonnes STEP 1 **intacts** +
append-only STEP 2 `screeningEnabled, watchThreshold, watchCount,
watchTruePositives, watchFalsePositives`. `mtcaodv-step01-manifest.json` : bloc
`defence` ajouté. FlowMonitor XML inchangé.

## 17. Résultats attendus qualitativement
Aucune valeur numérique non exécutée. Attendus :
- **Non-intrusion :** au même seed, `PDR(screening ON)` = `PDR(screening OFF)`
  (le routage ne change pas).
- **Attaque + screening :** `watchCount>0`, `watchTruePositives>0` (des blackholes
  levés en WATCH) ; le PDR reste celui de STEP 1 (WATCH n'exclut rien).
- **Sans attaque + screening :** `watchTruePositives=0` ; `watchFalsePositives`
  = **baseline de fausse alarme**. Avec les planchers, elle doit être
  **nettement inférieure** aux 30/30 mesurés avant correction. Aucune valeur
  n'est prédite : c'est précisément ce que la ré-exécution doit mesurer, et un
  FAR encore élevé serait un résultat à rapporter tel quel, pas à masquer.

## 18. Critères PASS/FAIL
**PASS** : build OK ; `mtcaodv-rrep-anomaly-detector` vert (Éq. 3–5, T-10
wrap-around, bornes, **régression MAD=0**) ; non-régression verte ;
PDR(ON)=PDR(OFF) au même seed ; attaque → `watchTP>0` ; **FAR sans attaque
nettement < 1,0** ; `validate_step02.py` PASS. **FAIL** : le screening change le PDR ;
un test échoue ; une fuite de vérité terrain dans le détecteur ; colonnes STEP 0/1
cassées ; `watchTP>attackerCount`.

## 19. Limitations
- `WATCH` collant (pas de sortie de WATCH) — la règle de dégagement est C-19,
  gelée après calibration. Sans effet sur le routage.
- Poids/seuil `θ_R` non calibrés (C-03/C-04) : les TP/FP bruts ne sont pas un FAR
  confirmatoire.
- Le TP/FP est une **évaluation hors ligne** (le pilote croise l'ensemble WATCH
  détecté, produit sans vérité terrain, avec `attackerNodeIds`).
- Le screening tourne aussi sur les nœuds attaquants (sans fuite) ; simplification
  de simulation.

## 20. Éléments volontairement non implémentés
Pas de `ForwardingObserver` (STEP 3), pas d'OCEA/masses (STEP 4), pas de
MOBeta-Trust (STEP 5), pas d'`ACCUSED`/quarantaine/certificats/PTMB (STEP 6+).
`WATCH` est le seul état atteignable au-delà de `NORMAL`. Aucune route n'est
jamais exclue à cette étape.

## Prochaine étape prévue
**STEP 3 — ForwardingObserver** : observation locale du forwarding au prochain
saut (empreinte de paquet, fenêtre d'observation, `MacPromiscRx` ou en-tête
explicite), entrée des masses OCEA (Éq. 6–10). À n'entamer qu'après validation
de STEP 2.

---
## Ce que je dois vous renvoyer
1. `./ns3 build` ; 2. `./test.py -s mtcaodv-rrep-anomaly-detector` + non-régression ;
3. la console des 3 `./ns3 run` (dont la preuve PDR ON=OFF) ; 4. le CSV + manifest ;
5. `validate_step02.py`. Je n'entame pas STEP 3 avant vos résultats.
