# MTC-AODV experiment results

This directory holds generated CSV rows, JSON manifests, and FlowMonitor XML
from pilot runs. Nothing here is committed as a scientific result until it has
been produced on the ns-3.48 PC and validated fail-closed.

- STEP 0: `mtcaodv-step00-*` via `validate_step00.py`.
- STEP 1: `mtcaodv-step01-*` via `validate_step01.py` (multiple full Blackhole).

No value in this directory is fabricated; a missing mandatory metric is `NaN` /
`N/A`, never an artificial zero.
