#!/usr/bin/env python3
"""Unit tests for the STEP 2 score-separability analysis (no ns-3 required)."""

from __future__ import annotations

import json
import math
import tempfile
import unittest
from pathlib import Path

import analyze_rrep_scores as a


class AucTests(unittest.TestCase):
    """AUC must be exact on cases whose value is known analytically."""

    def test_perfect_separation(self):
        self.assertAlmostEqual(a.compute_auc([0.9, 0.8, 0.7], [0.1, 0.2, 0.3]), 1.0)

    def test_perfect_inversion(self):
        self.assertAlmostEqual(a.compute_auc([0.1, 0.2], [0.8, 0.9]), 0.0)

    def test_all_ties_is_one_half(self):
        # Every score identical => no discriminative power whatsoever.
        self.assertAlmostEqual(a.compute_auc([0.5] * 5, [0.5] * 7), 0.5)

    def test_known_intermediate_value(self):
        # pos={2,4}, neg={1,3,5}: pairs pos>neg = (2>1),(4>1),(4>3) = 3 of 6.
        self.assertAlmostEqual(a.compute_auc([2.0, 4.0], [1.0, 3.0, 5.0]), 0.5)

    def test_half_ties(self):
        # pos={1,2}, neg={2,3}: 1>2 no, 1>3 no, 2>2 tie(0.5), 2>3 no => 0.5/4
        self.assertAlmostEqual(a.compute_auc([1.0, 2.0], [2.0, 3.0]), 0.125)

    def test_empty_class_is_nan(self):
        self.assertTrue(math.isnan(a.compute_auc([], [0.1])))
        self.assertTrue(math.isnan(a.compute_auc([0.1], [])))


class TripTests(unittest.TestCase):
    """Per-node trip counting is what WATCH's stickiness hides."""

    def test_counts_repeats_not_just_first(self):
        rows = [
            {"t": 1.0, "observer": 0, "neighbor": 4, "score": 0.9},
            {"t": 2.0, "observer": 1, "neighbor": 4, "score": 0.8},
            {"t": 3.0, "observer": 2, "neighbor": 7, "score": 0.9},
            {"t": 4.0, "observer": 0, "neighbor": 7, "score": 0.1},
        ]
        trips = a.per_node_trips(rows, 0.5)
        self.assertEqual(trips[4], 2)  # tripped twice
        self.assertEqual(trips[7], 1)  # tripped once
        # A stricter threshold changes the counts.
        self.assertEqual(a.per_node_trips(rows, 0.85)[4], 1)


class QuantileTests(unittest.TestCase):
    def test_median(self):
        self.assertAlmostEqual(a.quantile([1, 2, 3], 0.5), 2.0)
        self.assertAlmostEqual(a.quantile([1, 2, 3, 4], 0.5), 2.5)

    def test_empty_is_nan(self):
        self.assertTrue(math.isnan(a.quantile([], 0.5)))


class EndToEndTests(unittest.TestCase):
    def test_reads_scores_and_manifest(self):
        tmp = Path(tempfile.mkdtemp())
        scores = tmp / "s.csv"
        scores.write_text(
            "time_s,observerNodeId,destination,neighborNodeId,neighborIp,anomalyScore\n"
            "11.0,0,10.1.0.9,4,10.1.0.5,0.95\n"
            "12.0,1,10.1.0.9,7,10.1.0.8,0.10\n",
            encoding="utf-8",
        )
        manifest = tmp / "m.json"
        manifest.write_text(json.dumps({
            "attack": {"attackerNodeIds": [4]},
            "configuration": {"nodes": 30, "attackStart": 10.0},
        }), encoding="utf-8")
        rows = a.load_scores(scores)
        attackers, nodes, start = a.load_manifest(manifest)
        self.assertEqual(len(rows), 2)
        self.assertEqual(attackers, {4})
        self.assertEqual(nodes, 30)
        self.assertAlmostEqual(start, 10.0)
        pos = [r["score"] for r in rows if r["neighbor"] in attackers]
        neg = [r["score"] for r in rows if r["neighbor"] not in attackers]
        self.assertAlmostEqual(a.compute_auc(pos, neg), 1.0)

    def test_empty_scores_file_is_rejected(self):
        tmp = Path(tempfile.mkdtemp())
        scores = tmp / "s.csv"
        scores.write_text(
            "time_s,observerNodeId,destination,neighborNodeId,neighborIp,anomalyScore\n",
            encoding="utf-8")
        with self.assertRaises(a.ScoreAnalysisError):
            a.load_scores(scores)


if __name__ == "__main__":
    unittest.main()
