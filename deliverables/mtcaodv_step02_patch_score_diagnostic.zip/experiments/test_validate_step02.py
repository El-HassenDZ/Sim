#!/usr/bin/env python3
"""Standard-library unit tests for validate_step02.py (no ns-3 required)."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

import validate_step02 as v

_HEADER = (
    "protocol,nodes,simTime,minSpeed,maxSpeed,seed,run,attackerRatio,attackerCount,"
    "attackStart,appTxPackets,appRxPackets,appTxBytes,appRxBytes,pdr,plr,throughput_bps,"
    "goodput_bps,meanDelay_s,networkRxBytes,evaluationDuration_s,flowCount,packetPayloadBytes,"
    "dataRate,areaSize_m,maxRange_m,appStart_s,appStop_s,ipv4Network,ipv4Mask,mobilityStreamBase,"
    "wifiStreamBase,aodvStreamBase,trafficStreamBase,mobilityStreamsConsumed,wifiStreamsConsumed,"
    "aodvStreamsConsumed,trafficStreamsConsumed,monitoredApplicationFlows,pauseTime_s,"
    "sourceStartStagger_s,wifiStandard,wifiMac,propagationModel,forgedRrepCount,blackholeDropCount,"
    "attackStream,attackerSelectionStreamsConsumed,screeningEnabled,watchThreshold,watchCount,"
    "watchTruePositives,watchFalsePositives"
)


def _row(nodes=30, ratio=0.20, rx=1500, tx=2936, screening=1,
         watch_count=6, tp=3, fp=2):
    attacker_count = v.round_half_up(ratio * nodes)
    pdr = rx / tx
    vals = {
        "protocol": "MTC-AODV", "nodes": nodes, "simTime": 60, "minSpeed": 1, "maxSpeed": 20,
        "seed": 1, "run": 1, "attackerRatio": ratio, "attackerCount": attacker_count,
        "attackStart": 10, "appTxPackets": tx, "appRxPackets": rx, "appTxBytes": tx * 512,
        "appRxBytes": rx * 512, "pdr": pdr, "plr": 1 - pdr, "throughput_bps": 1.0,
        "goodput_bps": 1.0, "meanDelay_s": 0.01, "networkRxBytes": rx * 512 + 100,
        "evaluationDuration_s": 49, "flowCount": 4, "packetPayloadBytes": 512, "dataRate": "64kbps",
        "areaSize_m": 600, "maxRange_m": 200, "appStart_s": 10, "appStop_s": 59,
        "ipv4Network": "10.1.0.0", "ipv4Mask": "255.255.255.0", "mobilityStreamBase": 10000,
        "wifiStreamBase": 30000, "aodvStreamBase": 20000, "trafficStreamBase": 40000,
        "mobilityStreamsConsumed": 4 * nodes, "wifiStreamsConsumed": 5, "aodvStreamsConsumed": 3,
        "trafficStreamsConsumed": 8, "monitoredApplicationFlows": 4, "pauseTime_s": 0,
        "sourceStartStagger_s": 0.1, "wifiStandard": "802.11b", "wifiMac": "ns3::AdhocWifiMac",
        "propagationModel": "ns3::RangePropagationLossModel", "forgedRrepCount": 20,
        "blackholeDropCount": 500, "attackStream": 73001, "attackerSelectionStreamsConsumed": 1,
        "screeningEnabled": screening, "watchThreshold": 0.5, "watchCount": watch_count,
        "watchTruePositives": tp, "watchFalsePositives": fp,
    }
    cols = _HEADER.split(",")
    return ",".join(str(vals[c]) for c in cols)


class Step2ValidatorTests(unittest.TestCase):
    def _write(self, row_line, manifest=None):
        tmp = Path(tempfile.mkdtemp())
        csv_path = tmp / "r.csv"
        csv_path.write_text(_HEADER + "\n" + row_line + "\n", encoding="utf-8")
        man_path = None
        if manifest is not None:
            man_path = tmp / "m.json"
            man_path.write_text(json.dumps(manifest), encoding="utf-8")
        return csv_path, man_path

    def test_valid_row_passes(self):
        csv_path, _ = self._write(_row())
        v.validate(csv_path, None)

    def test_tp_cannot_exceed_attacker_count(self):
        csv_path, _ = self._write(_row(ratio=0.20, tp=99))  # attacker_count=6
        with self.assertRaises(v.Step2ValidationError):
            v.validate(csv_path, None)

    def test_screening_off_forbids_watch(self):
        csv_path, _ = self._write(_row(screening=0, watch_count=3, tp=1, fp=1))
        with self.assertRaises(v.Step2ValidationError):
            v.validate(csv_path, None)
        # screening off with zero activity is fine
        csv_ok, _ = self._write(_row(screening=0, watch_count=0, tp=0, fp=0))
        v.validate(csv_ok, None)

    def test_zero_ratio_forbids_true_positive(self):
        csv_path, _ = self._write(_row(ratio=0.0, tp=1, fp=2))
        with self.assertRaises(v.Step2ValidationError):
            v.validate(csv_path, None)
        # zero ratio with false positives only is a legitimate false-alarm baseline
        csv_ok, _ = self._write(_row(ratio=0.0, tp=0, fp=2))
        v.validate(csv_ok, None)

    def test_detected_without_watchcount_rejected(self):
        csv_path, _ = self._write(_row(watch_count=0, tp=1, fp=0))
        with self.assertRaises(v.Step2ValidationError):
            v.validate(csv_path, None)

    def test_manifest_defence_cross_check(self):
        row = _row(watch_count=6, tp=3, fp=2)
        good = {"schemaVersion": "mtcaodv-step01-v1",
                "defence": {"watchCount": 6, "watchTruePositives": 3, "watchFalsePositives": 2}}
        csv_path, man = self._write(row, good)
        v.validate(csv_path, man)
        bad = {"schemaVersion": "mtcaodv-step01-v1",
               "defence": {"watchCount": 5, "watchTruePositives": 3, "watchFalsePositives": 2}}
        csv2, man2 = self._write(row, bad)
        with self.assertRaises(v.Step2ValidationError):
            v.validate(csv2, man2)


if __name__ == "__main__":
    unittest.main()
