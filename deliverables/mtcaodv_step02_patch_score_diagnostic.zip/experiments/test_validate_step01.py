#!/usr/bin/env python3
"""Standard-library unit tests for validate_step01.py (no ns-3 required).

These are the STEP 1 "Niveau 1" checks: they exercise the fail-closed CSV /
manifest validator on synthetic rows so the user can confirm the validation
logic before any ns-3.48 build.  They do NOT run a simulation.
"""

from __future__ import annotations

import json
import math
import tempfile
import unittest
from pathlib import Path

import validate_step01 as v


def _consistent_attack_row(nodes: int = 20, ratio: float = 0.20) -> dict:
    """Build a self-consistent attacked CSV row (all equations satisfied)."""

    attacker_count = v.round_half_up(ratio * nodes)
    flow_count = 4
    payload = 512
    tx = 100
    rx = 40  # attacked: partial delivery
    app_tx_bytes = tx * payload
    app_rx_bytes = rx * payload
    network_rx = app_rx_bytes + 500  # network >= useful (headers)
    eval_dur = 49.0
    pdr = rx / tx
    plr = 1.0 - pdr
    throughput = 8.0 * network_rx / eval_dur
    goodput = 8.0 * app_rx_bytes / eval_dur
    return {
        "protocol": "MTC-AODV",
        "nodes": nodes,
        "simTime": 60.0,
        "minSpeed": 1.0,
        "maxSpeed": 20.0,
        "seed": 12345,
        "run": 1,
        "attackerRatio": ratio,
        "attackerCount": attacker_count,
        "attackStart": 10.0,
        "appTxPackets": tx,
        "appRxPackets": rx,
        "appTxBytes": app_tx_bytes,
        "appRxBytes": app_rx_bytes,
        "pdr": pdr,
        "plr": plr,
        "throughput_bps": throughput,
        "goodput_bps": goodput,
        "meanDelay_s": 0.05,
        "networkRxBytes": network_rx,
        "evaluationDuration_s": eval_dur,
        "flowCount": flow_count,
        "packetPayloadBytes": payload,
        "dataRate": "64kbps",
        "areaSize_m": 300.0,
        "maxRange_m": 150.0,
        "appStart_s": 10.0,
        "appStop_s": 59.0,
        "ipv4Network": "10.1.0.0",
        "ipv4Mask": "255.255.255.0",
        "mobilityStreamBase": 10000,
        "wifiStreamBase": 30000,
        "aodvStreamBase": 20000,
        "trafficStreamBase": 40000,
        "mobilityStreamsConsumed": 4 * nodes,
        "wifiStreamsConsumed": 5,
        "aodvStreamsConsumed": 3,
        "trafficStreamsConsumed": 4,
        "monitoredApplicationFlows": flow_count,
        "pauseTime_s": 0.0,
        "sourceStartStagger_s": 0.1,
        "wifiStandard": "802.11b",
        "wifiMac": "ns3::AdhocWifiMac",
        "propagationModel": "ns3::RangePropagationLossModel",
        "forgedRrepCount": 7,
        "blackholeDropCount": 12,
        "attackStream": 73001,
        "attackerSelectionStreamsConsumed": 1,
    }


def _manifest_for(row: dict, attacker_ids: list[int]) -> dict:
    """Build a manifest consistent with a CSV row and attacker list."""

    return {
        "schemaVersion": "mtcaodv-step01-v1",
        "targetNs3Version": "3.48",
        "protocol": "MTC-AODV",
        "attackImplemented": True,
        "configuration": {"attackerCount": row["attackerCount"]},
        "attack": {
            "forgedRrepCount": row["forgedRrepCount"],
            "blackholeDropCount": row["blackholeDropCount"],
            "attackerNodeIds": attacker_ids,
        },
    }


class Step1ValidatorTests(unittest.TestCase):
    """Fail-closed behaviour of the STEP 1 validator."""

    def _write(self, row: dict, manifest: dict) -> tuple[Path, Path]:
        """Write a CSV row + manifest to a temp dir and return their paths."""

        tmp = Path(tempfile.mkdtemp())
        csv_path = tmp / "r.csv"
        header = list(row.keys())
        with csv_path.open("w", encoding="utf-8", newline="") as handle:
            handle.write(",".join(header) + "\n")
            handle.write(
                ",".join(
                    ("NaN" if isinstance(row[k], float) and not math.isfinite(row[k])
                     else str(row[k]))
                    for k in header
                )
                + "\n"
            )
        manifest_path = tmp / "m.json"
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        return csv_path, manifest_path

    def test_attacker_count_follows_equation_2(self):
        """N=20 nodes, r=0.20 -> floor(4.5)=4 attackers."""
        self.assertEqual(v.round_half_up(0.20 * 20), 4)
        self.assertEqual(v.round_half_up(0.05 * 100), 5)
        self.assertEqual(v.round_half_up(0.30 * 100), 30)

    def test_valid_attacked_row_passes(self):
        row = _consistent_attack_row()
        manifest = _manifest_for(row, [5, 9, 13, 17])
        v.validate_record(row_to_record(row), manifest)

    def test_wrong_attacker_count_rejected(self):
        row = _consistent_attack_row()
        row["attackerCount"] = 3  # should be 4
        manifest = _manifest_for(row, [5, 9, 13])
        with self.assertRaises(v.Step1ValidationError):
            v.validate_record(row_to_record(row), manifest)

    def test_zero_attack_effect_rejected_by_default(self):
        row = _consistent_attack_row()
        row["forgedRrepCount"] = 0
        row["blackholeDropCount"] = 0
        manifest = _manifest_for(row, [5, 9, 13, 17])
        manifest["attack"]["forgedRrepCount"] = 0
        manifest["attack"]["blackholeDropCount"] = 0
        with self.assertRaises(v.Step1ValidationError):
            v.validate_record(row_to_record(row), manifest)
        # but allowed when explicitly relaxed
        v.validate_record(row_to_record(row), manifest, require_attack_effect=False)

    def test_endpoint_cannot_be_attacker(self):
        row = _consistent_attack_row()
        manifest = _manifest_for(row, [0, 9, 13, 17])  # node 0 is a source endpoint
        with self.assertRaises(v.Step1ValidationError):
            v.validate_record(row_to_record(row), manifest)

    def test_attacker_ids_must_be_unique(self):
        row = _consistent_attack_row()
        manifest = _manifest_for(row, [9, 9, 13, 17])
        with self.assertRaises(v.Step1ValidationError):
            v.validate_record(row_to_record(row), manifest)

    def test_pdr_out_of_range_rejected(self):
        row = _consistent_attack_row()
        row["pdr"] = 1.5
        manifest = _manifest_for(row, [5, 9, 13, 17])
        with self.assertRaises(v.Step1ValidationError):
            v.validate_record(row_to_record(row), manifest)

    def test_zero_ratio_requires_no_attack(self):
        row = _consistent_attack_row(ratio=0.0)
        row["attackerCount"] = 0
        row["forgedRrepCount"] = 0
        row["blackholeDropCount"] = 0
        row["attackerSelectionStreamsConsumed"] = 0
        # zero delivery not required here; keep partial rx consistent
        manifest = _manifest_for(row, [])
        manifest["configuration"]["attackerCount"] = 0
        v.validate_record(row_to_record(row), manifest)

    def test_zero_delivery_requires_nan_delay(self):
        row = _consistent_attack_row()
        row["appRxPackets"] = 0
        row["appRxBytes"] = 0
        row["pdr"] = 0.0
        row["plr"] = 1.0
        row["goodput_bps"] = 0.0
        row["throughput_bps"] = 8.0 * row["networkRxBytes"] / row["evaluationDuration_s"]
        row["meanDelay_s"] = 0.0  # WRONG: must be NaN when rx==0
        manifest = _manifest_for(row, [5, 9, 13, 17])
        with self.assertRaises(v.Step1ValidationError):
            v.validate_record(row_to_record(row), manifest)
        row["meanDelay_s"] = float("nan")
        v.validate_record(row_to_record(row), manifest)

    def test_end_to_end_via_files(self):
        row = _consistent_attack_row()
        manifest = _manifest_for(row, [5, 9, 13, 17])
        csv_path, manifest_path = self._write(row, manifest)
        schema = Path(__file__).resolve().parent / "schemas" / "step01_results_schema.json"
        record = v.validate_artifacts(csv_path, manifest_path, schema)
        self.assertEqual(record.attacker_count, 4)


def row_to_record(row: dict) -> "v.Step1Record":
    """Convert an int/float/str row dict into a typed record via string CSV."""

    string_row = {
        k: ("NaN" if isinstance(val, float) and not math.isfinite(val) else str(val))
        for k, val in row.items()
    }
    return v.Step1Record.from_csv_row(string_row)


if __name__ == "__main__":
    unittest.main()
