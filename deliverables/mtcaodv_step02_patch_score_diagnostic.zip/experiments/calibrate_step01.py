#!/usr/bin/env python3
"""Calibrate the STEP 1 multiple-Blackhole pilot scenario.

Problem this solves
-------------------
The 20-node / 300 m pilot cannot be simultaneously well-connected and
multi-hop: at long radio range the network is single-hop and the Blackhole
attack has no measurable effect on PDR; at short range the network partitions
and the *healthy* baseline PDR collapses and swings wildly by seed.  Choosing a
"good-looking" seed to hide that is scientifically invalid (it measures
disconnection, not attack).

This tool sweeps node count (and optionally area / range), runs REAL paired
no-attack vs attack ns-3.48 simulations for several seeds, aggregates the
results, and selects the (nodes, area, maxRange) triple that satisfies three
pre-registered criteria at once:

  1. Baseline (no-attack) PDR is healthy on EVERY seed (min > --min-baseline),
     so the scenario is not silently partitioned for some seeds.
  2. The baseline is genuinely multi-hop (mean end-to-end delay > --min-delay),
     so relays — and therefore Blackholes on the path — actually matter.
  3. The attack degrades delivery consistently: mean PDR drop > --min-effect
     AND attack PDR < baseline PDR on every seed.

No number is fabricated: a failed or non-finite run is reported and excluded,
never replaced by zero.  The tool only *reads* what ns-3 actually produced.

It shells out to `./ns3 run "mtcaodv-pilot-attack ..."` with per-run output
paths (so runs never clobber each other) and parses the pilot's own CSV.

Standard library only.
"""

from __future__ import annotations

import argparse
import csv
import math
import statistics
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence


# ----------------------------------------------------------------------------
# Data model
# ----------------------------------------------------------------------------
@dataclass(frozen=True)
class RunOutcome:
    """One executed simulation (one node count, one seed, attack on/off)."""

    nodes: int
    seed: int
    attack: bool
    ok: bool
    pdr: float = float("nan")
    mean_delay_s: float = float("nan")
    forged: int = 0
    drops: int = 0
    attacker_count: int = 0
    app_tx: int = 0
    app_rx: int = 0
    error: str = ""


@dataclass
class NodeSummary:
    """Aggregated paired result for one node count over all seeds."""

    nodes: int
    seeds: list[int] = field(default_factory=list)
    baseline_pdr: list[float] = field(default_factory=list)
    attack_pdr: list[float] = field(default_factory=list)
    baseline_delay: list[float] = field(default_factory=list)
    attack_drops: list[int] = field(default_factory=list)
    failures: int = 0

    # --- derived, healthy-only helpers -------------------------------------
    def _finite(self, xs: Sequence[float]) -> list[float]:
        return [x for x in xs if math.isfinite(x)]

    def baseline_min(self) -> float:
        vals = self._finite(self.baseline_pdr)
        return min(vals) if vals else float("nan")

    def baseline_mean(self) -> float:
        vals = self._finite(self.baseline_pdr)
        return statistics.fmean(vals) if vals else float("nan")

    def baseline_std(self) -> float:
        vals = self._finite(self.baseline_pdr)
        return statistics.pstdev(vals) if len(vals) > 1 else 0.0

    def attack_mean(self) -> float:
        vals = self._finite(self.attack_pdr)
        return statistics.fmean(vals) if vals else float("nan")

    def delay_mean(self) -> float:
        vals = self._finite(self.baseline_delay)
        return statistics.fmean(vals) if vals else float("nan")

    def effect_mean(self) -> float:
        return self.baseline_mean() - self.attack_mean()

    def seeds_with_effect(self) -> int:
        """Count seeds where attack PDR is strictly below baseline PDR."""
        count = 0
        for base, atk in zip(self.baseline_pdr, self.attack_pdr):
            if math.isfinite(base) and math.isfinite(atk) and atk < base:
                count += 1
        return count


# ----------------------------------------------------------------------------
# Pure aggregation / selection (unit-testable without ns-3)
# ----------------------------------------------------------------------------
def aggregate(outcomes: Sequence[RunOutcome]) -> dict[int, NodeSummary]:
    """Group paired outcomes by node count, aligning attack/no-attack by seed."""

    by_node: dict[int, NodeSummary] = {}
    # Index runs by (nodes, seed, attack) so we can pair them.
    index: dict[tuple[int, int, bool], RunOutcome] = {}
    node_seeds: dict[int, list[int]] = {}
    for outcome in outcomes:
        index[(outcome.nodes, outcome.seed, outcome.attack)] = outcome
        node_seeds.setdefault(outcome.nodes, [])
        if outcome.seed not in node_seeds[outcome.nodes]:
            node_seeds[outcome.nodes].append(outcome.seed)

    for nodes, seeds in node_seeds.items():
        summary = NodeSummary(nodes=nodes)
        for seed in sorted(seeds):
            base = index.get((nodes, seed, False))
            atk = index.get((nodes, seed, True))
            if base is None or atk is None or not base.ok or not atk.ok:
                summary.failures += 1
                continue
            summary.seeds.append(seed)
            summary.baseline_pdr.append(base.pdr)
            summary.attack_pdr.append(atk.pdr)
            summary.baseline_delay.append(base.mean_delay_s)
            summary.attack_drops.append(atk.drops)
        by_node[nodes] = summary
    return by_node


def select(
    summaries: dict[int, NodeSummary],
    *,
    min_baseline: float,
    min_delay: float,
    min_effect: float,
) -> list[int]:
    """Return node counts meeting all three pre-registered criteria, best first.

    "Best" is ordered by (all seeds show the effect, larger mean effect, higher
    baseline min) so the most convincing scenario surfaces first.
    """

    winners: list[int] = []
    for nodes, summary in summaries.items():
        if not summary.seeds:
            continue
        healthy = summary.baseline_min() > min_baseline
        multihop = summary.delay_mean() > min_delay
        effective = (
            summary.effect_mean() > min_effect
            and summary.seeds_with_effect() == len(summary.seeds)
        )
        if healthy and multihop and effective:
            winners.append(nodes)

    winners.sort(
        key=lambda n: (
            summaries[n].seeds_with_effect() == len(summaries[n].seeds),
            summaries[n].effect_mean(),
            summaries[n].baseline_min(),
        ),
        reverse=True,
    )
    return winners


# ----------------------------------------------------------------------------
# ns-3 execution
# ----------------------------------------------------------------------------
def run_one(
    ns3_dir: Path,
    exe: str,
    tmpdir: Path,
    *,
    nodes: int,
    seed: int,
    attack: bool,
    area: float,
    max_range: float,
    ratio: float,
    attack_start: float,
    sim_time: float,
    min_speed: float,
    max_speed: float,
    run: int,
    timeout_s: int,
) -> RunOutcome:
    """Execute one ns-3 pilot run and parse its CSV. Never fabricates numbers."""

    tag = f"n{nodes}_s{seed}_{'atk' if attack else 'base'}"
    csv_path = tmpdir / f"{tag}.csv"
    man_path = tmpdir / f"{tag}.json"
    fm_path = tmpdir / f"{tag}.xml"
    effective_ratio = ratio if attack else 0.0

    program_args = (
        f"{exe} --nodes={nodes} --simTime={sim_time} --minSpeed={min_speed} "
        f"--maxSpeed={max_speed} --areaSize={area} --maxRange={max_range} "
        f"--attackerRatio={effective_ratio} --attackStart={attack_start} "
        f"--seed={seed} --run={run} "
        f"--outputCsv={csv_path} --outputManifest={man_path} --flowMonitorXml={fm_path}"
    )
    try:
        proc = subprocess.run(
            ["./ns3", "run", program_args],
            cwd=str(ns3_dir),
            capture_output=True,
            text=True,
            timeout=timeout_s,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        return RunOutcome(nodes, seed, attack, ok=False, error=f"launch failed: {error}")

    if proc.returncode != 0 or not csv_path.exists():
        tail = (proc.stderr or proc.stdout or "").strip().splitlines()[-3:]
        return RunOutcome(
            nodes, seed, attack, ok=False, error=" | ".join(tail) or "no CSV produced"
        )

    try:
        with csv_path.open("r", encoding="utf-8", newline="") as handle:
            row = next(csv.DictReader(handle))
    except (OSError, StopIteration, csv.Error) as error:
        return RunOutcome(nodes, seed, attack, ok=False, error=f"CSV parse: {error}")

    def as_float(name: str) -> float:
        try:
            return float(row[name])
        except (KeyError, ValueError):
            return float("nan")

    def as_int(name: str) -> int:
        try:
            return int(row[name])
        except (KeyError, ValueError):
            return 0

    return RunOutcome(
        nodes=nodes,
        seed=seed,
        attack=attack,
        ok=True,
        pdr=as_float("pdr"),
        mean_delay_s=as_float("meanDelay_s"),
        forged=as_int("forgedRrepCount"),
        drops=as_int("blackholeDropCount"),
        attacker_count=as_int("attackerCount"),
        app_tx=as_int("appTxPackets"),
        app_rx=as_int("appRxPackets"),
    )


def run_grid(arguments: argparse.Namespace) -> list[RunOutcome]:
    """Run the full node x seed x {no-attack, attack} grid."""

    ns3_dir = Path(arguments.ns3_dir).resolve()
    if not (ns3_dir / "ns3").exists():
        raise SystemExit(f"'{ns3_dir}/ns3' not found; pass --ns3-dir pointing at ns-3.48")

    outcomes: list[RunOutcome] = []
    with tempfile.TemporaryDirectory(prefix="mtcaodv-calib-") as tmp:
        tmpdir = Path(tmp)
        total = len(arguments.nodes_list) * len(arguments.seeds) * 2
        done = 0
        for nodes in arguments.nodes_list:
            for seed in arguments.seeds:
                for attack in (False, True):
                    done += 1
                    label = f"[{done}/{total}] nodes={nodes} seed={seed} {'attack' if attack else 'baseline'}"
                    print(label + " ...", file=sys.stderr, flush=True)
                    outcome = run_one(
                        ns3_dir,
                        arguments.exe,
                        tmpdir,
                        nodes=nodes,
                        seed=seed,
                        attack=attack,
                        area=arguments.area,
                        max_range=arguments.max_range,
                        ratio=arguments.ratio,
                        attack_start=arguments.attack_start,
                        sim_time=arguments.sim_time,
                        min_speed=arguments.min_speed,
                        max_speed=arguments.max_speed,
                        run=arguments.run,
                        timeout_s=arguments.timeout,
                    )
                    if not outcome.ok:
                        print(f"    FAILED: {outcome.error}", file=sys.stderr, flush=True)
                    else:
                        kind = (
                            f"pdr={outcome.pdr:.3f} delay={outcome.mean_delay_s*1000:.1f}ms"
                            + (f" forged={outcome.forged} drops={outcome.drops}" if attack else "")
                        )
                        print("    " + kind, file=sys.stderr, flush=True)
                    outcomes.append(outcome)
    return outcomes


# ----------------------------------------------------------------------------
# Reporting
# ----------------------------------------------------------------------------
def print_report(
    summaries: dict[int, NodeSummary],
    winners: Sequence[int],
    arguments: argparse.Namespace,
) -> None:
    """Print the aggregated table and the calibration verdict."""

    print("\n=== STEP 1 calibration summary "
          f"(area={arguments.area} m, maxRange={arguments.max_range} m, "
          f"ratio={arguments.ratio}) ===")
    header = (
        f"{'nodes':>5} {'seeds':>5} {'baseMean':>8} {'baseMin':>7} {'baseStd':>7} "
        f"{'atkMean':>7} {'dropPP':>6} {'delayMs':>7} {'effSeeds':>8} {'fails':>5}"
    )
    print(header)
    print("-" * len(header))
    for nodes in sorted(summaries):
        s = summaries[nodes]
        n_ok = len(s.seeds)
        if n_ok == 0:
            print(f"{nodes:>5} {'0':>5}  (all runs failed: {s.failures})")
            continue
        print(
            f"{nodes:>5} {n_ok:>5} {s.baseline_mean():>8.3f} {s.baseline_min():>7.3f} "
            f"{s.baseline_std():>7.3f} {s.attack_mean():>7.3f} "
            f"{100*s.effect_mean():>6.1f} {1000*s.delay_mean():>7.1f} "
            f"{s.seeds_with_effect()}/{n_ok:<6} {s.failures:>5}"
        )

    print(
        f"\nCriteria: baseline_min > {arguments.min_baseline:.2f}, "
        f"mean_delay > {1000*arguments.min_delay:.0f} ms, "
        f"mean_effect > {100*arguments.min_effect:.0f} pp AND attack<baseline on every seed."
    )
    if winners:
        best = winners[0]
        s = summaries[best]
        print(
            f"\nSELECTED: nodes={best}, area={arguments.area}, maxRange={arguments.max_range} "
            f"-> baseline {s.baseline_mean():.3f} (min {s.baseline_min():.3f}), "
            f"attack {s.attack_mean():.3f}, drop {100*s.effect_mean():.1f} pp, "
            f"delay {1000*s.delay_mean():.1f} ms, effect on {s.seeds_with_effect()}/{len(s.seeds)} seeds."
        )
        if len(winners) > 1:
            print(f"Other qualifying node counts (best first): {winners}")
        print("Freeze this triple, then run >=30 paired seeds for the confirmatory measurement.")
    else:
        print(
            "\nNO node count met all three criteria in this sweep. Widen it: try larger "
            "--nodes-list and keep --area ~= 4x --max-range (e.g. area=600 maxRange=150), "
            "or relax --min-baseline if 0.90 is stricter than your target."
        )


def write_summary_csv(summaries: dict[int, NodeSummary], path: Path, arguments: argparse.Namespace) -> None:
    """Persist the aggregated table for the record / plotting."""

    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "nodes", "area_m", "maxRange_m", "ratio", "seedsOk",
                "baselinePdrMean", "baselinePdrMin", "baselinePdrStd",
                "attackPdrMean", "dropPP", "meanDelayMs", "seedsWithEffect", "failures",
            ]
        )
        for nodes in sorted(summaries):
            s = summaries[nodes]
            writer.writerow(
                [
                    nodes, arguments.area, arguments.max_range, arguments.ratio, len(s.seeds),
                    f"{s.baseline_mean():.6f}", f"{s.baseline_min():.6f}", f"{s.baseline_std():.6f}",
                    f"{s.attack_mean():.6f}", f"{100*s.effect_mean():.4f}",
                    f"{1000*s.delay_mean():.4f}", s.seeds_with_effect(), s.failures,
                ]
            )


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def _int_list(text: str) -> list[int]:
    return [int(part) for part in text.replace(" ", "").split(",") if part]


def _parse_arguments(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--ns3-dir", default=".", help="ns-3.48 root containing ./ns3")
    parser.add_argument("--exe", default="mtcaodv-pilot-attack", help="pilot example name")
    parser.add_argument("--nodes-list", type=_int_list, default=[30, 40, 50, 70],
                        help="comma-separated node counts to sweep")
    parser.add_argument("--seeds", type=_int_list, default=[1, 2, 3, 4, 5],
                        help="comma-separated seeds")
    parser.add_argument("--area", type=float, default=500.0, help="square area side in metres")
    parser.add_argument("--max-range", type=float, default=120.0, help="radio range in metres")
    parser.add_argument("--ratio", type=float, default=0.20, help="attacker ratio for the attack arm")
    parser.add_argument("--attack-start", type=float, default=10.0)
    parser.add_argument("--sim-time", type=float, default=60.0)
    parser.add_argument("--min-speed", type=float, default=1.0)
    parser.add_argument("--max-speed", type=float, default=20.0)
    parser.add_argument("--run", type=int, default=1)
    parser.add_argument("--timeout", type=int, default=600, help="per-run timeout seconds")
    parser.add_argument("--min-baseline", type=float, default=0.90,
                        help="required minimum baseline PDR on every seed")
    parser.add_argument("--min-delay", type=float, default=0.010,
                        help="required mean baseline delay (s) for multi-hop")
    parser.add_argument("--min-effect", type=float, default=0.05,
                        help="required mean PDR drop (fraction) under attack")
    parser.add_argument("--summary-csv", type=Path, default=Path("mtcaodv-step01-calibration.csv"))
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _parse_arguments(sys.argv[1:] if argv is None else argv)
    outcomes = run_grid(arguments)
    summaries = aggregate(outcomes)
    winners = select(
        summaries,
        min_baseline=arguments.min_baseline,
        min_delay=arguments.min_delay,
        min_effect=arguments.min_effect,
    )
    print_report(summaries, winners, arguments)
    write_summary_csv(summaries, arguments.summary_csv, arguments)
    print(f"\nAggregated summary written to {arguments.summary_csv}")
    # Exit 0 if a scenario was selected, 2 if none qualified (fail-closed signal).
    return 0 if winners else 2


if __name__ == "__main__":
    raise SystemExit(main())
