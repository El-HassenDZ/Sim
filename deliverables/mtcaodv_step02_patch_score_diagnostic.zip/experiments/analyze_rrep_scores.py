#!/usr/bin/env python3
"""STEP 2 diagnostic: does the A_RREP score separate attackers from honest nodes?

The WATCH counters cannot answer this. WATCH is sticky, so `watchCount` only
records the FIRST time a neighbour trips; a node that produced one incidental
anomaly and a node that produced fifty are indistinguishable. This tool consumes
the RAW score stream exported by the pilot (`--scoresCsv`) and measures the
actual separability of the score, independently of any threshold.

Ground truth (`attackerNodeIds`) is read from the run manifest and applied HERE,
offline. The simulator never labelled anything.

Reported:
  * per-class score distributions (attacker-neighbour vs honest-neighbour),
  * AUC = P(score_attacker > score_honest) + 0.5 P(equal), threshold-free,
  * how often each node trips a given threshold (the number WATCH hides),
  * FAR/recall as a function of theta_R, using a per-node "trips at least K times"
    rule, so the effect of a persistence requirement is visible before it is built.

A verdict is printed against a pre-registered decision rule. Standard library only.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path
from typing import Sequence


class ScoreAnalysisError(ValueError):
    """Raised when the diagnostic inputs are unusable."""


def compute_auc(positive: Sequence[float], negative: Sequence[float]) -> float:
    """Rank-based AUC = P(pos > neg) + 0.5 P(pos == neg).

    Args:
        positive: scores attributed to attacker neighbours.
        negative: scores attributed to honest neighbours.

    Returns:
        AUC in [0,1]; 0.5 means no discriminative power at all. NaN when either
        class is empty (undefined, never silently 0.5).
    """

    if not positive or not negative:
        return float("nan")
    merged = sorted([(s, 1) for s in positive] + [(s, 0) for s in negative])
    # Average ranks over ties so equal scores contribute exactly 0.5.
    ranks: list[float] = [0.0] * len(merged)
    i = 0
    while i < len(merged):
        j = i
        while j + 1 < len(merged) and merged[j + 1][0] == merged[i][0]:
            j += 1
        average_rank = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[k] = average_rank
        i = j + 1
    rank_sum_positive = sum(r for r, (_, label) in zip(ranks, merged) if label == 1)
    n_pos, n_neg = len(positive), len(negative)
    return (rank_sum_positive - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)


def quantile(values: Sequence[float], q: float) -> float:
    """Empirical quantile with linear interpolation; NaN on an empty sample."""
    if not values:
        return float("nan")
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    position = q * (len(ordered) - 1)
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return ordered[int(position)]
    return ordered[low] + (ordered[high] - ordered[low]) * (position - low)


def describe(name: str, values: Sequence[float]) -> str:
    """One-line distribution summary."""
    if not values:
        return f"  {name:22} n=0  (aucun score)"
    return (
        f"  {name:22} n={len(values):<7} "
        f"min={min(values):.3f} q25={quantile(values,0.25):.3f} "
        f"med={quantile(values,0.5):.3f} q75={quantile(values,0.75):.3f} "
        f"max={max(values):.3f} moy={sum(values)/len(values):.3f}"
    )


def histogram(name: str, values: Sequence[float], bins: int = 10, width: int = 40) -> str:
    """Text histogram over [0,1] so no plotting dependency is needed."""
    if not values:
        return f"  {name}: (vide)\n"
    counts = [0] * bins
    for v in values:
        index = min(bins - 1, max(0, int(v * bins)))
        counts[index] += 1
    peak = max(counts) or 1
    lines = [f"  {name} (n={len(values)}):"]
    for b in range(bins):
        lo, hi = b / bins, (b + 1) / bins
        bar = "#" * int(width * counts[b] / peak)
        lines.append(f"    [{lo:.1f},{hi:.1f}) {counts[b]:>7} |{bar}")
    return "\n".join(lines) + "\n"


def load_scores(path: Path) -> list[dict]:
    """Read the pilot's raw score CSV."""
    try:
        with path.open("r", encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
    except OSError as error:
        raise ScoreAnalysisError(f"cannot read scores CSV {path}: {error}") from error
    if not rows:
        raise ScoreAnalysisError(
            f"{path} contains no score row: the run produced no comparative score "
            "(check that screening was enabled and that n_R^min was reached)"
        )
    parsed = []
    for row in rows:
        try:
            parsed.append(
                {
                    "t": float(row["time_s"]),
                    "observer": int(row["observerNodeId"]),
                    "neighbor": int(row["neighborNodeId"]),
                    "score": float(row["anomalyScore"]),
                }
            )
        except (KeyError, ValueError) as error:
            raise ScoreAnalysisError(f"malformed score row: {error}") from error
    return parsed


def load_manifest(path: Path) -> tuple[set[int], int, float]:
    """Return (attackerNodeIds, nodeCount, attackStart) from the run manifest."""
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ScoreAnalysisError(f"cannot read manifest {path}: {error}") from error
    attackers = manifest.get("attack", {}).get("attackerNodeIds", [])
    configuration = manifest.get("configuration", {})
    if not isinstance(attackers, list):
        raise ScoreAnalysisError("manifest attackerNodeIds must be a list")
    return (set(int(a) for a in attackers),
            int(configuration.get("nodes", 0)),
            float(configuration.get("attackStart", 0.0)))


def per_node_trips(rows: Sequence[dict], threshold: float) -> dict[int, int]:
    """Count, per scored neighbour, how many scores reach the threshold."""
    trips: dict[int, int] = defaultdict(int)
    for row in rows:
        if row["score"] >= threshold:
            trips[row["neighbor"]] += 1
    return trips


def sweep(rows: Sequence[dict], attackers: set[int], nodes: int,
          thresholds: Sequence[float], persistences: Sequence[int]) -> None:
    """Print FAR/recall for a grid of (theta_R, K) using a 'trips >= K' rule."""
    scored_nodes = {row["neighbor"] for row in rows if row["neighbor"] >= 0}
    honest_universe = max(1, nodes - len(attackers))
    print(f"\n=== FAR / rappel selon (theta_R, K = nb minimal de declenchements) ===")
    print(f"{'theta_R':>8} {'K':>3} {'TP':>4} {'FP':>4} {'rappel':>8} {'FAR':>8} {'precision':>10}")
    for threshold in thresholds:
        trips = per_node_trips(rows, threshold)
        for k in persistences:
            flagged = {n for n, c in trips.items() if c >= k and n >= 0}
            tp = len(flagged & attackers)
            fp = len(flagged - attackers)
            recall = tp / len(attackers) if attackers else float("nan")
            far = fp / honest_universe
            precision = tp / (tp + fp) if (tp + fp) else float("nan")
            print(f"{threshold:>8.2f} {k:>3} {tp:>4} {fp:>4} {recall:>8.3f} {far:>8.3f} "
                  f"{precision:>10.3f}")
    _ = scored_nodes


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--scores", required=True, type=Path, help="CSV from --scoresCsv")
    parser.add_argument("--manifest", required=True, type=Path, help="run manifest")
    parser.add_argument("--after-attack-start", action="store_true",
                        help="keep only scores at or after attackStart (attacked runs)")
    parser.add_argument("--auc-floor", type=float, default=0.60,
                        help="pre-registered AUC above which the score is deemed informative")
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)

    try:
        rows = load_scores(arguments.scores)
        attackers, nodes, attack_start = load_manifest(arguments.manifest)
    except ScoreAnalysisError as error:
        print(f"ANALYSE FAIL: {error}", file=sys.stderr)
        return 1

    if arguments.after_attack_start:
        rows = [r for r in rows if r["t"] >= attack_start]
        if not rows:
            print("ANALYSE FAIL: aucun score apres attackStart", file=sys.stderr)
            return 1

    positive = [r["score"] for r in rows if r["neighbor"] in attackers]
    negative = [r["score"] for r in rows if r["neighbor"] not in attackers and r["neighbor"] >= 0]

    print("=== Separabilite du score A_RREP (diagnostic STEP 2) ===")
    print(f"  nodes={nodes}  attaquants={sorted(attackers)}  scores retenus={len(rows)}")
    print(describe("voisin ATTAQUANT", positive))
    print(describe("voisin HONNETE", negative))
    print()
    print(histogram("voisin ATTAQUANT", positive), end="")
    print(histogram("voisin HONNETE", negative), end="")

    auc = compute_auc(positive, negative)
    print(f"\n  AUC = {auc:.4f}   (0.5 = aucun pouvoir discriminant)")

    sweep(rows, attackers, nodes,
          thresholds=(0.30, 0.50, 0.70, 0.90, 0.99),
          persistences=(1, 3, 5, 10))

    print("\n=== Verdict (regle preenregistree) ===")
    if not attackers:
        print("  Run SANS attaque : pas d'AUC definie. Lire la colonne FP du balayage")
        print("  comme la baseline de fausse alarme selon (theta_R, K).")
        return 0
    if math.isnan(auc):
        print("  AUC indefinie (une des deux classes est vide) -> diagnostic non concluant.")
        return 2
    if auc < arguments.auc_floor:
        print(f"  AUC {auc:.4f} < {arguments.auc_floor:.2f} : le score A_RREP ne separe PAS")
        print("  les attaquants des honnetes dans ce scenario. Aucun seuil ni regle de")
        print("  persistance ne le sauvera. Conclusion actee : le stage 1 est une simple")
        print("  porte d'observation NON discriminante ; la detection revient a STEP 3-5.")
        return 0
    print(f"  AUC {auc:.4f} >= {arguments.auc_floor:.2f} : le score porte du signal.")
    print("  La regle de persistance (C-19) est justifiee ; choisir (theta_R, K) dans le")
    print("  balayage ci-dessus, sur des seeds DISTINCTS de ceux de l'evaluation finale.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
