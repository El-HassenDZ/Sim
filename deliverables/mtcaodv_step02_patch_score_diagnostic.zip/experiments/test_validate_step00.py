#!/usr/bin/env python3
"""Unit tests for the fail-closed STEP 0 artifact validator."""

from __future__ import annotations

import csv
import json
import tempfile
import unittest
from pathlib import Path
from typing import Any

from validate_step00 import (
    Step0ValidationError,
    validate_artifacts,
    validate_reproducible_pair,
)


REQUIRED_PREFIX = [
    "protocol",
    "nodes",
    "simTime",
    "minSpeed",
    "maxSpeed",
    "seed",
    "run",
    "attackerRatio",
    "attackerCount",
    "attackStart",
    "appTxPackets",
    "appRxPackets",
    "appTxBytes",
    "appRxBytes",
    "pdr",
    "plr",
    "throughput_bps",
    "goodput_bps",
    "meanDelay_s",
]

DIAGNOSTIC_COLUMNS = [
    "networkRxBytes",
    "evaluationDuration_s",
    "flowCount",
    "packetPayloadBytes",
    "dataRate",
    "areaSize_m",
    "maxRange_m",
    "appStart_s",
    "appStop_s",
    "ipv4Network",
    "ipv4Mask",
    "mobilityStreamBase",
    "wifiStreamBase",
    "aodvStreamBase",
    "trafficStreamBase",
    "mobilityStreamsConsumed",
    "wifiStreamsConsumed",
    "aodvStreamsConsumed",
    "trafficStreamsConsumed",
    "monitoredApplicationFlows",
    "pauseTime_s",
    "sourceStartStagger_s",
    "wifiStandard",
    "wifiMac",
    "propagationModel",
]


def _valid_row() -> dict[str, str]:
    """Build one internally consistent numerical oracle row."""

    tx_packets = 100
    rx_packets = 98
    payload_bytes = 512
    evaluation_seconds = 49.0
    network_rx_bytes = 54_880
    pdr = rx_packets / tx_packets

    return {
        "protocol": "AODV",
        "nodes": "20",
        "simTime": "60",
        "minSpeed": "1",
        "maxSpeed": "20",
        "seed": "12345",
        "run": "1",
        "attackerRatio": "0",
        "attackerCount": "0",
        "attackStart": "10",
        "appTxPackets": str(tx_packets),
        "appRxPackets": str(rx_packets),
        "appTxBytes": str(tx_packets * payload_bytes),
        "appRxBytes": str(rx_packets * payload_bytes),
        "pdr": repr(pdr),
        "plr": repr(1.0 - pdr),
        "throughput_bps": repr(8.0 * network_rx_bytes / evaluation_seconds),
        "goodput_bps": repr(8.0 * rx_packets * payload_bytes / evaluation_seconds),
        "meanDelay_s": "0.0125",
        "networkRxBytes": str(network_rx_bytes),
        "evaluationDuration_s": repr(evaluation_seconds),
        "flowCount": "4",
        "packetPayloadBytes": str(payload_bytes),
        "dataRate": "64kbps",
        "areaSize_m": "300",
        "maxRange_m": "150",
        "appStart_s": "10",
        "appStop_s": "59",
        "ipv4Network": "10.1.0.0",
        "ipv4Mask": "255.255.255.0",
        "mobilityStreamBase": "10000",
        "wifiStreamBase": "30000",
        "aodvStreamBase": "20000",
        "trafficStreamBase": "40000",
        "mobilityStreamsConsumed": "80",
        "wifiStreamsConsumed": "40",
        "aodvStreamsConsumed": "20",
        "trafficStreamsConsumed": "12",
        "monitoredApplicationFlows": "4",
        "pauseTime_s": "0",
        "sourceStartStagger_s": "0.1",
        "wifiStandard": "802.11b",
        "wifiMac": "ns3::AdhocWifiMac",
        "propagationModel": "ns3::RangePropagationLossModel",
    }


def _valid_manifest(row: dict[str, str]) -> dict[str, Any]:
    """Build a manifest that describes exactly the supplied CSV row."""

    return {
        "schemaVersion": "mtcaodv-step00-v1",
        "targetNs3Version": "3.48",
        "validationStatus": "UNVALIDATED_UNTIL_USER_EXECUTION",
        "protocol": "AODV",
        "attackImplemented": False,
        "network": {
            "ipv4Network": row["ipv4Network"],
            "ipv4Mask": row["ipv4Mask"],
            "wifiStandard": "802.11b",
            "wifiMac": "ns3::AdhocWifiMac",
            "propagationModel": "ns3::RangePropagationLossModel",
        },
        "configuration": {
            "nodes": int(row["nodes"]),
            "simTime": float(row["simTime"]),
            "minSpeed": float(row["minSpeed"]),
            "maxSpeed": float(row["maxSpeed"]),
            "pauseTime": float(row["pauseTime_s"]),
            "attackerRatio": float(row["attackerRatio"]),
            "attackerCount": int(row["attackerCount"]),
            "attackStart": float(row["attackStart"]),
            "seed": int(row["seed"]),
            "run": int(row["run"]),
            "areaSizeMeters": float(row["areaSize_m"]),
            "maximumRangeMeters": float(row["maxRange_m"]),
            "flowCount": int(row["flowCount"]),
            "packetPayloadBytes": int(row["packetPayloadBytes"]),
            "dataRate": row["dataRate"],
            "applicationStartSeconds": float(row["appStart_s"]),
            "applicationStopSeconds": float(row["appStop_s"]),
            "sourceStartStaggerSeconds": float(row["sourceStartStagger_s"]),
        },
        "rng": {
            "seed": int(row["seed"]),
            "run": int(row["run"]),
            "mobilityStreamBase": int(row["mobilityStreamBase"]),
            "wifiStreamBase": int(row["wifiStreamBase"]),
            "aodvStreamBase": int(row["aodvStreamBase"]),
            "trafficStreamBase": int(row["trafficStreamBase"]),
            "mobilityStreamsConsumed": int(row["mobilityStreamsConsumed"]),
            "wifiStreamsConsumed": int(row["wifiStreamsConsumed"]),
            "aodvStreamsConsumed": int(row["aodvStreamsConsumed"]),
            "trafficStreamsConsumed": int(row["trafficStreamsConsumed"]),
        },
        "metrics": {
            "appTxPackets": int(row["appTxPackets"]),
            "appRxPackets": int(row["appRxPackets"]),
            "appTxBytes": int(row["appTxBytes"]),
            "appRxBytes": int(row["appRxBytes"]),
            "networkRxBytes": int(row["networkRxBytes"]),
            "pdr": float(row["pdr"]),
            "plr": float(row["plr"]),
            "throughput_bps": float(row["throughput_bps"]),
            "goodput_bps": float(row["goodput_bps"]),
            "meanDelay_s": float(row["meanDelay_s"]),
            "monitoredApplicationFlows": int(row["monitoredApplicationFlows"]),
        },
    }


class Step0ValidatorTestCase(unittest.TestCase):
    """Exercise acceptance and representative blocking failures."""

    def setUp(self) -> None:
        """Create one isolated artifact directory per test."""

        self._temporary_directory = tempfile.TemporaryDirectory()
        self.directory = Path(self._temporary_directory.name)
        self.schema_path = self.directory / "schema.json"
        self.csv_path = self.directory / "result.csv"
        self.manifest_path = self.directory / "manifest.json"

    def tearDown(self) -> None:
        """Remove all temporary artifacts created by the test."""

        self._temporary_directory.cleanup()

    def _write_artifacts(
        self,
        row: dict[str, str],
        manifest: dict[str, Any],
        *,
        header: list[str] | None = None,
    ) -> None:
        """Write a schema, one CSV row, and one JSON manifest."""

        schema = {
            "schemaVersion": "mtcaodv-step00-v1",
            "requiredPrefix": REQUIRED_PREFIX,
            "requiredDiagnostics": DIAGNOSTIC_COLUMNS,
        }
        self.schema_path.write_text(json.dumps(schema), encoding="utf-8")
        self.manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

        selected_header = header or REQUIRED_PREFIX + DIAGNOSTIC_COLUMNS
        with self.csv_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=selected_header)
            writer.writeheader()
            writer.writerow({name: row[name] for name in selected_header})

    def test_accepts_consistent_artifacts(self) -> None:
        """A complete row matching all independent equations must pass."""

        row = _valid_row()
        self._write_artifacts(row, _valid_manifest(row))
        record = validate_artifacts(
            self.csv_path,
            self.manifest_path,
            self.schema_path,
            expected_seed=12345,
            expected_run=1,
            minimum_pdr=0.9,
        )
        self.assertEqual(record.app_tx_packets, 100)

    def test_accepts_identical_deterministic_replay(self) -> None:
        """Two complete copies of one deterministic realization must match."""

        row = _valid_row()
        manifest = _valid_manifest(row)
        self._write_artifacts(row, manifest)
        first_record = validate_artifacts(
            self.csv_path,
            self.manifest_path,
            self.schema_path,
        )

        replay_csv_path = self.directory / "replay.csv"
        replay_manifest_path = self.directory / "replay.json"
        with replay_csv_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=REQUIRED_PREFIX + DIAGNOSTIC_COLUMNS,
            )
            writer.writeheader()
            writer.writerow(row)
        replay_manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

        replay_record = validate_artifacts(
            replay_csv_path,
            replay_manifest_path,
            self.schema_path,
        )
        validate_reproducible_pair(
            first_record,
            self.manifest_path,
            replay_record,
            replay_manifest_path,
        )

    def test_rejects_reordered_required_prefix(self) -> None:
        """Later scripts must not silently accept renamed/reordered columns."""

        row = _valid_row()
        header = REQUIRED_PREFIX.copy()
        header[0], header[1] = header[1], header[0]
        header.extend(DIAGNOSTIC_COLUMNS)
        self._write_artifacts(row, _valid_manifest(row), header=header)
        with self.assertRaises(Step0ValidationError):
            validate_artifacts(self.csv_path, self.manifest_path, self.schema_path)

    def test_rejects_pdr_formula_mismatch(self) -> None:
        """A plausible but fabricated PDR must not pass validation."""

        row = _valid_row()
        row["pdr"] = "0.99"
        manifest = _valid_manifest(row)
        self._write_artifacts(row, manifest)
        with self.assertRaises(Step0ValidationError):
            validate_artifacts(self.csv_path, self.manifest_path, self.schema_path)

    def test_rejects_manifest_seed_mismatch(self) -> None:
        """CSV/manifest pairing must fail when one stochastic coordinate differs."""

        row = _valid_row()
        manifest = _valid_manifest(row)
        manifest["rng"]["seed"] = 999
        self._write_artifacts(row, manifest)
        with self.assertRaises(Step0ValidationError):
            validate_artifacts(self.csv_path, self.manifest_path, self.schema_path)

    def test_rejects_zero_transmissions(self) -> None:
        """No offered traffic is an invalid run, not PDR=0 evidence."""

        row = _valid_row()
        row.update(
            {
                "appTxPackets": "0",
                "appRxPackets": "0",
                "appTxBytes": "0",
                "appRxBytes": "0",
                "pdr": "nan",
                "plr": "nan",
                "meanDelay_s": "nan",
                "networkRxBytes": "0",
                "throughput_bps": "0",
                "goodput_bps": "0",
            }
        )
        self._write_artifacts(row, _valid_manifest(row))
        with self.assertRaises(Step0ValidationError):
            validate_artifacts(self.csv_path, self.manifest_path, self.schema_path)

    def test_rejects_replay_with_different_run(self) -> None:
        """Individually valid runs must still fail an invalid replay comparison."""

        first_row = _valid_row()
        self._write_artifacts(first_row, _valid_manifest(first_row))
        first_record = validate_artifacts(
            self.csv_path,
            self.manifest_path,
            self.schema_path,
        )

        second_row = _valid_row()
        second_row["run"] = "2"
        second_manifest = _valid_manifest(second_row)
        second_csv_path = self.directory / "replay.csv"
        second_manifest_path = self.directory / "replay.json"
        with second_csv_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=REQUIRED_PREFIX + DIAGNOSTIC_COLUMNS,
            )
            writer.writeheader()
            writer.writerow(second_row)
        second_manifest_path.write_text(json.dumps(second_manifest), encoding="utf-8")

        second_record = validate_artifacts(
            second_csv_path,
            second_manifest_path,
            self.schema_path,
        )
        with self.assertRaises(Step0ValidationError):
            validate_reproducible_pair(
                first_record,
                self.manifest_path,
                second_record,
                second_manifest_path,
            )


if __name__ == "__main__":
    unittest.main()
