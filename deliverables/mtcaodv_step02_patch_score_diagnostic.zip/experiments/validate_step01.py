#!/usr/bin/env python3
"""Validate one MTC-AODV STEP 1 CSV row and its reproducibility manifest.

STEP 1 introduces multiple simultaneous full Blackholes running on the forked
ns3::mtcaodv routing protocol.  This validator is fail closed: a missing column,
a non-finite required metric, a formula mismatch, an attacker-count that
violates Equation (2), a non-unique attacker id, or (by default) an attack that
produced no forged RREP / no drop rejects the run.

It uses only the Python standard library so it runs in the existing Python 3
environment without adding an analysis dependency.  The network/metric formula
checks mirror the validated STEP 0 validator; only the security additions are
new.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Any, Mapping, Sequence


class Step1ValidationError(ValueError):
    """Raised when a STEP 1 artifact violates a required invariant."""


def round_half_up(value: float) -> int:
    """Nearest-integer rounding matching Equation (2): floor(x + 0.5).

    Args:
        value: Non-negative real number (attackerRatio * nodes).

    Returns:
        The integer attacker count.
    """

    return math.floor(value + 0.5)


@dataclass(frozen=True)
class Step1Record:
    """Typed representation of the single STEP 1 CSV row.

    Field names mirror the C++ CSV schema in Python snake case.  Ratios are
    dimensionless, times are seconds, speeds m/s, distances m, byte counters
    bytes, rates bit/s, and the security counters are plain non-negative counts.
    """

    # --- STEP 0 stable prefix ---
    protocol: str
    nodes: int
    sim_time: float
    min_speed: float
    max_speed: float
    seed: int
    run: int
    attacker_ratio: float
    attacker_count: int
    attack_start: float
    app_tx_packets: int
    app_rx_packets: int
    app_tx_bytes: int
    app_rx_bytes: int
    pdr: float
    plr: float
    throughput_bps: float
    goodput_bps: float
    mean_delay_s: float

    # --- STEP 0 diagnostics used by STEP 1 ---
    network_rx_bytes: int
    evaluation_duration_s: float
    flow_count: int
    packet_payload_bytes: int
    app_start_s: float
    app_stop_s: float
    ipv4_network: str
    ipv4_mask: str
    monitored_application_flows: int
    wifi_standard: str
    wifi_mac: str
    propagation_model: str

    # --- STEP 1 append-only security columns ---
    forged_rrep_count: int
    blackhole_drop_count: int
    attack_stream: int
    attacker_selection_streams_consumed: int

    @classmethod
    def from_csv_row(cls, row: Mapping[str, str]) -> "Step1Record":
        """Parse a schema-checked CSV mapping into a typed record."""

        try:
            return cls(
                protocol=row["protocol"],
                nodes=int(row["nodes"]),
                sim_time=float(row["simTime"]),
                min_speed=float(row["minSpeed"]),
                max_speed=float(row["maxSpeed"]),
                seed=int(row["seed"]),
                run=int(row["run"]),
                attacker_ratio=float(row["attackerRatio"]),
                attacker_count=int(row["attackerCount"]),
                attack_start=float(row["attackStart"]),
                app_tx_packets=int(row["appTxPackets"]),
                app_rx_packets=int(row["appRxPackets"]),
                app_tx_bytes=int(row["appTxBytes"]),
                app_rx_bytes=int(row["appRxBytes"]),
                pdr=float(row["pdr"]),
                plr=float(row["plr"]),
                throughput_bps=float(row["throughput_bps"]),
                goodput_bps=float(row["goodput_bps"]),
                mean_delay_s=float(row["meanDelay_s"]),
                network_rx_bytes=int(row["networkRxBytes"]),
                evaluation_duration_s=float(row["evaluationDuration_s"]),
                flow_count=int(row["flowCount"]),
                packet_payload_bytes=int(row["packetPayloadBytes"]),
                app_start_s=float(row["appStart_s"]),
                app_stop_s=float(row["appStop_s"]),
                ipv4_network=row["ipv4Network"],
                ipv4_mask=row["ipv4Mask"],
                monitored_application_flows=int(row["monitoredApplicationFlows"]),
                wifi_standard=row["wifiStandard"],
                wifi_mac=row["wifiMac"],
                propagation_model=row["propagationModel"],
                forged_rrep_count=int(row["forgedRrepCount"]),
                blackhole_drop_count=int(row["blackholeDropCount"]),
                attack_stream=int(row["attackStream"]),
                attacker_selection_streams_consumed=int(
                    row["attackerSelectionStreamsConsumed"]
                ),
            )
        except (KeyError, TypeError, ValueError) as error:
            raise Step1ValidationError(f"invalid CSV field: {error}") from error


def _load_json(path: Path) -> dict[str, Any]:
    """Read one JSON object with an explicit diagnostic on failure."""

    try:
        with path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
    except (OSError, json.JSONDecodeError) as error:
        raise Step1ValidationError(f"cannot read valid JSON {path}: {error}") from error
    if not isinstance(value, dict):
        raise Step1ValidationError(f"JSON root must be an object: {path}")
    return value


def _read_single_csv_row(path: Path) -> tuple[list[str], dict[str, str]]:
    """Return the exact header and only data row from a STEP 1 CSV file."""

    try:
        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            header = list(reader.fieldnames or [])
            rows = list(reader)
    except OSError as error:
        raise Step1ValidationError(f"cannot read CSV {path}: {error}") from error
    if len(rows) != 1:
        raise Step1ValidationError(
            f"CSV must contain exactly one data row; found {len(rows)}"
        )
    if len(header) != len(set(header)):
        raise Step1ValidationError("CSV header contains duplicate column names")
    return header, rows[0]


def _require_finite(name: str, value: float) -> None:
    """Reject NaN and infinity for a metric required in a successful run."""

    if not math.isfinite(value):
        raise Step1ValidationError(f"{name} must be finite, got {value!r}")


def _require_close(name: str, actual: float, expected: float) -> None:
    """Compare a computed field with its independent equation oracle."""

    if not math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-12):
        raise Step1ValidationError(
            f"{name} mismatch: observed {actual:.17g}, expected {expected:.17g}"
        )


def validate_record(
    record: Step1Record,
    manifest: Mapping[str, Any],
    *,
    expected_seed: int | None = None,
    expected_run: int | None = None,
    require_attack_effect: bool = True,
) -> None:
    """Validate scientific, numerical, attack, and pairing invariants.

    Args:
        record: Typed CSV row.
        manifest: Parsed JSON sidecar.
        expected_seed: Optional externally expected global seed.
        expected_run: Optional externally expected ns-3 run number.
        require_attack_effect: When True (default) and attackerRatio>0, the run
            must have produced at least one forged RREP and one silent drop
            (spec test T-08 PASS criterion).  Set False only for a documented
            topology where an attacker legitimately never receives a routable
            RREQ.

    Raises:
        Step1ValidationError: On the first violated invariant.
    """

    if record.protocol != "MTC-AODV":
        raise Step1ValidationError("STEP 1 must use protocol=MTC-AODV")

    _require_finite("attackerRatio", record.attacker_ratio)
    _require_finite("attackStart", record.attack_start)

    if not 2 <= record.nodes <= 254 or record.sim_time <= 0.0:
        raise Step1ValidationError("nodes and simTime must define a nonempty network run")
    if record.min_speed <= 0.0 or record.max_speed < record.min_speed:
        raise Step1ValidationError("speed bounds must satisfy 0 < minSpeed <= maxSpeed")
    if record.seed <= 0:
        raise Step1ValidationError("seed must be positive")

    # --- Attack configuration (Equation 2) ---
    if not 0.0 <= record.attacker_ratio < 1.0:
        raise Step1ValidationError("attackerRatio must be in [0,1)")
    expected_attacker_count = round_half_up(record.attacker_ratio * record.nodes)
    if record.attacker_count != expected_attacker_count:
        raise Step1ValidationError(
            f"attackerCount {record.attacker_count} violates Equation (2) "
            f"floor(r_a*N+0.5)={expected_attacker_count}"
        )
    if record.attacker_count >= record.nodes:
        raise Step1ValidationError("attackerCount cannot reach the whole population")

    # attackStart must precede the application stop when an attack is present.
    if record.attacker_ratio > 0.0 and record.attack_start >= record.app_stop_s:
        raise Step1ValidationError("attackStart is not before the application stop time")

    # --- Application counters and Equations (20),(24),(25),(26) ---
    if record.app_tx_packets <= 0:
        raise Step1ValidationError("appTxPackets must be observed and strictly positive")
    if not 0 <= record.app_rx_packets <= record.app_tx_packets:
        raise Step1ValidationError("appRxPackets must be in [0, appTxPackets]")
    if record.packet_payload_bytes <= 0:
        raise Step1ValidationError("packetPayloadBytes must be positive")
    if record.app_tx_bytes != record.app_tx_packets * record.packet_payload_bytes:
        raise Step1ValidationError("appTxBytes is inconsistent with observed Tx packets")
    if record.app_rx_bytes != record.app_rx_packets * record.packet_payload_bytes:
        raise Step1ValidationError("appRxBytes is inconsistent with observed Rx packets")
    if record.network_rx_bytes < record.app_rx_bytes:
        raise Step1ValidationError("networkRxBytes cannot be smaller than useful Rx bytes")
    if record.evaluation_duration_s <= 0.0:
        raise Step1ValidationError("evaluationDuration_s must be positive")
    _require_close(
        "evaluationDuration_s",
        record.evaluation_duration_s,
        record.app_stop_s - record.app_start_s,
    )

    expected_pdr = record.app_rx_packets / record.app_tx_packets
    _require_finite("pdr", record.pdr)
    _require_close("pdr (Equation 20)", record.pdr, expected_pdr)
    if not 0.0 <= record.pdr <= 1.0:
        raise Step1ValidationError("pdr must be in [0,1]")

    expected_plr = 1.0 - expected_pdr
    _require_finite("plr", record.plr)
    _require_close("plr (Equation 24)", record.plr, expected_plr)
    if not 0.0 <= record.plr <= 1.0:
        raise Step1ValidationError("plr must be in [0,1]")

    expected_throughput = 8.0 * record.network_rx_bytes / record.evaluation_duration_s
    expected_goodput = 8.0 * record.app_rx_bytes / record.evaluation_duration_s
    _require_finite("throughput_bps", record.throughput_bps)
    _require_finite("goodput_bps", record.goodput_bps)
    _require_close("throughput_bps (Equation 25)", record.throughput_bps, expected_throughput)
    _require_close("goodput_bps (Equation 25)", record.goodput_bps, expected_goodput)
    if record.throughput_bps < record.goodput_bps:
        raise Step1ValidationError("network throughput cannot be below useful goodput")

    # meanDelay is required only when at least one packet was delivered; unlike
    # the healthy STEP 0 baseline, a fully successful Blackhole may deliver zero
    # useful packets, which is a legitimate attacked outcome, not a failure.
    if record.app_rx_packets > 0:
        _require_finite("meanDelay_s", record.mean_delay_s)
        if record.mean_delay_s < 0.0:
            raise Step1ValidationError("meanDelay_s cannot be negative")
    else:
        # Fail-closed discipline: a zero-delivery run must report NaN delay,
        # never a fabricated 0.
        if math.isfinite(record.mean_delay_s):
            raise Step1ValidationError(
                "meanDelay_s must be NaN when no packet was delivered"
            )

    # --- Addressing and PHY/MAC identity (unchanged from STEP 0) ---
    if record.ipv4_network != "10.1.0.0" or record.ipv4_mask != "255.255.255.0":
        raise Step1ValidationError("pilot addressing must be exactly 10.1.0.0/24")
    if (
        record.wifi_standard != "802.11b"
        or record.wifi_mac != "ns3::AdhocWifiMac"
        or record.propagation_model != "ns3::RangePropagationLossModel"
    ):
        raise Step1ValidationError("unexpected STEP 1 Wi-Fi or propagation configuration")
    if record.monitored_application_flows != record.flow_count:
        raise Step1ValidationError("FlowMonitor did not observe every configured UDP flow")

    # --- STEP 1 security counters ---
    if record.forged_rrep_count < 0 or record.blackhole_drop_count < 0:
        raise Step1ValidationError("security counters must be non-negative")

    if record.attacker_ratio == 0.0:
        # A healthy fork sanity run attaches no policy: no forge, no drop.
        if record.forged_rrep_count != 0 or record.blackhole_drop_count != 0:
            raise Step1ValidationError(
                "attackerRatio=0 must produce zero forged RREPs and zero drops"
            )
        if record.attacker_count != 0 or record.attacker_selection_streams_consumed != 0:
            raise Step1ValidationError(
                "attackerRatio=0 must select no attacker and consume no draw stream"
            )
    else:
        if record.attacker_selection_streams_consumed != 1:
            raise Step1ValidationError(
                "a nonzero attacker draw must consume exactly one RNG stream"
            )
        if require_attack_effect:
            # Spec test T-08 PASS: the attack must be observable.
            if record.forged_rrep_count <= 0:
                raise Step1ValidationError(
                    "attackerRatio>0 but no forged RREP was emitted (A2.3); "
                    "re-check topology/timing or pass --allow-zero-attack-effect"
                )
            if record.blackhole_drop_count <= 0:
                raise Step1ValidationError(
                    "attackerRatio>0 but no transit packet was dropped (A2.4); "
                    "re-check topology/timing or pass --allow-zero-attack-effect"
                )

    if expected_seed is not None and record.seed != expected_seed:
        raise Step1ValidationError(
            f"seed mismatch: observed {record.seed}, expected {expected_seed}"
        )
    if expected_run is not None and record.run != expected_run:
        raise Step1ValidationError(
            f"run mismatch: observed {record.run}, expected {expected_run}"
        )

    _validate_manifest(record, manifest)


def _validate_manifest(record: Step1Record, manifest: Mapping[str, Any]) -> None:
    """Cross-check the manifest header, attacker list, and security counters."""

    if manifest.get("schemaVersion") != "mtcaodv-step01-v1":
        raise Step1ValidationError("unexpected manifest schemaVersion")
    if manifest.get("targetNs3Version") != "3.48":
        raise Step1ValidationError("manifest targetNs3Version must be 3.48")
    if manifest.get("protocol") != "MTC-AODV" or manifest.get("attackImplemented") is not True:
        raise Step1ValidationError("manifest protocol/attack status is inconsistent with STEP 1")

    configuration = manifest.get("configuration")
    attack = manifest.get("attack")
    if not isinstance(configuration, dict) or not isinstance(attack, dict):
        raise Step1ValidationError("manifest configuration/attack objects are required")

    if configuration.get("attackerCount") != record.attacker_count:
        raise Step1ValidationError("manifest attackerCount differs from CSV")

    if attack.get("forgedRrepCount") != record.forged_rrep_count:
        raise Step1ValidationError("manifest forgedRrepCount differs from CSV")
    if attack.get("blackholeDropCount") != record.blackhole_drop_count:
        raise Step1ValidationError("manifest blackholeDropCount differs from CSV")

    attacker_ids = attack.get("attackerNodeIds")
    if not isinstance(attacker_ids, list):
        raise Step1ValidationError("manifest attackerNodeIds must be a list")
    if len(attacker_ids) != record.attacker_count:
        raise Step1ValidationError(
            "manifest attackerNodeIds length differs from attackerCount"
        )
    # Spec invariant: attacker IDs are unique, sorted, and in range.
    if any(not isinstance(node_id, int) or isinstance(node_id, bool) for node_id in attacker_ids):
        raise Step1ValidationError("attackerNodeIds must all be integers")
    if len(set(attacker_ids)) != len(attacker_ids):
        raise Step1ValidationError("attackerNodeIds must be unique")
    if attacker_ids != sorted(attacker_ids):
        raise Step1ValidationError("attackerNodeIds must be sorted")
    if any(not 0 <= node_id < record.nodes for node_id in attacker_ids):
        raise Step1ValidationError("attackerNodeIds must be valid node identifiers")
    # Traffic endpoints (sources 0..flowCount-1 and destination nodes-1) must be
    # excluded from the attacker set by default.
    endpoints = set(range(record.flow_count)) | {record.nodes - 1}
    if endpoints & set(attacker_ids):
        raise Step1ValidationError("a traffic endpoint was selected as an attacker")


def validate_artifacts(
    csv_path: Path,
    manifest_path: Path,
    schema_path: Path,
    *,
    expected_seed: int | None = None,
    expected_run: int | None = None,
    require_attack_effect: bool = True,
) -> Step1Record:
    """Load and validate the three STEP 1 artifacts."""

    schema = _load_json(schema_path)
    header, row = _read_single_csv_row(csv_path)

    required_prefix = schema.get("requiredPrefix")
    required_diagnostics = schema.get("requiredDiagnostics")
    required_security = schema.get("requiredSecurityColumns")
    if not all(
        isinstance(value, list)
        for value in (required_prefix, required_diagnostics, required_security)
    ):
        raise Step1ValidationError("schema column lists are missing")

    # The STEP 0 prefix must remain first and in order.  STEP 1 columns may only
    # be appended after it, so positional drift is a blocking error.
    if header[: len(required_prefix)] != required_prefix:
        raise Step1ValidationError("CSV required prefix is missing, reordered, or renamed")
    for column in required_diagnostics + required_security:
        if column not in header:
            raise Step1ValidationError(f"CSV is missing required column: {column}")

    record = Step1Record.from_csv_row(row)
    manifest = _load_json(manifest_path)
    validate_record(
        record,
        manifest,
        expected_seed=expected_seed,
        expected_run=expected_run,
        require_attack_effect=require_attack_effect,
    )
    return record


def validate_reproducible_pair(
    first_record: Step1Record,
    first_manifest_path: Path,
    second_record: Step1Record,
    second_manifest_path: Path,
) -> None:
    """Require two same-coordinate executions to be data-equivalent."""

    for field in fields(Step1Record):
        first_value = getattr(first_record, field.name)
        second_value = getattr(second_record, field.name)
        if first_value != second_value:
            raise Step1ValidationError(
                f"replay mismatch in {field.name}: {first_value!r} != {second_value!r}"
            )
    first_manifest = _load_json(first_manifest_path)
    second_manifest = _load_json(second_manifest_path)
    if first_manifest != second_manifest:
        raise Step1ValidationError("replay manifests differ despite equal typed CSV rows")


def _parse_arguments(argv: Sequence[str]) -> argparse.Namespace:
    """Parse command-line arguments without performing validation work."""

    default_schema = (
        Path(__file__).resolve().parent / "schemas" / "step01_results_schema.json"
    )
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", required=True, type=Path, help="CSV produced by the STEP 1 pilot")
    parser.add_argument("--manifest", required=True, type=Path, help="JSON manifest of the run")
    parser.add_argument("--schema", type=Path, default=default_schema, help="STEP 1 schema JSON")
    parser.add_argument("--expected-seed", type=int, default=None)
    parser.add_argument("--expected-run", type=int, default=None)
    parser.add_argument(
        "--allow-zero-attack-effect",
        action="store_true",
        help="Do not require forged>0/drops>0 when attackerRatio>0",
    )
    parser.add_argument("--replay-csv", type=Path, default=None)
    parser.add_argument("--replay-manifest", type=Path, default=None)
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    """Validate one run and return a shell-compatible status code."""

    arguments = _parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        if (arguments.replay_csv is None) != (arguments.replay_manifest is None):
            raise Step1ValidationError(
                "--replay-csv and --replay-manifest must be supplied together"
            )
        record = validate_artifacts(
            arguments.csv,
            arguments.manifest,
            arguments.schema,
            expected_seed=arguments.expected_seed,
            expected_run=arguments.expected_run,
            require_attack_effect=not arguments.allow_zero_attack_effect,
        )
        replay_record: Step1Record | None = None
        if arguments.replay_csv is not None and arguments.replay_manifest is not None:
            replay_record = validate_artifacts(
                arguments.replay_csv,
                arguments.replay_manifest,
                arguments.schema,
                expected_seed=arguments.expected_seed,
                expected_run=arguments.expected_run,
                require_attack_effect=not arguments.allow_zero_attack_effect,
            )
            validate_reproducible_pair(
                record, arguments.manifest, replay_record, arguments.replay_manifest
            )
    except Step1ValidationError as error:
        print(f"STEP 1 validation FAIL: {error}", file=sys.stderr)
        return 1

    replay_suffix = " with deterministic replay" if replay_record is not None else ""
    print(
        "STEP 1 validation PASS: "
        f"{arguments.csv} (attackers={record.attacker_count}, "
        f"forged={record.forged_rrep_count}, drops={record.blackhole_drop_count}, "
        f"PDR={record.pdr:.6f}){replay_suffix}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
