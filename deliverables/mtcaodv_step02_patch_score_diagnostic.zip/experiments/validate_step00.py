#!/usr/bin/env python3
"""Validate one MTC-AODV STEP 0 CSV row and its reproducibility manifest.

The validator is deliberately fail closed: missing columns, non-finite required
metrics, inconsistent counters, or formula mismatches reject the run.  It uses
only the Python standard library so it can execute in the user's existing
Python 3 environment without adding an analysis dependency.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Any, Mapping, Sequence


class Step0ValidationError(ValueError):
    """Raised when a STEP 0 artifact violates a required invariant."""


@dataclass(frozen=True)
class Step0Record:
    """Typed representation of the single CSV row produced by the pilot.

    Names intentionally mirror the C++ CSV schema while using Python snake
    case. Ratios are dimensionless, times are seconds, speeds are metres per
    second, distances are metres, byte counters are bytes, and rates are bit/s.
    """

    # Experiment identity and principal paired coordinates.
    protocol: str
    nodes: int
    sim_time: float
    min_speed: float
    max_speed: float
    seed: int
    run: int
    attacker_ratio: float
    attacker_count: int
    attack_start: float

    # Direct application observations and Equation (20)/(24)-(26) outputs.
    app_tx_packets: int
    app_rx_packets: int
    app_tx_bytes: int
    app_rx_bytes: int
    pdr: float
    plr: float
    throughput_bps: float
    goodput_bps: float
    mean_delay_s: float

    # Traffic-load and evaluation-window diagnostics.
    network_rx_bytes: int
    evaluation_duration_s: float
    flow_count: int
    packet_payload_bytes: int
    data_rate: str
    area_size_m: float
    max_range_m: float
    app_start_s: float
    app_stop_s: float

    # Fixed addressing and explicitly partitioned random-stream coordinates.
    ipv4_network: str
    ipv4_mask: str
    mobility_stream_base: int
    wifi_stream_base: int
    aodv_stream_base: int
    traffic_stream_base: int
    mobility_streams_consumed: int
    wifi_streams_consumed: int
    aodv_streams_consumed: int
    traffic_streams_consumed: int
    monitored_application_flows: int

    # Remaining physical/MAC coordinates needed for deterministic pairing.
    pause_time_s: float
    source_start_stagger_s: float
    wifi_standard: str
    wifi_mac: str
    propagation_model: str

    @classmethod
    def from_csv_row(cls, row: Mapping[str, str]) -> "Step0Record":
        """Parse an already schema-checked CSV mapping.

        Args:
            row: Mapping from exact CSV column names to raw field strings.

        Returns:
            A fully typed immutable record.

        Raises:
            Step0ValidationError: If any field cannot be converted to its
                required type.
        """

        try:
            return cls(
                protocol=row["protocol"],
                nodes=int(row["nodes"]),
                sim_time=float(row["simTime"]),
                min_speed=float(row["minSpeed"]),
                max_speed=float(row["maxSpeed"]),
                seed=int(row["seed"]),
                run=int(row["run"]),
                attacker_ratio=float(row["attackerRatio"]),
                attacker_count=int(row["attackerCount"]),
                attack_start=float(row["attackStart"]),
                app_tx_packets=int(row["appTxPackets"]),
                app_rx_packets=int(row["appRxPackets"]),
                app_tx_bytes=int(row["appTxBytes"]),
                app_rx_bytes=int(row["appRxBytes"]),
                pdr=float(row["pdr"]),
                plr=float(row["plr"]),
                throughput_bps=float(row["throughput_bps"]),
                goodput_bps=float(row["goodput_bps"]),
                mean_delay_s=float(row["meanDelay_s"]),
                network_rx_bytes=int(row["networkRxBytes"]),
                evaluation_duration_s=float(row["evaluationDuration_s"]),
                flow_count=int(row["flowCount"]),
                packet_payload_bytes=int(row["packetPayloadBytes"]),
                data_rate=row["dataRate"],
                area_size_m=float(row["areaSize_m"]),
                max_range_m=float(row["maxRange_m"]),
                app_start_s=float(row["appStart_s"]),
                app_stop_s=float(row["appStop_s"]),
                ipv4_network=row["ipv4Network"],
                ipv4_mask=row["ipv4Mask"],
                mobility_stream_base=int(row["mobilityStreamBase"]),
                wifi_stream_base=int(row["wifiStreamBase"]),
                aodv_stream_base=int(row["aodvStreamBase"]),
                traffic_stream_base=int(row["trafficStreamBase"]),
                mobility_streams_consumed=int(row["mobilityStreamsConsumed"]),
                wifi_streams_consumed=int(row["wifiStreamsConsumed"]),
                aodv_streams_consumed=int(row["aodvStreamsConsumed"]),
                traffic_streams_consumed=int(row["trafficStreamsConsumed"]),
                monitored_application_flows=int(row["monitoredApplicationFlows"]),
                pause_time_s=float(row["pauseTime_s"]),
                source_start_stagger_s=float(row["sourceStartStagger_s"]),
                wifi_standard=row["wifiStandard"],
                wifi_mac=row["wifiMac"],
                propagation_model=row["propagationModel"],
            )
        except (KeyError, TypeError, ValueError) as error:
            raise Step0ValidationError(f"invalid CSV field: {error}") from error


def _load_json(path: Path) -> dict[str, Any]:
    """Read one JSON object with an explicit diagnostic on failure."""

    try:
        with path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
    except (OSError, json.JSONDecodeError) as error:
        raise Step0ValidationError(f"cannot read valid JSON {path}: {error}") from error

    # A manifest or schema represented by a scalar/list cannot supply named
    # fields, so reject it before any nested lookup produces a vague error.
    if not isinstance(value, dict):
        raise Step0ValidationError(f"JSON root must be an object: {path}")
    return value


def _read_single_csv_row(path: Path) -> tuple[list[str], dict[str, str]]:
    """Return the exact header and only data row from a STEP 0 CSV file."""

    try:
        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            header = list(reader.fieldnames or [])
            rows = list(reader)
    except OSError as error:
        raise Step0ValidationError(f"cannot read CSV {path}: {error}") from error

    # One invocation produces exactly one immutable run row.  Accepting zero or
    # multiple rows would make manifest-to-row pairing ambiguous.
    if len(rows) != 1:
        raise Step0ValidationError(
            f"CSV must contain exactly one data row; found {len(rows)}"
        )
    if len(header) != len(set(header)):
        raise Step0ValidationError("CSV header contains duplicate column names")
    return header, rows[0]


def _require_finite(name: str, value: float) -> None:
    """Reject NaN and infinity for a metric required in a successful pilot."""

    if not math.isfinite(value):
        raise Step0ValidationError(f"{name} must be finite, got {value!r}")


def _require_close(name: str, actual: float, expected: float) -> None:
    """Compare a computed field with its independent equation oracle."""

    if not math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-12):
        raise Step0ValidationError(
            f"{name} mismatch: observed {actual:.17g}, expected {expected:.17g}"
        )


def _require_manifest_equal(
    name: str,
    manifest_value: Any,
    csv_value: int | float | str,
) -> None:
    """Compare one manifest coordinate with the corresponding CSV value."""

    if isinstance(csv_value, float):
        if isinstance(manifest_value, bool) or not isinstance(manifest_value, (int, float)):
            raise Step0ValidationError(f"manifest {name} is not numeric")
        _require_close(f"manifest {name}", float(manifest_value), csv_value)
    elif isinstance(csv_value, int):
        if (
            isinstance(manifest_value, bool)
            or not isinstance(manifest_value, int)
            or manifest_value != csv_value
        ):
            raise Step0ValidationError(
                f"manifest {name}={manifest_value!r} differs from CSV {csv_value!r}"
            )
    elif not isinstance(manifest_value, str) or manifest_value != csv_value:
        raise Step0ValidationError(
            f"manifest {name}={manifest_value!r} differs from CSV {csv_value!r}"
        )


def validate_record(
    record: Step0Record,
    manifest: Mapping[str, Any],
    *,
    expected_seed: int | None = None,
    expected_run: int | None = None,
    minimum_pdr: float | None = None,
) -> None:
    """Validate scientific, numerical, addressing, and pairing invariants.

    Args:
        record: Typed CSV row.
        manifest: Parsed JSON sidecar.
        expected_seed: Optional externally expected global seed.
        expected_run: Optional externally expected ns-3 run number.
        minimum_pdr: Optional pilot quality threshold.  This never changes the
            measured PDR; it only rejects a baseline below the requested level.

    Raises:
        Step0ValidationError: On the first violated invariant.
    """

    if record.protocol != "AODV":
        raise Step0ValidationError("STEP 0 must use protocol=AODV")

    _require_finite("simTime", record.sim_time)
    _require_finite("minSpeed", record.min_speed)
    _require_finite("maxSpeed", record.max_speed)
    _require_finite("pauseTime_s", record.pause_time_s)
    _require_finite("attackerRatio", record.attacker_ratio)
    _require_finite("attackStart", record.attack_start)
    _require_finite("areaSize_m", record.area_size_m)
    _require_finite("maxRange_m", record.max_range_m)
    _require_finite("appStart_s", record.app_start_s)
    _require_finite("appStop_s", record.app_stop_s)
    _require_finite("sourceStartStagger_s", record.source_start_stagger_s)

    # A /24 network can assign at most addresses .1 through .254 to nodes.
    # Rejecting a larger topology here avoids an address-allocation failure that
    # could otherwise be misdiagnosed as an AODV or mobility problem.
    if not 2 <= record.nodes <= 254 or record.sim_time <= 0.0:
        raise Step0ValidationError("nodes and simTime must define a nonempty network run")

    if record.min_speed <= 0.0 or record.max_speed < record.min_speed:
        raise Step0ValidationError("speed bounds must satisfy 0 < minSpeed <= maxSpeed")

    if record.pause_time_s < 0.0 or record.source_start_stagger_s < 0.0:
        raise Step0ValidationError("pause and source-start stagger must be non-negative")

    if record.area_size_m <= 0.0 or record.max_range_m <= 0.0:
        raise Step0ValidationError("areaSize_m and maxRange_m must be positive")

    if record.seed <= 0:
        raise Step0ValidationError("seed must be positive")

    if record.attack_start < 0.0:
        raise Step0ValidationError("attackStart must be non-negative")

    if record.flow_count <= 0 or record.flow_count >= record.nodes:
        raise Step0ValidationError("flowCount must be in [1, nodes-1]")

    if record.app_start_s <= 0.5 or record.app_stop_s <= record.app_start_s:
        raise Step0ValidationError("the application window is invalid")
    _require_close("appStop_s", record.app_stop_s, record.sim_time - 1.0)
    last_source_start_s = (
        record.app_start_s
        + record.source_start_stagger_s * (record.flow_count - 1)
    )
    if last_source_start_s >= record.app_stop_s:
        raise Step0ValidationError("the last UDP source starts after the usable window")

    if not record.data_rate:
        raise Step0ValidationError("dataRate must not be empty")

    # A nonzero ratio in STEP 0 would label an unattacked baseline as attacked.
    if record.attacker_ratio != 0.0 or record.attacker_count != 0:
        raise Step0ValidationError("STEP 0 requires attackerRatio=0 and attackerCount=0")

    if record.app_tx_packets <= 0:
        raise Step0ValidationError("appTxPackets must be observed and strictly positive")

    if not 0 <= record.app_rx_packets <= record.app_tx_packets:
        raise Step0ValidationError("appRxPackets must be in [0, appTxPackets]")

    if record.packet_payload_bytes <= 0:
        raise Step0ValidationError("packetPayloadBytes must be positive")

    # Every application unit in STEP 0 has one fixed useful payload size.  The
    # equality proves that byte counts came from all observed packet traces.
    if record.app_tx_bytes != record.app_tx_packets * record.packet_payload_bytes:
        raise Step0ValidationError("appTxBytes is inconsistent with observed Tx packets")
    if record.app_rx_bytes != record.app_rx_packets * record.packet_payload_bytes:
        raise Step0ValidationError("appRxBytes is inconsistent with observed Rx packets")

    if record.network_rx_bytes < record.app_rx_bytes:
        raise Step0ValidationError("networkRxBytes cannot be smaller than useful Rx bytes")

    if record.evaluation_duration_s <= 0.0:
        raise Step0ValidationError("evaluationDuration_s must be positive")
    _require_close(
        "evaluationDuration_s",
        record.evaluation_duration_s,
        record.app_stop_s - record.app_start_s,
    )

    # Equation (20): PDR uses actual application packet observations.
    expected_pdr = record.app_rx_packets / record.app_tx_packets
    _require_finite("pdr", record.pdr)
    _require_close("pdr (Equation 20)", record.pdr, expected_pdr)
    if not 0.0 <= record.pdr <= 1.0:
        raise Step0ValidationError("pdr must be in [0,1]")

    # Equation (24): loss is the complement of delivery for this single sink.
    expected_plr = 1.0 - expected_pdr
    _require_finite("plr", record.plr)
    _require_close("plr (Equation 24)", record.plr, expected_plr)
    if not 0.0 <= record.plr <= 1.0:
        raise Step0ValidationError("plr must be in [0,1]")

    # Equation (25): network headers belong to throughput but not useful goodput.
    expected_throughput = 8.0 * record.network_rx_bytes / record.evaluation_duration_s
    expected_goodput = 8.0 * record.app_rx_bytes / record.evaluation_duration_s
    _require_finite("throughput_bps", record.throughput_bps)
    _require_finite("goodput_bps", record.goodput_bps)
    _require_close("throughput_bps (Equation 25)", record.throughput_bps, expected_throughput)
    _require_close("goodput_bps (Equation 25)", record.goodput_bps, expected_goodput)

    if record.throughput_bps < record.goodput_bps:
        raise Step0ValidationError("network throughput cannot be below useful goodput")

    # Equation (26) is required only after at least one delivery.  A healthy
    # baseline with zero deliveries is rejected rather than assigned delay zero.
    if record.app_rx_packets == 0:
        raise Step0ValidationError("healthy baseline delivered no application packet")
    _require_finite("meanDelay_s", record.mean_delay_s)
    if record.mean_delay_s < 0.0:
        raise Step0ValidationError("meanDelay_s cannot be negative")

    if record.monitored_application_flows != record.flow_count:
        raise Step0ValidationError("FlowMonitor did not observe every configured UDP flow")

    if record.ipv4_network != "10.1.0.0" or record.ipv4_mask != "255.255.255.0":
        raise Step0ValidationError("pilot addressing must be exactly 10.1.0.0/24")

    if (
        record.wifi_standard != "802.11b"
        or record.wifi_mac != "ns3::AdhocWifiMac"
        or record.propagation_model != "ns3::RangePropagationLossModel"
    ):
        raise Step0ValidationError("unexpected STEP 0 Wi-Fi or propagation configuration")

    expected_stream_bases = (10000, 30000, 20000, 40000)
    observed_stream_bases = (
        record.mobility_stream_base,
        record.wifi_stream_base,
        record.aodv_stream_base,
        record.traffic_stream_base,
    )
    if observed_stream_bases != expected_stream_bases:
        raise Step0ValidationError("unexpected deterministic RNG stream bases")

    # STEP 0 explicitly allocates four RandomWaypoint variables for each node.
    if record.mobility_streams_consumed != 4 * record.nodes:
        raise Step0ValidationError("unexpected RandomWaypoint stream count")
    if min(
        record.wifi_streams_consumed,
        record.aodv_streams_consumed,
        record.traffic_streams_consumed,
    ) <= 0:
        raise Step0ValidationError("all stochastic components must report assigned streams")

    if expected_seed is not None and record.seed != expected_seed:
        raise Step0ValidationError(
            f"seed mismatch: observed {record.seed}, expected {expected_seed}"
        )
    if expected_run is not None and record.run != expected_run:
        raise Step0ValidationError(
            f"run mismatch: observed {record.run}, expected {expected_run}"
        )

    if minimum_pdr is not None:
        if not 0.0 <= minimum_pdr <= 1.0:
            raise Step0ValidationError("minimum_pdr must be in [0,1]")
        if record.pdr < minimum_pdr:
            raise Step0ValidationError(
                f"baseline PDR {record.pdr:.6f} is below requested pilot threshold "
                f"{minimum_pdr:.6f}"
            )

    if manifest.get("schemaVersion") != "mtcaodv-step00-v1":
        raise Step0ValidationError("unexpected manifest schemaVersion")
    if manifest.get("targetNs3Version") != "3.48":
        raise Step0ValidationError("manifest targetNs3Version must be 3.48")
    if manifest.get("protocol") != "AODV" or manifest.get("attackImplemented") is not False:
        raise Step0ValidationError("manifest protocol/attack status is inconsistent with STEP 0")

    configuration = manifest.get("configuration")
    rng = manifest.get("rng")
    metrics = manifest.get("metrics")
    network = manifest.get("network")
    if not all(isinstance(value, dict) for value in (configuration, rng, metrics, network)):
        raise Step0ValidationError(
            "manifest configuration/rng/metrics/network objects are required"
        )

    # These loops compare every coordinate needed to pair later protocol runs.
    # The invariant is that CSV and manifest describe the same single execution.
    configuration_pairs: Sequence[tuple[str, int | float | str]] = (
        ("nodes", record.nodes),
        ("simTime", record.sim_time),
        ("minSpeed", record.min_speed),
        ("maxSpeed", record.max_speed),
        ("attackerRatio", record.attacker_ratio),
        ("attackerCount", record.attacker_count),
        ("attackStart", record.attack_start),
        ("seed", record.seed),
        ("run", record.run),
        ("flowCount", record.flow_count),
        ("packetPayloadBytes", record.packet_payload_bytes),
        ("dataRate", record.data_rate),
        ("pauseTime", record.pause_time_s),
        ("areaSizeMeters", record.area_size_m),
        ("maximumRangeMeters", record.max_range_m),
        ("applicationStartSeconds", record.app_start_s),
        ("applicationStopSeconds", record.app_stop_s),
        ("sourceStartStaggerSeconds", record.source_start_stagger_s),
    )
    for field_name, csv_value in configuration_pairs:
        _require_manifest_equal(field_name, configuration.get(field_name), csv_value)

    metric_pairs: Sequence[tuple[str, int | float]] = (
        ("appTxPackets", record.app_tx_packets),
        ("appRxPackets", record.app_rx_packets),
        ("appTxBytes", record.app_tx_bytes),
        ("appRxBytes", record.app_rx_bytes),
        ("networkRxBytes", record.network_rx_bytes),
        ("pdr", record.pdr),
        ("plr", record.plr),
        ("throughput_bps", record.throughput_bps),
        ("goodput_bps", record.goodput_bps),
        ("meanDelay_s", record.mean_delay_s),
        ("monitoredApplicationFlows", record.monitored_application_flows),
    )
    for field_name, csv_value in metric_pairs:
        _require_manifest_equal(field_name, metrics.get(field_name), csv_value)

    if (
        network.get("ipv4Network") != record.ipv4_network
        or network.get("ipv4Mask") != record.ipv4_mask
    ):
        raise Step0ValidationError("manifest and CSV network coordinates differ")
    if network.get("wifiMac") != "ns3::AdhocWifiMac":
        raise Step0ValidationError("manifest must identify ns3::AdhocWifiMac")
    if network.get("wifiStandard") != record.wifi_standard:
        raise Step0ValidationError("manifest and CSV Wi-Fi standard differ")
    if network.get("wifiMac") != record.wifi_mac:
        raise Step0ValidationError("manifest and CSV Wi-Fi MAC differ")
    if network.get("propagationModel") != record.propagation_model:
        raise Step0ValidationError("manifest and CSV propagation models differ")

    rng_pairs: Sequence[tuple[str, int]] = (
        ("seed", record.seed),
        ("run", record.run),
        ("mobilityStreamBase", record.mobility_stream_base),
        ("wifiStreamBase", record.wifi_stream_base),
        ("aodvStreamBase", record.aodv_stream_base),
        ("trafficStreamBase", record.traffic_stream_base),
        ("mobilityStreamsConsumed", record.mobility_streams_consumed),
        ("wifiStreamsConsumed", record.wifi_streams_consumed),
        ("aodvStreamsConsumed", record.aodv_streams_consumed),
        ("trafficStreamsConsumed", record.traffic_streams_consumed),
    )
    for field_name, csv_value in rng_pairs:
        _require_manifest_equal(field_name, rng.get(field_name), csv_value)


def validate_artifacts(
    csv_path: Path,
    manifest_path: Path,
    schema_path: Path,
    *,
    expected_seed: int | None = None,
    expected_run: int | None = None,
    minimum_pdr: float | None = None,
) -> Step0Record:
    """Load and validate the three STEP 0 artifacts."""

    schema = _load_json(schema_path)
    header, row = _read_single_csv_row(csv_path)

    required_prefix = schema.get("requiredPrefix")
    required_diagnostics = schema.get("requiredDiagnostics")
    if not isinstance(required_prefix, list) or not isinstance(required_diagnostics, list):
        raise Step0ValidationError("schema column lists are missing")

    # The stable prefix must remain first and in order.  Later steps may append
    # columns only after this prefix, so positional drift is a blocking error.
    if header[: len(required_prefix)] != required_prefix:
        raise Step0ValidationError("CSV required prefix is missing, reordered, or renamed")

    missing_diagnostics = [name for name in required_diagnostics if name not in header]
    if missing_diagnostics:
        raise Step0ValidationError(
            "CSV is missing diagnostic columns: " + ", ".join(missing_diagnostics)
        )

    record = Step0Record.from_csv_row(row)
    manifest = _load_json(manifest_path)
    validate_record(
        record,
        manifest,
        expected_seed=expected_seed,
        expected_run=expected_run,
        minimum_pdr=minimum_pdr,
    )
    return record


def validate_reproducible_pair(
    first_record: Step0Record,
    first_manifest_path: Path,
    second_record: Step0Record,
    second_manifest_path: Path,
) -> None:
    """Require two same-coordinate executions to be bitwise-equivalent in data.

    The filenames may differ, but filenames are not embedded in either row or
    manifest.  All configuration, stream, counter, and metric fields must
    therefore compare exactly for a deterministic replay.
    """

    # Report the first differing typed field so a stream or configuration drift
    # can be diagnosed without comparing long raw lines manually.
    for field in fields(Step0Record):
        first_value = getattr(first_record, field.name)
        second_value = getattr(second_record, field.name)
        if first_value != second_value:
            raise Step0ValidationError(
                f"replay mismatch in {field.name}: {first_value!r} != {second_value!r}"
            )

    first_manifest = _load_json(first_manifest_path)
    second_manifest = _load_json(second_manifest_path)
    if first_manifest != second_manifest:
        raise Step0ValidationError("replay manifests differ despite equal typed CSV rows")


def _parse_arguments(argv: Sequence[str]) -> argparse.Namespace:
    """Parse command-line arguments without performing validation work."""

    default_schema = Path(__file__).resolve().parent / "schemas" / "step00_results_schema.json"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", required=True, type=Path, help="CSV produced by mtcaodv-pilot")
    parser.add_argument(
        "--manifest",
        required=True,
        type=Path,
        help="JSON manifest produced by the same mtcaodv-pilot run",
    )
    parser.add_argument(
        "--schema",
        type=Path,
        default=default_schema,
        help="STEP 0 schema JSON (defaults to the packaged schema)",
    )
    parser.add_argument("--expected-seed", type=int, default=None)
    parser.add_argument("--expected-run", type=int, default=None)
    parser.add_argument(
        "--minimum-pdr",
        type=float,
        default=None,
        help="Optional pilot-quality threshold; omitted by default",
    )
    parser.add_argument(
        "--replay-csv",
        type=Path,
        default=None,
        help="Optional CSV from a second execution with identical coordinates",
    )
    parser.add_argument(
        "--replay-manifest",
        type=Path,
        default=None,
        help="Manifest paired with --replay-csv",
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    """Validate one run and return a shell-compatible status code."""

    arguments = _parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        # Supplying only one replay artifact would make the second execution
        # impossible to validate as a complete run.
        if (arguments.replay_csv is None) != (arguments.replay_manifest is None):
            raise Step0ValidationError(
                "--replay-csv and --replay-manifest must be supplied together"
            )

        record = validate_artifacts(
            arguments.csv,
            arguments.manifest,
            arguments.schema,
            expected_seed=arguments.expected_seed,
            expected_run=arguments.expected_run,
            minimum_pdr=arguments.minimum_pdr,
        )

        replay_record: Step0Record | None = None
        if arguments.replay_csv is not None and arguments.replay_manifest is not None:
            replay_record = validate_artifacts(
                arguments.replay_csv,
                arguments.replay_manifest,
                arguments.schema,
                expected_seed=arguments.expected_seed,
                expected_run=arguments.expected_run,
                minimum_pdr=arguments.minimum_pdr,
            )
            validate_reproducible_pair(
                record,
                arguments.manifest,
                replay_record,
                arguments.replay_manifest,
            )
    except Step0ValidationError as error:
        print(f"STEP 0 validation FAIL: {error}", file=sys.stderr)
        return 1

    replay_suffix = " with deterministic replay" if replay_record is not None else ""
    print(
        "STEP 0 validation PASS: "
        f"{arguments.csv} (Tx={record.app_tx_packets}, Rx={record.app_rx_packets}, "
        f"PDR={record.pdr:.6f}){replay_suffix}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
