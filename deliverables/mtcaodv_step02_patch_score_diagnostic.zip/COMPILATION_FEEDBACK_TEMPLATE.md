# MTC-AODV STEP 0 — éléments à retourner

Ne modifiez pas et ne résumez pas les sorties. Après exécution, renvoyez :

1. `mtcaodv-step00-configure.log` ;
2. `mtcaodv-step00-build.log` ;
3. `mtcaodv-step00-metrics-test.log` ;
4. `mtcaodv-step00-attack-manager-regression.log` ;
5. `mtcaodv-step00-blackhole-policy-regression.log` ;
6. `mtcaodv-step00-python-tests.log` ;
7. `mtcaodv-step00-pilot.log` ;
8. `mtcaodv-step00-pilot-replay.log` ;
9. `mtcaodv-step00-validation.log` ;
10. `experiments/results/step00-seed12345-run1.csv` ;
11. `experiments/results/step00-seed12345-run1.json` ;
12. `experiments/results/step00-seed12345-run1-replay.csv` ;
13. `experiments/results/step00-seed12345-run1-replay.json` ;
14. en cas d’échec, le premier message d’erreur complet et non tronqué.

Le XML FlowMonitor peut être ajouté si le PDR est faible ou si le validateur
signale un désaccord sur `networkRxBytes`.
