/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * Deterministic unit tests for the STEP 0 baseline metric equations.
 */

#include "ns3/baseline-metrics.h"
#include "ns3/test.h"

#include <cmath>

namespace ns3
{
namespace mtcaodv
{

/** Numerical tolerance used only for closed-form test oracles. */
constexpr double METRIC_TEST_TOLERANCE = 1e-12;

/**
 * @brief Verifies Equations (20), (24), (25), and (26) against a manual oracle.
 */
class BaselineMetricFormulaTestCase : public TestCase
{
  public:
    /** @brief Construct the closed-form metric test. */
    BaselineMetricFormulaTestCase()
        : TestCase("STEP 0 baseline metrics match manually calculated values")
    {
    }

  private:
    /** @brief Execute two delivered packets with known payloads and delays. */
    void DoRun() override
    {
        BaselineMetricsCollector collector(Seconds(10.0));

        // Two accepted transmissions establish the observed denominator rather
        // than assuming that a configured source necessarily sent both packets.
        collector.RecordSuccessfulTransmission(512);
        collector.RecordSuccessfulTransmission(512);

        collector.RecordSuccessfulReception(512, Seconds(1.0), Seconds(1.1));
        collector.RecordSuccessfulReception(512, Seconds(2.0), Seconds(2.3));

        // The network-byte oracle includes 48 bytes of protocol/instrumentation
        // overhead per packet solely to test the throughput/goodput separation.
        collector.SetNetworkReceivedBytes(1120);
        const BaselineMetricSummary summary = collector.BuildSummary();

        NS_TEST_EXPECT_MSG_EQ(summary.appTxPackets, 2, "Unexpected Tx packet count");
        NS_TEST_EXPECT_MSG_EQ(summary.appRxPackets, 2, "Unexpected Rx packet count");
        NS_TEST_EXPECT_MSG_EQ(summary.appTxBytes, 1024, "Unexpected Tx payload bytes");
        NS_TEST_EXPECT_MSG_EQ(summary.appRxBytes, 1024, "Unexpected Rx payload bytes");
        NS_TEST_EXPECT_MSG_EQ(summary.networkRxBytes, 1120, "Unexpected network bytes");
        NS_TEST_EXPECT_MSG_EQ_TOL(summary.pdr, 1.0, METRIC_TEST_TOLERANCE, "Eq. (20)");
        NS_TEST_EXPECT_MSG_EQ_TOL(summary.plr, 0.0, METRIC_TEST_TOLERANCE, "Eq. (24)");
        NS_TEST_EXPECT_MSG_EQ_TOL(summary.throughputBitsPerSecond,
                                  896.0,
                                  METRIC_TEST_TOLERANCE,
                                  "Eq. (25) throughput");
        NS_TEST_EXPECT_MSG_EQ_TOL(summary.goodputBitsPerSecond,
                                  819.2,
                                  METRIC_TEST_TOLERANCE,
                                  "Eq. (25) goodput");
        NS_TEST_EXPECT_MSG_EQ_TOL(summary.meanDelaySeconds,
                                  0.2,
                                  METRIC_TEST_TOLERANCE,
                                  "Eq. (26)");
    }
};

/**
 * @brief Verifies partial loss and undefined zero-denominator behavior.
 */
class BaselineMetricEdgeCaseTestCase : public TestCase
{
  public:
    /** @brief Construct the edge-case test. */
    BaselineMetricEdgeCaseTestCase()
        : TestCase("STEP 0 metrics preserve loss and undefined values")
    {
    }

  private:
    /** @brief Exercise a 50% loss case and a run with no transmissions. */
    void DoRun() override
    {
        BaselineMetricsCollector partialLoss(Seconds(10.0));
        partialLoss.RecordSuccessfulTransmission(512);
        partialLoss.RecordSuccessfulTransmission(512);
        partialLoss.RecordSuccessfulReception(512, Seconds(1.0), Seconds(1.25));
        partialLoss.SetNetworkReceivedBytes(560);

        const BaselineMetricSummary lossSummary = partialLoss.BuildSummary();
        NS_TEST_EXPECT_MSG_EQ_TOL(lossSummary.pdr,
                                  0.5,
                                  METRIC_TEST_TOLERANCE,
                                  "PDR must use observed counts");
        NS_TEST_EXPECT_MSG_EQ_TOL(lossSummary.plr,
                                  0.5,
                                  METRIC_TEST_TOLERANCE,
                                  "PLR must equal one minus PDR");
        NS_TEST_EXPECT_MSG_EQ_TOL(lossSummary.meanDelaySeconds,
                                  0.25,
                                  METRIC_TEST_TOLERANCE,
                                  "Mean delay must use delivered packets only");

        BaselineMetricsCollector noTraffic(Seconds(10.0));
        noTraffic.SetNetworkReceivedBytes(0);
        const BaselineMetricSummary emptySummary = noTraffic.BuildSummary();

        // Undefined metrics must remain NaN.  Returning zero here would conceal
        // a failed traffic generator and violate the fail-closed requirement.
        NS_TEST_EXPECT_MSG_EQ(std::isnan(emptySummary.pdr), true, "PDR must be NaN");
        NS_TEST_EXPECT_MSG_EQ(std::isnan(emptySummary.plr), true, "PLR must be NaN");
        NS_TEST_EXPECT_MSG_EQ(std::isnan(emptySummary.meanDelaySeconds),
                              true,
                              "Mean delay must be NaN");
    }
};

/**
 * @brief Registers all deterministic STEP 0 metric tests with ns-3.
 */
class BaselineMetricsTestSuite : public TestSuite
{
  public:
    /** @brief Add quick unit tests to the suite. */
    BaselineMetricsTestSuite()
        : TestSuite("mtcaodv-step00-baseline-metrics", Type::UNIT)
    {
        AddTestCase(new BaselineMetricFormulaTestCase(), TestCase::Duration::QUICK);
        AddTestCase(new BaselineMetricEdgeCaseTestCase(), TestCase::Duration::QUICK);
    }
};

/** Static registration required by the ns-3 test runner. */
static BaselineMetricsTestSuite g_baselineMetricsTestSuite;

} // namespace mtcaodv
} // namespace ns3
