/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * This file is part of the MTC-AODV research prototype.
 *
 * STEP 1 integration test (spec test T-08, "chaîne causale Gate 1B").
 *
 * Purpose: prove that the forked ns3::mtcaodv routing protocol
 *   (a) behaves like healthy AODV when no attack policy is attached, and
 *   (b) when a BlackholeBehavior is attached to a relay, actually forges RREPs
 *       (Algorithm A2.3 / Eq. 23) and silently drops transit data
 *       (Algorithm A2.4), reducing end-to-end delivery.
 *
 * The topology is the deterministic "diamond" fixture of Section 16.3:
 *
 *        S(0,0) ---- A(40,0)          side  = 40 m
 *          |            |             range = 45 m  -> sides connected
 *        B(0,40) --- D(40,40)         diagonal = 40*sqrt(2) ~ 56.57 m > 45 m
 *
 * S=node0 (source), A=node1, B=node2 relays, D=node3 (destination).  S cannot
 * reach D directly, so a relay must forward.  When node A is a Blackhole it
 * forges a 1-hop, very-fresh RREP that out-competes the honest 2-hop route via
 * B, attracts the data, and drops it.
 */

#include "ns3/applications-module.h"
#include "ns3/blackhole-behavior.h"
#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/ipv4-address-generator.h"
#include "ns3/mobility-module.h"
#include "ns3/mtc-aodv-helper.h"
#include "ns3/mtc-aodv-routing-protocol.h"
#include "ns3/network-module.h"
#include "ns3/test.h"
#include "ns3/wifi-module.h"

#include <cstdint>

namespace ns3
{
namespace mtcaodv
{

/// Observable outcome of one diamond-fixture realization.
struct DiamondOutcome
{
    uint64_t deliveredBytes{0};  ///< Bytes accepted by the sink at node D.
    uint32_t forgedRrepCount{0}; ///< Forged RREPs emitted by the attacker node.
    uint32_t blackholeDrops{0};  ///< Transit packets silently dropped by attacker.
};

/**
 * @brief Registers the STEP 1 fork integration tests with ns-3.
 */
class MtcAodvRoutingProtocolTestCase : public TestCase
{
  public:
    /** @brief Construct the diamond causal-chain integration test. */
    MtcAodvRoutingProtocolTestCase()
        : TestCase("MTC-AODV fork forges RREPs and drops transit data under attack")
    {
    }

  private:
    /**
     * @brief Run the diamond fixture once.
     * @param attackerNodeId Node to make a Blackhole, or -1 for an all-honest run.
     * @return Delivered bytes plus the attacker's forged/drop counters.
     *
     * RNG streams are fixed (Wi-Fi 83000+, routing 84000+) so the outcome is
     * deterministic and independent between the two comparison runs.
     */
    DiamondOutcome RunDiamond(int32_t attackerNodeId)
    {
        // Deterministic scenario coordinates.
        RngSeedManager::SetSeed(12345);
        RngSeedManager::SetRun(1);
        RngSeedManager::ResetNextStreamIndex();
        Ipv4AddressGenerator::Reset();

        NodeContainer nodes;
        nodes.Create(4);

        // Fixed diamond positions.
        Ptr<ListPositionAllocator> positions = CreateObject<ListPositionAllocator>();
        positions->Add(Vector(0.0, 0.0, 0.0));   // 0 = S
        positions->Add(Vector(40.0, 0.0, 0.0));  // 1 = A
        positions->Add(Vector(0.0, 40.0, 0.0));  // 2 = B
        positions->Add(Vector(40.0, 40.0, 0.0)); // 3 = D
        MobilityHelper mobility;
        mobility.SetPositionAllocator(positions);
        mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
        mobility.Install(nodes);

        // Range-limited 802.11b ad hoc radio: 45 m connects the sides only.
        YansWifiChannelHelper channel;
        channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
        channel.AddPropagationLoss("ns3::RangePropagationLossModel",
                                   "MaxRange",
                                   DoubleValue(45.0));
        YansWifiPhyHelper phy;
        phy.SetChannel(channel.Create());
        WifiHelper wifi;
        wifi.SetStandard(WIFI_STANDARD_80211b);
        wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                     "DataMode",
                                     StringValue("DsssRate1Mbps"),
                                     "ControlMode",
                                     StringValue("DsssRate1Mbps"));
        WifiMacHelper mac;
        mac.SetType("ns3::AdhocWifiMac");
        NetDeviceContainer devices = wifi.Install(phy, mac, nodes);
        WifiHelper::AssignStreams(devices, 83000);

        // Forked MTC-AODV on every node.
        MtcAodvHelper mtcAodv;
        InternetStackHelper internet;
        internet.SetRoutingHelper(mtcAodv);
        internet.Install(nodes);
        mtcAodv.AssignStreams(nodes, 84000);

        Ipv4AddressHelper ipv4;
        ipv4.SetBase("10.1.0.0", "255.255.255.0");
        Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);

        // Optionally attach a Blackhole to the requested relay.  Activation at
        // 1 s leaves a short honest warm-up, matching the Gate 1B profile.
        if (attackerNodeId >= 0)
        {
            Ptr<BlackholeBehavior> behavior = CreateObject<BlackholeBehavior>();
            behavior->SetAttribute("AttackStartTime", TimeValue(Seconds(1.0)));
            mtcAodv.InstallAttackBehavior(nodes.Get(attackerNodeId), behavior);
        }

        // UDP flow S(0) -> D(3) on port 9100.
        const uint16_t port = 9100;
        Ipv4Address destinationAddress = interfaces.GetAddress(3);
        PacketSinkHelper sinkHelper(
            "ns3::UdpSocketFactory",
            InetSocketAddress(Ipv4Address::GetAny(), port));
        ApplicationContainer sinkApps = sinkHelper.Install(nodes.Get(3));
        sinkApps.Start(Seconds(0.5));
        sinkApps.Stop(Seconds(10.0));

        OnOffHelper source("ns3::UdpSocketFactory",
                           InetSocketAddress(destinationAddress, port));
        source.SetAttribute("DataRate", DataRateValue(DataRate("16kbps")));
        source.SetAttribute("PacketSize", UintegerValue(512));
        source.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1e9]"));
        source.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0.0]"));
        ApplicationContainer sourceApps = source.Install(nodes.Get(0));
        sourceApps.Start(Seconds(3.0));
        sourceApps.Stop(Seconds(9.0));

        Simulator::Stop(Seconds(10.0));
        Simulator::Run();

        DiamondOutcome outcome;
        Ptr<PacketSink> sink = DynamicCast<PacketSink>(sinkApps.Get(0));
        outcome.deliveredBytes = sink ? sink->GetTotalRx() : 0;

        if (attackerNodeId >= 0)
        {
            Ptr<Ipv4> ipv4Stack = nodes.Get(attackerNodeId)->GetObject<Ipv4>();
            Ptr<RoutingProtocol> rp =
                DynamicCast<RoutingProtocol>(ipv4Stack->GetRoutingProtocol());
            if (rp)
            {
                outcome.forgedRrepCount = rp->GetForgedReplyCount();
                outcome.blackholeDrops = rp->GetBlackholeTransitDropCount();
            }
        }

        Simulator::Destroy();
        return outcome;
    }

    /** @brief Compare an honest run against an attacked run. */
    void DoRun() override
    {
        // (1) All-honest fork must deliver useful data over the 2-hop relay.
        const DiamondOutcome honest = RunDiamond(/*attackerNodeId=*/-1);
        NS_TEST_ASSERT_MSG_GT(honest.deliveredBytes,
                              0u,
                              "Honest fork failed to deliver any data over the diamond");
        NS_TEST_EXPECT_MSG_EQ(honest.forgedRrepCount,
                              0u,
                              "An honest run must never forge an RREP");
        NS_TEST_EXPECT_MSG_EQ(honest.blackholeDrops,
                              0u,
                              "An honest run must never perform a Blackhole drop");

        // (2) Blackhole on relay A must forge, drop, and lower delivery.
        const DiamondOutcome attacked = RunDiamond(/*attackerNodeId=*/1);
        NS_TEST_ASSERT_MSG_GT(attacked.forgedRrepCount,
                              0u,
                              "Attacker did not emit any forged RREP (Algorithm A2.3)");
        NS_TEST_ASSERT_MSG_GT(attacked.blackholeDrops,
                              0u,
                              "Attacker did not drop any transit data (Algorithm A2.4)");
        NS_TEST_EXPECT_MSG_LT(attacked.deliveredBytes,
                              honest.deliveredBytes,
                              "Blackhole attack did not reduce end-to-end delivery");
    }
};

/**
 * @brief STEP 1 fork test suite.
 */
class MtcAodvRoutingProtocolTestSuite : public TestSuite
{
  public:
    /** @brief Register the diamond causal-chain integration test. */
    MtcAodvRoutingProtocolTestSuite()
        : TestSuite("mtcaodv-routing-protocol", Type::SYSTEM)
    {
        // EXTENSIVE duration: this case builds a small radio scenario twice.
        AddTestCase(new MtcAodvRoutingProtocolTestCase, TestCase::Duration::EXTENSIVE);
    }
};

/** Static registration discovered automatically by the ns-3 test runner. */
static MtcAodvRoutingProtocolTestSuite g_mtcAodvRoutingProtocolTestSuite;

} // namespace mtcaodv
} // namespace ns3
