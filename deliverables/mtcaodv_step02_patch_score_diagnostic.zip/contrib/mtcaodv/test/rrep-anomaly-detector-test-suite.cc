/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * This file is part of the MTC-AODV research prototype.
 *
 * STEP 2 unit tests (spec tests T-09, T-10) for the RREP anomaly screening
 * (Eq. (3)-(5)) and the bounded candidate buffer.  Expected A_RREP values are
 * the numerically-verified oracle of the specification equations (a Python
 * reference implementation computed the same values before this test was
 * written), asserted here to a tolerance.
 */

#include "ns3/rrep-anomaly-detector.h"
#include "ns3/rrep-candidate-buffer.h"
#include "ns3/test.h"

#include <cstdint>
#include <vector>

namespace ns3
{
namespace mtcaodv
{

namespace
{
/// Default (pilot) screening parameters shared by the fixtures.
RrepAnomalyParameters
DefaultParameters()
{
    RrepAnomalyParameters p; // w_s=1, w_h=1, w_t=0.5, b_R=2, eps=1e-6, n_R^min=2
    return p;
}
} // namespace

/**
 * @brief T-09/T-13: median, MAD and score building blocks are correct and bounded.
 */
class RrepScoreMathTestCase : public TestCase
{
  public:
    RrepScoreMathTestCase()
        : TestCase("RREP screening median/MAD and Eq. (3)-(5) score are correct")
    {
    }

  private:
    void DoRun() override
    {
        // Median: odd and even counts.
        NS_TEST_EXPECT_MSG_EQ_TOL(RrepAnomalyDetector::Median({3.0, 1.0, 2.0}), 2.0, 1e-12,
                                  "median of odd-length sample");
        NS_TEST_EXPECT_MSG_EQ_TOL(RrepAnomalyDetector::Median({1.0, 2.0, 3.0, 4.0}), 2.5, 1e-12,
                                  "median of even-length sample");
        // MAD of {1,2,4}: median 2, deviations {1,0,2} -> median 1.
        NS_TEST_EXPECT_MSG_EQ_TOL(RrepAnomalyDetector::MedianAbsoluteDeviation({1.0, 2.0, 4.0}),
                                  1.0, 1e-12, "MAD of {1,2,4}");

        RrepAnomalyDetector detector(DefaultParameters());

        // Fixture A (all-normal): seqs {100,101,102}, hops {3,3,4}, t {1.00,1.02,1.05}.
        // Oracle A_RREP: idx0=0.182422, idx1=0.119203, idx2=0.268941 (all < theta_R).
        const std::vector<RrepCandidate> normal = {
            {100, 3, 1.00}, {101, 3, 1.02}, {102, 4, 1.05}};
        NS_TEST_EXPECT_MSG_EQ_TOL(detector.Score(normal, 0).anomalyScore, 0.182426, 1e-5,
                                  "normal idx0 score");
        NS_TEST_EXPECT_MSG_EQ_TOL(detector.Score(normal, 1).anomalyScore, 0.119203, 1e-5,
                                  "normal idx1 score");
        NS_TEST_EXPECT_MSG_EQ_TOL(detector.Score(normal, 2).anomalyScore, 0.182426, 1e-5,
                                  "normal idx2 score");
        for (std::size_t i = 0; i < normal.size(); ++i)
        {
            NS_TEST_EXPECT_MSG_EQ(detector.Score(normal, i).anomalyScore < 0.5, true,
                                  "no normal reply should reach the WATCH threshold");
        }
    }
};

/**
 * @brief T-09: a forged (fresh + low-hop + early) RREP scores ~1 and is flagged.
 */
class RrepForgedReplyTestCase : public TestCase
{
  public:
    RrepForgedReplyTestCase()
        : TestCase("A forged fresh/low-hop/early RREP scores near 1")
    {
    }

  private:
    void DoRun() override
    {
        RrepAnomalyDetector detector(DefaultParameters());
        // Fixture B: forged idx0 (seq 1101=101+1000, hop 1, earliest) among 2 honest.
        const std::vector<RrepCandidate> withForged = {
            {1101, 1, 1.00}, {100, 3, 1.05}, {101, 4, 1.08}};
        const RrepAnomalyResult forged = detector.Score(withForged, 0);
        NS_TEST_ASSERT_MSG_EQ(forged.available, true, "score must be available with 3 replies");
        NS_TEST_EXPECT_MSG_EQ_TOL(forged.anomalyScore, 1.0, 1e-6, "forged reply scores ~1");
        NS_TEST_EXPECT_MSG_EQ(forged.anomalyScore >= 0.5, true, "forged reply is above theta_R");
        // Honest replies stay low.
        NS_TEST_EXPECT_MSG_EQ(detector.Score(withForged, 1).anomalyScore < 0.5, true,
                              "honest reply 1 stays below theta_R");
        NS_TEST_EXPECT_MSG_EQ(detector.Score(withForged, 2).anomalyScore < 0.5, true,
                              "honest reply 2 stays below theta_R");
    }
};

/**
 * @brief T-10: wrap-around correctness — modular AODV order, not naive subtraction.
 */
class RrepWrapAroundTestCase : public TestCase
{
  public:
    RrepWrapAroundTestCase()
        : TestCase("Sequence anomaly uses modular AODV order across the 2^32 wrap")
    {
    }

  private:
    void DoRun() override
    {
        // Signed-delta helper: (2^32 - 5) as a difference means -5, not ~4.29e9.
        NS_TEST_EXPECT_MSG_EQ(RrepAnomalyDetector::SignedSequenceDelta(0xFFFFFFFBu), -5,
                              "0xFFFFFFFB must read as -5 in AODV order");
        NS_TEST_EXPECT_MSG_EQ(RrepAnomalyDetector::SignedSequenceDelta(1000u), 1000,
                              "small positive difference reads as +1000");

        RrepAnomalyDetector detector(DefaultParameters());
        // Fixture C: honest seqs near 2^32; forged = (max-5 + 1000) mod 2^32 = 995,
        // which numerically looks TINY but is 1000 fresher in AODV order.
        const uint32_t nearMaxA = 0xFFFFFFFBu; // 2^32 - 5
        const uint32_t nearMaxB = 0xFFFFFFFAu; // 2^32 - 6
        const uint32_t forgedSeq = static_cast<uint32_t>(nearMaxA + 1000u); // wraps to 995
        NS_TEST_ASSERT_MSG_EQ(forgedSeq, 995u, "forged sequence wraps to 995");
        const std::vector<RrepCandidate> wrap = {
            {nearMaxA, 3, 1.05}, {nearMaxB, 4, 1.08}, {forgedSeq, 1, 1.00}};
        const RrepAnomalyResult forged = detector.Score(wrap, 2);
        NS_TEST_EXPECT_MSG_EQ_TOL(forged.anomalyScore, 1.0, 1e-6,
                                  "wrapped forged reply is still flagged (T-10)");
        // The honest replies, despite huge numeric sequence values, are not flagged.
        NS_TEST_EXPECT_MSG_EQ(detector.Score(wrap, 0).anomalyScore < 0.5, true,
                              "near-max honest reply is not a false positive");
    }
};

/**
 * @brief D-07/C-16: fewer than n_R^min replies -> no comparative score.
 */
class RrepInsufficientRepliesTestCase : public TestCase
{
  public:
    RrepInsufficientRepliesTestCase()
        : TestCase("Below n_R^min the score is unavailable, not zero")
    {
    }

  private:
    void DoRun() override
    {
        RrepAnomalyDetector detector(DefaultParameters());
        const std::vector<RrepCandidate> single = {{5000, 1, 1.0}};
        NS_TEST_EXPECT_MSG_EQ(detector.Score(single, 0).available, false,
                              "a lone RREP yields NO_COMPARATIVE_SCORE, not normality");
        // n_R^min is now 3: two candidates are still not a usable comparison,
        // because their MAD degenerates as soon as they agree.
        const std::vector<RrepCandidate> pair = {{5000, 1, 1.0}, {5001, 3, 1.1}};
        NS_TEST_EXPECT_MSG_EQ(detector.Score(pair, 0).available, false,
                              "two RREPs are below n_R^min=3, so no comparative score");
    }
};

/**
 * @brief Regression (STEP 2 calibration fix): MAD = 0 must NOT flag an honest reply.
 *
 * Two honest replies advertising the same hop count give MAD(hop) = 0.  With the
 * first pilot value epsilon = 1e-6 and no dispersion floor, a one-hop difference
 * produced z_h = 1e6 and saturated the score to 1.0, which is what drove the
 * measured false-alarm rate to 0.96 (attack) / 1.00 (no attack).  With a floor of
 * one hop the same reply scores well below the WATCH threshold, while a genuinely
 * forged reply still scores ~1.
 */
class RrepZeroDispersionTestCase : public TestCase
{
  public:
    RrepZeroDispersionTestCase()
        : TestCase("A zero MAD must not turn an honest reply into a false WATCH")
    {
    }

  private:
    void DoRun() override
    {
        RrepAnomalyDetector detector(DefaultParameters());
        // hops {2,3,3} -> median 3, deviations {1,0,0} -> MAD(hop) = 0 exactly.
        const std::vector<RrepCandidate> degenerate = {
            {100, 2, 1.00}, {101, 3, 1.02}, {102, 3, 1.05}};
        const RrepAnomalyResult honest = detector.Score(degenerate, 0);
        NS_TEST_ASSERT_MSG_EQ(honest.available, true, "score must be available");
        // Oracle with the floors: z_h = 1/1 = 1, z_t = 1, z_s = 0 -> A = 0.377541.
        NS_TEST_EXPECT_MSG_EQ_TOL(honest.anomalyScore, 0.377541, 1e-5,
                                  "honest reply under MAD=0 must score ~0.378, not ~1");
        NS_TEST_EXPECT_MSG_EQ(honest.anomalyScore < 0.5, true,
                              "MAD=0 must not raise WATCH on an honest reply");
        // Each anomaly stays bounded by the configured clip.
        NS_TEST_EXPECT_MSG_EQ(honest.hopAnomaly <= DefaultParameters().maximumAnomaly, true,
                              "hop anomaly must respect the clip");
    }
};

/**
 * @brief Bounded buffer respects the window and both capacity bounds.
 */
class RrepBufferBoundsTestCase : public TestCase
{
  public:
    RrepBufferBoundsTestCase()
        : TestCase("RREP candidate buffer enforces window and capacity bounds")
    {
    }

  private:
    void DoRun() override
    {
        // window 1.0 s, 3 candidates/destination, 2 destinations.
        RrepCandidateBuffer buffer(1.0, 3, 2);
        const uint32_t dstA = 0x0A010001; // 10.1.0.1
        const uint32_t dstB = 0x0A010002;
        const uint32_t dstC = 0x0A010003;

        // Capacity per destination: insert 5, keep the newest 3.
        for (int i = 0; i < 5; ++i)
        {
            RrepCandidate c;
            c.sequenceNumber = 100 + i;
            c.hopCount = 3;
            c.arrivalTimeSeconds = 10.0 + 0.01 * i;
            buffer.Insert(dstA, 0x0A0100FF, c, c.arrivalTimeSeconds);
        }
        NS_TEST_EXPECT_MSG_EQ(buffer.GetCandidates(dstA).size(), std::size_t(3),
                              "per-destination capacity bound (3) must hold");

        // Window: a much later insert purges the older-than-window entries.
        RrepCandidate late;
        late.sequenceNumber = 999;
        late.hopCount = 3;
        late.arrivalTimeSeconds = 100.0; // >> window past the previous inserts
        buffer.Insert(dstA, 0x0A0100FF, late, 100.0);
        NS_TEST_EXPECT_MSG_EQ(buffer.GetCandidates(dstA).size(), std::size_t(1),
                              "stale entries beyond W_R are purged");

        // Destination-count bound: tracking a 3rd destination evicts the LRU one.
        RrepCandidate c;
        c.sequenceNumber = 1;
        c.hopCount = 3;
        c.arrivalTimeSeconds = 101.0;
        buffer.Insert(dstB, 0x0A0100FE, c, 101.0);
        c.arrivalTimeSeconds = 102.0;
        buffer.Insert(dstC, 0x0A0100FD, c, 102.0);
        NS_TEST_EXPECT_MSG_EQ(buffer.TrackedDestinationCount(), std::size_t(2),
                              "destination-count bound (2) must hold");
    }
};

/**
 * @brief STEP 2 detector/buffer test suite.
 */
class RrepAnomalyDetectorTestSuite : public TestSuite
{
  public:
    RrepAnomalyDetectorTestSuite()
        : TestSuite("mtcaodv-rrep-anomaly-detector", Type::UNIT)
    {
        AddTestCase(new RrepScoreMathTestCase, TestCase::Duration::QUICK);
        AddTestCase(new RrepForgedReplyTestCase, TestCase::Duration::QUICK);
        AddTestCase(new RrepWrapAroundTestCase, TestCase::Duration::QUICK);
        AddTestCase(new RrepInsufficientRepliesTestCase, TestCase::Duration::QUICK);
        AddTestCase(new RrepZeroDispersionTestCase, TestCase::Duration::QUICK);
        AddTestCase(new RrepBufferBoundsTestCase, TestCase::Duration::QUICK);
    }
};

/** Static registration discovered by the ns-3 test runner. */
static RrepAnomalyDetectorTestSuite g_rrepAnomalyDetectorTestSuite;

} // namespace mtcaodv
} // namespace ns3
