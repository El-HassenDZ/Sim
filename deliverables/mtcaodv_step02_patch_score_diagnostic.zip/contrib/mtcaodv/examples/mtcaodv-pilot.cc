/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * STEP 0: reproducible, mobile, healthy stock-AODV baseline for MTC-AODV.
 */

#include "ns3/aodv-module.h"
#include "ns3/applications-module.h"
#include "ns3/baseline-metrics.h"
#include "ns3/core-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/internet-module.h"
#include "ns3/ipv4-address-generator.h"
#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/wifi-module.h"

#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

using namespace ns3;

namespace
{

/** First RNG stream reserved for RandomWaypoint position, speed, and pause. */
constexpr int64_t MOBILITY_STREAM_BASE = 10000;

/** Number of explicitly assigned RandomWaypoint streams per node. */
constexpr int64_t MOBILITY_STREAMS_PER_NODE = 4;

/** First RNG stream reserved for stock AODV. */
constexpr int64_t AODV_STREAM_BASE = 20000;

/** First RNG stream reserved for Wi-Fi PHY/MAC processes. */
constexpr int64_t WIFI_STREAM_BASE = 30000;

/** First RNG stream reserved for the UDP OnOff applications. */
constexpr int64_t TRAFFIC_STREAM_BASE = 40000;

/** UDP destination port reserved for the STEP 0 useful-data flows. */
constexpr uint16_t APPLICATION_DESTINATION_PORT = 9000;

/** IPv4 protocol number assigned to UDP. */
constexpr uint8_t UDP_PROTOCOL_NUMBER = 17;

/** IPv4 network required by the project pilot. */
constexpr const char* IPV4_NETWORK = "10.1.0.0";

/** IPv4 mask required by the project pilot. */
constexpr const char* IPV4_MASK = "255.255.255.0";

/**
 * @brief Configurable scientific coordinates of the STEP 0 simulation.
 *
 * Values not fixed by the specification (area, range, flow load, and warm-up)
 * remain visible command-line parameters.  Their defaults are pilot values,
 * not confirmatory values, and must be frozen only after baseline diagnosis.
 */
struct PilotConfiguration
{
    /** @brief Number of MANET nodes. Unit: nodes. */
    uint32_t nodes{20};

    /** @brief Complete simulation duration. Unit: s. */
    double simulationTimeSeconds{60.0};

    /** @brief Minimum RandomWaypoint speed. Unit: m/s. */
    double minimumSpeedMetersPerSecond{1.0};

    /** @brief Maximum RandomWaypoint speed. Unit: m/s. */
    double maximumSpeedMetersPerSecond{20.0};

    /** @brief RandomWaypoint pause duration. Unit: s. */
    double pauseTimeSeconds{0.0};

    /** @brief Requested attacker fraction; STEP 0 accepts exactly zero. */
    double attackerRatio{0.0};

    /** @brief Future attack activation time retained for schema stability. Unit: s. */
    double attackStartSeconds{10.0};

    /** @brief Global ns-3 seed. */
    uint32_t seed{12345};

    /** @brief ns-3 independent replication number. */
    uint64_t run{1};

    /** @brief Width and height of the square mobility area. Unit: m. */
    double areaSizeMeters{300.0};

    /** @brief Deterministic maximum communication distance. Unit: m. */
    double maximumRangeMeters{150.0};

    /** @brief Number of concurrent UDP sources. Unit: flows. */
    uint32_t flowCount{4};

    /** @brief Useful payload per generated application unit. Unit: bytes. */
    uint32_t packetPayloadBytes{512};

    /** @brief Constant offered data rate of each source. */
    std::string dataRate{"64kbps"};

    /** @brief Start of the earliest source after mobility warm-up. Unit: s. */
    double applicationStartSeconds{10.0};

    /** @brief Deterministic separation between source starts. Unit: s. */
    double sourceStartStaggerSeconds{0.1};

    /** @brief Destination CSV path. */
    std::string outputCsv{"mtcaodv-step00-results.csv"};

    /** @brief Destination JSON manifest path. */
    std::string outputManifest{"mtcaodv-step00-manifest.json"};

    /** @brief Destination FlowMonitor XML path. */
    std::string flowMonitorXml{"mtcaodv-step00-flowmon.xml"};
};

/**
 * @brief Counts and stream allocations observed during one pilot run.
 */
struct PilotRunResult
{
    /** @brief Derived application/network metrics. */
    mtcaodv::BaselineMetricSummary metrics;

    /** @brief Number of application five-tuples found by FlowMonitor. */
    uint32_t monitoredApplicationFlows{0};

    /** @brief Explicit RandomWaypoint streams allocated. */
    int64_t mobilityStreamsConsumed{0};

    /** @brief Wi-Fi streams allocated by WifiHelper. */
    int64_t wifiStreamsConsumed{0};

    /** @brief Stock-AODV streams allocated by AodvHelper. */
    int64_t aodvStreamsConsumed{0};

    /** @brief OnOffApplication streams allocated across all sources. */
    int64_t trafficStreamsConsumed{0};

    /** @brief Earliest application start used as the evaluation-window origin. */
    double evaluationStartSeconds{0.0};

    /** @brief Common application stop used as the evaluation-window end. */
    double evaluationStopSeconds{0.0};
};

/**
 * @brief Validate all command-line values before ns-3 objects are created.
 * @param configuration Candidate pilot configuration.
 * @throws std::invalid_argument when a coordinate is invalid or STEP 0 is
 *         asked to simulate an attack that it does not yet implement.
 */
void
ValidateConfiguration(const PilotConfiguration& configuration)
{
    // The required /24 network exposes exactly 254 usable host addresses.
    // Keeping this bound explicit prevents an address allocator failure from
    // being mistaken for a routing or mobility failure.
    if (configuration.nodes < 2 || configuration.nodes > 254)
    {
        throw std::invalid_argument("nodes must be in [2, 254] for 10.1.0.0/24");
    }

    if (!std::isfinite(configuration.simulationTimeSeconds) ||
        configuration.simulationTimeSeconds <= 0.0)
    {
        throw std::invalid_argument("simTime must be finite and positive");
    }

    if (!std::isfinite(configuration.minimumSpeedMetersPerSecond) ||
        !std::isfinite(configuration.maximumSpeedMetersPerSecond) ||
        configuration.minimumSpeedMetersPerSecond <= 0.0 ||
        configuration.maximumSpeedMetersPerSecond <
            configuration.minimumSpeedMetersPerSecond)
    {
        throw std::invalid_argument("minSpeed and maxSpeed must satisfy 0 < minSpeed <= maxSpeed");
    }

    if (!std::isfinite(configuration.pauseTimeSeconds) ||
        configuration.pauseTimeSeconds < 0.0)
    {
        throw std::invalid_argument("pauseTime must be finite and non-negative");
    }

    // STEP 0 is a healthy stock-AODV baseline.  Accepting a nonzero ratio while
    // installing no attacker would create a scientifically mislabeled row.
    if (!std::isfinite(configuration.attackerRatio) ||
        configuration.attackerRatio != 0.0)
    {
        throw std::invalid_argument("STEP 0 requires attackerRatio=0");
    }

    if (!std::isfinite(configuration.attackStartSeconds) ||
        configuration.attackStartSeconds < 0.0)
    {
        throw std::invalid_argument("attackStart must be finite and non-negative");
    }

    if (configuration.seed == 0)
    {
        throw std::invalid_argument("seed must be positive");
    }

    if (!std::isfinite(configuration.areaSizeMeters) ||
        configuration.areaSizeMeters <= 0.0 ||
        !std::isfinite(configuration.maximumRangeMeters) ||
        configuration.maximumRangeMeters <= 0.0)
    {
        throw std::invalid_argument("areaSize and maxRange must be finite and positive");
    }

    // The last node is the common destination; each source must be distinct
    // from it.  This check also prevents an empty workload.
    if (configuration.flowCount == 0 || configuration.flowCount >= configuration.nodes)
    {
        throw std::invalid_argument("flowCount must be in [1, nodes-1]");
    }

    SeqTsSizeHeader instrumentationHeader;
    const uint32_t instrumentationBytes = instrumentationHeader.GetSerializedSize();
    constexpr uint32_t MAXIMUM_IPV4_UDP_PAYLOAD_BYTES = 65507;

    // packetPayloadBytes denotes useful data.  The instrumentation header is
    // added transparently and the combined IPv4 UDP payload must remain legal.
    if (configuration.packetPayloadBytes == 0 ||
        configuration.packetPayloadBytes >
            MAXIMUM_IPV4_UDP_PAYLOAD_BYTES - instrumentationBytes)
    {
        throw std::invalid_argument("packetPayloadBytes is outside the IPv4 UDP payload limit");
    }

    if (configuration.dataRate.empty())
    {
        throw std::invalid_argument("dataRate must not be empty");
    }

    if (!std::isfinite(configuration.applicationStartSeconds) ||
        configuration.applicationStartSeconds <= 0.5 ||
        !std::isfinite(configuration.sourceStartStaggerSeconds) ||
        configuration.sourceStartStaggerSeconds < 0.0)
    {
        throw std::invalid_argument("application timing values are invalid");
    }

    const double applicationStopSeconds = configuration.simulationTimeSeconds - 1.0;
    const double lastSourceStartSeconds =
        configuration.applicationStartSeconds +
        configuration.sourceStartStaggerSeconds * (configuration.flowCount - 1);

    // One second is reserved after application stop so packets still in flight
    // can arrive and FlowMonitor can classify losses before Simulator::Stop().
    if (applicationStopSeconds <= configuration.applicationStartSeconds ||
        lastSourceStartSeconds >= applicationStopSeconds)
    {
        throw std::invalid_argument("simTime is too short for the configured application window");
    }

    if (configuration.outputCsv.empty() || configuration.outputManifest.empty() ||
        configuration.flowMonitorXml.empty())
    {
        throw std::invalid_argument("all output paths must be non-empty");
    }
}

/**
 * @brief Install one independently-streamed RandomWaypoint model per node.
 * @param nodes MANET nodes.
 * @param configuration Validated mobility coordinates.
 * @return Number of explicitly reserved RNG streams.
 */
int64_t
InstallRandomWaypointMobility(const NodeContainer& nodes,
                              const PilotConfiguration& configuration)
{
    // Each iteration assigns exactly four disjoint streams to one node: X, Y,
    // speed, and pause.  The invariant after node i is 4*(i+1) reserved streams.
    for (uint32_t nodeIndex = 0; nodeIndex < nodes.GetN(); ++nodeIndex)
    {
        const int64_t nodeStreamBase =
            MOBILITY_STREAM_BASE + MOBILITY_STREAMS_PER_NODE * nodeIndex;

        Ptr<UniformRandomVariable> xCoordinate = CreateObject<UniformRandomVariable>();
        xCoordinate->SetAttribute("Min", DoubleValue(0.0));
        xCoordinate->SetAttribute("Max", DoubleValue(configuration.areaSizeMeters));
        xCoordinate->SetStream(nodeStreamBase);

        Ptr<UniformRandomVariable> yCoordinate = CreateObject<UniformRandomVariable>();
        yCoordinate->SetAttribute("Min", DoubleValue(0.0));
        yCoordinate->SetAttribute("Max", DoubleValue(configuration.areaSizeMeters));
        yCoordinate->SetStream(nodeStreamBase + 1);

        Ptr<RandomRectanglePositionAllocator> positionAllocator =
            CreateObject<RandomRectanglePositionAllocator>();
        positionAllocator->SetAttribute("X", PointerValue(xCoordinate));
        positionAllocator->SetAttribute("Y", PointerValue(yCoordinate));

        Ptr<UniformRandomVariable> speed = CreateObject<UniformRandomVariable>();
        speed->SetAttribute("Min", DoubleValue(configuration.minimumSpeedMetersPerSecond));
        speed->SetAttribute("Max", DoubleValue(configuration.maximumSpeedMetersPerSecond));
        speed->SetStream(nodeStreamBase + 2);

        Ptr<ConstantRandomVariable> pause = CreateObject<ConstantRandomVariable>();
        pause->SetAttribute("Constant", DoubleValue(configuration.pauseTimeSeconds));
        pause->SetStream(nodeStreamBase + 3);

        MobilityHelper mobility;
        mobility.SetPositionAllocator(positionAllocator);
        mobility.SetMobilityModel("ns3::RandomWaypointMobilityModel",
                                  "Speed",
                                  PointerValue(speed),
                                  "Pause",
                                  PointerValue(pause),
                                  "PositionAllocator",
                                  PointerValue(positionAllocator));
        mobility.Install(nodes.Get(nodeIndex));
    }

    return MOBILITY_STREAMS_PER_NODE * static_cast<int64_t>(nodes.GetN());
}

/**
 * @brief Install range-bounded IEEE 802.11b ad hoc devices.
 * @param nodes MANET nodes.
 * @param configuration Validated radio coordinates.
 * @param streamsConsumed Output number of RNG streams consumed by Wi-Fi.
 * @return Installed devices in node order.
 */
NetDeviceContainer
InstallAdHocWifi(const NodeContainer& nodes,
                 const PilotConfiguration& configuration,
                 int64_t& streamsConsumed)
{
    YansWifiChannelHelper channel;
    channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    channel.AddPropagationLoss("ns3::RangePropagationLossModel",
                               "MaxRange",
                               DoubleValue(configuration.maximumRangeMeters));

    YansWifiPhyHelper phy;
    phy.SetChannel(channel.Create());

    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211b);
    wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                 "DataMode",
                                 StringValue("DsssRate11Mbps"),
                                 "ControlMode",
                                 StringValue("DsssRate1Mbps"));

    WifiMacHelper mac;
    mac.SetType("ns3::AdhocWifiMac");

    NetDeviceContainer devices = wifi.Install(phy, mac, nodes);
    streamsConsumed = WifiHelper::AssignStreams(devices, WIFI_STREAM_BASE);
    return devices;
}

/**
 * @brief Install untouched ns-3.48 AODV and assign deterministic streams.
 * @param nodes Complete MANET node set.
 * @return Number of RNG streams consumed by stock AODV.
 */
int64_t
InstallStockAodv(const NodeContainer& nodes)
{
    AodvHelper aodv;
    InternetStackHelper internet;
    internet.SetRoutingHelper(aodv);
    internet.Install(nodes);

    return aodv.AssignStreams(nodes, AODV_STREAM_BASE);
}

/**
 * @brief Install one sink and deterministic constant-rate UDP sources.
 * @param nodes MANET node set.
 * @param interfaces Assigned IPv4 interfaces.
 * @param configuration Validated traffic coordinates.
 * @param collector Metrics callback target that remains alive through Run().
 * @return Number of application RNG streams explicitly assigned.
 */
int64_t
InstallUdpTraffic(const NodeContainer& nodes,
                  const Ipv4InterfaceContainer& interfaces,
                  const PilotConfiguration& configuration,
                  mtcaodv::BaselineMetricsCollector& collector)
{
    const uint32_t destinationNodeIndex = nodes.GetN() - 1;
    const Ipv4Address destinationAddress = interfaces.GetAddress(destinationNodeIndex);
    const double applicationStopSeconds = configuration.simulationTimeSeconds - 1.0;

    PacketSinkHelper sinkHelper(
        "ns3::UdpSocketFactory",
        InetSocketAddress(Ipv4Address::GetAny(), APPLICATION_DESTINATION_PORT));
    sinkHelper.SetAttribute("EnableSeqTsSizeHeader", BooleanValue(true));
    ApplicationContainer sinkApplications =
        sinkHelper.Install(nodes.Get(destinationNodeIndex));
    sinkApplications.Start(Seconds(0.5));
    sinkApplications.Stop(Seconds(configuration.simulationTimeSeconds));

    Ptr<PacketSink> sink = DynamicCast<PacketSink>(sinkApplications.Get(0));
    if (!sink)
    {
        throw std::logic_error("Installed sink is not an ns3::PacketSink");
    }

    const bool sinkTraceConnected = sink->TraceConnectWithoutContext(
        "RxWithSeqTsSize",
        MakeCallback(&mtcaodv::BaselineMetricsCollector::ObserveApplicationRxWithSeqTsSize,
                     &collector));
    if (!sinkTraceConnected)
    {
        throw std::logic_error("Could not connect PacketSink RxWithSeqTsSize trace");
    }

    SeqTsSizeHeader instrumentationHeader;
    const uint32_t encodedApplicationDataUnitBytes =
        configuration.packetPayloadBytes + instrumentationHeader.GetSerializedSize();
    const DataRate sourceDataRate(configuration.dataRate);
    int64_t nextTrafficStream = TRAFFIC_STREAM_BASE;

    // Sources are nodes [0, flowCount-1] and the destination is nodes-1.  The
    // loop preserves distinct endpoints and sequential, non-overlapping stream
    // allocation for every already-installed source.
    for (uint32_t flowIndex = 0; flowIndex < configuration.flowCount; ++flowIndex)
    {
        OnOffHelper sourceHelper(
            "ns3::UdpSocketFactory",
            InetSocketAddress(destinationAddress, APPLICATION_DESTINATION_PORT));
        sourceHelper.SetAttribute("DataRate", DataRateValue(sourceDataRate));
        sourceHelper.SetAttribute("PacketSize", UintegerValue(encodedApplicationDataUnitBytes));
        sourceHelper.SetAttribute("OnTime",
                                  StringValue(
                                      "ns3::ConstantRandomVariable[Constant=1000000000.0]"));
        sourceHelper.SetAttribute("OffTime",
                                  StringValue("ns3::ConstantRandomVariable[Constant=0.0]"));
        sourceHelper.SetAttribute("EnableSeqTsSizeHeader", BooleanValue(true));

        ApplicationContainer sourceApplications =
            sourceHelper.Install(nodes.Get(flowIndex));
        const double sourceStartSeconds =
            configuration.applicationStartSeconds +
            configuration.sourceStartStaggerSeconds * flowIndex;
        sourceApplications.Start(Seconds(sourceStartSeconds));
        sourceApplications.Stop(Seconds(applicationStopSeconds));

        Ptr<OnOffApplication> source =
            DynamicCast<OnOffApplication>(sourceApplications.Get(0));
        if (!source)
        {
            throw std::logic_error("Installed source is not an ns3::OnOffApplication");
        }

        const bool sourceTraceConnected = source->TraceConnectWithoutContext(
            "Tx",
            MakeCallback(
                &mtcaodv::BaselineMetricsCollector::ObserveSuccessfulApplicationTx,
                &collector));
        if (!sourceTraceConnected)
        {
            throw std::logic_error("Could not connect OnOffApplication Tx trace");
        }

        // Constant On/Off variables do not alter the offered pattern, but their
        // streams are still explicitly assigned and recorded for future pairing.
        const int64_t applicationStreamCount = source->AssignStreams(nextTrafficStream);
        if (applicationStreamCount <= 0)
        {
            throw std::logic_error("OnOffApplication did not report assigned RNG streams");
        }
        nextTrafficStream += applicationStreamCount;
    }

    return nextTrafficStream - TRAFFIC_STREAM_BASE;
}

/**
 * @brief Extract received network bytes for only the configured data flows.
 * @param helper FlowMonitor helper owning the IPv4 classifier.
 * @param monitor Completed FlowMonitor instance.
 * @param flowCount Output number of matched UDP five-tuples with Tx activity.
 * @return Sum of FlowStats::rxBytes for destination port 9000. Unit: bytes.
 */
uint64_t
CollectApplicationNetworkBytes(FlowMonitorHelper& helper,
                               Ptr<FlowMonitor> monitor,
                               uint32_t& flowCount)
{
    Ptr<Ipv4FlowClassifier> classifier =
        DynamicCast<Ipv4FlowClassifier>(helper.GetClassifier());
    if (!classifier || !monitor)
    {
        throw std::logic_error("FlowMonitor IPv4 classifier is unavailable");
    }

    uint64_t networkReceivedBytes = 0;
    flowCount = 0;
    const FlowMonitor::FlowStatsContainer statistics = monitor->GetFlowStats();

    // Only UDP five-tuples terminating at the pilot application port are part
    // of Equation (25).  This excludes AODV's UDP control port 654 and avoids
    // inflating useful network throughput with routing traffic.
    for (const auto& flowEntry : statistics)
    {
        const Ipv4FlowClassifier::FiveTuple tuple = classifier->FindFlow(flowEntry.first);
        if (tuple.protocol == UDP_PROTOCOL_NUMBER &&
            tuple.destinationPort == APPLICATION_DESTINATION_PORT)
        {
            networkReceivedBytes += flowEntry.second.rxBytes;
            if (flowEntry.second.txPackets > 0)
            {
                ++flowCount;
            }
        }
    }

    return networkReceivedBytes;
}

/**
 * @brief Escape a string for a JSON string literal.
 * @param value Untrusted command-line value.
 * @return Escaped content without surrounding quotation marks.
 */
std::string
EscapeJson(const std::string& value)
{
    std::ostringstream escaped;

    // The loop emits a valid escape for every control or structural character;
    // ordinary UTF-8 bytes are preserved byte-for-byte.
    for (const unsigned char character : value)
    {
        switch (character)
        {
        case '"':
            escaped << "\\\"";
            break;
        case '\\':
            escaped << "\\\\";
            break;
        case '\b':
            escaped << "\\b";
            break;
        case '\f':
            escaped << "\\f";
            break;
        case '\n':
            escaped << "\\n";
            break;
        case '\r':
            escaped << "\\r";
            break;
        case '\t':
            escaped << "\\t";
            break;
        default:
            if (character < 0x20)
            {
                escaped << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                        << static_cast<unsigned int>(character) << std::dec;
            }
            else
            {
                escaped << static_cast<char>(character);
            }
            break;
        }
    }

    return escaped.str();
}

/**
 * @brief Escape a value for one CSV field.
 * @param value Raw field text.
 * @return RFC-4180-compatible field text.
 */
std::string
EscapeCsv(const std::string& value)
{
    const bool requiresQuotes =
        value.find_first_of(",\"\n\r") != std::string::npos;
    if (!requiresQuotes)
    {
        return value;
    }

    std::string escaped = "\"";
    for (const char character : value)
    {
        // CSV represents a literal quotation mark by doubling it.
        if (character == '"')
        {
            escaped += "\"\"";
        }
        else
        {
            escaped += character;
        }
    }
    escaped += '"';
    return escaped;
}

/**
 * @brief Write a floating-point CSV field without fabricating undefined values.
 * @param output Open output stream.
 * @param value Metric or configuration value.
 */
void
WriteCsvDouble(std::ostream& output, double value)
{
    if (std::isfinite(value))
    {
        output << std::setprecision(17) << value;
    }
    else
    {
        output << "NaN";
    }
}

/**
 * @brief Write a JSON number or null for an undefined numerical metric.
 * @param output Open output stream.
 * @param value Candidate numerical value.
 */
void
WriteJsonDouble(std::ostream& output, double value)
{
    if (std::isfinite(value))
    {
        output << std::setprecision(17) << value;
    }
    else
    {
        output << "null";
    }
}

/**
 * @brief Persist the stable STEP 0 CSV schema and one observed row.
 * @param configuration Executed coordinates.
 * @param result Observed run result.
 * @throws std::runtime_error when the file cannot be written.
 */
void
WriteCsvResult(const PilotConfiguration& configuration, const PilotRunResult& result)
{
    std::ofstream output(configuration.outputCsv, std::ios::out | std::ios::trunc);
    if (!output)
    {
        throw std::runtime_error("Cannot open CSV output: " + configuration.outputCsv);
    }

    // The first nineteen columns are the immutable prefix requested by the
    // project specification.  Diagnostic columns are append-only after it.
    output << "protocol,nodes,simTime,minSpeed,maxSpeed,seed,run,attackerRatio,"
              "attackerCount,attackStart,appTxPackets,appRxPackets,appTxBytes,"
              "appRxBytes,pdr,plr,throughput_bps,goodput_bps,meanDelay_s,"
              "networkRxBytes,evaluationDuration_s,flowCount,packetPayloadBytes,"
              "dataRate,areaSize_m,maxRange_m,appStart_s,appStop_s,ipv4Network,"
              "ipv4Mask,mobilityStreamBase,wifiStreamBase,aodvStreamBase,"
              "trafficStreamBase,mobilityStreamsConsumed,wifiStreamsConsumed,"
              "aodvStreamsConsumed,trafficStreamsConsumed,monitoredApplicationFlows,"
              "pauseTime_s,sourceStartStagger_s,wifiStandard,wifiMac,"
              "propagationModel\n";

    output << "AODV," << configuration.nodes << ',';
    WriteCsvDouble(output, configuration.simulationTimeSeconds);
    output << ',';
    WriteCsvDouble(output, configuration.minimumSpeedMetersPerSecond);
    output << ',';
    WriteCsvDouble(output, configuration.maximumSpeedMetersPerSecond);
    output << ',' << configuration.seed << ',' << configuration.run << ',';
    WriteCsvDouble(output, configuration.attackerRatio);
    output << ",0,";
    WriteCsvDouble(output, configuration.attackStartSeconds);
    output << ',' << result.metrics.appTxPackets << ',' << result.metrics.appRxPackets
           << ',' << result.metrics.appTxBytes << ',' << result.metrics.appRxBytes << ',';
    WriteCsvDouble(output, result.metrics.pdr);
    output << ',';
    WriteCsvDouble(output, result.metrics.plr);
    output << ',';
    WriteCsvDouble(output, result.metrics.throughputBitsPerSecond);
    output << ',';
    WriteCsvDouble(output, result.metrics.goodputBitsPerSecond);
    output << ',';
    WriteCsvDouble(output, result.metrics.meanDelaySeconds);
    output << ',' << result.metrics.networkRxBytes << ',';
    WriteCsvDouble(output, result.evaluationStopSeconds - result.evaluationStartSeconds);
    output << ',' << configuration.flowCount << ',' << configuration.packetPayloadBytes << ','
           << EscapeCsv(configuration.dataRate) << ',';
    WriteCsvDouble(output, configuration.areaSizeMeters);
    output << ',';
    WriteCsvDouble(output, configuration.maximumRangeMeters);
    output << ',';
    WriteCsvDouble(output, result.evaluationStartSeconds);
    output << ',';
    WriteCsvDouble(output, result.evaluationStopSeconds);
    output << ',' << IPV4_NETWORK << ',' << IPV4_MASK << ',' << MOBILITY_STREAM_BASE << ','
           << WIFI_STREAM_BASE << ',' << AODV_STREAM_BASE << ',' << TRAFFIC_STREAM_BASE
           << ',' << result.mobilityStreamsConsumed << ',' << result.wifiStreamsConsumed
           << ',' << result.aodvStreamsConsumed << ',' << result.trafficStreamsConsumed
           << ',' << result.monitoredApplicationFlows << ',';
    WriteCsvDouble(output, configuration.pauseTimeSeconds);
    output << ',';
    WriteCsvDouble(output, configuration.sourceStartStaggerSeconds);
    output << ",802.11b,ns3::AdhocWifiMac,ns3::RangePropagationLossModel\n";

    if (!output)
    {
        throw std::runtime_error("Failed while writing CSV output: " +
                                 configuration.outputCsv);
    }
}

/**
 * @brief Persist a deterministic manifest for pairing and diagnosis.
 * @param configuration Executed coordinates.
 * @param result Observed run result.
 * @throws std::runtime_error when the file cannot be written.
 */
void
WriteManifest(const PilotConfiguration& configuration, const PilotRunResult& result)
{
    std::ofstream output(configuration.outputManifest, std::ios::out | std::ios::trunc);
    if (!output)
    {
        throw std::runtime_error("Cannot open manifest output: " +
                                 configuration.outputManifest);
    }

    output << "{\n"
           << "  \"schemaVersion\": \"mtcaodv-step00-v1\",\n"
           << "  \"targetNs3Version\": \"3.48\",\n"
           << "  \"validationStatus\": \"UNVALIDATED_UNTIL_USER_EXECUTION\",\n"
           << "  \"protocol\": \"AODV\",\n"
           << "  \"attackImplemented\": false,\n"
           << "  \"network\": {\n"
           << "    \"ipv4Network\": \"" << IPV4_NETWORK << "\",\n"
           << "    \"ipv4Mask\": \"" << IPV4_MASK << "\",\n"
           << "    \"wifiStandard\": \"802.11b\",\n"
           << "    \"wifiMac\": \"ns3::AdhocWifiMac\",\n"
           << "    \"propagationModel\": \"ns3::RangePropagationLossModel\"\n"
           << "  },\n"
           << "  \"configuration\": {\n"
           << "    \"nodes\": " << configuration.nodes << ",\n"
           << "    \"simTime\": ";
    WriteJsonDouble(output, configuration.simulationTimeSeconds);
    output << ",\n    \"minSpeed\": ";
    WriteJsonDouble(output, configuration.minimumSpeedMetersPerSecond);
    output << ",\n    \"maxSpeed\": ";
    WriteJsonDouble(output, configuration.maximumSpeedMetersPerSecond);
    output << ",\n    \"pauseTime\": ";
    WriteJsonDouble(output, configuration.pauseTimeSeconds);
    output << ",\n    \"attackerRatio\": ";
    WriteJsonDouble(output, configuration.attackerRatio);
    output << ",\n    \"attackerCount\": 0,\n"
           << "    \"attackStart\": ";
    WriteJsonDouble(output, configuration.attackStartSeconds);
    output << ",\n    \"seed\": " << configuration.seed << ",\n"
           << "    \"run\": " << configuration.run << ",\n"
           << "    \"areaSizeMeters\": ";
    WriteJsonDouble(output, configuration.areaSizeMeters);
    output << ",\n    \"maximumRangeMeters\": ";
    WriteJsonDouble(output, configuration.maximumRangeMeters);
    output << ",\n    \"flowCount\": " << configuration.flowCount << ",\n"
           << "    \"packetPayloadBytes\": " << configuration.packetPayloadBytes << ",\n"
           << "    \"dataRate\": \"" << EscapeJson(configuration.dataRate) << "\",\n"
           << "    \"applicationStartSeconds\": ";
    WriteJsonDouble(output, result.evaluationStartSeconds);
    output << ",\n    \"applicationStopSeconds\": ";
    WriteJsonDouble(output, result.evaluationStopSeconds);
    output << ",\n    \"sourceStartStaggerSeconds\": ";
    WriteJsonDouble(output, configuration.sourceStartStaggerSeconds);
    output << "\n  },\n"
           << "  \"rng\": {\n"
           << "    \"seed\": " << configuration.seed << ",\n"
           << "    \"run\": " << configuration.run << ",\n"
           << "    \"mobilityStreamBase\": " << MOBILITY_STREAM_BASE << ",\n"
           << "    \"wifiStreamBase\": " << WIFI_STREAM_BASE << ",\n"
           << "    \"aodvStreamBase\": " << AODV_STREAM_BASE << ",\n"
           << "    \"trafficStreamBase\": " << TRAFFIC_STREAM_BASE << ",\n"
           << "    \"mobilityStreamsConsumed\": " << result.mobilityStreamsConsumed
           << ",\n"
           << "    \"wifiStreamsConsumed\": " << result.wifiStreamsConsumed << ",\n"
           << "    \"aodvStreamsConsumed\": " << result.aodvStreamsConsumed << ",\n"
           << "    \"trafficStreamsConsumed\": " << result.trafficStreamsConsumed
           << "\n  },\n"
           << "  \"metrics\": {\n"
           << "    \"appTxPackets\": " << result.metrics.appTxPackets << ",\n"
           << "    \"appRxPackets\": " << result.metrics.appRxPackets << ",\n"
           << "    \"appTxBytes\": " << result.metrics.appTxBytes << ",\n"
           << "    \"appRxBytes\": " << result.metrics.appRxBytes << ",\n"
           << "    \"networkRxBytes\": " << result.metrics.networkRxBytes << ",\n"
           << "    \"pdr\": ";
    WriteJsonDouble(output, result.metrics.pdr);
    output << ",\n    \"plr\": ";
    WriteJsonDouble(output, result.metrics.plr);
    output << ",\n    \"throughput_bps\": ";
    WriteJsonDouble(output, result.metrics.throughputBitsPerSecond);
    output << ",\n    \"goodput_bps\": ";
    WriteJsonDouble(output, result.metrics.goodputBitsPerSecond);
    output << ",\n    \"meanDelay_s\": ";
    WriteJsonDouble(output, result.metrics.meanDelaySeconds);
    output << ",\n    \"monitoredApplicationFlows\": "
           << result.monitoredApplicationFlows << "\n"
           << "  }\n"
           << "}\n";

    if (!output)
    {
        throw std::runtime_error("Failed while writing manifest: " +
                                 configuration.outputManifest);
    }
}

/**
 * @brief Execute the stock-AODV pilot after configuration validation.
 * @param configuration Validated simulation coordinates.
 * @return Observed metrics and allocated-stream diagnostics.
 */
PilotRunResult
RunPilot(const PilotConfiguration& configuration)
{
    // Reset process-wide allocators before object construction so rerunning the
    // same seed/run in one process cannot inherit an implicit stream or address.
    RngSeedManager::SetSeed(configuration.seed);
    RngSeedManager::SetRun(configuration.run);
    RngSeedManager::ResetNextStreamIndex();
    Ipv4AddressGenerator::Reset();

    NodeContainer nodes;
    nodes.Create(configuration.nodes);

    PilotRunResult result;
    result.mobilityStreamsConsumed = InstallRandomWaypointMobility(nodes, configuration);

    NetDeviceContainer devices =
        InstallAdHocWifi(nodes, configuration, result.wifiStreamsConsumed);
    result.aodvStreamsConsumed = InstallStockAodv(nodes);

    // This exact address helper sequence is normative for the project pilot.
    Ipv4AddressHelper ipv4;
    ipv4.SetBase("10.1.0.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);

    result.evaluationStartSeconds = configuration.applicationStartSeconds;
    result.evaluationStopSeconds = configuration.simulationTimeSeconds - 1.0;
    const Time evaluationDuration =
        Seconds(result.evaluationStopSeconds - result.evaluationStartSeconds);
    mtcaodv::BaselineMetricsCollector collector(evaluationDuration);

    result.trafficStreamsConsumed =
        InstallUdpTraffic(nodes, interfaces, configuration, collector);

    // Stream ranges are deliberately separated by 10,000.  Verify the actual
    // helper-reported consumption before the simulation starts so a future
    // topology increase or ns-3 implementation change cannot silently make
    // two stochastic components share a stream.
    if (MOBILITY_STREAM_BASE + result.mobilityStreamsConsumed > AODV_STREAM_BASE ||
        AODV_STREAM_BASE + result.aodvStreamsConsumed > WIFI_STREAM_BASE ||
        WIFI_STREAM_BASE + result.wifiStreamsConsumed > TRAFFIC_STREAM_BASE)
    {
        throw std::logic_error("Configured RNG stream ranges overlap");
    }

    FlowMonitorHelper flowMonitorHelper;
    Ptr<FlowMonitor> flowMonitor = flowMonitorHelper.InstallAll();

    Simulator::Stop(Seconds(configuration.simulationTimeSeconds));
    Simulator::Run();

    flowMonitor->CheckForLostPackets();
    const uint64_t networkReceivedBytes = CollectApplicationNetworkBytes(
        flowMonitorHelper,
        flowMonitor,
        result.monitoredApplicationFlows);
    collector.SetNetworkReceivedBytes(networkReceivedBytes);
    result.metrics = collector.BuildSummary();

    // Preserve raw FlowMonitor data for diagnosis; the CSV still uses only the
    // explicitly filtered UDP data flows for its throughput calculation.
    flowMonitor->SerializeToXmlFile(configuration.flowMonitorXml, true, true);

    Simulator::Destroy();
    return result;
}

/**
 * @brief Print concise observed values after a completed simulation.
 * @param configuration Executed configuration.
 * @param result Actual result returned by RunPilot().
 */
void
PrintResult(const PilotConfiguration& configuration, const PilotRunResult& result)
{
    std::cout << std::setprecision(10)
              << "STEP 0 simulation completed with stock AODV\n"
              << "appTxPackets=" << result.metrics.appTxPackets << '\n'
              << "appRxPackets=" << result.metrics.appRxPackets << '\n'
              << "appTxBytes=" << result.metrics.appTxBytes << '\n'
              << "appRxBytes=" << result.metrics.appRxBytes << '\n'
              << "pdr=" << result.metrics.pdr << '\n'
              << "plr=" << result.metrics.plr << '\n'
              << "throughput_bps=" << result.metrics.throughputBitsPerSecond << '\n'
              << "goodput_bps=" << result.metrics.goodputBitsPerSecond << '\n'
              << "meanDelay_s=" << result.metrics.meanDelaySeconds << '\n'
              << "csv=" << configuration.outputCsv << '\n'
              << "manifest=" << configuration.outputManifest << '\n'
              << "flowMonitorXml=" << configuration.flowMonitorXml << std::endl;
}

} // namespace

/**
 * @brief Configure, execute, and persist one STEP 0 baseline realization.
 */
int
main(int argc, char* argv[])
{
    PilotConfiguration configuration;

    CommandLine commandLine(__FILE__);
    commandLine.AddValue("nodes", "Number of MANET nodes", configuration.nodes);
    commandLine.AddValue("simTime",
                         "Simulation duration in seconds",
                         configuration.simulationTimeSeconds);
    commandLine.AddValue("minSpeed",
                         "Minimum RandomWaypoint speed in m/s",
                         configuration.minimumSpeedMetersPerSecond);
    commandLine.AddValue("maxSpeed",
                         "Maximum RandomWaypoint speed in m/s",
                         configuration.maximumSpeedMetersPerSecond);
    commandLine.AddValue("pauseTime",
                         "RandomWaypoint pause duration in seconds",
                         configuration.pauseTimeSeconds);
    commandLine.AddValue("attackerRatio",
                         "Attacker ratio; STEP 0 accepts only zero",
                         configuration.attackerRatio);
    commandLine.AddValue("attackStart",
                         "Future attack start in seconds; recorded but inactive in STEP 0",
                         configuration.attackStartSeconds);
    commandLine.AddValue("seed", "Global ns-3 seed", configuration.seed);
    commandLine.AddValue("run", "ns-3 replication run number", configuration.run);
    commandLine.AddValue("areaSize",
                         "Square mobility-area side length in meters",
                         configuration.areaSizeMeters);
    commandLine.AddValue("maxRange",
                         "RangePropagationLossModel maximum range in meters",
                         configuration.maximumRangeMeters);
    commandLine.AddValue("flowCount",
                         "Number of concurrent UDP source flows",
                         configuration.flowCount);
    commandLine.AddValue("packetSize",
                         "Useful application payload per packet in bytes",
                         configuration.packetPayloadBytes);
    commandLine.AddValue("dataRate",
                         "Per-source constant application data rate",
                         configuration.dataRate);
    commandLine.AddValue("appStart",
                         "Earliest UDP source start in seconds",
                         configuration.applicationStartSeconds);
    commandLine.AddValue("sourceStartStagger",
                         "Deterministic source-start separation in seconds",
                         configuration.sourceStartStaggerSeconds);
    commandLine.AddValue("outputCsv", "STEP 0 CSV output path", configuration.outputCsv);
    commandLine.AddValue("outputManifest",
                         "STEP 0 JSON manifest output path",
                         configuration.outputManifest);
    commandLine.AddValue("flowMonitorXml",
                         "Raw FlowMonitor XML output path",
                         configuration.flowMonitorXml);
    commandLine.Parse(argc, argv);

    try
    {
        ValidateConfiguration(configuration);
        const PilotRunResult result = RunPilot(configuration);
        WriteCsvResult(configuration, result);
        WriteManifest(configuration, result);
        PrintResult(configuration, result);
    }
    catch (const std::exception& error)
    {
        // Destroy is safe after partial construction and prevents stale static
        // simulator state if this executable is invoked by a test harness.
        Simulator::Destroy();
        std::cerr << "STEP 0 execution failed: " << error.what() << std::endl;
        return 1;
    }

    return 0;
}
