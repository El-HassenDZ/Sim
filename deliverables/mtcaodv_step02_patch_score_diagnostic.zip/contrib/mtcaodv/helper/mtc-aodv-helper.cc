/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * This file is part of the MTC-AODV research prototype.
 * Derived from the ns-3.48 AodvHelper (Copyright (c) 2009 IITP RAS).
 */

#include "mtc-aodv-helper.h"

#include "ns3/ipv4-list-routing.h"
#include "ns3/mtc-aodv-routing-protocol.h"
#include "ns3/names.h"
#include "ns3/node-list.h"
#include "ns3/ptr.h"

#include <stdexcept>

namespace ns3
{
namespace mtcaodv
{

MtcAodvHelper::MtcAodvHelper()
    : Ipv4RoutingHelper()
{
    // Bind the factory to the forked TypeId so both the stock ns3::aodv module
    // and this fork can be linked into the same program without collision.
    m_agentFactory.SetTypeId("ns3::mtcaodv::RoutingProtocol");
}

MtcAodvHelper*
MtcAodvHelper::Copy() const
{
    return new MtcAodvHelper(*this);
}

Ptr<Ipv4RoutingProtocol>
MtcAodvHelper::Create(Ptr<Node> node) const
{
    Ptr<RoutingProtocol> agent = m_agentFactory.Create<RoutingProtocol>();
    node->AggregateObject(agent);
    return agent;
}

void
MtcAodvHelper::Set(std::string name, const AttributeValue& value)
{
    m_agentFactory.Set(name, value);
}

int64_t
MtcAodvHelper::AssignStreams(NodeContainer c, int64_t stream)
{
    // Mirror of AodvHelper::AssignStreams, but resolving the forked type.
    int64_t currentStream = stream;
    Ptr<Node> node;
    for (auto i = c.Begin(); i != c.End(); ++i)
    {
        node = (*i);
        Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
        NS_ASSERT_MSG(ipv4, "Ipv4 not installed on node");
        Ptr<Ipv4RoutingProtocol> proto = ipv4->GetRoutingProtocol();
        NS_ASSERT_MSG(proto, "Ipv4 routing not installed on node");
        Ptr<RoutingProtocol> mtcaodv = DynamicCast<RoutingProtocol>(proto);
        if (mtcaodv)
        {
            currentStream += mtcaodv->AssignStreams(currentStream);
            continue;
        }
        // The forked protocol may also sit inside an Ipv4ListRouting container.
        Ptr<Ipv4ListRouting> list = DynamicCast<Ipv4ListRouting>(proto);
        if (list)
        {
            int16_t priority;
            Ptr<Ipv4RoutingProtocol> listProto;
            Ptr<RoutingProtocol> listMtcaodv;
            for (uint32_t j = 0; j < list->GetNRoutingProtocols(); j++)
            {
                listProto = list->GetRoutingProtocol(j, priority);
                listMtcaodv = DynamicCast<RoutingProtocol>(listProto);
                if (listMtcaodv)
                {
                    currentStream += listMtcaodv->AssignStreams(currentStream);
                    break;
                }
            }
        }
    }
    return (currentStream - stream);
}

void
MtcAodvHelper::InstallAttackBehavior(Ptr<Node> node, Ptr<AttackBehavior> behavior) const
{
    Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
    if (!ipv4)
    {
        throw std::runtime_error("InstallAttackBehavior: node has no Ipv4 stack");
    }
    Ptr<Ipv4RoutingProtocol> proto = ipv4->GetRoutingProtocol();
    Ptr<RoutingProtocol> mtcaodv = DynamicCast<RoutingProtocol>(proto);

    // The forked protocol may be wrapped in an Ipv4ListRouting; unwrap it.
    if (!mtcaodv)
    {
        Ptr<Ipv4ListRouting> list = DynamicCast<Ipv4ListRouting>(proto);
        if (list)
        {
            int16_t priority;
            for (uint32_t j = 0; j < list->GetNRoutingProtocols(); j++)
            {
                Ptr<RoutingProtocol> candidate =
                    DynamicCast<RoutingProtocol>(list->GetRoutingProtocol(j, priority));
                if (candidate)
                {
                    mtcaodv = candidate;
                    break;
                }
            }
        }
    }

    if (!mtcaodv)
    {
        throw std::runtime_error(
            "InstallAttackBehavior: node does not run ns3::mtcaodv::RoutingProtocol");
    }
    mtcaodv->SetAttackBehavior(behavior);
}

} // namespace mtcaodv
} // namespace ns3
