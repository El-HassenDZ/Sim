/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * This file is part of the MTC-AODV research prototype.
 *
 * Derived from the ns-3.48 AodvHelper (Copyright (c) 2009 IITP RAS,
 * Author Pavel Boyko).  The original license notice is preserved: the class
 * is a minimal fork that (a) instantiates the forked ns3::mtcaodv fork of the
 * AODV routing protocol instead of the stock ns3::aodv one, and (b) can attach
 * an mtcaodv::AttackBehavior policy to selected nodes.  Every AODV mechanism
 * (RREQ/RREP/RERR, reverse routes, sequence numbers, lifetimes, precursors)
 * is inherited unchanged from that fork.
 */

#ifndef MTC_AODV_HELPER_H
#define MTC_AODV_HELPER_H

#include "ns3/attack-behavior.h"

#include "ns3/ipv4-routing-helper.h"
#include "ns3/node-container.h"
#include "ns3/node.h"
#include "ns3/object-factory.h"
#include "ns3/ptr.h"

namespace ns3
{
namespace mtcaodv
{

/**
 * @ingroup mtcaodv
 * @brief Helper class that installs the forked MTC-AODV routing protocol and
 *        optionally attaches an attack policy.
 *
 * Rationale for a distinct helper: the stock AodvHelper hard-codes the TypeId
 * "ns3::aodv::RoutingProtocol".  Because MTC-AODV is an isolated fork with the
 * TypeId "ns3::mtcaodv::RoutingProtocol", it needs its own object factory so
 * that both modules can coexist in one build without a registry clash.
 */
class MtcAodvHelper : public Ipv4RoutingHelper
{
  public:
    /** @brief Construct a helper bound to the forked routing-protocol TypeId. */
    MtcAodvHelper();

    /**
     * @brief Clone this helper (required by Ipv4RoutingHelper).
     * @return A heap copy owned by the caller.
     */
    MtcAodvHelper* Copy() const override;

    /**
     * @brief Create one forked routing-protocol instance for @p node.
     * @param node Node receiving the protocol; called by InternetStackHelper.
     * @return The newly created routing protocol aggregated onto the node.
     */
    Ptr<Ipv4RoutingProtocol> Create(Ptr<Node> node) const override;

    /**
     * @brief Set an attribute on the forked routing protocol TypeId.
     * @param name Attribute name (identical to stock AODV attributes).
     * @param value Attribute value.
     */
    void Set(std::string name, const AttributeValue& value);

    /**
     * @brief Assign deterministic RNG streams to the forked protocol.
     * @param c Nodes whose protocol streams are fixed. InternetStackHelper must
     *          already have installed the stack.
     * @param stream First stream index to use.
     * @return Number of stream indices consumed.
     */
    int64_t AssignStreams(NodeContainer c, int64_t stream);

    /**
     * @brief Attach an attack policy to one node's forked routing protocol.
     * @param node Node on which the MTC-AODV protocol is already installed.
     * @param behavior Attack policy (e.g. a BlackholeBehavior instance). Passing
     *        nullptr detaches any current policy and restores honest behaviour.
     * @throws std::runtime_error if @p node does not run mtcaodv::RoutingProtocol.
     *
     * Scientific-integrity boundary: this method belongs to the experiment /
     * scenario layer.  It is the ONLY sanctioned consumer of attacker ground
     * truth, together with the AttackManager selection.  No detector, trust or
     * ledger component may call it or read its result.
     */
    void InstallAttackBehavior(Ptr<Node> node, Ptr<AttackBehavior> behavior) const;

  private:
    /** @brief Factory that creates the forked routing-protocol object. */
    ObjectFactory m_agentFactory;
};

} // namespace mtcaodv
} // namespace ns3

#endif // MTC_AODV_HELPER_H
