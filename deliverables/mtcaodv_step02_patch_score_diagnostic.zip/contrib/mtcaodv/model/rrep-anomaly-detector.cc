/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * This file is part of the MTC-AODV research prototype.
 * STEP 2 — Robust RREP anomaly screening (Section 5.3, Eq. (3)-(5)).
 */

#include "rrep-anomaly-detector.h"

#include <algorithm>
#include <cmath>

namespace ns3
{
namespace mtcaodv
{

RrepAnomalyDetector::RrepAnomalyDetector(const RrepAnomalyParameters& parameters)
    : m_parameters(parameters)
{
}

void
RrepAnomalyDetector::SetParameters(const RrepAnomalyParameters& parameters)
{
    m_parameters = parameters;
}

const RrepAnomalyParameters&
RrepAnomalyDetector::GetParameters() const
{
    return m_parameters;
}

double
RrepAnomalyDetector::Median(std::vector<double> values)
{
    // Precondition: non-empty. The caller guarantees this; an empty sample has
    // no defined median and would be a logic error upstream.
    const std::size_t n = values.size();
    std::sort(values.begin(), values.end());
    if (n % 2 == 1)
    {
        return values[n / 2];
    }
    // Even count: mean of the two central order statistics.
    return 0.5 * (values[n / 2 - 1] + values[n / 2]);
}

double
RrepAnomalyDetector::MedianAbsoluteDeviation(const std::vector<double>& values)
{
    // MAD(X) = med(|X - med(X)|).  Robust dispersion used to normalise the
    // anomalies so a single attractive RREP cannot dominate by raw magnitude.
    const double centre = Median(values);
    std::vector<double> deviations;
    deviations.reserve(values.size());
    for (const double value : values)
    {
        deviations.push_back(std::abs(value - centre));
    }
    return Median(std::move(deviations));
}

int64_t
RrepAnomalyDetector::SignedSequenceDelta(uint32_t unsignedDifference)
{
    // Map an unsigned 32-bit difference into [-2^31, 2^31).  This is exactly the
    // AODV serial-number comparison (RFC 3561 §6.1 / ns-3 int32_t cast): a small
    // POSITIVE result means the first sequence number is fresher than the second,
    // even across the 2^32 wrap boundary.  A naive unsigned subtraction would
    // report a gigantic spurious gap for a wrapped value (edge case in Sec. 21).
    return static_cast<int64_t>(static_cast<int32_t>(unsignedDifference));
}

namespace
{
/**
 * @brief Normalise an anomaly excess by a floored dispersion, then clip it.
 * @param excess Non-negative numerator (Eq. 3/4a/4b).
 * @param mad Observed median absolute deviation of the sample.
 * @param floorValue Minimum dispersion, in the physical unit of the quantity.
 * @param epsilon Division-by-zero guard.
 * @param maximum Upper clip on the resulting anomaly.
 * @return A bounded, robust z-like anomaly.
 *
 * Using max(MAD, floor) instead of (MAD + tiny epsilon) is what prevents the
 * degenerate MAD = 0 case from saturating the logistic on honest replies.
 */
double
NormaliseAnomaly(double excess, double mad, double floorValue, double epsilon, double maximum)
{
    const double dispersion = std::max(mad, floorValue) + epsilon;
    return std::min(maximum, excess / dispersion);
}
} // namespace

RrepAnomalyResult
RrepAnomalyDetector::Score(const std::vector<RrepCandidate>& candidates,
                           std::size_t evaluatedIndex) const
{
    RrepAnomalyResult result;

    // Decision D-07 / C-16: without at least n_R^min comparable replies there is
    // NO comparative score.  We return available=false; the caller must not read
    // this as normality (score 0).
    if (candidates.size() < m_parameters.minimumComparableReplies ||
        evaluatedIndex >= candidates.size())
    {
        result.available = false;
        return result;
    }

    // ---- Eq. (3): positive freshness anomaly, in AODV modular order ----------
    // Reference all sequence numbers to candidates[0] and work in signed deltas
    // so the median/MAD are computed in a wrap-safe neighbourhood.
    const uint32_t reference = candidates.front().sequenceNumber;
    std::vector<double> sequenceOffsets;
    sequenceOffsets.reserve(candidates.size());
    for (const RrepCandidate& candidate : candidates)
    {
        sequenceOffsets.push_back(
            static_cast<double>(SignedSequenceDelta(candidate.sequenceNumber - reference)));
    }
    const double sequenceMedian = Median(sequenceOffsets);
    const double sequenceMad = MedianAbsoluteDeviation(sequenceOffsets);
    const double evaluatedOffset = sequenceOffsets[evaluatedIndex];
    // Numerator keeps only an EXCESS of freshness (Eq. 3): honest, equally fresh
    // or staler replies contribute zero.
    const double sequenceExcess = std::max(0.0, evaluatedOffset - sequenceMedian);
    result.sequenceAnomaly = NormaliseAnomaly(sequenceExcess,
                                              sequenceMad,
                                              m_parameters.sequenceMadFloor,
                                              m_parameters.epsilon,
                                              m_parameters.maximumAnomaly);

    // ---- Eq. (4a): low-hop anomaly ------------------------------------------
    std::vector<double> hopCounts;
    hopCounts.reserve(candidates.size());
    for (const RrepCandidate& candidate : candidates)
    {
        hopCounts.push_back(static_cast<double>(candidate.hopCount));
    }
    const double hopMedian = Median(hopCounts);
    const double hopMad = MedianAbsoluteDeviation(hopCounts);
    const double hopDeficit =
        std::max(0.0, hopMedian - static_cast<double>(candidates[evaluatedIndex].hopCount));
    result.hopAnomaly = NormaliseAnomaly(hopDeficit,
                                         hopMad,
                                         m_parameters.hopMadFloor,
                                         m_parameters.epsilon,
                                         m_parameters.maximumAnomaly);

    // ---- Eq. (4b): earliness anomaly ----------------------------------------
    std::vector<double> arrivalTimes;
    arrivalTimes.reserve(candidates.size());
    for (const RrepCandidate& candidate : candidates)
    {
        arrivalTimes.push_back(candidate.arrivalTimeSeconds);
    }
    const double timeMedian = Median(arrivalTimes);
    const double timeMad = MedianAbsoluteDeviation(arrivalTimes);
    const double earliness =
        std::max(0.0, timeMedian - candidates[evaluatedIndex].arrivalTimeSeconds);
    result.timingAnomaly = NormaliseAnomaly(earliness,
                                            timeMad,
                                            m_parameters.timingMadFloorSeconds,
                                            m_parameters.epsilon,
                                            m_parameters.maximumAnomaly);

    // ---- Eq. (5): logistic anomaly score ------------------------------------
    const double logit = m_parameters.sequenceWeight * result.sequenceAnomaly +
                         m_parameters.hopWeight * result.hopAnomaly +
                         m_parameters.timingWeight * result.timingAnomaly -
                         m_parameters.logisticBias;
    const double score = 1.0 / (1.0 + std::exp(-logit));
    // Clip defensively; the logistic already lies in (0,1) for finite inputs.
    result.anomalyScore = std::min(1.0, std::max(0.0, score));
    result.available = true;
    return result;
}

} // namespace mtcaodv
} // namespace ns3
