/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * This file is part of the MTC-AODV research prototype.
 * STEP 2 — Bounded, windowed RREP candidate buffer (Algorithm A3.1 input).
 */

#include "rrep-candidate-buffer.h"

#include <algorithm>

namespace ns3
{
namespace mtcaodv
{

RrepCandidateBuffer::RrepCandidateBuffer(double windowSeconds,
                                         std::size_t maxCandidatesPerDestination,
                                         std::size_t maxDestinations)
    : m_windowSeconds(windowSeconds),
      m_maxCandidatesPerDestination(std::max<std::size_t>(1, maxCandidatesPerDestination)),
      m_maxDestinations(std::max<std::size_t>(1, maxDestinations))
{
}

void
RrepCandidateBuffer::PurgeStale(std::deque<BufferedRrepCandidate>& entries,
                                double nowSeconds) const
{
    // Drop replies whose age exceeds the comparison window W_R.  Entries are
    // ordered oldest-first, so we pop from the front until the oldest is fresh.
    while (!entries.empty() &&
           (nowSeconds - entries.front().candidate.arrivalTimeSeconds) > m_windowSeconds)
    {
        entries.pop_front();
    }
}

void
RrepCandidateBuffer::Insert(uint32_t destinationKey,
                            uint32_t senderKey,
                            const RrepCandidate& candidate,
                            double nowSeconds)
{
    std::deque<BufferedRrepCandidate>& entries = m_byDestination[destinationKey];

    // (1) Window bound: forget stale replies for this destination.
    PurgeStale(entries, nowSeconds);

    // (2) Append the new observation.
    entries.push_back(BufferedRrepCandidate{candidate, senderKey});

    // (3) Per-destination capacity bound: keep only the most recent replies.
    while (entries.size() > m_maxCandidatesPerDestination)
    {
        entries.pop_front();
    }

    m_lastUpdate[destinationKey] = nowSeconds;

    // (4) Destination-count bound: evict the least-recently-updated destination.
    // The loop tolerates more than one over-budget destination, though a single
    // insert can only add one.
    while (m_byDestination.size() > m_maxDestinations)
    {
        uint32_t lruKey = 0;
        double lruTime = 0.0;
        bool found = false;
        for (const auto& [key, time] : m_lastUpdate)
        {
            if (key == destinationKey)
            {
                continue; // never evict the destination we just updated
            }
            if (!found || time < lruTime)
            {
                found = true;
                lruKey = key;
                lruTime = time;
            }
        }
        if (!found)
        {
            break; // only the current destination remains; nothing to evict
        }
        m_byDestination.erase(lruKey);
        m_lastUpdate.erase(lruKey);
    }
}

std::vector<BufferedRrepCandidate>
RrepCandidateBuffer::GetCandidates(uint32_t destinationKey) const
{
    std::vector<BufferedRrepCandidate> candidates;
    const auto iterator = m_byDestination.find(destinationKey);
    if (iterator == m_byDestination.end())
    {
        return candidates;
    }
    candidates.assign(iterator->second.begin(), iterator->second.end());
    return candidates;
}

std::size_t
RrepCandidateBuffer::TrackedDestinationCount() const
{
    return m_byDestination.size();
}

std::size_t
RrepCandidateBuffer::TotalCandidateCount() const
{
    std::size_t total = 0;
    for (const auto& [key, entries] : m_byDestination)
    {
        total += entries.size();
    }
    return total;
}

} // namespace mtcaodv
} // namespace ns3
