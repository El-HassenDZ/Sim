/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * This file is part of the MTC-AODV research prototype.
 *
 * STEP 2 — Bounded buffer of comparable RREP candidates (Algorithm A3.1 input,
 * specification Section 11.4 "structures bornées").  Pure C++ (no ns3::Object):
 * it is unit-tested for its window and capacity bounds.  Keys are IPv4 addresses
 * reduced to uint32 tokens so the buffer stays independent of ns-3 types.
 *
 * Every structure here is bounded (Invariant 20.4.2): at most
 * @a maxCandidatesPerDestination replies per destination and at most
 * @a maxDestinations tracked destinations; older-than-window and over-capacity
 * entries are dropped deterministically.
 */

#ifndef MTC_AODV_RREP_CANDIDATE_BUFFER_H
#define MTC_AODV_RREP_CANDIDATE_BUFFER_H

#include "rrep-anomaly-detector.h"

#include <cstdint>
#include <deque>
#include <unordered_map>
#include <vector>

namespace ns3
{
namespace mtcaodv
{

/**
 * @ingroup mtcaodv
 * @brief One buffered RREP with the neighbour that relayed it.
 *
 * @a senderKey is the IPv4 address (as a uint32) of the neighbour from which
 * the reply arrived — the node a high anomaly score would place under WATCH.
 */
struct BufferedRrepCandidate
{
    RrepCandidate candidate;  //!< Advertised RREP values + arrival time.
    uint32_t senderKey{0};    //!< Relaying neighbour (IPv4 address as uint32).
};

/**
 * @ingroup mtcaodv
 * @brief Bounded, windowed per-destination store of comparable RREPs.
 */
class RrepCandidateBuffer
{
  public:
    /**
     * @brief Construct a bounded buffer.
     * @param windowSeconds Comparison window @f$W_R@f$: replies older than this
     *        (relative to the newest insert time for a destination) are dropped.
     * @param maxCandidatesPerDestination Per-destination capacity (>=1).
     * @param maxDestinations Maximum simultaneously tracked destinations (>=1);
     *        exceeding it evicts the least-recently-updated destination.
     */
    RrepCandidateBuffer(double windowSeconds,
                        std::size_t maxCandidatesPerDestination,
                        std::size_t maxDestinations);

    /**
     * @brief Insert one observed RREP for a destination.
     * @param destinationKey Advertised destination (IPv4 as uint32).
     * @param senderKey Relaying neighbour (IPv4 as uint32).
     * @param candidate Advertised values and local arrival time.
     * @param nowSeconds Current time; also used to purge stale entries.
     *
     * Purges entries older than @f$W_R@f$ for this destination, enforces the
     * per-destination and destination-count bounds, then appends the reply.
     */
    void Insert(uint32_t destinationKey,
                uint32_t senderKey,
                const RrepCandidate& candidate,
                double nowSeconds);

    /**
     * @brief Return the current comparable set for a destination.
     * @param destinationKey Destination whose live window is requested.
     * @return The buffered candidates within the window (possibly empty).
     */
    std::vector<BufferedRrepCandidate> GetCandidates(uint32_t destinationKey) const;

    /** @brief Number of destinations currently tracked. */
    std::size_t TrackedDestinationCount() const;

    /** @brief Total buffered candidates across all destinations (for bounds tests). */
    std::size_t TotalCandidateCount() const;

  private:
    /** @brief Drop entries older than the window for one destination deque. */
    void PurgeStale(std::deque<BufferedRrepCandidate>& entries, double nowSeconds) const;

    double m_windowSeconds;                    //!< @f$W_R@f$, comparison window.
    std::size_t m_maxCandidatesPerDestination; //!< Per-destination capacity.
    std::size_t m_maxDestinations;             //!< Destination-count bound.

    /** @brief destinationKey -> ordered (oldest front) window of candidates. */
    std::unordered_map<uint32_t, std::deque<BufferedRrepCandidate>> m_byDestination;
    /** @brief destinationKey -> last insert time, for LRU destination eviction. */
    std::unordered_map<uint32_t, double> m_lastUpdate;
};

} // namespace mtcaodv
} // namespace ns3

#endif // MTC_AODV_RREP_CANDIDATE_BUFFER_H
