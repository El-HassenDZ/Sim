/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * This file is part of the MTC-AODV research prototype.
 */

#ifndef MTC_AODV_BASELINE_METRICS_H
#define MTC_AODV_BASELINE_METRICS_H

#include "ns3/address.h"
#include "ns3/nstime.h"
#include "ns3/packet.h"
#include "ns3/ptr.h"
#include "ns3/seq-ts-size-header.h"

#include <cstdint>

namespace ns3
{
namespace mtcaodv
{

/**
 * @ingroup mtcaodv
 *
 * @brief Immutable numerical result of the STEP 0 application measurement.
 *
 * Packet and byte counters are observations emitted by the applications, not
 * values inferred from the configured traffic rate.  Application bytes count
 * useful payload only: the SeqTsSize instrumentation header is intentionally
 * excluded from appTxBytes/appRxBytes and included in FlowMonitor network
 * bytes.  This separation implements the throughput/goodput distinction in
 * Equation (25) of the project specification.
 */
struct BaselineMetricSummary
{
    /** @brief Successfully transmitted application data units. Unit: packets. */
    uint64_t appTxPackets{0};

    /** @brief Delivered application data units. Unit: packets. */
    uint64_t appRxPackets{0};

    /** @brief Useful application payload successfully transmitted. Unit: bytes. */
    uint64_t appTxBytes{0};

    /** @brief Useful application payload delivered. Unit: bytes. */
    uint64_t appRxBytes{0};

    /** @brief Network-layer bytes delivered for the measured UDP flows. Unit: bytes. */
    uint64_t networkRxBytes{0};

    /** @brief Packet Delivery Ratio from Equation (20). Domain: [0,1] or NaN. */
    double pdr{0.0};

    /** @brief Packet Loss Ratio from Equation (24). Domain: [0,1] or NaN. */
    double plr{0.0};

    /** @brief Received network throughput from Equation (25). Unit: bit/s. */
    double throughputBitsPerSecond{0.0};

    /** @brief Delivered useful-payload goodput from Equation (25). Unit: bit/s. */
    double goodputBitsPerSecond{0.0};

    /** @brief Mean application end-to-end delay from Equation (26). Unit: s or NaN. */
    double meanDelaySeconds{0.0};
};

/**
 * @ingroup mtcaodv
 *
 * @brief Collects the minimal real measurements required by the healthy AODV
 *        baseline.
 *
 * The collector is deliberately independent of the Blackhole ground truth and
 * of every future defense component.  It consumes public OnOffApplication and
 * PacketSink traces.  SeqTsSizeHeader is used only as measurement metadata in
 * the UDP application payload; its serialized bytes are excluded from useful
 * goodput and included in network throughput.
 *
 * This class is not an ns3::Object because it owns no simulator lifecycle,
 * Attribute, or TraceSource.  A TypeId would therefore add registry state
 * without providing a configuration or tracing benefit.
 */
class BaselineMetricsCollector
{
  public:
    /**
     * @brief Construct an empty collector for a fixed evaluation window.
     * @param evaluationDuration Duration used in rate denominators. Unit: time;
     *        it must be strictly positive.
     * @throws std::invalid_argument when the duration is not positive.
     */
    explicit BaselineMetricsCollector(Time evaluationDuration);

    /** @brief Destroy the collector. */
    ~BaselineMetricsCollector();

    /**
     * @brief Callback for the successful OnOffApplication `Tx` TraceSource.
     * @param packet Successfully sent UDP application data unit, including the
     *        serialized SeqTsSizeHeader.
     *
     * OnOffApplication emits `Tx` only after Socket::Send() accepts the complete
     * packet.  Counting this trace therefore satisfies the requirement to use
     * actual transmissions rather than the configured number of packets.
     */
    void ObserveSuccessfulApplicationTx(Ptr<const Packet> packet);

    /**
     * @brief Callback for PacketSink `RxWithSeqTsSize`.
     * @param payload Packet after PacketSink removed SeqTsSizeHeader; its size is
     *        the delivered useful application payload in bytes.
     * @param sourceAddress Source socket address carried by the trace.
     * @param destinationAddress Local sink address carried by the trace.
     * @param header Header containing the source timestamp and complete ADU size.
     */
    void ObserveApplicationRxWithSeqTsSize(Ptr<const Packet> payload,
                                           const Address& sourceAddress,
                                           const Address& destinationAddress,
                                           const SeqTsSizeHeader& header);

    /**
     * @brief Record one accepted application transmission deterministically.
     * @param payloadBytes Useful payload size. Unit: bytes; must be positive.
     *
     * This method is the testable calculation core used by the Tx callback.
     */
    void RecordSuccessfulTransmission(uint32_t payloadBytes);

    /**
     * @brief Record one delivered application packet and its delay.
     * @param payloadBytes Useful delivered payload. Unit: bytes; positive.
     * @param transmissionTime Timestamp created at the source. Unit: time.
     * @param receptionTime Timestamp observed at the sink. Unit: time.
     * @throws std::invalid_argument for zero payload or a negative delay.
     *
     * The difference receptionTime-transmissionTime is the per-packet term in
     * Equation (26).
     */
    void RecordSuccessfulReception(uint32_t payloadBytes,
                                    Time transmissionTime,
                                    Time receptionTime);

    /**
     * @brief Supply the network-layer bytes observed by FlowMonitor.
     * @param networkReceivedBytes Sum of rxBytes for the measured UDP flows.
     *        Unit: bytes.
     *
     * The value is supplied after Simulator::Run(), when FlowMonitor statistics
     * are complete.  Calling this method more than once replaces the previous
     * value explicitly rather than accumulating duplicate reads.
     */
    void SetNetworkReceivedBytes(uint64_t networkReceivedBytes);

    /**
     * @brief Validate counter relationships that must hold for this UDP pilot.
     * @throws std::logic_error when received counts exceed transmitted counts,
     *         network bytes are absent, or delay sampling is incomplete.
     */
    void ValidateInvariants() const;

    /**
     * @brief Compute Equations (20), (24), (25), and (26).
     * @return A value object containing counters and derived metrics.
     *
     * PDR, PLR, and mean delay are NaN when their mathematical denominator is
     * zero.  They are never replaced with an artificial zero.
     * @throws std::logic_error when ValidateInvariants() fails.
     */
    BaselineMetricSummary BuildSummary() const;

    /**
     * @brief Return the evaluation-window duration.
     * @return Positive duration used by throughput and goodput formulas.
     */
    Time GetEvaluationDuration() const;

  private:
    /** @brief Fixed denominator window for rate metrics. Unit: time. */
    Time m_evaluationDuration;

    /** @brief Successfully transmitted useful application units. Unit: packets. */
    uint64_t m_appTxPackets;

    /** @brief Successfully delivered useful application units. Unit: packets. */
    uint64_t m_appRxPackets;

    /** @brief Useful payload accepted by UDP source sockets. Unit: bytes. */
    uint64_t m_appTxBytes;

    /** @brief Useful payload delivered by the UDP sink. Unit: bytes. */
    uint64_t m_appRxBytes;

    /** @brief Sum of end-to-end delays for delivered packets. Unit: time. */
    Time m_delaySum;

    /** @brief Number of delivered packets contributing a valid delay sample. */
    uint64_t m_delaySampleCount;

    /** @brief Network-layer bytes delivered for application flows. Unit: bytes. */
    uint64_t m_networkRxBytes;

    /** @brief True after FlowMonitor supplied its completed byte observation. */
    bool m_hasNetworkReceivedBytes;
};

} // namespace mtcaodv
} // namespace ns3

#endif // MTC_AODV_BASELINE_METRICS_H
