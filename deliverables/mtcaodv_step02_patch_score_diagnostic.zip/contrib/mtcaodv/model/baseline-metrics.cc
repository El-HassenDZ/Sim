/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * This file is part of the MTC-AODV research prototype.
 */

#include "baseline-metrics.h"

#include "ns3/simulator.h"

#include <limits>
#include <stdexcept>

namespace ns3
{
namespace mtcaodv
{

BaselineMetricsCollector::BaselineMetricsCollector(Time evaluationDuration)
    : m_evaluationDuration(evaluationDuration),
      m_appTxPackets(0),
      m_appRxPackets(0),
      m_appTxBytes(0),
      m_appRxBytes(0),
      m_delaySum(Seconds(0)),
      m_delaySampleCount(0),
      m_networkRxBytes(0),
      m_hasNetworkReceivedBytes(false)
{
    // Rate equations require a strictly positive denominator.  Rejecting the
    // configuration here avoids producing infinities later in the CSV.
    if (!evaluationDuration.IsStrictlyPositive())
    {
        throw std::invalid_argument("evaluationDuration must be strictly positive");
    }
}

BaselineMetricsCollector::~BaselineMetricsCollector() = default;

void
BaselineMetricsCollector::ObserveSuccessfulApplicationTx(Ptr<const Packet> packet)
{
    if (!packet)
    {
        throw std::invalid_argument("Tx trace supplied a null packet");
    }

    SeqTsSizeHeader instrumentationHeader;
    const uint32_t instrumentationBytes = instrumentationHeader.GetSerializedSize();

    // The pilot enables SeqTsSizeHeader on every source.  `Tx` observes the
    // complete accepted ADU, so removing exactly the known header size yields
    // useful payload without relying on the configured packet count or rate.
    if (packet->GetSize() <= instrumentationBytes)
    {
        throw std::logic_error("Tx packet does not contain a positive instrumented payload");
    }

    RecordSuccessfulTransmission(packet->GetSize() - instrumentationBytes);
}

void
BaselineMetricsCollector::ObserveApplicationRxWithSeqTsSize(
    Ptr<const Packet> payload,
    const Address& sourceAddress,
    const Address& destinationAddress,
    const SeqTsSizeHeader& header)
{
    // Addresses belong to the trace contract and are intentionally retained in
    // the callback signature.  STEP 0 aggregates all configured UDP sources;
    // flow-level attribution is performed independently by FlowMonitor.
    (void)sourceAddress;
    (void)destinationAddress;

    if (!payload)
    {
        throw std::invalid_argument("Rx trace supplied a null packet");
    }

    const uint64_t encodedApplicationDataUnitBytes = header.GetSize();
    const uint32_t instrumentationBytes = header.GetSerializedSize();

    // PacketSink removes SeqTsSizeHeader before emitting this trace.  Checking
    // the advertised ADU size protects the payload counter against a malformed
    // or accidentally uninstrumented traffic source.
    if (encodedApplicationDataUnitBytes < instrumentationBytes ||
        encodedApplicationDataUnitBytes - instrumentationBytes != payload->GetSize())
    {
        throw std::logic_error("Rx payload size is inconsistent with SeqTsSizeHeader");
    }

    RecordSuccessfulReception(payload->GetSize(), header.GetTs(), Simulator::Now());
}

void
BaselineMetricsCollector::RecordSuccessfulTransmission(uint32_t payloadBytes)
{
    if (payloadBytes == 0)
    {
        throw std::invalid_argument("A measured application payload must be positive");
    }

    ++m_appTxPackets;
    m_appTxBytes += payloadBytes;
}

void
BaselineMetricsCollector::RecordSuccessfulReception(uint32_t payloadBytes,
                                                     Time transmissionTime,
                                                     Time receptionTime)
{
    if (payloadBytes == 0)
    {
        throw std::invalid_argument("A delivered application payload must be positive");
    }

    // A negative delay indicates an invalid timestamp or event ordering.  It
    // must stop validation instead of being clipped to a plausible value.
    if (receptionTime < transmissionTime)
    {
        throw std::invalid_argument("Reception time precedes transmission time");
    }

    ++m_appRxPackets;
    m_appRxBytes += payloadBytes;
    m_delaySum += receptionTime - transmissionTime;
    ++m_delaySampleCount;
}

void
BaselineMetricsCollector::SetNetworkReceivedBytes(uint64_t networkReceivedBytes)
{
    m_networkRxBytes = networkReceivedBytes;
    m_hasNetworkReceivedBytes = true;
}

void
BaselineMetricsCollector::ValidateInvariants() const
{
    // UDP unicast in this pilot has one sink delivery for at most one accepted
    // source transmission.  A larger Rx count indicates trace contamination or
    // duplicate delivery and would invalidate PDR as a probability.
    if (m_appRxPackets > m_appTxPackets)
    {
        throw std::logic_error("appRxPackets exceeds appTxPackets");
    }

    if (m_appRxBytes > m_appTxBytes)
    {
        throw std::logic_error("appRxBytes exceeds appTxBytes");
    }

    // Every RxWithSeqTsSize event produces exactly one delay sample.  Keeping
    // this equality explicit prevents a partial delay mean from being reported
    // as though it covered all delivered packets.
    if (m_delaySampleCount != m_appRxPackets)
    {
        throw std::logic_error("The delay sample count differs from appRxPackets");
    }

    if (!m_hasNetworkReceivedBytes)
    {
        throw std::logic_error("FlowMonitor network received bytes were not supplied");
    }

    // Network bytes include the instrumentation, UDP, and IPv4 headers, so the
    // total cannot be smaller than the useful payload delivered by PacketSink.
    if (m_networkRxBytes < m_appRxBytes)
    {
        throw std::logic_error("networkRxBytes is smaller than delivered payload bytes");
    }
}

BaselineMetricSummary
BaselineMetricsCollector::BuildSummary() const
{
    ValidateInvariants();

    BaselineMetricSummary summary;
    summary.appTxPackets = m_appTxPackets;
    summary.appRxPackets = m_appRxPackets;
    summary.appTxBytes = m_appTxBytes;
    summary.appRxBytes = m_appRxBytes;
    summary.networkRxBytes = m_networkRxBytes;

    const double undefinedMetric = std::numeric_limits<double>::quiet_NaN();
    const double evaluationSeconds = m_evaluationDuration.GetSeconds();

    // Equation (20): PDR uses actual successful application transmissions and
    // actual PacketSink deliveries.  A zero denominator remains undefined.
    if (m_appTxPackets > 0)
    {
        summary.pdr = static_cast<double>(m_appRxPackets) /
                      static_cast<double>(m_appTxPackets);

        // Equation (24): PLR is the complementary loss fraction under the
        // already-validated Rx <= Tx invariant.
        summary.plr = 1.0 - summary.pdr;
    }
    else
    {
        summary.pdr = undefinedMetric;
        summary.plr = undefinedMetric;
    }

    // Equation (25): throughput includes network headers measured by
    // FlowMonitor, while goodput includes only useful application payload.
    summary.throughputBitsPerSecond =
        8.0 * static_cast<double>(m_networkRxBytes) / evaluationSeconds;
    summary.goodputBitsPerSecond =
        8.0 * static_cast<double>(m_appRxBytes) / evaluationSeconds;

    // Equation (26): report no artificial delay when no packet arrived.
    summary.meanDelaySeconds =
        m_appRxPackets > 0
            ? m_delaySum.GetSeconds() / static_cast<double>(m_appRxPackets)
            : undefinedMetric;

    return summary;
}

Time
BaselineMetricsCollector::GetEvaluationDuration() const
{
    return m_evaluationDuration;
}

} // namespace mtcaodv
} // namespace ns3
