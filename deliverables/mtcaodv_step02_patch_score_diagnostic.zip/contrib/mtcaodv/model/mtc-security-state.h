/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * This file is part of the MTC-AODV research prototype.
 */

#ifndef MTC_SECURITY_STATE_H
#define MTC_SECURITY_STATE_H

#include <string>

namespace ns3
{
namespace mtcaodv
{

/**
 * @ingroup mtcaodv
 *
 * @brief Local per-neighbour security state (specification Section 3.4).
 *
 * The five states form the state machine NORMAL -> WATCH -> ACCUSED ->
 * QUARANTINED -> REHABILITATING defined in Section 9.5.  Only NORMAL and WATCH
 * are reachable in STEP 2: RREP anomaly screening may raise a neighbour to
 * WATCH (renforced observation) but, per the invariants, it can NEVER quarantine
 * or otherwise exclude a route.  The later states are declared here so the enum
 * is stable across steps; they are introduced by STEP 4+ (accusation) and
 * STEP 7+ (certified quarantine).
 */
enum class SecurityState
{
    NORMAL = 0,        //!< No current reason for reinforced monitoring.
    WATCH = 1,         //!< Local suspicion; reinforced observation, NO exclusion.
    ACCUSED = 2,       //!< Posterior accusation criteria met (STEP 4+); not STEP 2.
    QUARANTINED = 3,   //!< Valid certificate excludes the route (STEP 7+); not STEP 2.
    REHABILITATING = 4 //!< Progressive return after expiry/revocation (STEP 7+).
};

/**
 * @brief Human-readable name of a security state (for traces/manifests).
 * @param state Security state value.
 * @return A stable lowercase label.
 */
inline std::string
SecurityStateName(SecurityState state)
{
    switch (state)
    {
    case SecurityState::NORMAL:
        return "NORMAL";
    case SecurityState::WATCH:
        return "WATCH";
    case SecurityState::ACCUSED:
        return "ACCUSED";
    case SecurityState::QUARANTINED:
        return "QUARANTINED";
    case SecurityState::REHABILITATING:
        return "REHABILITATING";
    }
    return "UNKNOWN";
}

} // namespace mtcaodv
} // namespace ns3

#endif // MTC_SECURITY_STATE_H
