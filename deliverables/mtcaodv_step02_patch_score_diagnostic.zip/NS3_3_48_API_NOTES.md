# ns-3.48 API notes — MTC-AODV STEP 0

This note records the public contracts used by the STEP 0 source. It is a
static API review, not a claim that the package compiled in the current
environment. Final compatibility remains **À compiler et tester sur le PC
utilisateur**.

| API/contract used | STEP 0 use | Verification consequence |
|---|---|---|
| `MobilityHelper::SetPositionAllocator(Ptr<PositionAllocator>)` and `Install(Ptr<Node>)` | One separately configured RandomWaypoint instance per node | Avoids a global coordinator and permits explicit per-node RNG objects |
| `RandomWaypointMobilityModel` Attributes `Speed`, `Pause`, `PositionAllocator` | Dynamic movement with values supplied as `PointerValue` | Speed, pause and destination selection remain visible and streamable |
| `RandomRectanglePositionAllocator` Attributes `X` and `Y` | Initial and subsequent waypoints inside the square area | Both coordinates use explicit `UniformRandomVariable` streams |
| `RandomVariableStream::SetStream(int64_t)` | X/Y/speed/pause stream binding | No `std::rand()` or implicit mobility stream is used |
| `WifiMacHelper::SetType("ns3::AdhocWifiMac")` | Required ad hoc MAC | No infrastructure AP or coordinator is introduced |
| `WifiHelper::AssignStreams(NetDeviceContainer, int64_t)` | Wi-Fi PHY/MAC reproducibility | Returned consumption is written to CSV/manifest |
| `AodvHelper::AssignStreams(NodeContainer, int64_t)` | Official AODV reproducibility after stack installation | `src/aodv/` remains untouched |
| `OnOffApplication` Attribute `EnableSeqTsSizeHeader` | Adds sequence/timestamp/ADU-size measurement metadata | CLI packet size remains defined as useful payload by adding header bytes internally |
| `OnOffApplication` TraceSource `Tx` | Successful source transmission counter | This trace is emitted only after the complete packet is accepted by `Socket::Send()` |
| `OnOffApplication::AssignStreams(int64_t)` | Explicit application RNG allocation | Even constant On/Off variables receive recorded streams |
| `PacketSink` Attribute `EnableSeqTsSizeHeader` | Parses the measurement header | Required for the paired Rx trace |
| `PacketSink` TraceSource `RxWithSeqTsSize` | Delivered useful bytes and timestamp | Callback signature is packet, source address, local address, and `const SeqTsSizeHeader&` |
| `SeqTsSizeHeader::GetTs()`, `GetSize()`, `GetSerializedSize()` | Delay and payload/header separation | Avoids relying on packet UIDs or a configured packet count |
| `FlowMonitorHelper::InstallAll()` and IPv4 classifier `FindFlow()` | Network received bytes for data UDP five-tuples | Destination port 9000 filters out AODV control port 654 |
| `FlowMonitor::GetFlowStats()` / `FlowStats::rxBytes` | Equation (25) network-throughput numerator | Raw XML is also retained for diagnosis |
| `Ipv4AddressHelper::SetBase()` | Exact pilot address plan | Source contains the required literal call for `10.1.0.0/24` |
| `RngSeedManager::ResetNextStreamIndex()` | Repeatability in reused processes | Called before stochastic object construction |
| `Ipv4AddressGenerator::Reset()` | Repeatability of address allocation | Prevents stale process-global allocation state |

## Exact normative address code

```cpp
Ipv4AddressHelper ipv4;
ipv4.SetBase("10.1.0.0", "255.255.255.0");
```

## Deliberate non-claims

- No ns-3.48 compilation was performed in this workspace.
- No PDR, throughput, goodput, or delay value is predicted.
- The pilot radio/load defaults are not frozen confirmatory parameters.
- FlowMonitor does not replace the application traces: it supplies only the
  network-byte numerator needed to distinguish throughput from goodput.
- No attack or defense mechanism is activated in this executable.

---

# ns-3.48 API notes — MTC-AODV STEP 1 (forked AODV + attack hooks)

The forked routing protocol is a byte-for-byte copy of the ns-3.48
`src/aodv/` sources (fetched from the `ns-3.48` tag) with only a namespace /
TypeId / log-component rename and two behavioural hooks added. The following
real contracts were inspected in those sources before use (no API was guessed):

| API/contract (ns-3.48 `src/aodv`) | STEP 1 use | Verification consequence |
|---|---|---|
| `aodv::RoutingProtocol::RecvRequest(Ptr<Packet>, Ipv4Address receiver, Ipv4Address src)` | Insertion point of the forged-RREP hook, right after the reverse route `toOrigin` is created/updated and `m_nb.Update(src,...)` | Reverse route is guaranteed present, so the forged reply is deliverable |
| `aodv::RoutingProtocol::Forwarding(Ptr<const Packet>, const Ipv4Header&, UnicastForwardCallback, ErrorCallback)` returning `bool` | Silent-drop hook at the top; returns `true` (consumed) without `ucb`/`ecb`/RERR | Models a full-Blackhole silent drop; honest branches below are untouched |
| `aodv::RoutingProtocol::SendReply(const RreqHeader&, const RoutingTableEntry&)` | Template for `SendForgedReply()`: identical packaging (`SocketIpTtlTag` = `toOrigin.GetHop()`, `RrepHeader`, `TypeHeader(AODVTYPE_RREP)`, unicast to `toOrigin.GetNextHop()` on `AODV_PORT`) | Forged RREP is indistinguishable in format from a legitimate one |
| `RrepHeader(prefixSize, hopCount, dst, dstSeqNo, origin, lifetime)` | Forged reply fields from `ForgedReplyProfile` | Standard header; no hidden field extension |
| `RreqHeader::GetDst()`, `GetDstSeqno()` | Observed destination + sequence number feeding Eq. (23) | `seq_fake=(GetDstSeqno()+Δseq) mod 2^32` |
| `RoutingTableEntry::GetFlag()` / `RouteFlags::VALID` | Reverse-route usability test in the forge hook | Forge only over a VALID reverse route |
| `AODV_PORT = 654` | UDP control port for the forged unicast | Matches AODV control plane |
| `Object::AddTraceSource(name, help, MakeTraceSourceAccessor(&m), "signatureTypedef")` (4-arg form) | `ForgedReply` and `BlackholeDrop` TraceSources | 4th argument is a documentation string only; no real typedef is required at runtime |
| `TracedCallback<...>` from `ns3/traced-callback.h` | Experiment probes on the fork | Header explicitly includes `ns3/traced-callback.h` and `<cstdint>` |
| `AodvHelper` factory pattern (`m_agentFactory.SetTypeId("ns3::aodv::RoutingProtocol")`) | Cloned into `MtcAodvHelper` with TypeId `ns3::mtcaodv::RoutingProtocol` | Both modules coexist without a TypeId/log-component registry clash |
| `ConstantPositionMobilityModel`, `ListPositionAllocator`, `RangePropagationLossModel`, `PacketSink::GetTotalRx()` | STEP 1 diamond integration test (T-08) | Deterministic causal-chain check |

## Deliberate non-claims (STEP 1)

- No ns-3.48 C++ compilation or execution was performed in this workspace.
- Only the Python validator's 10 unit tests were run (offline, no ns-3).
- `src/aodv/` is NOT modified; the fork lives entirely in `contrib/mtcaodv/`.
- No PDR/throughput/goodput/delay/attack-count value is predicted.
- The attack policy executes ground truth supplied by the scenario layer; no
  detector/trust/ledger component exists yet, so none can read it.
