# STEP 4 — Attribution OCEA en quatre masses (A3.3, Éq. 6–10)

**Révision 2** — intègre les arbitrages de l'utilisateur sur `queuePressure`,
`predictedContactPersistence`, \(\varepsilon\), et la séparation entre
`passiveVisibility` et \(z_e\).

Document de **spécification**. Source normative :
`MTCAODV_Mathematical_Algorithms_Specification.md`, § 5.4 et algorithme A3.3.

---

## 1. Le fait qui détermine le périmètre

L'observateur du STEP 3 renseigne **une seule** caractéristique d'opportunité,
`passiveVisibility` ; les cinq indicateurs \(y_\ell\) sont marqués indisponibles.
A3.3 ligne 7 : `if d = 0 then return (0,0,0,1)`.

**Sur le run validé, OCEA renverrait une incertitude totale pour les 10 962
observations.** Conforme à la spécification, mais cela ne démontrerait qu'une
chose : que le cas « diagnostics indisponibles » est correctement traité.

Le corps de STEP 4 est donc **l'instrumentation et la validation des observables
qui alimentent A3.3**, pas les trente lignes d'arithmétique des équations.

---

## 2. Arbitrages tranchés (verrouillés)

### 2.1 `queuePressure` — indisponible

La file pertinente pour expliquer une non-retransmission est celle de \(j\).
**Aucune lecture de l'état interne de \(j\) dans la voie déployable.** Son
indicateur de disponibilité reste à zéro.

La file locale de \(i\) **ne doit pas être présentée sous le même nom**. Si elle
est utilisée un jour, ce sera comme un **proxy distinct de congestion locale**,
portant son propre nom, avec sa propre validation. Confondre les deux dans le
code ou dans un texte publié serait une faute de méthode, pas un raccourci.

### 2.2 `predictedContactPersistence` — indisponible, non supprimée

Elle n'est **pas** retirée de la spécification. Elle reste indisponible tant
qu'un estimateur fondé **uniquement sur l'historique local observable du lien
\(i\!-\!j\)** n'a pas été défini **et validé**. En l'absence d'un tel estimateur,
\(a_k(e) = 0\) en permanence.

Aucune lecture de `MobilityModel` de \(j\) : techniquement triviale en
simulation, scientifiquement invalide.

### 2.3 \(\varepsilon\) — pas un plancher

\(\varepsilon\) **n'est pas** utilisé comme plancher arbitraire sur \(x_k\) dans
l'Éq. (7). La forme normative traite explicitement \(c_e = 0\), et un
\(x_k = 0\) **réellement disponible doit pouvoir produire \(O_e = 0\)** — c'est
une information, pas une singularité à masquer.

Implémentation : si la moyenne géométrique passe par le domaine logarithmique,
le cas \(x_k = 0\) est traité **explicitement avant tout appel à \(\log\)**,
jamais remplacé par \(\varepsilon\).

**C-06 reste ouvert** jusqu'à ce que les usages numériques exacts de
\(\varepsilon\) et de `numericalTolerance` soient **figés par les tests**.

### 2.4 `passiveVisibility` ≠ \(z_e\)

`passiveVisibility` doit mesurer la **capacité de l'observateur à écouter
pendant la fenêtre**, indépendamment du résultat de cette écoute. \(z_e\) reste
un résultat séparé.

Le raisonnement à interdire : si `passiveVisibility = 0` parce qu'aucune
retransmission n'a été entendue, alors toute non-observation donne \(O_e = 0\),
puis \(I_e = 0\), et **aucune évidence malveillante ne peut jamais être
produite**. Le mécanisme s'auto-annulerait.

---

## 3. État réel de `passiveVisibility` : vérifié, et insuffisant

### 3.1 Pas de circularité — vérifié dans le code

`m_lastHeardFromNeighbor` n'est écrit que dans `LearnAddressMapping`, appelée
**uniquement** sous `packetType == PACKET_BROADCAST`. La retransmission
surveillée est un relais **unicast** (`PACKET_OTHERHOST`) : elle ne met jamais
cette table à jour.

```
z_e                ← appariement d'empreinte, trame UNICAST
passiveVisibility  ← réception de trames BROADCAST de j
```

Classes de trames **disjointes**. L'indépendance est structurelle.

Cette séparation provient d'une décision du spike C-17 prise pour une raison
différente — une trame unicast peut être un relais dont l'IP source est un tiers
— et non d'une anticipation de cet argument. Elle est correcte ; elle n'était
pas intentionnelle.

### 3.2 Le défaut réel : ce n'est pas la bonne grandeur

`passiveVisibility` mesure **l'activité broadcast de \(j\)**, pas la capacité
d'écoute de \(i\). AODV ne diffuse des RREQ que pendant la découverte ; en régime
établi, un voisin parfaitement audible peut ne rien diffuser pendant plusieurs
secondes.

`passiveVisibility = 0` confond donc :

- « je ne peux pas entendre \(j\) » — l'information voulue ;
- « \(j\) n'avait rien à diffuser dans les 150 dernières ms » — un artefact du
  protocole de routage.

Ce n'est pas circulaire, mais ce n'est pas ce que l'Éq. (7) demande.

### 3.3 Redirection proposée, à valider par la mesure

Sources d'audibilité **indépendantes de \(z_e\) pour l'événement \(e\)** :

- **toute trame attribuable à \(j\)** reçue pendant la fenêtre **autre que celle
  qui clôt \(e\)** — y compris les relais unicast de \(j\) portant sur d'autres
  flux, qui prouvent que \(j\) est vivant et audible sans rien dire de \(e\) ;
- **activité du canal** : l'observateur a-t-il reçu la moindre trame pendant la
  fenêtre ? Un canal totalement silencieux ne prouve pas que \(j\) se tait, il
  prouve que \(i\) n'écoutait rien d'utile.

Ces deux pistes ne sont **pas** retenues par décret : elles seront mesurées
avant d'être adoptées. La réserve à instruire : utiliser les autres relais de
\(j\) crée, à travers les événements, une corrélation avec l'honnêteté de \(j\)
— nulle pour \(e\) pris isolément, non nulle en agrégat.

---

## 4. Mesure préalable, sur données déjà produites

`experiments/analyze_features.py` mesure le **plafond d'attribution** avant
qu'une seule ligne de C++ soit écrite.

L'Éq. (7) étant une moyenne géométrique, une visibilité nulle donne
\(O_e = 0\) donc \(I_e = 0\) — **quels que soient les diagnostics \(y_\ell\)
instrumentés ensuite**. Donc :

> Le nombre de non-observations d'attaquant **avec** visibilité non nulle est une
> **borne dure** sur ce qu'OCEA peut attribuer avec l'instrumentation actuelle.

Si ce plafond est nul ou faible, instrumenter les \(y_\ell\) sans corriger la
caractéristique d'opportunité serait **sans effet**. Cette mesure décide donc
l'ordre des travaux, et elle est disponible immédiatement.

Le script rapporte aussi \(P(\text{visible} \mid z_e{=}1)\) et
\(P(\text{visible} \mid z_e{=}0)\). **Aucun seuil n'est préenregistré pour leur
écart** : un voisin physiquement joignable a plus de chances des deux côtés, donc
un écart est attendu et ne prouve **pas** une circularité. Le script rapporte, il
ne juge pas.

---

## 4bis. RÉSULTATS DE LA MESURE (seed=1, 10 962 événements)

Exécutée sur les données du STEP 3. Elle devait décider l'ordre des travaux ;
elle le fait, et elle **inverse** la partie B ci-dessous.

### Indépendance : confirmée

| comparaison | écart | SE | z |
|---|---|---|---|
| attaquant : visible \| z=1 − visible \| z=0 | +0.0022 | 0.0111 | **+0.20** |
| honnête : visible \| z=1 − visible \| z=0 | −0.0873 | 0.0648 | −1.35 |

Sur la comparaison bien dotée (n = 1 272 et 5 467), l'écart vaut 0,2 écart-type :
indistinguable de zéro. Chez l'honnête le signe est négatif — l'inverse d'une
circularité — mais n(z=0) = 30 ne permet aucune conclusion. L'argument
structurel du § 3.1 est confirmé empiriquement.

### Pouvoir discriminant : NUL

| | taux de visibilité |
|---|---|
| voisin honnête | 0.1466 |
| voisin attaquant | 0.1484 |

Écart **+0.0018**, SE 0.0070, **z = +0.26**. `passiveVisibility` ne distingue pas
un attaquant d'un nœud honnête. Le § 3.2 l'annonçait ; la mesure est bien plus
brutale que la formulation.

### Destruction de l'interprétabilité

**9 343 des 10 962 événements (85,2 %)** donneraient \(O_e = 0\) donc
\(I_e = 0\), quels que soient les \(y_\ell\) instrumentés ensuite.

Plafond chez l'attaquant : **809 sur 6 739 événements, soit 12,0 %**. La
visibilité ne discriminant rien, ces 809 sont un sous-échantillon **arbitraire**,
pas les cas informatifs.

### L'erreur de conception du STEP 3

Dans l'Éq. (7), **une caractéristique disponible valant exactement 0 est un veto
absolu, quel que soit son poids** : \(0^{\omega/c} = 0\) pour tout
\(\omega > 0\). Baisser \(\omega_{pv}\) ne corrigerait rien.

Or le code du STEP 3 écrit `passiveVisibility = 0` **avec `available = 1`**
quand \(j\) n'a rien diffusé dans la fenêtre. C'est une **affirmation** qu'il
n'y a eu aucune opportunité d'observation, alors qu'on sait seulement que \(j\)
n'a pas diffusé.

C'est le miroir de la faute que l'Éq. (6) existe pour empêcher, et que le même
fichier énonce en commentaire : *« remplir une valeur par défaut ferait passer
une observation partielle pour complète »*. Le piège a été évité dans un sens et
commis dans l'autre — proclamer une opportunité nulle là où il n'y a qu'une
absence de preuve.

**L'encodage honnête est `available = 0`, pas `value = 0`.** Indisponible réduit
la couverture \(c_e\) ; disponible-et-nul oppose un veto.

**CORRIGÉ dans cette révision.** `forwarding-observer.cc` ne déclare plus
`passiveVisibility` disponible que lorsque le voisin a effectivement été entendu
dans la fenêtre ; sinon `available = 0`. La suite `mtcaodv-forwarding-observer`
assure l'invariant *disponible ⇒ valeur non nulle*, qui ne dépend d'aucun aléa de
calendrier. `analyze_features.py` détecte et signale un CSV produit sous
l'ancien encodage plutôt que d'en tirer des taux trompeurs.

**Explication mécanique du 0,147.** AODV diffuse des HELLO périodiques
(`HelloInterval` = 1 s par défaut) et la fenêtre d'observation vaut 150 ms :
\(0{,}150 / 1{,}0 = 0{,}15\), à comparer aux 0,1466 et 0,1484 mesurés. La
« visibilité » ne mesurait donc ni l'audibilité ni l'honnêteté, mais la
probabilité qu'un HELLO tombe dans la fenêtre — une pure cadence de protocole.
L'accord quantitatif confirme le diagnostic.

### Ordre des travaux imposé par la mesure

1. **La caractéristique d'opportunité d'abord.** Instrumenter les \(y_\ell\)
   en premier serait quasi sans effet : 85 % des événements resteraient à
   \(O_e = 0\).
2. **Candidat prioritaire : `linkReliability`** — historique des émissions de
   \(i\) vers \(j\). Local, légitime, disponible pour ~100 % des événements
   (une fenêtre ne s'ouvre qu'après une émission de \(i\) vers \(j\)), et
   **graduée** dans \([0,1]\) donc n'atteignant quasi jamais le veto exact.
   Limite énoncée : elle mesure le lien \(i \to j\) alors que l'écoute dépend
   du lien \(j \to i\) ; corrélés en canal réciproque, non identiques.
3. **Règle générale.** Une caractéristique **binaire** dans l'Éq. (7) est un veto
   déguisé. Préférer des grandeurs graduées, et réserver la valeur 0 aux cas où
   l'on sait réellement qu'il n'y avait aucune opportunité.

## 4ter. `linkReliability` : mesure ACTIVE, instrumentée

**Sources vérifiées dans l'arbre ns-3.48 de l'utilisateur**, non supposées :

| trace | signature | emplacement |
|---|---|---|
| `AckedMpdu` | `void(Ptr<const WifiMpdu>)` | `src/wifi/model/wifi-mac.cc:333` |
| `NAckedMpdu` | `void(Ptr<const WifiMpdu>)` | `src/wifi/model/wifi-mac.cc:338` |

`WifiMpdu::GetHeader().GetAddr1()` porte la MAC du destinataire.

**Pourquoi une mesure active est nécessaire.** L'écoute passive ne peut pas
distinguer « \(j\) est inaudible » de « \(j\) est silencieux » : c'est une
limite d'information, pas un manque d'implémentation. Le 0,147 en est la
démonstration chiffrée. Un ACK MAC, lui, prouve que \(j\) a reçu — donc qu'il y
avait une opportunité de le voir relayer.

**Pourquoi cela devrait discriminer là où `passiveVisibility` échouait.** Un
Blackhole **acquitte normalement** — l'acquittement est matériel, il ne relève
pas de la politique de transfert. Il présentera donc une fiabilité **élevée**
tout en ne relayant rien. C'est exactement le signal que l'Éq. (7) doit capter :
opportunité forte + aucune retransmission = évidence. À **vérifier par la
mesure**, non à supposer.

**Structure bornée par construction.** Les 32 dernières issues tiennent dans un
`uint32_t`, bit de poids faible = la plus récente ; au-delà, elles sortent du mot
d'elles-mêmes. Aucune allocation, aucun élagage périodique qu'on pourrait
oublier. Table plafonnée par `MaxLearnedAddresses`.

**Disponibilité.** `available` seulement si ≥ `LinkReliabilityMinSamples` (4 par
défaut) issues sont connues **et** si la MAC du voisin a été apprise. En deçà,
**indisponible** — une fraction calculée sur une ou deux émissions vaudrait 0 ou
1 sur presque rien.

**La valeur 0 y est LÉGITIME**, contrairement à `passiveVisibility` : si aucune
émission récente vers \(j\) n'a été acquittée, il n'y avait réellement aucune
opportunité, et le veto de l'Éq. (7) est la bonne réponse. C'est le cas auquel
la valeur 0 doit être réservée.

**LIMITE ÉNONCÉE.** Ceci mesure le lien \(i \to j\) alors que l'écoute dépend
du lien \(j \to i\). Corrélés en canal réciproque, non identiques. C'est une
hypothèse de modélisation ; elle est écrite dans le code et doit être citée
comme telle dans tout texte publié.

## 4quater. RÉSULTAT : la couverture passe de 14,7 % à 99,4 %

Mesuré sur le même run (seed=1, 10 962 événements) après instrumentation.

| | `passiveVisibility` | `linkReliability` | couverture \(c_e > 0\) | plafond réel | ancien |
|---|---|---|---|---|---|
| honnête | 0.1466 | **0.9905** | **0.9943** | 30 / 30 | 7 |
| attaquant | 0.1484 | **0.9933** | **0.9939** | **5 441 / 5 467** | 809 |

85,2 % des événements étaient annulés ; il en reste 0,6 %. **Aucun veto par
`linkReliability = 0`** : le chemin « valeur nulle légitime » n'est donc pas
exercé par ces données — il reste testé unitairement, pas empiriquement.

### Correction d'une confusion que j'avais introduite au § 4bis

J'y reprochais à `passiveVisibility` son absence de pouvoir discriminant
(z = +0.26). **Ce reproche était mal posé.**

> **Une caractéristique d'opportunité n'a pas à discriminer.** Son rôle est
> d'établir qu'observer *était possible*, pour qu'une non-observation devienne
> interprétable. La grandeur discriminante est \(z_e\), pas \(x_k\).

Des valeurs proches entre honnête et attaquant sont donc **attendues** pour une
bonne caractéristique d'opportunité. Ce qui condamnait `passiveVisibility`
n'était pas l'absence de discrimination mais le **veto sur 85 % des
événements** — l'absence de discrimination n'en était que le *symptôme*,
révélant qu'elle mesurait la cadence des HELLO et non l'opportunité.

Confondre les deux aurait conduit à rejeter `linkReliability` pour la même
raison, alors qu'elle se comporte correctement.

### Le facteur limitant a changé

L'instrumentation d'opportunité n'est plus le goulot. **Le facteur limitant est
désormais \(d_e\)** : sans aucun diagnostic \(y_\ell\), l'Éq. (8) renvoie
toujours \((0,0,0,1)\) via la ligne 7 d'A3.3. La partie B peut donc reprendre
son ordre initial — les diagnostics viennent maintenant.

### Défaut corrigé dans le script

`analyze_features.py` imprimait une conclusion contredite par ses propres
chiffres trois lignes plus haut (« `passiveVisibility` est la SEULE
caractéristique », « au plus 809 »). Le texte narratif n'avait pas suivi
l'ajout de la caractéristique. Corrigé, et la **valeur** de `linkReliability`
est désormais rapportée — moyenne globale, et ventilée selon \(z_e\) — car ne
mesurer que la disponibilité était exactement l'erreur commise avec
`passiveVisibility`.

## 4quinquies. `linkReliability` était borgne : mesuré, puis corrigé

**Mesure :** `linkSuccesses = 23 284`, `linkFailures = 0`. Exactement zéro, et
`linkReliability = 1.0000` partout — moyenne, médiane, ventilée selon \(z_e\),
honnête et attaquant.

**Cause :** seule `AckedMpdu` était branchée. En 802.11b avec ACK normal, une
émission qui épuise ses retransmissions part dans **`DroppedMpdu`**, pas dans
`NAckedMpdu` qui ne concerne que les NACK de *block ack*. Seuls les succès
étaient comptés, donc la fiabilité valait structurellement 1.

**Ce qui n'est pas remis en cause :** le gain de couverture, 14,7 % → 99,4 %.
**Ce qui l'est :** la valeur ne portait aucune information.

### Filtrage par raison, et pourquoi il est nécessaire

`WifiMacDropReason` (lu dans `wifi-mac.h:70`) compte quatre valeurs :

| raison | nature | défaillance de LIEN ? |
|---|---|---|
| `WIFI_MAC_DROP_REACHED_RETRY_LIMIT` | pair muet malgré retransmissions | **oui** |
| `WIFI_MAC_DROP_FAILED_ENQUEUE` | file pleine chez \(i\) | non — congestion locale |
| `WIFI_MAC_DROP_EXPIRED_LIFETIME` | attente en file trop longue | non — congestion locale |
| `WIFI_MAC_DROP_QOS_OLD_PACKET` | ordonnancement QoS | non |

Les compter toutes ferait de `linkReliability` une **mesure de congestion
déguisée**, portant deux phénomènes distincts sous un seul nom.

Les quatre compteurs sont rapportés séparément : sans eux, « 0 échec » resterait
indiscernable de « la trace n'est pas branchée » — l'ambiguïté même qui a permis
au défaut de survivre.

### Convergence pour un futur diagnostic

`FAILED_ENQUEUE` et `EXPIRED_LIFETIME` sont exactement le **proxy local de
congestion** autorisé en § 2.1, à condition qu'il porte un nom distinct. Une
seule trace fournit donc les deux signaux, séparés par leur raison. Ils ne sont
pas fondus dans `linkReliability` et ne le seront pas.

### Pré-enregistrement, pour ne pas rationaliser après coup

Après ce branchement, deux issues sont possibles et la conclusion est fixée
**d'avance** :

- **`macDropsRetryLimit > 0`** → la fiabilité varie, la caractéristique porte
  enfin de l'information, et sa distribution devient mesurable.
- **`macDropsRetryLimit = 0`** → les liens de ce scénario ne défaillent
  réellement jamais au niveau MAC. `linkReliability` reste alors constante à
  1,0 : **correcte mais muette**. Il faudra le dire ainsi, et non présenter une
  constante comme une mesure. La conséquence serait qu'à 200 m de portée avec
  `RangePropagationLossModel` — un modèle binaire tout-ou-rien, sans
  évanouissement — l'échec de lien n'existe pas par construction du canal, et
  la caractéristique d'opportunité devrait être cherchée ailleurs ou le modèle
  de propagation reconsidéré.

## 4sexies. `DroppedMpdu` branchée : cas A, mais l'intuition du cas B tenait

**Mesure :** `linkSuccesses = 23 284`, `linkFailures = 37`, tous en
`macDropsRetryLimit` ; les trois autres raisons valent 0. Le pré-enregistrement
désigne donc le **cas A** : la fiabilité varie.

**Mais l'intuition du cas B était juste sur le fond.** Plage dynamique observée :
**0,9928 à 1,0000**, pour un taux d'échec global de 0,159 %. Comparée à la
variation de la couverture (0,147 → 0,993), la contribution des *valeurs* à
\(O_e\) est négligeable : \(O_e \approx c_e\). `RangePropagationLossModel`
est bien un canal quasi binaire ; le compteur non nul ne le contredit pas.

| | moyenne | \| retransmission vue | \| AUCUNE retransmission |
|---|---|---|---|
| honnête | 0.9993 | 0.9994 | **0.9928** |
| attaquant | 0.9998 | 1.0000 | **0.9998** |

### Le signal est là, mais la moyenne l'écrase

Sur une plage de 0,993 à 1,000, une moyenne est illisible. Ré-exprimé en
**fraction d'événements dont le lien a récemment défailli**, le même fait
devient net. Les valeurs déduites des moyennes suggèrent ~23 % côté honnête
contre ~0,6 % côté attaquant, soit un facteur ~36.

**Ces chiffres sont INFÉRÉS des moyennes, pas mesurés.** `analyze_features.py`
mesure désormais la fraction **directement** — `LIEN DEGRADE (fiabilite < 1)`,
ventilée selon \(z_e\) — précisément pour ne pas fonder une conclusion sur une
déduction. Les valeurs mesurées remplaceront les valeurs déduites.

### Réserve de conception, non tranchée

Le raisonnement qui rend ce signal intéressant est le suivant : *une défaillance
récente du lien est une explication **bénigne** d'une non-observation — le voisin
n'a peut-être jamais reçu le paquet.*

Or c'est la définition d'un diagnostic \(y_\ell\) (Éq. 8), pas d'une
caractéristique d'opportunité \(x_k\) (Éq. 7), rôle sous lequel `linkReliability`
est actuellement instrumentée.

Employer la même grandeur dans les deux équations demande une **justification
explicite** : \(O_e\) faible réduit \(I_e\) donc augmente l'incertitude, tandis
que \(\bar B_e\) élevé déplace la masse vers le bénin. Les deux effets sont
distincts, mais adossés au même fait. Sans justification, le même événement
serait compté deux fois. **À trancher avant l'implémentation d'A3.3.**

## 4septies. ARBITRAGE : option (1) avec séparation temporelle stricte

Décision utilisateur, normative.

### La règle

\[
x_{\mathrm{link}}(e) = \widehat R_{ij}(t_e^-)
\]

`linkReliability` **reste** une caractéristique d'opportunité \(x_k\), calculée
**uniquement** à partir de l'historique disponible **avant** l'ouverture de la
fenêtre. Elle répond à : *avant d'observer le résultat de cet événement,
avions-nous de bonnes raisons de penser que le paquet pouvait atteindre \(j\) ?*

Le diagnostic bénin sera une variable **distincte**
\(y_{\mathrm{link\text{-}failure}}(e)\), construite à partir d'informations
observées **pendant** l'événement. Elle répond à une autre question : *avons-nous
observé pendant cet événement un mécanisme bénin susceptible d'expliquer la
non-retransmission ?*

**Rejeté** : \(x_{\mathrm{link}} = r,\; y_{\mathrm{link}} = 1-r\) depuis le
même \(r\). Cela appliquerait deux fois la même information sans modèle
probabiliste justifiant la factorisation.

**Invariant normatif** : \(x_{\mathrm{link}}(e)\) est **gelée à l'ouverture** et
ne doit jamais incorporer l'issue de \(e\) avant le calcul des masses.

### La fuite existait dans le code livré

`linkReliability` était calculée dans `CloseWindow()`, 0 à 150 ms après
l'ouverture. Dans cet intervalle, l'issue MAC de la transmission qui a **ouvert**
la fenêtre est enregistrée — l'ACK arrive en moins d'une milliseconde.

Le couplage est **causal**, pas statistique : un échec MAC vers \(j\) implique
que \(j\) n'a jamais reçu le paquet, donc \(z_e = 0\) **forcé**. La
caractéristique d'opportunité prédisait son propre résultat.

**Conséquence sur le § 4sexies.** L'écart honnête `0.9928` (non-observé) contre
`0.9994` (observé), présenté comme « causalement intéressant », est au moins en
partie cette contamination. L'inférence des ~23 % était en outre fragile pour une
seconde raison : elle confondait « échec de CETTE transmission » et « échec
quelque part dans les 32 dernières », un même échec dégradant jusqu'à 32
événements consécutifs. **Ce chiffre est retiré.**

### Correction et vérification sur traces

- `OpenWindowRecord` porte `linkReliabilityAtOpen`, capturée dans `OpenWindow()`.
  Celle-ci est appelée depuis la trace `Ipv4L3Protocol`, donc **au niveau IP,
  avant que le paquet n'atteigne le MAC** : l'issue de l'événement ne peut
  structurellement pas y figurer.
- `CloseWindow()` utilise la valeur gelée, sans recalcul.
- La valeur recalculée à la clôture est exportée comme
  `linkReliabilityAtClose` — **DIAGNOSTIC UNIQUEMENT, n'entre dans aucune
  équation**. L'écart entre les deux colonnes **est** la contamination
  supprimée, et le compteur `linkReliabilityChangedDuringWindow` la totalise.

C'est la vérification sur traces exigée au point 5 : elle mesure le défaut au
lieu de se contenter de l'avoir corrigé.

### Option (2) écartée comme modèle normatif

Si `linkReliability` devenait uniquement \(y_\ell\) sans autre \(x_k\) valide,
la formulation actuelle donne \(c_e = 0\) puis \(O_e = 0\), et non une
opportunité utile. Poser \(O_e = c_e\) serait une **modification supplémentaire
de l'Éq. (7)**, à évaluer séparément.

Le constat \(O_e \approx c_e\) justifie en revanche une **ablation
« coverage-only »** contre l'Éq. (7) complète. Simplification uniquement sur
preuve expérimentale : gain nul mesurable en calibration, en FQR ou en
discrimination, à performance de détection comparable.

### Reste à faire avant de déclarer A3.3 validé

1. ✅ `linkReliability(t⁻)` reste \(x_k\)
2. ✅ gelée avant l'événement courant
3. ⬜ diagnostic événementiel de rupture/livraison, instrumenté séparément
   comme \(y_\ell\)
4. ✅ aucune information du même événement des deux côtés
5. ⬜ vérification de la séparation **sur traces** — outillage livré, mesure à
   produire

## 4octies. MESURE DU GEL : le signal apparent était la fuite

Exécuté après le gel, même run (seed=1, 10 962 événements).

### Le résultat qui compte

| non-observations honnêtes | avant le gel | après le gel |
|---|---|---|
| `VALEUR linkReliability` | 0.9928 | **1.0000** |
| `LIEN DEGRADE` | ~23 % (inféré) | **0.0000 — 0 événement** |

**Le « ~23 % des non-observations honnêtes expliquées par une défaillance de
lien » était entièrement un artefact de la fuite temporelle.** Avec la
caractéristique causalement propre, **aucune** des 29 non-observations honnêtes
n'avait de lien dégradé, et le sens de l'écart s'inverse : honnête 1.0000 contre
attaquant 0.9998.

L'invariant n'a donc pas corrigé un défaut de forme : il a **supprimé un signal
qui n'existait pas**.

### La fuite, mesurée

`linkReliabilityChangedDuringWindow = 49` — honnête 31 (dont 5
non-observations), attaquant 18 (dont **18** non-observations).

**18 sur 18 côté attaquant** : chaque événement affecté était une
non-observation. C'est exactement le couplage causal — un échec MAC vers \(j\)
implique que \(j\) n'a jamais reçu le paquet, donc \(z_e = 0\) forcé.

### Deux réserves sur ma propre lecture

**Le compteur 49 est une borne supérieure, pas la fuite.** La fenêtre glissante
de 32 issues change aussi quand un échec **ancien en sort** : la valeur **monte**,
ce qui est inoffensif. Seule la **baisse** traduit un échec qui vient d'entrer.
Côté honnête, 26 des 31 événements affectés étaient appariés — vraisemblablement
des sorties de fenêtre. La ventilation par direction est désormais rapportée.

**`0/29` contre `30/5405` n'est pas une différence.** À un taux de 0,56 %,
l'espérance sur 29 événements vaut 0,16 : observer zéro n'a rien de remarquable.
Le script refuse maintenant d'imprimer un rapport quand l'espérance du petit
échantillon est inférieure à 5, plutôt que d'afficher un « 0.0x » qui se lirait
comme un résultat.

### Effet secondaire du gel, mineur et attendu

Disponibilité 0.9905 → 0.9877 (honnête), 0.9933 → 0.9878 (attaquant) : à
l'ouverture, moins d'issues sont accumulées qu'à la clôture, donc quelques
événements passent sous le seuil de 4. Couverture 0.9943 → 0.9922, plafond
attaquant 5 441 → 5 405.

### Conséquence pour l'Éq. (8)

La baseline bénigne de 0,0071 n'est **pas** expliquée par la qualité du lien.
Les 30 non-observations honnêtes viennent d'ailleurs : collisions sur le trajet
d'écoute, fenêtre de 150 ms, terminal caché, mobilité. Le diagnostic
\(y_\ell\) du point 3 devra chercher **ces** mécanismes, et non la défaillance
de lien que la mesure vient d'écarter.

## 4nonies. Fenêtre écartée par mesure ; un quatrième chemin mort trouvé

### Le levier de fenêtre fonctionne — vérifié par falsification

| | 150 ms | 300 ms | 1 ms |
|---|---|---|---|
| `windowsMatched` | 5 465 | 5 465 | **3 839** |
| `windowsDeadline` | 5 497 | 5 497 | **7 123** |
| `windowsOpened` | 10 962 | 10 962 | 10 962 |
| `pdr` | 0.5971558524 | idem | idem |

Le run à 300 ms, identique au dernier chiffre, aurait pu signifier « la fenêtre
n'y est pour rien » **ou** « le paramètre n'est pas appliqué ». Un run à la
valeur minimale autorisée (1 ms) départage : la perte de 30 % prouve que le
levier agit.

**Conclusion : les 30 non-observations honnêtes ne sont pas dues à la fenêtre.**
Elles sont réelles — \(j\) n'a pas retransmis dans les 150 ms, ni dans les
300 ms. Candidat écarté par mesure.

*Prédiction et réalité :* j'annonçais « environ la moitié » des appariements
perdus, la perte est de 30 %. Direction juste, quantité fausse — la fenêtre
effective est plus généreuse que mon estimation, l'appariement survenant à la
réception à tout instant avant le balayage.

### Comptabilité des 30 non-observations honnêtes

| cause | événements | statut |
|---|---|---|
| échec MAC pendant la fenêtre | 5 | cible de \(y_{\text{link-failure}}\) |
| fenêtre trop courte | 0 | **écarté par mesure** |
| collision d'écoute, mobilité | ~25 | à instrumenter |

### `NEIGHBOR_LOST` : un chemin déclaré, jamais atteint — depuis RETIRÉ

`CloseWindow()` n'est appelée qu'avec `MATCHED`, `DEADLINE` et `EVICTED`.
`NEIGHBOR_LOST` n'apparaît dans le `.cc` qu'au `case` du `switch` qui incrémente
son compteur. **Rien ne l'émet.**

`windowsNeighborLost = 0` n'est donc pas une mesure de la mobilité : c'est une
absence de code. Et `forwarding-observation.h` documente cette raison comme
« SCIENTIFIQUE, pas décorative ».

### Le motif, et la garde qui le rend systématique

Quatrième occurrence de la même erreur dans cette étape :

| | grandeur | valeur structurellement constante |
|---|---|---|
| 1 | `passiveVisibility` | mesurait la cadence des HELLO |
| 2 | `available=1, value=0` | veto sur 85 % des événements |
| 3 | `linkReliability` | 1,0 — `NAckedMpdu` inerte en 802.11b |
| 4 | `windowsNeighborLost` | 0 — jamais émis |

Toutes se lisent comme des mesures ; toutes ont été trouvées une par une.

`validate_step03.py` porte désormais `STRUCTURALLY_ZERO` et
`audit_zero_counters()` :

> **Un compteur valant exactement zéro est soit une mesure, soit un chemin non
> implémenté. Le code doit dire lequel.**

Tout compteur nul absent de la table déclenche un avertissement exigeant sa
classification. Les compteurs actuellement nuls y sont classés.

**Suite donnée à `windowsNeighborLost` : suppression, sur décision utilisateur.**
Le classer en « chemin non implémenté » aurait pérennisé un compteur qu'aucun
appelant n'incrémentait ; le retirer supprime l'ambiguïté à la source — il n'y a
plus rien à classer. La raison de clôture, son compteur, son accesseur, sa
colonne CSV et son entrée dans la conservation ont été retirés de six fichiers.

**Vérification préalable, décisive.** La spécification a été relue AVANT la
suppression : A3.2 ligne 10 dit *« if j disappeared before a meaningful
opportunity existed then LOWER COVERAGE »* — elle demande d'agir sur les drapeaux
de disponibilité \(a_k\) de l'Éq. (6), et ne spécifie **aucune** quatrième
raison de clôture. `NEIGHBOR_LOST` était donc une invention de l'implémentation,
et la retirer ne remplace aucune méthode spécifiée.

**Mais A3.2 ligne 10 reste NON IMPLÉMENTÉE**, sous sa forme réelle : abaisser
\(c_e\). Le commentaire du code désignait cette ligne pour justifier un
mécanisme qu'elle n'avait jamais demandé, ce qui masquait l'exigence au lieu de
la satisfaire. Elle est désormais suivie comme ouverte.

**Réserve.** Détecter la disparition de \(j\) reste soumis à la même contrainte
d'échelle de temps, quelle que soit la forme retenue : la table AODV est 13 fois
plus lente que la fenêtre. Satisfaire A3.2 ligne 10 demandera un détecteur plus
rapide que la table de voisinage, ou une fenêtre bien plus longue.

## 4decies. JEU DE CALIBRATION : la baseline du seed 1 sous-estimait d'un facteur 3,6

Dix seeds (2 à 11), scénario gelé. Le seed 1 reste réservé à l'évaluation.

| | seed 1 seul | 10 seeds agrégés |
|---|---|---|
| événements honnêtes | 4 223 | **49 636** |
| non-observations | 30 | **1 266** |
| baseline | **0,0071** | **0,0255** |
| incertitude annoncée | ± 0,0013 (binomiale) | **± 0,0063** (inter-seed) |

### Trois résultats

**1. La baseline citée depuis STEP 3 sous-estimait d'un facteur 3,6.** Le taux
groupé vaut 0,0255 contre 0,0071 sur le seed 1. Ce dernier est le **3ᵉ plus
faible sur 11**, et l'étendue observée va de 0,0051 à 0,0593 — un rapport de
**11,6×**.

Techniquement, le seed 1 n'est pas une valeur aberrante (\(z = -0{,}86\)). Le
défaut n'est pas qu'il soit atypique, c'est de l'avoir cité **seul**, comme « la
mesure qui porte la valeur scientifique de l'étape », sans la dispersion qui
seule lui donne un sens.

**2. La dispersion inter-seed écrase l'erreur binomiale d'un facteur 28.**
\(\sigma_{\text{inter-seed}} = 0{,}0198\) contre \(\sigma_{\text{binomiale}}
= 0{,}00071\). Les événements d'un même seed **ne sont pas indépendants** :
topologie et mobilité sont partagées par tous les événements d'une réalisation.

> Toute barre d'erreur publiée sur cette baseline doit venir de la dispersion
> inter-seed. La formule binomiale la sous-estimerait d'un facteur 28.

**3. Le jeu de calibration existe : 1 266 non-observations honnêtes**, 42 fois
le seed 1. Les poids \(\nu_\ell\) peuvent désormais être calibrés sur des
données, sur des seeds distincts de l'évaluation.

### Effet structurel à consigner

Le volume d'observations honnêtes varie de **959 à 8 842** selon le seed, un
rapport de 9,2×, alors que le scénario est identique. Seule la **position des
attaquants** change. Les attaquants attirant les routes, leur placement
détermine la part du trafic qui reste observable sur voisin honnête. Aucune
corrélation nette entre volume et taux n'apparaît (taux groupé 0,0255 contre
moyenne des taux 0,0242).

### Une garde de moi qui était inerte

La colonne `seed` du rapport affichait `?` pour les dix seeds : `_seed_of()`
cherchait `seed`, `rngSeed` et `scenario.seed`, alors que le pilote écrit le
seed sous **`rng.seed`** et **`configuration.seed`**. La garde de séparation
calibration / évaluation n'a donc **jamais pu se déclencher** — elle laissait
passer en silence, et ce silence se lisait comme une vérification réussie.

Cinquième occurrence du même motif recensé au § 4nonies, cette fois **dans le
code de la garde elle-même**.

Corrigé sur deux plans :

- les emplacements réels sont lus, et la liste `SEED_LOCATIONS` cite les lignes
  du pilote qui les produisent ;
- un seed **introuvable** est désormais une **ignorance**, pas un seed
  différent : l'agrégation est refusée, sauf `--allow-unknown-seed` explicite.

Les tests portaient une part de responsabilité : leur manifeste plaçait le seed
à la racine, un emplacement que le pilote n'utilise pas. Ils validaient une
structure fictive pendant que la garde restait inerte sur les vrais fichiers.
Ils exercent maintenant les trois emplacements réels.

## 4undecies. A3.3 ENCODÉE : la partie A est faite, et elle ne ferme rien

### Ce qui a été fait

`contrib/mtcaodv/model/ocea-attribution.{h,cc}` — les Éq. (6)–(10) comme
**fonction pure**, sans aucun en-tête ns-3.

Les valeurs attendues viennent de `experiments/ocea_reference.py`, écrite
**avant** l'encodage C++. Huit oracles, tous vérifiables à la main :

| cas | \(c_e\) | \(O_e\) | \(d_e\) | \(\bar B_e\) | \(I_e\) | \((g,m,b,u)\) |
|---|---|---|---|---|---|---|
| \(z_e = 1\) | — | — | — | — | — | (1, 0, 0, 0) |
| \(c_e = 0\) | 0 | 0 | — | — | 0 | (0, 0, 0, 1) |
| \(d_e = 0\) | 0,5 | 0,5 | 0 | — | 0 | (0, 0, 0, 1) |
| veto \(x_k = 0\) disponible | 1,0 | **0** | 1,0 | 0,5 | 0 | (0, 0, 0, 1) |
| nominal \(x=(0{,}81;0{,}49)\), \(y=(0{,}25;0{,}75)\) | 1,0 | **0,63** | 1,0 | 0,5 | 0,63 | (0; **0,315**; **0,315**; **0,37**) |
| une seule \(x\), \(\omega = 0{,}4\) | 0,4 | **0,24** | 1,0 | 1,0 | 0,24 | (0; 0; 0,24; 0,76) |
| \(\bar B_e = 1\) | 1,0 | 1,0 | 1,0 | 1,0 | 1,0 | (0; 0; **1,0**; 0) |
| \(\bar B_e = 0\) | 1,0 | 1,0 | 1,0 | 0,0 | 1,0 | (0; **1,0**; 0; 0) |

Le cas du veto mérite une ligne : il ne demande **aucune branche dédiée**.
\(O_e = 0\) donne \(I_e = 0\) donne \((0,0,0,1)\) par la seule Éq. (10). Une
branche `if (vetoed) return ...` aurait été du code mort déguisé en prudence.

### Le contre-contrôle que la pureté a rendu possible

Ne pas inclure ns-3 n'était pas une préférence de style. Conséquence concrète :

```
$ bash experiments/check_ocea_arithmetic.sh
ok    compilation sans ns-3 (g++, C++17)
ok    aucun avertissement (-Wall -Wextra -Wpedantic)
ok    pilote exécuté, 8 lignes produites
8 oracles concordants ; ecart maximal 0 (-), tolerance 1e-12
== Contre-contrôle : ACCORD ==
```

**Exécuté dans l'environnement de développement**, pas seulement rédigé. Les
deux implémentations sont sorties **identiques octet pour octet** sur les 72
champs numériques et les 24 drapeaux (8 oracles x 12 champs). Le comparateur a été vérifié capable d'échouer : une valeur
altérée et un fichier tronqué sont tous deux rejetés — une garde qui ne peut pas
se déclencher se lit comme une vérification réussie, et ce projet en a déjà
recensé cinq.

La suite ns-3 `mtcaodv-ocea-attribution` (7 cas, dont la grille T-13 à 8 192
combinaisons) reste **à compiler et tester sur le PC utilisateur** : elle exige
`ns3/test.h`, absent de l'environnement de développement.

### Une règle d'implémentation à trancher : \(\omega_k = 0\)

L'Éq. (7) ne dit rien du cas où un poids est **exactement nul**. IEEE-754 donne
`pow(0, 0) = 1`, si bien qu'une caractéristique disponible valant 0 avec un poids
de 0 **ne vetoerait pas**, alors qu'un poids de 0,0001 vetoerait tout. La
discontinuité serait arbitraire.

**Retenu (statut : Proposé).** Le critère est \(\omega_k a_k > 0\), le même
que celui de la somme (6) : un poids nul exclut la caractéristique du produit
comme il l'exclut de la couverture. Cohérent, et testé dans les deux langages.

### Une garde ajoutée hors A3.3, et pourquoi

A3.3 suppose ses entrées propres. Les accepter sans contrôle laisserait un
\(x_k = 1{,}5\) produire une masse d'incertitude **négative** en silence, et le
`clip` de la ligne 9 masquerait le défaut au lieu de le signaler.

Les entrées invalides (poids ne sommant pas à 1, valeur hors \([0,1]\), `NaN`)
sont donc **refusées**, jamais écrêtées, et le refus est **marqué** :
`inputsValid = false`. Un événement refusé et un événement légitimement
incertain produisent les mêmes quatre masses ; seul ce drapeau les sépare, et
sans lui un défaut d'appelant se compterait comme de l'incertitude physique.

Même raisonnement pour `computed` : quand \(z_e = 1\) court-circuite, les
intermédiaires valent 0 **par convention, non par mesure**. Un exportateur qui
les moyennerait avec les \(c_e\) réellement calculés ferait chuter la couverture
rapportée sans qu'aucune couverture n'ait baissé — sixième variante du même
motif, évitée cette fois avant d'être commise.

Les assertions des lignes 13–14 sont exposées comme **prédicat**
(`OceaMassesAreConserved`), non comme `assert()` : `assert()` disparaît sous
`NDEBUG`, donc dans toute construction optimisée. Une vérification qui
s'évapore en production est exactement le motif contre lequel ce document met
en garde depuis le § 4nonies.

### CE QUE CELA NE FERME PAS — à lire avant toute satisfaction

Le critère de fermeture n° 7 déclare **FAIL** si la fraction d'événements non
interprétables vaut 1. Aucun \(y_\ell\) n'étant instrumenté, \(d_e = 0\) pour
**tous** les événements, et la ligne 7 d'A3.3 renverrait \((0,0,0,1)\) partout.

**Implémenter A3.3 ne corrige pas ce manque ; cela le rend calculable.** Sur les
huit critères, trois sont couverts (1 : T-13 ; 2 : fail closed ; 3 : oracles
calculés avant encodage). Les cinq autres restent ouverts, et quatre d'entre eux
(4 à 7) attendent tous la même chose : **un premier diagnostic \(y_\ell\)**.

### L'adaptateur `ForwardingObservation` → A3.3 : DÉLIBÉRÉMENT REPORTÉ

Il était prévu dans ce lot. Il en est retiré, pour deux raisons qui ne sont pas
des excuses :

1. **Il exigerait des poids.** \(\omega_k, \nu_\ell\) sont marqués
   *À confirmer C-05* et ne peuvent être calibrés qu'après l'instrumentation.
   Livrer des poids uniformes « provisoires » produirait des nombres qui
   ressemblent à un résultat. C'est précisément ce que la contrainte
   « ne jamais fabriquer de résultat » interdit.
2. **Sa forme n'est pas encore connue.** La liste des \(y_\ell\) changera quand
   le premier sera instrumenté. Fixer maintenant la signature du consommateur
   reviendrait à la réécrire au lot suivant.

Ce que l'adaptateur devra faire, consigné pour ne pas être oublié :

- lire `linkReliability` (**gelé**), jamais `linkReliabilityAtClose` — le champ
  de diagnostic dont l'usage dans un calcul de masse réintroduirait exactement
  la fuite temporelle corrigée au § 4octies ;
- refuser d'attribuer une clôture `EVICTED` : elle n'est pas une observation, et
  `forwarding-observation.h` dit déjà qu'elle « ne doit jamais alimenter une
  masse ». Passer son \(z_e = 0\) à l'Éq. (10) transformerait une limite de
  notre propre tampon en masse de malveillance ;
- **ne pas renormaliser** les poids des caractéristiques définitivement
  indisponibles. \(c_e\) mesure la part du modèle réellement instrumentée ;
  renormaliser effacerait l'information qu'un tiers du modèle ne l'est pas.

---

## 4duodecies. PREMIER \(y_\ell\) INSTRUMENTÉ : l'issue MAC pendant la fenêtre

### La grandeur, et pourquoi celle-là

\(y_{lien}(e)\) : **une issue MAC vers \(j\) a-t-elle échoué PENDANT la
fenêtre ?** Binaire, disponible dès qu'au moins une issue a été observée et que
la MAC de \(j\) était connue à l'ouverture.

C'est le point 3 de la liste utilisateur : « un \(y_\ell\) au niveau événement,
instrumenté séparément ». Il est retenu en premier parce qu'il est le seul
diagnostic dont la source existe déjà et qui reste dans la voie déployable :

- `mobilityBreak` — la table de voisinage AODV garde un voisin
  \(2\,\text{s}\), treize fois la fenêtre. Le signal arriverait **après** la
  cause qu'il prétend expliquer ;
- `queuePressure` — exigerait de lire la file de \(j\). Interdit ;
- `coherentRerr` — accessible, candidat suivant, non instrumenté ici.

### La séparation temporelle, qui est tout l'intérêt

| | \(x_{link}(e)\) | \(y_{lien}(e)\) |
|---|---|---|
| équation | (7), géométrique | (8), arithmétique |
| fenêtre temporelle | historique **avant** \(t_e\) | \([t_{ouv}, t_{clôt}]\) |
| gelé à l'ouverture | oui | sans objet |
| effet d'une valeur 0 | **VETO absolu** | atténuation |

**Aucune issue MAC ne peut alimenter les deux.** C'est exactement ce que
l'arbitrage « option (1) avec séparation temporelle stricte » achetait, et
c'était sa raison d'être : la même information des deux côtés serait un double
comptage. Le gel de \(x_{link}\) n'était donc pas seulement une correction de
fuite — il rendait ce diagnostic **possible**.

### Un point que je n'avais pas vu, et qui décide du critère 7

J'ai d'abord raisonné en volume d'**échecs** : 37 sur le run, ~23 pendant une
fenêtre. Un diagnostic ne couvrant que ces 23 événements aurait laissé 99,8 %
des observations non interprétables — un critère 7 satisfait sur le papier et
vide en pratique.

**Ce raisonnement confondait disponibilité et valeur** — la faute même commise
avec `passiveVisibility`, sous une autre forme.

> \(a_\ell = 1\) signifie « le diagnostic était **évaluable** », pas « le
> diagnostic a **déclenché** ». Un ACK observé vers \(j\) est une information :
> il **écarte** la cause bénigne « le paquet n'est jamais arrivé ». C'est donc
> \(a_\ell = 1, y_\ell = 0\) — disponible et négatif, jamais indisponible.

Attendu : \(d_e > 0\) pour la quasi-totalité des événements, et \(y_\ell = 1\)
pour une poignée. **À MESURER — les deux chiffres sont des prédictions, pas des
résultats.** Le compteur `windowsWithLinkOutcome` les tranchera.

### Ce que le résultat contiendra, et qu'il ne faudra pas cacher

Si \(\bar B_e = 0\) pour l'essentiel des non-observations, l'Éq. (10) leur
accorde \(m_e = I_e\). Sur le run mesuré, **30 non-observations honnêtes**, dont
**5 seulement** avaient vu \(x_{link}\) baisser pendant la fenêtre. Les autres
recevraient une masse malveillante **sans explication bénigne**.

Ce n'est pas un défaut de l'implémentation : c'est la conséquence honnête de
n'avoir qu'un seul diagnostic. Le rapport l'imprime sous
`NON-OBSERVATIONS SANS EXPLICATION`. Ce nombre est la pression de faux positifs
que MOBeta-Trust devra absorber, et **l'argument chiffré** pour un second
\(y_\ell\). Le masquer ici ne le ferait pas disparaître en aval.

### Portée réelle : par PAIR, pas par PAQUET — et c'est mesuré

L'observateur constate qu'une issue vers \(j\) est survenue pendant la fenêtre,
**sans prouver qu'elle concernait ce paquet**. Sur 150 ms, une seconde émission
vers \(j\) est possible.

Deux voies s'ouvraient. L'attribution par paquet — retrouver l'en-tête IPv4 dans
le `WifiMpdu`, après le `LlcSnapHeader` — est exacte mais repose sur des détails
d'API que **je ne peux pas vérifier depuis l'environnement de développement**,
ns-3.48 y étant absent. Deux cycles ont déjà été perdus sur des API supposées.

Retenu : l'attribution par pair **plus un compteur d'ambiguïté**
(`windowsMultipleLinkOutcomes`). La limite est ainsi **mesurée**, pas supposée
négligeable, et le raffinement ne sera entrepris que si le chiffre le justifie.
C'est une limite énoncée, pas une approximation cachée.

### Gel de la résolution IPv4 -> MAC

La correspondance est figée à l'ouverture. L'apprendre en cours de fenêtre
ferait dépendre la **disponibilité** du diagnostic d'un fait postérieur à
l'ouverture — et une disponibilité qui varie avec ce qui est observé ensuite est
le premier pas vers une grandeur qui prédit son propre résultat.

Coût : les fenêtres ouvertes avant que \(j\) n'ait diffusé quoi que ce soit sont
sans diagnostic. Compté par `windowsPeerMacUnknownAtOpen`, jamais silencieux.

### Les quatre compteurs, délibérément NON classés

Ils sont ajoutés à `REQUIRED_STEP3` du validateur et **absents** de
`STRUCTURALLY_ZERO`. Un zéro déclenchera donc l'avertissement « mesure ou chemin
non implémenté ? ». Les classer maintenant reviendrait à **décider de la réponse
avant la mesure** ; la classification vient après les chiffres.

### État des critères de fermeture

| critère | état |
|---|---|
| 1 — T-13 | **couvert** (§ 4undecies) |
| 2 — fail closed | **couvert** |
| 3 — oracles avant encodage | **couvert** |
| 4 — instrumentation effective | **partiel** : 2 \(x_k\) + 1 \(y_\ell\) ; `coherentRerr` reste accessible et non fait |
| 5 — compteurs de disponibilité | **couvert**, à mesurer sur run |
| 6 — distributions | exige l'adaptateur, non livré |
| 7 — fraction non interprétable | **à mesurer** — c'est ce run qui tranche |
| 8 — non-intrusion, non-régression | à vérifier sur le run |

**À COMPILER ET TESTER SUR LE PC UTILISATEUR.** ns-3.48 est absent de
l'environnement de développement : le C++ de ce lot n'a pas été compilé. Seuls
les 106 tests Python et l'arithmétique A3.3 y ont été exécutés.

---

## 4terdecies. LE PREMIER \(y_\ell\), MESURÉ : critère 7 franchi, deux prédictions fausses

Run seed = 1, 10 962 événements. Chiffres bruts de l'exécution utilisateur.

### Critère 7 : franchi, et pas de justesse

| | valeur |
|---|---|
| non-observations | 5 497 |
| dont **attribuables** (\(c_e>0\), pas de veto, \(d_e>0\)) | **5 428 — 98,74 %** |
| événements non interprétables, tous confondus | 69 / 10 962 = **0,63 %** |

Le critère de fermeture n° 7 déclarait FAIL si cette fraction valait 1. Elle vaut
**0,0063**. L'Éq. (8) s'applique désormais à la quasi-totalité des
non-observations, ce qui n'était le cas d'**aucune** avant ce lot.

### Le diagnostic discrimine, et fortement

| | expliquées par \(y_\ell = 1\) | attribuables | taux |
|---|---|---|---|
| voisin **honnête** | 5 | 27 | **0,1852** |
| voisin **attaquant** | 15 | 5 401 | **0,00278** |

**Rapport 66,7×**, Fisher exact unilatéral **p = 3,0 × 10⁻⁸**.

C'est le comportement attendu d'un diagnostic bénin : une non-observation
honnête est bien plus souvent imputable à un échec de lien qu'un silence
d'attaquant. Le mécanisme n'est donc pas une construction — il se voit dans les
données, sur un échantillon honnête pourtant minuscule (27).

**Cohérence croisée.** Les 15 événements attaquants avec \(y_\ell = 1\) sont
exactement les 15 « baisses » de \(x_{link}\) relevées au § 4octies, et les 8
honnêtes exactement les 8 baisses honnêtes. Les deux instruments voient le même
phénomène par deux chemins indépendants. C'est aussi la confirmation que le gel
de \(x_{link}\) n'a pas détruit l'information : il l'a **déplacée du bon côté**
de la séparation, où elle est utilisable sans circularité.

### PRÉDICTION FAUSSE n° 1 : la disponibilité

J'annonçais \(a_\ell = 1\) pour « la quasi-totalité » des événements, soit
~99 %. **Mesuré : 74,7 % (8 187 / 10 962).**

Cause : les fenêtres **appariées** se referment en 1,6 ms (médiane) et n'ont
souvent vu passer aucune issue MAC ; les non-observations restent ouvertes les
150 ms entières. La disponibilité globale mélangeait donc deux populations que
rien n'obligeait à se ressembler.

**L'erreur d'annonce n'a toutefois aucune conséquence sur l'attribution**, et il
faut le dire aussi précisément : A3.3 ligne 2 court-circuite dès \(z_e = 1\),
donc \(d_e\) n'est jamais lu sur une fenêtre appariée. La disponibilité qui
compte est celle des **non-observations** : **99,47 % (5 468 / 5 497)**.

Ma prédiction visait la mauvaise population. Le rapport ventile désormais
\(a_\ell\) selon \(z_e\), avec la mention explicite de celle qui entre dans une
équation.

### PRÉDICTION FAUSSE n° 2 : l'ambiguïté

Je l'avais qualifiée de « possible » sur 150 ms, en refusant de la supposer
négligeable — d'où le compteur. **Mesuré : 5 458 / 8 187 = 66,7 %** des fenêtres
évaluables ont vu **plusieurs** issues MAC vers \(j\).

Deux tiers. L'attribution est donc massivement par PAIR et non par PAQUET, bien
au-delà de ce que le mot « possible » laissait entendre.

**Ce que ce taux ne dit PAS.** Il ne dit rien de la fiabilité des 23 attributions
bénignes : ce qui compte n'est pas l'ambiguïté globale mais l'ambiguïté **des
événements où \(y_\ell = 1\)**. Une fenêtre ambiguë dont aucune issue n'a échoué
donne \(y_\ell = 0\), verdict que l'ambiguïté ne peut pas avoir faussé dans le
sens dangereux : elle ne peut qu'**excuser à tort**, jamais accuser à tort.

Ce croisement **n'avait pas été instrumenté** — le compteur agrégé ne permet pas
de le calculer. Corrigé : `linkOutcomesDuringWindow` est désormais exporté PAR
ÉVÉNEMENT, et le rapport imprime `y_l = 1 EXACT (1 issue)` contre `AMBIGU (>1)`.
**Chiffre à produire au prochain run.** Sans lui, aucune des 23 attributions
bénignes ne peut être déclarée fiable.

### Le vrai facteur limitant a changé de nature

**22 des 27 non-observations honnêtes attribuables (81,5 %) n'ont AUCUNE
explication bénigne** et recevraient \(m_e = I_e\).

Le facteur limitant n'est plus la **couverture** — elle est à 98,7 % — mais le
**pouvoir explicatif**. Un seul diagnostic explique 18,5 % des non-observations
honnêtes ; les quatre cinquièmes restants sont la pression de faux positifs que
MOBeta-Trust devra absorber. C'est l'argument chiffré pour `coherentRerr`, et il
ne sera pas caché dans les résultats publiés.

### Deux défauts de MOI, du même type, corrigés

**Le bloc de clôture de `run_all.sh` mentait.** Il affirmait encore « aucun
diagnostic \(y_\ell\) n'est instrumenté, donc \(d_e = 0\) » dans le lot même qui
en instrumentait un — en contradiction directe avec les chiffres imprimés vingt
lignes plus haut. Texte narratif qui n'a pas suivi le code.

**`analyze_features.py` répétait la même chose**, et c'était la **deuxième fois
dans ce même fichier** (§ 4quater : « `passiveVisibility` est la SEULE
caractéristique »).

Les deux sont corrigés, et la conclusion de l'analyseur est maintenant
**CALCULÉE à partir de ses propres chiffres** au lieu d'être écrite à la main :
elle ne peut plus se désynchroniser. Le bloc de `run_all.sh` renvoie désormais
aux compteurs plutôt que d'affirmer à leur place.

### `windowsPeerMacUnknownAtOpen = 0` : classé, après mesure

Le validateur l'a signalé — la garde a fonctionné. Il est maintenant classé
MESURE, avec sa raison structurelle : une fenêtre ne s'ouvre que vers un
prochain saut routé, et établir la route exige d'avoir reçu un RREQ **diffusé**
de ce voisin. La correspondance IPv4 -> MAC existe donc toujours avant la
première fenêtre. Le chemin reste **vivant** —
`BenignDiagnosticAvailabilityTestCase` le force et vérifie le compteur.

Dépendance notée : la disponibilité du diagnostic repose sur le **même canal
d'apprentissage passif** que `passiveVisibility`. Ce n'est pas une circularité —
diffusion et unicast sont des classes disjointes de \(z_e\) — mais les deux
tomberaient ensemble si ce canal se tarissait.

### État des critères

| critère | état |
|---|---|
| 1 — T-13 | couvert |
| 2 — fail closed | couvert |
| 3 — oracles avant encodage | couvert |
| 4 — instrumentation effective | **partiel** : 2 \(x_k\) + 1 \(y_\ell\) ; `coherentRerr` accessible, non fait |
| 5 — compteurs de disponibilité | **couvert et mesuré** |
| 6 — distributions des masses | **non couvert** : exige l'adaptateur |
| 7 — fraction non interprétable | **couvert : 0,0063**, contre 1 attendu sans \(y_\ell\) |
| 8 — non-intrusion, non-régression | couvert : PDR identique au chiffre, 12 suites vertes, `src/aodv` intact |

---

## 4quaterdecies. L'AMBIGUÏTÉ TRANCHE CONTRE MOI, et une garde manquait

### La règle préenregistrée s'applique

J'avais écrit avant de connaître le chiffre : *« Si le croisement est
majoritairement EXACT, les 23 attributions tiennent et je passe à l'adaptateur.
S'il est majoritairement AMBIGU, l'attribution par paquet devient un
préalable. »*

**Mesuré : EXACT 10, AMBIGU 13 — 56,5 % d'ambiguïté.** La règle s'applique. Une
majorité de 57 contre 43 est mince, et c'est exactement le cas où l'on est
tenté de la relire à son avantage. Elle est appliquée telle qu'écrite.

### Un défaut de mon instrumentation : le croisement n'était pas ventilé

Le rapport comptait EXACT / AMBIGU sur **tous** les événements. Côté attaquant
c'est sans effet — les 15 événements \(y_\ell = 1\) sont tous des
non-observations. Côté honnête, **8 événements portent \(y_\ell = 1\) mais 5
seulement sont des non-observations**, si bien que la part exacte parmi
celles-ci reste **indéterminée entre 1 et 4**.

Ce n'est pas un détail de présentation. En ne gardant que les attributions
exactes :

| honnête (exactes) | rapport | Fisher exact |
|---|---|---|
| 1 / 27 | 33× | **p = 3,4 × 10⁻²** |
| 2 / 27 | 67× | p = 6,6 × 10⁻⁴ |
| 3 / 27 | 100× | p = 9,0 × 10⁻⁶ |
| 4 / 27 | 133× | p = 1,0 × 10⁻⁷ |

**Un chiffre qui laisse le résultat osciller entre « marginal » et
« écrasant » ne mesure rien.** Corrigé : le croisement est désormais restreint
aux non-observations, seule population où \(y_\ell\) entre dans une équation
(A3.3 ligne 2 court-circuite dès \(z_e = 1\)).

### Borne d'impact, dans le bon sens

L'ambiguïté ne peut qu'**excuser à tort**, jamais accuser à tort : elle attribue
un échec survenu pendant la fenêtre à un paquet qui, lui, est peut-être arrivé.

| | faux bénins au pire | sur | part |
|---|---|---|---|
| attaquant | 9 | 5 401 attribuables | 0,17 % — négligeable |
| honnête | 4 | 27 attribuables | **14,8 %** |

Le risque n'est donc pas de manquer des attaquants : il est de **perdre les
rares explications bénignes** qui protègent les nœuds honnêtes. C'est ce qui
justifie de traiter l'ambiguïté avant, et non après, l'adaptateur.

### UNE COÏNCIDENCE QUE JE NE M'EXPLIQUE PAS

Côté honnête, sur le run r18 :

- `emetteur attribue au voisin` = 2 719 / 4 193 = 0,648462
- `a_l | retransmission vue` = 0,6485, soit **2 719 / 4 193**

Deux conditions de nature différente — une correspondance MAC apprise sur
diffusion d'un côté, un ACK MAC reçu pendant la fenêtre de l'autre — donnant le
**même effectif au paquet près**. Ce n'est pas crédible comme hasard.

**Aucune explication n'est avancée ici.** Un croisement est instrumenté : si les
deux hors-diagonales sont nulles, les ensembles sont identiques et il existe une
cause commune non identifiée — possiblement un défaut. Le rapport l'imprime et
avertit explicitement. **Tant que ce point n'est pas instruit, aucune conclusion
ne doit s'appuyer sur `senderAttributed` ni sur \(a_\ell\) séparément.**

### TROISIÈME OCCURRENCE, ET CETTE FOIS LA CAUSE EST STRUCTURELLE

Le run r18 a imprimé, en clôture, la conclusion de r17 : « aucun diagnostic
\(y_\ell\) n'est instrumenté, donc \(d_e = 0\) » — sous des chiffres qui la
démentaient vingt lignes plus haut.

L'archive r18 contenait pourtant le texte corrigé. **C'est `run_all.sh` sur
l'arbre de l'utilisateur qui était resté en r17** pendant que le module, les
scripts Python et le pilote étaient en r18.

**Aucune garde ne pouvait le voir**, et c'est le vrai enseignement. Les huit
contrôles de `check_step03_build.sh` comparent tous des **sources** à des
**artefacts de compilation** : source plus récente que la bibliothèque, objet
périmé, marqueur absent de la bibliothèque de test. Un script shell n'est pas
compilé ; une page de documentation non plus. **Ils peuvent rester en arrière
indéfiniment, et ce sont précisément eux que l'utilisateur lit.**

Corrigé par un **tampon de révision** : chaque fichier livré porte
`MTCAODV_DELIVERY_REVISION: rN`, `DELIVERY_REVISION.txt` fait foi, et la garde
refuse de continuer en nommant le fichier fautif. Vérifiée capable d'échouer sur
les deux cas (fichier d'une autre révision, fichier sans tampon).

Les deux corrections précédentes portaient sur le **contenu** du texte ;
celle-ci porte sur le **mécanisme** qui laissait un texte périmé atteindre
l'utilisateur. Les deux premières n'auraient pas empêché la troisième.

### Ce qui est demandé avant l'adaptateur

L'attribution par paquet exige de retrouver l'en-tête IPv4 dans le `WifiMpdu`,
après le `LlcSnapHeader`. Les détails d'API ne sont **pas vérifiables depuis
l'environnement de développement** — ns-3.48 y est absent, et deux cycles ont
déjà été perdus sur des API supposées. Les extraits nécessaires sont demandés à
l'utilisateur plutôt que devinés.

---

## 4quindecies. LA COÏNCIDENCE ÉLUCIDÉE, ET CE QU'ELLE A DÉCOUVERT

### Le croisement répond : ensembles identiques, cause commune trouvée

| voisin honnête, fenêtres appariées | effectif |
|---|---|
| `senderAttributed` ET \(a_\ell\) | 2 719 |
| `senderAttributed` seul | **0** |
| \(a_\ell\) seul | **0** |
| ni l'un ni l'autre | 1 474 |

Les ensembles sont **identiques**. J'avais écrit « possiblement un défaut » ;
**ce n'en est pas un**, et la cause est mécanique :

- un appariement **attribué** signifie que la trame entendue venait de \(j\),
  donc que \(j\) avait bien reçu le paquet — donc qu'un ACK MAC de \(j\) est
  survenu pendant la fenêtre, ce qui rend \(a_\ell\) disponible ;
- un appariement **non attribué** signifie qu'un TIERS a relayé le paquet et
  que sa trame a fermé la fenêtre **avant** que l'émission de \(i\) vers \(j\)
  n'ait produit d'issue — d'où \(a_\ell = 0\).

Les deux grandeurs mesurent donc, sur une fenêtre appariée, **le même fait** :
« l'émission de \(i\) vers \(j\) a-t-elle abouti avant la fermeture ? »
Ce n'est pas une redondance nuisible, mais elle doit être **déclarée** : sur les
fenêtres appariées, ces deux colonnes ne sont pas deux témoignages indépendants.

### CE QUE CELA MET AU JOUR, et qui est plus sérieux

Le corollaire est que **1 474 des 4 193 appariements honnêtes (35,2 %) se sont
fermés sur la trame d'un TIERS**, pas sur celle de \(j\). Côté attaquant, c'est
**1 272 sur 1 272 — la totalité**.

L'Éq. (9) accorde \((1,0,0,0)\) — preuve positive **pleine** — dès
\(z_e = 1\). Sur ces événements, un trou noir qui n'a rien relayé reçoit donc
la même preuve qu'un voisin exemplaire. Le § 7 avait enregistré ce risque ;
il est maintenant **quantifié**, et il est bien plus large que « 18,9 % ».

### UNE ANOMALIE QUI EXIGE UNE EXPLICATION AVANT TOUTE SUITE

Les 1 272 appariements d'attaquant présentent une latence **médiane ET
maximale** de « 0,00 ms ». Aucune retransmission radio ne s'entend en moins de
5 µs : il faut au minimum une durée de trame et un SIFS.

Deux hypothèses, et une seule mesure les départage :

1. **L'observateur apparie sa PROPRE émission.** Ce serait un défaut grave —
   \(z_e\) fabriqué, et l'Éq. (9) accordant une preuve positive pleine à un
   trou noir. Toutes les masses calculées en aval seraient fausses **sans le
   paraître**.
2. **L'appariement vient d'un tiers**, et la latence quasi nulle a une autre
   cause, qu'il faudra chercher.

**Aucun comportement n'est modifié dans ce lot.** Changer la règle
d'appariement déplacerait \(z_e\) sur tous les événements en même temps qu'on
cherche à comprendre pourquoi — on ne corrige pas avant de diagnostiquer.

Ce qui est ajouté :

- `observedSenderIsSelf` par événement, `matchedFromSelf` en agrégé ;
- **échec dur** du validateur et de `run_all.sh` si le compteur est non nul :
  une observation fausse ne se rattrape par aucune équation en aval ;
- la latence est désormais rapportée **en microsecondes**. En millisecondes,
  les 1 272 événements s'affichaient tous « 0.00 ms ». Une unité trop
  grossière ne rend pas seulement imprécis : **elle efface le signal**. C'est
  l'arrondi, et non l'absence d'instrument, qui avait caché ce point pendant
  trois révisions.

### Ce qui est DÉLIBÉRÉMENT reporté

L'attribution par paquet — les en-têtes ns-3 nécessaires sont maintenant connus
(`WifiMpdu::GetPacket()`, `LlcSnapHeader` à 8 octets, `GetType()`) — **n'est pas
faite dans ce lot**.

Raison : elle modifierait \(y_\ell\) au moment même où l'on cherche à établir
si \(z_e\) est fiable. Deux grandeurs qui bougent ensemble ne se diagnostiquent
pas. \(z_e\) est en amont de tout : si l'appariement est faux, la précision de
\(y_\ell\) n'a aucun intérêt.

Ordre retenu : **\(z_e\) d'abord, \(y_\ell\) ensuite, l'adaptateur en
dernier.**

---

## 4sexdecies. L'AUTO-APPARIEMENT EST RÉFUTÉ ; L'ANOMALIE EST PIRE

### Ce que r20 a mesuré

`matchedFromSelf = 0`. **Mon hypothèse est fausse** : l'observateur ne
s'apparie pas sur sa propre émission.

Mais le passage en microsecondes a durci le fait au lieu de le dissoudre :

| voisin | min | médiane | max |
|---|---|---|---|
| honnête | 0,0 µs | 1 565,8 µs | 69 583,7 µs |
| **attaquant** | **0,0 µs** | **0,0 µs** | **0,0 µs** |

Les 1 272 appariements d'attaquant sont **tous** à latence nulle. Une
retransmission 802.11b exige au minimum une durée de trame et un SIFS — des
dizaines de microsecondes. **Aucun de ces \(z_e = 1\) n'est une preuve de
relais**, quelle qu'en soit la cause.

### L'hypothèse restante, et l'instrument qui la tranche

L'émetteur apparié n'est ni \(j\) (`senderAttributed = 0`) ni nous-mêmes
(`matchedFromSelf = 0`). Reste un tiers — ou la **trame entrante du paquet
lui-même** : \(i\) reçoit le paquet de \(h\), l'IP le relaie, la fenêtre
s'ouvre, et le rappel promiscuité de cette même trame apparie l'empreinte qui
vient d'être enregistrée. L'émetteur serait \(h\), ce qui correspond
exactement au profil mesuré.

Instrument ajouté : **`openedByRelay`**. Les traces `SendOutgoing` et
`UnicastForward` étaient branchées sur un rappel UNIQUE ; elles ont désormais
deux rappels distincts. Si tous les appariements à \(\Delta t = 0\) viennent
de fenêtres de **relais**, le mécanisme est établi. S'il s'en trouve sur des
émissions locales, l'hypothèse tombe.

Comparaison **exacte**, sans seuil : introduire un plancher déciderait par
avance de ce que la mesure doit montrer.

### PORTÉE : ce qui est mis en doute

Si le mécanisme est confirmé, **2 746 appariements** (1 474 honnêtes non
attribués + 1 272 attaquants) ne sont pas des observations de relais mais des
artefacts. Conséquences, énoncées sans atténuation :

- Ces observations sont **nulles**, et non « de valeur erronée » : l'appariement
  parasite a détruit la fenêtre avant qu'elle ne puisse observer quoi que ce
  soit. On ne peut pas les reclasser en non-observations.
- La **baseline honnête de 0,0071** repose sur 4 193 appariements dont 1 474
  seraient artificiels. Elle est **en doute**, et tout texte qui la cite doit
  attendre ce diagnostic.
- Le finding du § 7 — « 18,9 % des \(z_e = 1\) d'attaquant venaient d'un
  tiers » — serait lui-même un artefact : non pas un tiers, mais la trame
  entrante du paquet.

### Aucune correction dans ce lot, et pourquoi

Le lot r20 avait déjà posé la règle : on ne corrige pas avant de
diagnostiquer. Elle vaut encore. Filtrer les appariements à \(\Delta t = 0\)
serait probablement la bonne correction — elle est physiquement fondée — mais
l'appliquer avant d'avoir identifié le mécanisme masquerait un défaut éventuel
plus profond au lieu de le résoudre.

**Ordre confirmé : \(z_e\) d'abord, \(y_\ell\) ensuite, l'adaptateur en
dernier.** L'attribution par paquet reste reportée : la précision de
\(y_\ell\) n'a aucun intérêt tant que l'appariement lui-même est suspect.

---

## 4septdecies. DÉFAUT CONFIRMÉ ET CORRIGÉ — et ce qu'il faut retirer

### Le verdict

```
matchedAtZeroLatency=2746  dont par RELAIS=2746
```

| | \(\Delta t = 0\) | par relais | attribués à \(j\) |
|---|---|---|---|
| honnête | 1 474 / 4 193 | **1 474** | **0** |
| attaquant | 1 272 / 1 272 | **1 272** | **0** |

\(N = M\) exactement, dans les deux classes. L'hypothèse est **confirmée**.

### Le mécanisme

Quand \(i\) **relaie**, la trame entrante et le relais IP qui en découle se
produisent dans le **même événement de simulation** : aucun temps ne s'écoule
entre les deux. La fenêtre s'ouvre, puis le rappel promiscuité de **cette même
trame entrante** apparie l'empreinte qui vient d'être enregistrée.

**L'observateur se voyait RECEVOIR et en concluait que \(j\) avait RELAYÉ.**

Une vraie retransmission exige que \(i\) ait d'abord émis la trame — à 1 Mbps,
plus de 4 ms pour 512 octets — puis que \(j\) la reçoive et la réémette. Elle
ne peut structurellement pas tomber dans le même instant.

### La correction

Un appariement survenant dans le même instant de simulation que l'ouverture est
**REJETÉ**, et **la fenêtre reste OUVERTE** : cette trame n'est pas une
observation, ni positive ni négative. La fermer — même en `DEADLINE` —
fabriquerait un \(z_e\) là où il n'y a aucune information.

Égalité **exacte**, sans seuil. Le test porte sur la **cause** — identité
d'événement de simulation — et non sur le symptôme « latence petite ». Exposé
comme prédicat pur `IsSameInstantMatch()`, testable sans simulation.

`matchedAtZeroLatency` devient un **échec dur** du validateur et de
`run_all.sh` : non nul signifie que la correction ne s'applique plus.

### CE QUI EST RETIRÉ — sans atténuation

25,1 % de toutes les observations étaient des artefacts. Les chiffres suivants,
présents dans ce document et dans tous les rapports antérieurs à r22, sont
**RETIRÉS** et non simplement « à réviser » :

| grandeur retirée | valeur publiée | statut |
|---|---|---|
| baseline de non-observation honnête | 0,0071 | **RETIRÉE** — 1 474 des 4 193 appariements étaient artificiels |
| non-observation attaquant | 0,8112 | **RETIRÉE** — les 1 272 appariements l'étaient TOUS |
| écart honnête/attaquant | +0,8041 | **RETIRÉE** — différence de deux quantités fausses |
| § 7 : « 18,9 % des \(z_e=1\) d'attaquant venaient d'un tiers » | 1 272 | **RETIRÉ** — ce n'était pas un tiers, c'était la trame entrante |
| jeu multi-seeds § 4decies : taux groupé 0,0255, SD 0,0198 | 10 seeds | **RETIRÉ** — même défaut sur les dix runs |

Les mesures **non affectées** sont celles qui ne dépendent pas de \(z_e\) :
disponibilité de `passiveVisibility` et de `linkReliability`, couverture
\(c_e\), arithmétique A3.3, ambiguïté de \(y_\ell\). Les ventilations
« selon \(z_e\) » de ces mêmes grandeurs, en revanche, sont contaminées.

### Ce que le défaut apprend, au-delà de sa correction

Il n'a été trouvé ni par les tests, ni par les gardes, ni par le validateur —
tous verts pendant six révisions. Il a été trouvé parce qu'**une latence
médiane ET maximale de 0,00 ms a été jugée physiquement impossible**.

Trois choses l'avaient masqué :

1. **L'unité.** En millisecondes, 2 746 événements affichaient « 0.00 ms ».
   L'arrondi ne rendait pas la mesure imprécise : il l'**effaçait**.
2. **Le sens de l'artefact.** Il produisait \(z_e = 1\) — un succès. Un défaut
   qui fabrique des échecs se remarque ; un défaut qui fabrique des succès
   confirme ce qu'on espère.
3. **La plausibilité du résultat.** Une baseline honnête de 0,7 % et un
   attaquant à 81 % : exactement ce qu'on attendait. **Le défaut rendait le
   résultat MEILLEUR**, et c'est pour cela qu'il a survécu à six revues.

Aucune garde générique n'aurait attrapé cela. La seule défense qui a fonctionné
est la confrontation d'un chiffre à une **borne physique**.

### Conséquence sur l'ordre des travaux

La prochaine exécution produit une **nouvelle baseline STEP 3**, sur des
observations propres. Tant qu'elle n'est pas mesurée, aucun chiffre de
non-observation ne doit être cité. L'adaptateur et l'attribution par paquet
restent après.

---

## 5. Périmètre en trois parties

**A — A3.3 exactement. FAIT** (§ 4undecies). Fonction pure, sans ns-3, oracles
calculés à la main.
Éq. (6) somme des poids disponibles ; Éq. (7) moyenne géométrique pondérée ×
couverture, avec \(x_k = 0\) traité avant tout \(\log\) ; Éq. (8) moyenne
arithmétique pondérée ; Éq. (9) \(z_e\) seul ; Éq. (10) \(I_e = O_e d_e\).

**B — Instrumentation.** Le corps de l'étape.

| grandeur | type | statut décidé |
|---|---|---|
| `passiveVisibility` | \(x_k\) | **`available = 0`** quand \(j\) n'a rien diffusé, jamais `value = 0` (§ 4bis) ; redéfinition § 3.3 à mesurer |
| `linkReliability` | \(x_k\) | **INSTRUMENTÉE** — traces MAC `AckedMpdu` / `NAckedMpdu`, historique borné de 32 issues, `available` si ≥ 4 issues |
| `predictedContactPersistence` | \(x_k\) | **indisponible** jusqu'à estimateur local validé |
| **`linkFailureDuringWindow`** | \(y_\ell\) | **INSTRUMENTÉ** (§ 4duodecies) — issue MAC observée PENDANT la fenêtre |
| `mobilityBreak` | \(y_\ell\) | ÉCARTÉ pour l'instant — la table de voisinage AODV retient 2 s, 13x la fenêtre |
| `coherentRerr` | \(y_\ell\) | à instrumenter — flux RERR reçu par \(i\) |
| `queuePressure` | \(y_\ell\) | **indisponible** (file de \(j\) non lisible) |

**C — Calibration de \(\omega_k, \nu_\ell\).** Marqués **À confirmer C-05**.
Seeds **distincts** de l'évaluation. Ne peut pas venir avant B.

---

## 6. Critères de fermeture (élargis sur demande utilisateur)

STEP 4 **ne peut pas** être fermé sur la seule implémentation de
`EvidenceAttributor`. PASS exige les huit :

1. **T-13**, test prescrit par la spécification : sur une grille de valeurs,
   toutes les masses dans \([0,1]\) et \(g+m+b+u = 1\) à la tolérance près.
2. **Fail closed** : \(c_e = 0 \Rightarrow (0,0,0,1)\) et
   \(d_e = 0 \Rightarrow (0,0,0,1)\), testés explicitement.
3. **Oracles calculés à la main** avant encodage, au moins trois attributions
   complètes.
4. **Instrumentation locale effective** des caractéristiques et diagnostics
   réellement accessibles (§ 5 partie B).
5. **Compteurs de disponibilité** rapportés par grandeur : combien d'événements
   avec \(a_k = 1\), combien avec \(a_\ell = 1\).
6. **Distributions rapportées** de \(c_e\), \(d_e\), \(O_e\), \(I_e\), \(u_e\).
7. **Fraction d'événements non interprétables** mesurée et rapportée.
   Si elle vaut 1, l'étape est **FAIL** — l'instrumentation n'aurait rien apporté.
8. **Non-intrusion et non-régression** : `PDR` inchangé au chiffre près, les 11
   suites vertes, `src/aodv` intact.

Les poids OCEA ne peuvent être **calibrés et gelés qu'après** cette validation.

**Rapporté sans seuil** : distributions des quatre masses chez un voisin honnête
et chez un attaquant ; écart entre l'Éq. (9) spécifiée et la variante
\(z_e \wedge \text{attribué}\).

**FAIL :** une masse hors \([0,1]\) ; une somme ≠ 1 ; une valeur par défaut
substituée à une caractéristique indisponible ; la lecture de l'état interne
d'un voisin ; l'usage de la liste des attaquants hors évaluation hors ligne ;
`passiveVisibility` dérivé de \(z_e\).

---

## 7. Le finding hérité du STEP 3

L'Éq. (9) accorde \((1,0,0,0)\) dès \(z_e = 1\). Le STEP 3 a mesuré **1 272 des
6 739 événements d'attaquant (18,9 %) avec \(z_e = 1\) et attribution nulle** :
la retransmission venait d'un **tiers**.

**Traitement :** l'Éq. (9) est implémentée telle que spécifiée. STEP 4 rapporte
**en parallèle**, en diagnostic séparé, les masses obtenues sous
\(z_e \wedge \text{attribué}\). Implémenter la spécification, instrumenter
l'alternative, mesurer l'écart.

---

## 8. Ce que STEP 4 ne fera PAS

- Pas de MOBeta-Trust : les Éq. (11)–(12) et le posterior Beta consomment les
  masses OCEA, étape suivante.
- Pas de calibration finale de \(\omega, \nu\) : après B, sur seeds distincts.
- Pas de changement de machine à états : WATCH reste une surveillance renforcée,
  ACCUSED n'est pas une quarantaine, QUARANTINED exige un certificat.
- Pas de correction de `IsBroadcast()` : faiblesse enregistrée au STEP 3, sans
  effet sur ce périmètre.

<!-- MTCAODV_DELIVERY_REVISION: r22 -->
