#!/usr/bin/env python3
# MTCAODV_DELIVERY_REVISION: r22
"""Baseline bénigne agrégée sur PLUSIEURS seeds — le jeu de calibration.

Pourquoi ce script existe
-------------------------
La baseline de non-observation honnête vaut 0,0071 sur le seed 1, mesurée sur
**30 événements**. Deux conséquences que les livraisons précédentes ont
signalées sans jamais les lever :

  * l'erreur-type vaut ±0,0013, soit 18 % en relatif, sur la grandeur même que
    l'Éq. (8) doit expliquer ;
  * la variabilité INTER-SEED est inconnue. Un seed unique ne dit pas si 0,0071
    est représentatif ou particulier.

Trente événements ne calibrent aucun poids. Ce script agrège plusieurs seeds
pour produire, d'une part la taille d'échantillon nécessaire à la calibration
des ν_l, d'autre part la dispersion inter-seed qui manquait.

Séparation calibration / évaluation
-----------------------------------
Le seed d'évaluation ne doit PAS figurer ici. La règle de l'utilisateur est que
les poids se calibrent sur des seeds DISTINCTS de ceux qui servent à mesurer la
performance. Le script refuse un seed explicitement réservé (--evaluation-seed)
plutôt que de laisser la contamination passer silencieusement.

Évaluation HORS LIGNE : le regroupement honnête/attaquant lit les manifestes.
L'observateur n'a jamais accès à cette information.

Bibliothèque standard uniquement.
"""

from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
from pathlib import Path
from typing import Sequence

from analyze_features import load_rows
from analyze_forwarding import ForwardingAnalysisError, load_manifest


def _ratio(numerator: int, denominator: int) -> float:
    """Un dénominateur nul rend NaN, jamais 0 : l'absence n'est pas un zéro."""
    return numerator / denominator if denominator else math.nan


def _fmt(value: float) -> str:
    return "indefini" if math.isnan(value) else f"{value:.4f}"


# Emplacements EFFECTIFS du seed dans le manifeste du pilote, verifies dans
# mtcaodv-pilot-attack.cc : blocs "rng" (ligne 1115) et "configuration"
# (ligne 1098). Une premiere version cherchait "seed", "rngSeed" et
# "scenario.seed" -- aucun n'existe. La garde de separation etait donc INERTE :
# elle ne trouvait jamais le seed, donc n'a jamais rien refuse, et son silence
# se lisait comme une verification reussie. Meme motif que les quatre chemins
# morts deja recenses, cette fois dans le code de la garde elle-meme.
SEED_LOCATIONS = (("rng", "seed"), ("configuration", "seed"), ("seed",))


def _seed_of(manifest_path: Path) -> int | None:
    """Lit le seed déclaré dans le manifeste. None si INTROUVABLE, jamais 0."""
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    for path in SEED_LOCATIONS:
        node = data
        for key in path:
            if not isinstance(node, dict) or key not in node:
                node = None
                break
            node = node[key]
        if node is None:
            continue
        try:
            return int(node)
        except (TypeError, ValueError):
            continue
    return None


def summarise_seed(observations: Path, manifest: Path) -> dict:
    """Baseline honnête d'un seed. Lève plutôt que de rendre un résultat partiel."""
    rows = load_rows(observations)
    attackers, nodes, _ = load_manifest(manifest)
    honest = [r for r in rows
              if r["neighbor"] >= 0 and r["neighbor"] not in attackers]
    if not honest:
        raise ForwardingAnalysisError(
            f"{observations} : aucune observation sur voisin honnete. La "
            "baseline de ce seed est INDEFINIE, elle ne peut pas entrer dans "
            "une agregation.")
    missed = sum(1 for r in honest if not r["observed"])
    return {
        "observations": observations,
        "manifest": manifest,
        "seed": _seed_of(manifest),
        "nodes": nodes,
        "attackers": sorted(attackers),
        "honest": len(honest),
        "missed": missed,
        "rate": _ratio(missed, len(honest)),
    }


def pool(summaries: Sequence[dict]) -> dict:
    """Agrège. Le taux groupé n'est PAS la moyenne des taux par seed.

    Les seeds n'ont pas le même nombre d'observations ; la moyenne des taux les
    pondérerait également, alors que l'estimateur correct de la baseline est le
    rapport des totaux. Les deux sont rapportés, et leur écart est informatif.
    """
    total_honest = sum(s["honest"] for s in summaries)
    total_missed = sum(s["missed"] for s in summaries)
    rates = [s["rate"] for s in summaries if not math.isnan(s["rate"])]
    pooled = _ratio(total_missed, total_honest)
    return {
        "seeds": len(summaries),
        "totalHonest": total_honest,
        "totalMissed": total_missed,
        "pooledRate": pooled,
        "meanOfRates": statistics.fmean(rates) if rates else math.nan,
        # Dispersion INTER-SEED : la quantite inconnue depuis la premiere
        # mesure. Elle demande au moins deux seeds ; avec un seul, elle reste
        # indefinie et ne doit pas etre remplacee par zero.
        "betweenSeedSd": statistics.stdev(rates) if len(rates) > 1 else math.nan,
        "minRate": min(rates) if rates else math.nan,
        "maxRate": max(rates) if rates else math.nan,
        # Erreur-type du taux groupe, sous hypothese binomiale. Elle IGNORE la
        # correlation intra-seed ; comparee a la dispersion inter-seed, elle dit
        # si l'hypothese tient.
        "pooledStandardError": (
            math.sqrt(pooled * (1 - pooled) / total_honest)
            if total_honest and not math.isnan(pooled) else math.nan),
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--observations", required=True, nargs="+", type=Path)
    parser.add_argument("--manifests", required=True, nargs="+", type=Path)
    parser.add_argument("--evaluation-seed", type=int, default=1,
                        help="Seed reserve a l'evaluation ; sa presence est refusee.")
    parser.add_argument("--allow-unknown-seed", action="store_true",
                        help="Poursuivre malgre un seed introuvable dans un "
                             "manifeste. La separation calibration / evaluation "
                             "n'est alors PAS verifiee.")
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)

    if len(arguments.observations) != len(arguments.manifests):
        print(f"AGREGATION IMPOSSIBLE : {len(arguments.observations)} fichiers "
              f"d'observations pour {len(arguments.manifests)} manifestes. "
              "L'appariement est POSITIONNEL ; des longueurs differentes "
              "associeraient un seed au manifeste d'un autre.", file=sys.stderr)
        return 1

    summaries = []
    try:
        for obs, man in zip(arguments.observations, arguments.manifests):
            summary = summarise_seed(obs, man)
            # FAIL CLOSED. Un seed INTROUVABLE n'est pas un seed different de
            # celui d'evaluation : c'est une ignorance. Accepter silencieusement
            # rendrait la garde inerte -- ce qu'elle a ete jusqu'ici, faute de
            # chercher au bon endroit.
            if summary["seed"] is None:
                print(f"AGREGATION REFUSEE : seed INTROUVABLE dans {man}. "
                      f"Emplacements cherches : {SEED_LOCATIONS}. Sans le seed, "
                      "la separation calibration / evaluation ne peut pas etre "
                      "verifiee, et une garde qui ne verifie rien vaut moins "
                      "que pas de garde. Utilisez --allow-unknown-seed pour "
                      "passer outre en connaissance de cause.", file=sys.stderr)
                if not arguments.allow_unknown_seed:
                    return 1
            if summary["seed"] is not None and summary["seed"] == arguments.evaluation_seed:
                print(f"AGREGATION REFUSEE : {man} declare le seed "
                      f"{summary['seed']}, reserve a l'EVALUATION. Calibrer sur "
                      "le seed d'evaluation invaliderait la separation exigee.",
                      file=sys.stderr)
                return 1
            summaries.append(summary)
    except ForwardingAnalysisError as error:
        print(f"AGREGATION IMPOSSIBLE : {error}", file=sys.stderr)
        return 1

    print("=== Baseline benigne agregee — jeu de CALIBRATION ===")
    print(f"  seeds={len(summaries)}  (le seed {arguments.evaluation_seed} est "
          "reserve a l'evaluation et refuse ici)")
    print()
    print(f"  {'seed':>6} {'honnetes':>10} {'non-obs':>9} {'taux':>9}   attaquants")
    for s in summaries:
        seed = s["seed"] if s["seed"] is not None else "?"
        print(f"  {str(seed):>6} {s['honest']:>10} {s['missed']:>9} "
              f"{_fmt(s['rate']):>9}   {s['attackers']}")

    p = pool(summaries)
    print()
    print("=== Agregation ===")
    print(f"  evenements honnetes    = {p['totalHonest']}")
    print(f"  NON-OBSERVATIONS       = {p['totalMissed']}   <- taille du jeu de calibration")
    print(f"  taux groupe            = {_fmt(p['pooledRate'])} "
          f"(+/- {_fmt(p['pooledStandardError'])} binomial)")
    print(f"  moyenne des taux/seed  = {_fmt(p['meanOfRates'])}")
    print(f"  dispersion INTER-SEED  = {_fmt(p['betweenSeedSd'])} "
          f"(min {_fmt(p['minRate'])}, max {_fmt(p['maxRate'])})")

    print()
    print("=== Lecture ===")
    print("  Le taux groupe est le rapport des totaux, PAS la moyenne des taux :")
    print("  les seeds n'ont pas le meme nombre d'observations. Un ecart notable")
    print("  entre les deux signale des seeds tres inegaux en volume.")
    print()
    if math.isnan(p["betweenSeedSd"]):
        print("  Dispersion inter-seed INDEFINIE : un seul seed exploitable.")
    elif p["betweenSeedSd"] > 2 * p["pooledStandardError"]:
        print("  La dispersion inter-seed DEPASSE largement l'erreur binomiale.")
        print("  Les evenements ne sont donc pas independants a l'interieur d'un")
        print("  seed : topologie et mobilite sont partagees. Toute barre")
        print("  d'erreur publiee doit venir de la dispersion inter-seed, jamais")
        print("  de la formule binomiale, qui la sous-estimerait.")
    else:
        print("  La dispersion inter-seed reste comparable a l'erreur binomiale.")
        print("  Aucune correlation intra-seed marquee n'est detectee A CE VOLUME ;")
        print("  ce n'est pas une preuve d'independance, seulement une absence de")
        print("  preuve du contraire.")

    print()
    print("  AUCUN SEUIL n'est preenregistre pour la baseline elle-meme : elle")
    print("  est RAPPORTEE, jamais comparee a une valeur attendue.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
