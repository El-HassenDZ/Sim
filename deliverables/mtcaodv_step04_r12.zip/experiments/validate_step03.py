#!/usr/bin/env python3
"""Validate one MTC-AODV STEP 3 CSV row and manifest (forwarding observation).

STEP 3 adds the next-hop forwarding observation (A3.2) on top of the STEP 1
attack and the STEP 2 + C-19 WATCH screening. This validator is fail closed and
checks, in addition to the STEP 1 network/attack invariants:

  * the STEP 0 prefix is intact and the STEP 1, STEP 2, C-19 and STEP 3 columns
    are all present;
  * screening bookkeeping is consistent:
      - watchTruePositives + watchFalsePositives = distinct WATCH'd nodes,
      - watchTruePositives <= attackerCount,
      - watchTP + watchFP <= nodes,
      - screeningEnabled=0  =>  watchCount = watchTP = watchFP = 0,
      - attackerRatio=0     =>  watchTruePositives = 0  (no attacker to detect;
        watchFalsePositives MAY be > 0 — that is the false-alarm baseline).

C-19 (WATCH lifecycle) additionally requires:
      - the live counters are a subset of the cumulative ones:
        watch*PositivesCurrent <= watch*Positives,
      - the lifecycle parameters are usable: 1 <= minAnomalies <= window,
        0 <= anomalyFraction <= 1, expiry > 0 (WATCH must be able to clear),
        maxTrackedNeighbors >= 1 (bounded structures),
      - the manifest repeats the same counters and parameters as the CSV.

STEP 3 (A3.2 forwarding observation) additionally requires:
      - conservation: matched + deadline + neighborLost + evicted <= opened
        (a shortfall is a window still open at t_end, an excess is double
        counting; either way the observation bookkeeping is not trustworthy),
      - observationEnabled=0  =>  no window opened and no frame inspected
        (the OFF arm must be a true no-op, otherwise the non-intrusion
        comparison PDR(ON) == PDR(OFF) proves nothing),
      - the accounting of every inspected transmission is closed, as an exact
        identity and not a one-sided bound: opened + skippedLastHop +
        skippedNoRoute + skippedControlPlane + skippedNonUnicast +
        fragmentedPacketsExcluded = transmissionsInspected. A shortfall means an
        exit path was added to the observer without a counter, i.e. a
        transmission silently dropped,
      - windows opened while skippedLastHop = 0 is REJECTED. On the frozen
        scenario the mean corrected path is 1.73 hops, so the last-hop case
        dominates; a run that never skips it is observing the wrong end of the
        path and would fabricate a near-perfect honest baseline (STEP3_README
        section 10). NOTE that this is a property of the NETWORK-WIDE sum, not
        of any single observer: only a node whose next hop IS the destination
        can increment skippedLastHop, so a source two hops away legitimately
        reports zero. The CSV carries the sum over every observer, which is why
        the rule holds here and would be wrong per node,
      - the bounds are usable: observationWindow_s > 0, observationSweep_s > 0
        and <= the window, maxActiveWindows >= 1 (bounded structures).

Standard library only.  No metric is fabricated; a missing required column or a
violated invariant rejects the run.
"""

from __future__ import annotations

import argparse
import csv
import math
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence


class Step3ValidationError(ValueError):
    """Raised when a STEP 3 artifact violates a required invariant."""


def round_half_up(value: float) -> int:
    """Equation (2): floor(x + 0.5)."""
    return math.floor(value + 0.5)


REQUIRED_PREFIX = [
    "protocol", "nodes", "simTime", "minSpeed", "maxSpeed", "seed", "run",
    "attackerRatio", "attackerCount", "attackStart", "appTxPackets",
    "appRxPackets", "appTxBytes", "appRxBytes", "pdr", "plr", "throughput_bps",
    "goodput_bps", "meanDelay_s",
]
REQUIRED_STEP1 = ["forgedRrepCount", "blackholeDropCount", "attackStream",
                  "attackerSelectionStreamsConsumed"]
REQUIRED_STEP2 = ["screeningEnabled", "watchThreshold", "watchCount",
                  "watchTruePositives", "watchFalsePositives"]
# C-19 (WATCH lifecycle: persistence + expiry).  These columns are appended after
# the STEP 2 block; they report the LIVE surveillance set at t_end plus the
# lifecycle parameters that produced it.  A detection figure without its rule is
# not interpretable, so both the counters and the parameters are mandatory.
REQUIRED_C19 = ["watchTruePositivesCurrent", "watchFalsePositivesCurrent",
                "watchWindowSize", "watchMinimumAnomalies", "watchAnomalyFraction",
                "watchExpiry_s", "maxTrackedNeighbors"]
# STEP 3 (A3.2, next-hop forwarding observation). Appended after the C-19 block.
REQUIRED_STEP3 = ["observationEnabled", "windowsOpened", "windowsMatched",
                  "windowsDeadline", "windowsNeighborLost", "windowsEvicted",
                  "fingerprintCollisions", "fragmentedPacketsExcluded",
                  "promiscuousFramesInspected", "observationWindow_s",
                  "observationSweep_s", "maxActiveWindows",
                  # Why a window did NOT open. Mandatory: without them, "few
                  # windows" cannot be told from "the hook never fires".
                  "transmissionsInspected", "skippedLastHop", "skippedNoRoute",
                  "skippedControlPlane", "skippedNonUnicast"]


def _read_single_csv_row(path: Path) -> tuple[list[str], dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            header = list(reader.fieldnames or [])
            rows = list(reader)
    except OSError as error:
        raise Step3ValidationError(f"cannot read CSV {path}: {error}") from error
    if len(rows) != 1:
        raise Step3ValidationError(f"CSV must contain exactly one data row; found {len(rows)}")
    if len(header) != len(set(header)):
        raise Step3ValidationError("CSV header contains duplicate column names")
    return header, rows[0]


def _load_json(path: Path) -> dict[str, Any]:
    import json
    try:
        with path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
    except (OSError, ValueError) as error:
        raise Step3ValidationError(f"cannot read valid JSON {path}: {error}") from error
    if not isinstance(value, dict):
        raise Step3ValidationError(f"JSON root must be an object: {path}")
    return value


def _f(row: Mapping[str, str], name: str) -> float:
    try:
        return float(row[name])
    except (KeyError, ValueError) as error:
        raise Step3ValidationError(f"invalid float field {name}: {error}") from error


def _i(row: Mapping[str, str], name: str) -> int:
    try:
        return int(row[name])
    except (KeyError, ValueError) as error:
        raise Step3ValidationError(f"invalid int field {name}: {error}") from error


# ---------------------------------------------------------------------------
# AUDIT DES COMPTEURS NULS
#
# Un compteur qui vaut exactement zero sur un run entier est AMBIGU : soit le
# phenomene ne s'est pas produit (une mesure), soit le chemin qui l'incremente
# n'existe pas (une absence de code). Les deux se lisent identiquement dans une
# sortie, et rien ne les distingue sans lire les sources.
#
# Ce projet a produit quatre fois la meme erreur -- une grandeur structurellement
# constante presentee comme une mesure :
#   * passiveVisibility mesurait la cadence des HELLO, pas l'audibilite ;
#   * `available=1, value=0` opposait un veto a 85 % des evenements ;
#   * linkReliability valait 1,0 car NAckedMpdu est inerte en 802.11b ;
#   * windowsNeighborLost vaut 0 car NEIGHBOR_LOST n'est jamais emis.
#
# Chacune a ete trouvee par hasard. Cette table les rend systematiques : tout
# compteur nul doit etre CLASSE ici, avec sa raison. Un compteur nul absent de
# la table declenche un avertissement -- il faut alors decider s'il s'agit d'une
# mesure ou d'un chemin mort, et l'ecrire.
STRUCTURALLY_ZERO = {
    "windowsNeighborLost": (
        "CHEMIN NON IMPLEMENTE. NEIGHBOR_LOST est declare dans l'enumeration et "
        "compte dans CloseWindow(), mais AUCUN appelant ne le passe : les trois "
        "sites d'appel utilisent MATCHED, DEADLINE et EVICTED. Ce zero n'est "
        "donc pas une mesure de la mobilite."),
    "skippedNonUnicast": (
        "MESURE, expliquee. Ipv4Address::IsBroadcast() ne teste que "
        "255.255.255.255 ; les RREQ d'AODV visent une diffusion dirigee de "
        "sous-reseau et tombent dans skippedControlPlane (UDP 654) avant "
        "d'atteindre ce test."),
    "windowsEvicted": (
        "MESURE. La borne MaxActiveWindows (256) n'a jamais ete saturee sur le "
        "scenario gele ; le chemin d'eviction existe et est teste unitairement."),
    "fingerprintCollisions": (
        "MESURE. Aucune collision d'empreinte sur ce volume ; le compteur est "
        "incremente sur un chemin atteignable et couvert par les tests."),
    "fragmentedPacketsExcluded": (
        "MESURE. Aucun paquet fragmente : la charge utile de 512 octets reste "
        "sous la MTU."),
}


def audit_zero_counters(row: Mapping[str, str]) -> list[str]:
    """Signale les compteurs nuls non classes. Retourne les avertissements."""
    warnings: list[str] = []
    for column in REQUIRED_STEP3:
        # Seuls les COMPTEURS sont concernes ; les parametres et les drapeaux
        # peuvent legitimement valoir zero sans rien dire du code.
        if column.endswith("_s") or column in ("observationEnabled", "maxActiveWindows"):
            continue
        try:
            if int(row[column]) != 0:
                continue
        except (KeyError, ValueError):
            continue
        if column not in STRUCTURALLY_ZERO:
            warnings.append(
                f"{column} vaut 0 sans classification : est-ce une MESURE "
                f"(le phenomene ne s'est pas produit) ou un CHEMIN NON "
                f"IMPLEMENTE (rien ne l'incremente) ? Ajoutez-le a "
                f"STRUCTURALLY_ZERO avec sa raison.")
    return warnings


def validate(csv_path: Path,
             manifest_path: Path | None,
             *,
             expect_frozen_scenario: bool = False) -> dict[str, Any]:
    """Validate the STEP 3 CSV (and manifest when given). Returns a summary."""

    header, row = _read_single_csv_row(csv_path)

    # Column presence (prefix first and in order, then required columns).
    if header[: len(REQUIRED_PREFIX)] != REQUIRED_PREFIX:
        raise Step3ValidationError("CSV required prefix is missing, reordered, or renamed")
    for column in REQUIRED_STEP1 + REQUIRED_STEP2 + REQUIRED_C19 + REQUIRED_STEP3:
        if column not in header:
            raise Step3ValidationError(f"CSV missing required column: {column}")

    if row["protocol"] != "MTC-AODV":
        raise Step3ValidationError("STEP 3 must use protocol=MTC-AODV")

    nodes = _i(row, "nodes")
    ratio = _f(row, "attackerRatio")
    attacker_count = _i(row, "attackerCount")
    pdr = _f(row, "pdr")
    plr = _f(row, "plr")
    tx = _i(row, "appTxPackets")
    rx = _i(row, "appRxPackets")

    # Core STEP 1 invariants (subset; the full set lives in validate_step01.py).
    if not 0.0 <= ratio < 1.0:
        raise Step3ValidationError("attackerRatio must be in [0,1)")
    if attacker_count != round_half_up(ratio * nodes):
        raise Step3ValidationError("attackerCount violates Equation (2)")
    if tx <= 0 or not 0 <= rx <= tx:
        raise Step3ValidationError("appRxPackets must be in [0, appTxPackets] with appTxPackets>0")
    if math.isfinite(pdr):
        if not 0.0 <= pdr <= 1.0:
            raise Step3ValidationError("pdr must be in [0,1]")
        if not math.isclose(pdr, rx / tx, rel_tol=1e-9, abs_tol=1e-12):
            raise Step3ValidationError("pdr does not match appRxPackets/appTxPackets (Eq. 20)")
    if math.isfinite(plr) and not math.isclose(plr, 1.0 - rx / tx, rel_tol=1e-9, abs_tol=1e-12):
        raise Step3ValidationError("plr does not match 1 - pdr (Eq. 24)")

    # STEP 2 screening invariants.
    screening = _i(row, "screeningEnabled")
    threshold = _f(row, "watchThreshold")
    watch_count = _i(row, "watchCount")
    watch_tp = _i(row, "watchTruePositives")
    watch_fp = _i(row, "watchFalsePositives")

    if screening not in (0, 1):
        raise Step3ValidationError("screeningEnabled must be 0 or 1")
    if not 0.0 <= threshold <= 1.0:
        raise Step3ValidationError("watchThreshold must be in [0,1]")
    if min(watch_count, watch_tp, watch_fp) < 0:
        raise Step3ValidationError("WATCH counters must be non-negative")
    if watch_tp > attacker_count:
        raise Step3ValidationError("watchTruePositives cannot exceed attackerCount")
    if watch_tp + watch_fp > nodes:
        raise Step3ValidationError("distinct WATCH'd nodes cannot exceed the population")
    # A distinct node is WATCH'd only if at least one observer flagged it, which
    # requires at least one WATCH transition somewhere.
    if (watch_tp + watch_fp) > 0 and watch_count == 0:
        raise Step3ValidationError("detected nodes exist but watchCount is zero")
    if screening == 0 and (watch_count or watch_tp or watch_fp):
        raise Step3ValidationError("screeningEnabled=0 must produce zero WATCH activity")
    if ratio == 0.0 and watch_tp != 0:
        raise Step3ValidationError("attackerRatio=0 cannot yield a true positive")

    # ---- C-19 WATCH-lifecycle invariants ----
    watch_tp_current = _i(row, "watchTruePositivesCurrent")
    watch_fp_current = _i(row, "watchFalsePositivesCurrent")
    window_size = _i(row, "watchWindowSize")
    minimum_anomalies = _i(row, "watchMinimumAnomalies")
    anomaly_fraction = _f(row, "watchAnomalyFraction")
    expiry_seconds = _f(row, "watchExpiry_s")
    max_tracked = _i(row, "maxTrackedNeighbors")

    if min(watch_tp_current, watch_fp_current) < 0:
        raise Step3ValidationError("current WATCH counters must be non-negative")
    # The live set is a subset of the cumulative set by construction: a node can
    # only be "still watched" if it was watched at least once.  A violation means
    # the two aggregations disagree, i.e. a bookkeeping bug, not a scientific
    # result -- so it is rejected rather than reported.
    if watch_tp_current > watch_tp:
        raise Step3ValidationError(
            "watchTruePositivesCurrent cannot exceed the cumulative watchTruePositives"
        )
    if watch_fp_current > watch_fp:
        raise Step3ValidationError(
            "watchFalsePositivesCurrent cannot exceed the cumulative watchFalsePositives"
        )
    if screening == 0 and (watch_tp_current or watch_fp_current):
        raise Step3ValidationError("screeningEnabled=0 must produce no live WATCH set")
    if ratio == 0.0 and watch_tp_current != 0:
        raise Step3ValidationError("attackerRatio=0 cannot yield a live true positive")
    # Parameter sanity: an unusable rule would silently disable the defence.
    if window_size < 1:
        raise Step3ValidationError("watchWindowSize must be >= 1")
    if minimum_anomalies < 1:
        raise Step3ValidationError("watchMinimumAnomalies must be >= 1")
    if minimum_anomalies > window_size:
        raise Step3ValidationError(
            "watchMinimumAnomalies > watchWindowSize would make WATCH unreachable"
        )
    if not 0.0 <= anomaly_fraction <= 1.0:
        raise Step3ValidationError("watchAnomalyFraction must be in [0,1]")
    if not math.isfinite(expiry_seconds) or expiry_seconds <= 0.0:
        # At expiry = 0 a raised WATCH survives only until the neighbour's very
        # next observation, so the live surveillance set is empty in practice and
        # the defence is silently a no-op. That is a misconfiguration, not a
        # result, so it is rejected rather than reported as a low false-alarm rate.
        raise Step3ValidationError(
            "watchExpiry_s must be finite and > 0: at 0 the WATCH state cannot "
            "survive a single subsequent observation, silently voiding the defence"
        )
    if max_tracked < 1:
        raise Step3ValidationError("maxTrackedNeighbors must be >= 1 (bounded structures)")

    # ---- STEP 3 forwarding-observation invariants ----
    observation_enabled = _i(row, "observationEnabled")
    windows_opened = _i(row, "windowsOpened")
    windows_matched = _i(row, "windowsMatched")
    windows_deadline = _i(row, "windowsDeadline")
    windows_lost = _i(row, "windowsNeighborLost")
    windows_evicted = _i(row, "windowsEvicted")
    collisions = _i(row, "fingerprintCollisions")
    fragmented = _i(row, "fragmentedPacketsExcluded")
    frames_inspected = _i(row, "promiscuousFramesInspected")
    observation_window = _f(row, "observationWindow_s")
    observation_sweep = _f(row, "observationSweep_s")
    max_active = _i(row, "maxActiveWindows")

    if observation_enabled not in (0, 1):
        raise Step3ValidationError("observationEnabled must be 0 or 1")
    counters = (windows_opened, windows_matched, windows_deadline, windows_lost,
                windows_evicted, collisions, fragmented, frames_inspected)
    if min(counters) < 0:
        raise Step3ValidationError("observation counters must be non-negative")

    # CONSERVATION: every window that opened must eventually close, through
    # exactly one of the four paths. A shortfall means windows were still open at
    # the end -- observations silently lost; an excess means double counting.
    closed = windows_matched + windows_deadline + windows_lost + windows_evicted
    if closed > windows_opened:
        raise Step3ValidationError(
            f"more closures ({closed}) than openings ({windows_opened}): "
            "the observation bookkeeping is inconsistent"
        )

    if observation_enabled == 0 and (windows_opened or closed or frames_inspected):
        raise Step3ValidationError(
            "observationEnabled=0 must produce no window and inspect no frame"
        )

    # An EVICTED window observed nothing at all, so it can never be read as
    # z_e = 0. It is counted separately precisely so it cannot be.
    if windows_evicted > windows_opened:
        raise Step3ValidationError("windowsEvicted cannot exceed windowsOpened")

    if not math.isfinite(observation_window) or observation_window <= 0.0:
        raise Step3ValidationError(
            "observationWindow_s must be finite and > 0: a zero window closes "
            "every observation unmatched, turning every honest forward into an "
            "apparent non-observation"
        )
    if not math.isfinite(observation_sweep) or observation_sweep <= 0.0:
        raise Step3ValidationError("observationSweep_s must be finite and > 0")
    if observation_sweep > observation_window:
        raise Step3ValidationError(
            "observationSweep_s > observationWindow_s: windows would routinely "
            "outlive their deadline before the sweep noticed, inflating the "
            "measured match latency"
        )
    if max_active < 1:
        raise Step3ValidationError("maxActiveWindows must be >= 1 (bounded structures)")

    # ---- Accounting of transmissions the observer chose NOT to follow ----
    transmissions = _i(row, "transmissionsInspected")
    skipped_last_hop = _i(row, "skippedLastHop")
    skipped_no_route = _i(row, "skippedNoRoute")
    skipped_control = _i(row, "skippedControlPlane")
    skipped_non_unicast = _i(row, "skippedNonUnicast")
    skipped = (skipped_last_hop + skipped_no_route + skipped_control +
               skipped_non_unicast)

    if min(transmissions, skipped_last_hop, skipped_no_route, skipped_control,
           skipped_non_unicast) < 0:
        raise Step3ValidationError("skip counters must be non-negative")
    if observation_enabled == 0 and (transmissions or skipped):
        raise Step3ValidationError(
            "observationEnabled=0 must inspect no transmission at all"
        )
    # CLOSED ACCOUNTING. OnIpv4Transmit() counts every transmission it inspects,
    # then leaves through exactly one of six exits: the four skip counters, the
    # fragmented exclusion inside OpenWindow(), or an opened window. OpenWindow()
    # has a single call site, so the six are exhaustive and the identity is exact:
    #
    #   transmissionsInspected = windowsOpened + skippedLastHop + skippedNoRoute
    #                          + skippedControlPlane + skippedNonUnicast
    #                          + fragmentedPacketsExcluded
    #
    # Equality is enforced, not the one-sided bound: an excess means double
    # counting, and a SHORTFALL means a seventh exit was added without a counter
    # -- a transmission the observer silently dropped. That is the same family of
    # defect as the wrong-end-of-the-path bug this step was rewritten to fix, and
    # it is invisible to every other check here. The residual is reported so the
    # missing path is named by the failure itself.
    accounted = windows_opened + skipped + fragmented
    if observation_enabled == 1 and accounted != transmissions:
        raise Step3ValidationError(
            f"observation accounting is not closed: opened ({windows_opened}) + "
            f"skips ({skipped}) + fragmented ({fragmented}) = {accounted}, but "
            f"transmissionsInspected = {transmissions} "
            f"(residual {transmissions - accounted}); "
            "every inspected transmission must leave through exactly one counted exit"
        )
    # THE invariant that the first version of this step violated. On a network
    # whose paths are mostly two hops, the last hop -- relay to destination --
    # dominates, and the destination never retransmits. If nothing is ever
    # skipped as a last hop while windows are being opened, the observer is
    # opening windows on packets nobody will ever forward, and every honest
    # closure becomes a false non-observation.
    if observation_enabled == 1 and windows_opened > 0 and skipped_last_hop == 0:
        raise Step3ValidationError(
            "windows opened but skippedLastHop is zero: on a multi-hop network the "
            "relay-to-destination hop must be recognised and skipped, otherwise "
            "every honest final delivery is scored as a non-observation"
        )

    if expect_frozen_scenario:
        area = _f(row, "areaSize_m")
        max_range = _f(row, "maxRange_m")
        if nodes != 30 or not math.isclose(area, 600.0) or not math.isclose(max_range, 200.0):
            raise Step3ValidationError(
                "frozen STEP 1 scenario expected: nodes=30, area=600, maxRange=200"
            )

    if manifest_path is not None:
        manifest = _load_json(manifest_path)
        if manifest.get("schemaVersion") != "mtcaodv-step01-v1":
            raise Step3ValidationError("manifest schemaVersion mismatch")
        defence = manifest.get("defence")
        if not isinstance(defence, dict):
            raise Step3ValidationError("manifest is missing the 'defence' block")
        if int(defence.get("watchCount", -1)) != watch_count:
            raise Step3ValidationError("manifest watchCount differs from CSV")
        if int(defence.get("watchTruePositives", -1)) != watch_tp:
            raise Step3ValidationError("manifest watchTruePositives differs from CSV")
        if int(defence.get("watchFalsePositives", -1)) != watch_fp:
            raise Step3ValidationError("manifest watchFalsePositives differs from CSV")
        if int(defence.get("watchTruePositivesCurrent", -1)) != watch_tp_current:
            raise Step3ValidationError("manifest watchTruePositivesCurrent differs from CSV")
        if int(defence.get("watchFalsePositivesCurrent", -1)) != watch_fp_current:
            raise Step3ValidationError("manifest watchFalsePositivesCurrent differs from CSV")
        if int(defence.get("watchWindowSize", -1)) != window_size:
            raise Step3ValidationError("manifest watchWindowSize differs from CSV")
        if int(defence.get("watchMinimumAnomalies", -1)) != minimum_anomalies:
            raise Step3ValidationError("manifest watchMinimumAnomalies differs from CSV")

    return {
        "nodes": nodes, "attackerCount": attacker_count, "pdr": pdr,
        "screeningEnabled": screening, "watchCount": watch_count,
        "watchTP": watch_tp, "watchFP": watch_fp,
        "watchTPCurrent": watch_tp_current, "watchFPCurrent": watch_fp_current,
        "watchWindowSize": window_size, "watchMinimumAnomalies": minimum_anomalies,
        "watchAnomalyFraction": anomaly_fraction, "watchExpiry_s": expiry_seconds,
        "observationEnabled": observation_enabled, "windowsOpened": windows_opened,
        "windowsMatched": windows_matched, "windowsDeadline": windows_deadline,
        "windowsEvicted": windows_evicted, "fingerprintCollisions": collisions,
        "transmissionsInspected": transmissions, "skippedLastHop": skipped_last_hop,
        "skippedNoRoute": skipped_no_route,
        "zeroCounterWarnings": audit_zero_counters(row),
    }


def _parse_arguments(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--csv", required=True, type=Path)
    parser.add_argument("--manifest", type=Path, default=None)
    parser.add_argument("--expect-frozen-scenario", action="store_true",
                        help="require nodes=30, area=600, maxRange=200 (the STEP 1 freeze)")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        summary = validate(arguments.csv, arguments.manifest,
                           expect_frozen_scenario=arguments.expect_frozen_scenario)
    except Step3ValidationError as error:
        print(f"STEP 3 validation FAIL: {error}", file=sys.stderr)
        return 1
    for warning in summary.get("zeroCounterWarnings", []):
        print(f"AVERTISSEMENT compteur nul : {warning}", file=sys.stderr)
    print(
        "STEP 3 validation PASS: "
        f"{arguments.csv} (attackers={summary['attackerCount']}, PDR={summary['pdr']:.6f}, "
        f"screening={summary['screeningEnabled']}, watchCount={summary['watchCount']}, "
        f"TP={summary['watchTP']}, FP={summary['watchFP']}, "
        f"observation={summary['observationEnabled']}, "
        f"tx={summary['transmissionsInspected']}, "
        f"skippedLastHop={summary['skippedLastHop']}, "
        f"opened={summary['windowsOpened']}, matched={summary['windowsMatched']})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
