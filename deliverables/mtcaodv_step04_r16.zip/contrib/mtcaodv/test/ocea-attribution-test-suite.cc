/* SPDX-License-Identifier: GPL-2.0-only */

/**
 * @file
 * @ingroup mtcaodv-tests
 * @brief Tests de l'Algorithme A3.3 — attribution OCEA (Eq. 6-10).
 *
 * D'OU VIENNENT LES VALEURS ATTENDUES
 * -----------------------------------
 * De `experiments/ocea_reference.py`, implementation de reference ecrite AVANT
 * cet encodage C++, et dont chaque oracle est verifiable a la main :
 *
 *     python3 experiments/ocea_reference.py --oracles
 *
 * Un test qui se contenterait de constater ce que le code produit ne verifierait
 * rien. C'est la meme discipline qu'aux Eq. (3)-(5) du STEP 2 et qu'a l'empreinte
 * de paquet du STEP 3.
 *
 * AUCUNE SIMULATION
 * -----------------
 * Ces tests ne demarrent pas ns-3. A3.3 est de l'arithmetique pure ; l'y
 * soumettre a un `Simulator::Run()` rendrait les echecs difficiles a localiser
 * et masquerait les cas limites (0.0, 1.0, poids nuls) qu'aucun scenario ne
 * produit spontanement.
 */

#include "ns3/ocea-attribution.h"
#include "ns3/test.h"

#include <cmath>
#include <vector>

using namespace ns3;
using namespace ns3::mtcaodv;

namespace
{

/** @brief Tolerance des comparaisons numeriques ; voir OCEA_CONSERVATION_TOLERANCE. */
constexpr double TOL = 1e-12;

/** @brief Raccourci : une caracteristique complete. */
OceaFeature
Feat(double weight, double value, bool available)
{
    OceaFeature f;
    f.weight = weight;
    f.value = value;
    f.available = available;
    return f;
}

/** @brief Raccourci : deux caracteristiques de poids 0,5 formant une partition. */
std::vector<OceaFeature>
Pair(double v0, bool a0, double v1, bool a1)
{
    return {Feat(0.5, v0, a0), Feat(0.5, v1, a1)};
}

} // namespace

/**
 * @brief Les huit oracles calcules en Python avant tout encodage.
 *
 * Ils couvrent les cinq sorties structurellement differentes d'A3.3 : preuve
 * positive (ligne 2), couverture nulle (ligne 4), diagnostic nul (ligne 7),
 * veto de l'Eq. (7), et le regime nominal de l'Eq. (10).
 */
class OceaOracleTestCase : public TestCase
{
  public:
    OceaOracleTestCase()
        : TestCase("Les huit oracles A3.3 reproduisent la reference Python")
    {
    }

  private:
    void DoRun() override
    {
        // --- Oracle 1 : z_e = 1, Eq. (9). Sortie avant toute couverture. ---
        {
            const auto r = AttributeOceaEvidence(true,
                                                 Pair(0.81, true, 0.49, true),
                                                 Pair(0.25, true, 0.75, true));
            NS_TEST_ASSERT_MSG_EQ_TOL(r.positiveEvidenceMass, 1.0, TOL, "g attendu 1");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.maliciousEvidenceMass, 0.0, TOL, "m attendu 0");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.benignLossMass, 0.0, TOL, "b attendu 0");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 0.0, TOL, "u attendu 0");
        }

        // --- Oracle 2 : c_e = 0, A3.3 ligne 4. -----------------------------
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(0.81, false, 0.49, false),
                                                 Pair(0.25, true, 0.75, true));
            NS_TEST_ASSERT_MSG_EQ_TOL(r.opportunityCoverage, 0.0, TOL, "c attendu 0");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 1.0, TOL, "u attendu 1");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.maliciousEvidenceMass, 0.0, TOL, "m attendu 0");
        }

        // --- Oracle 3 : d_e = 0, A3.3 ligne 7. c=0,5 ; O=0,5*1^1=0,5. ------
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(1.0, true, 0.25, false),
                                                 Pair(0.25, false, 0.75, false));
            NS_TEST_ASSERT_MSG_EQ_TOL(r.opportunityCoverage, 0.5, TOL, "c attendu 0,5");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.forwardingOpportunity, 0.5, TOL, "O attendu 0,5");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.diagnosticCoverage, 0.0, TOL, "d attendu 0");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 1.0, TOL, "u attendu 1");
        }

        // --- Oracle 4 : veto. x_k = 0 DISPONIBLE -> O = 0 -> (0,0,0,1). ----
        // Aucune branche dediee : l'Eq. (10) produit seule le bon resultat.
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(0.0, true, 0.49, true),
                                                 Pair(0.25, true, 0.75, true));
            NS_TEST_ASSERT_MSG_EQ(r.opportunityVetoed, true, "veto attendu");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.opportunityCoverage, 1.0, TOL, "c attendu 1");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.forwardingOpportunity, 0.0, TOL, "O attendu 0");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.diagnosticCoverage, 1.0, TOL, "d attendu 1");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 1.0, TOL, "u attendu 1");
        }

        // --- Oracle 5 : nominal. O = sqrt(0,81 x 0,49) = 0,9 x 0,7 = 0,63. -
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(0.81, true, 0.49, true),
                                                 Pair(0.25, true, 0.75, true));
            NS_TEST_ASSERT_MSG_EQ_TOL(r.opportunityCoverage, 1.0, TOL, "c attendu 1");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.forwardingOpportunity, 0.63, TOL, "O attendu 0,63");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.diagnosticCoverage, 1.0, TOL, "d attendu 1");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.benignLossLikelihood, 0.5, TOL, "B attendu 0,5");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.interpretableEvidence, 0.63, TOL, "I attendu 0,63");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.maliciousEvidenceMass, 0.315, TOL, "m attendu 0,315");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.benignLossMass, 0.315, TOL, "b attendu 0,315");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 0.37, TOL, "u attendu 0,37");
        }

        // --- Oracle 6 : une seule x disponible, poids 0,4. -----------------
        // c = 0,4 ; O = 0,4 x 0,6^(0,4/0,4) = 0,24 ; B = 1 ; I = 0,24.
        // La couverture PLAFONNE l'opportunite : instrumenter une seule des
        // deux caracteristiques ne peut pas donner une opportunite pleine.
        {
            const std::vector<OceaFeature> opportunity = {Feat(0.4, 0.6, true),
                                                          Feat(0.6, 0.9, false)};
            const auto r =
                AttributeOceaEvidence(false, opportunity, Pair(1.0, true, 1.0, true));
            NS_TEST_ASSERT_MSG_EQ_TOL(r.opportunityCoverage, 0.4, TOL, "c attendu 0,4");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.forwardingOpportunity, 0.24, TOL, "O attendu 0,24");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.benignLossLikelihood, 1.0, TOL, "B attendu 1");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.maliciousEvidenceMass, 0.0, TOL, "m attendu 0");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.benignLossMass, 0.24, TOL, "b attendu 0,24");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 0.76, TOL, "u attendu 0,76");
        }

        // --- Oracle 7 : B = 1, cause benigne certaine. ---------------------
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(1.0, true, 1.0, true),
                                                 Pair(1.0, true, 1.0, true));
            NS_TEST_ASSERT_MSG_EQ_TOL(r.benignLossMass, 1.0, TOL, "b attendu 1");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.maliciousEvidenceMass, 0.0, TOL, "m attendu 0");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 0.0, TOL, "u attendu 0");
        }

        // --- Oracle 8 : B = 0, aucune cause benigne. -----------------------
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(1.0, true, 1.0, true),
                                                 Pair(0.0, true, 0.0, true));
            NS_TEST_ASSERT_MSG_EQ_TOL(r.maliciousEvidenceMass, 1.0, TOL, "m attendu 1");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.benignLossMass, 0.0, TOL, "b attendu 0");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 0.0, TOL, "u attendu 0");
        }
    }
};

/**
 * @brief T-13, le test de conservation prescrit par la specification.
 *
 * La grille croise valeurs, disponibilites et \f$z_e\f$, et inclut 0.0 et 1.0
 * aux bornes : ce sont precisement les valeurs ou une implementation naive
 * casse — `log(0)`, `pow(0,0)`, `1 - I < 0`.
 */
class OceaConservationTestCase : public TestCase
{
  public:
    OceaConservationTestCase()
        : TestCase("T-13 : masses dans [0,1] et de somme 1 sur une grille exhaustive")
    {
    }

  private:
    void DoRun() override
    {
        const double values[] = {0.0, 0.25, 0.5, 1.0};
        const bool flags[] = {false, true};
        uint32_t checked = 0;

        for (bool z : flags)
        {
            for (double x0 : values)
            {
                for (double x1 : values)
                {
                    for (bool a0 : flags)
                    {
                        for (bool a1 : flags)
                        {
                            for (double y0 : values)
                            {
                                for (double y1 : values)
                                {
                                    for (bool b0 : flags)
                                    {
                                        for (bool b1 : flags)
                                        {
                                            const auto r =
                                                AttributeOceaEvidence(z,
                                                                      Pair(x0, a0, x1, a1),
                                                                      Pair(y0, b0, y1, b1));
                                            NS_TEST_ASSERT_MSG_EQ(
                                                OceaMassesAreConserved(r),
                                                true,
                                                "conservation rompue en x0=" << x0 << " x1=" << x1
                                                                             << " y0=" << y0
                                                                             << " y1=" << y1);
                                            ++checked;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Une grille reduite a un point passerait aussi : on fige sa taille.
        NS_TEST_ASSERT_MSG_EQ(checked,
                              static_cast<uint32_t>(2 * 4 * 4 * 2 * 2 * 4 * 4 * 2 * 2),
                              "grille tronquee");

        // Poids non uniformes : la conservation ne doit rien devoir a la symetrie.
        for (double w : {0.0, 0.1, 0.5, 0.9, 1.0})
        {
            const std::vector<OceaFeature> opportunity = {Feat(w, 0.3, true),
                                                          Feat(1.0 - w, 0.8, true)};
            const std::vector<OceaFeature> diagnostic = {Feat(w, 0.2, true),
                                                         Feat(1.0 - w, 0.6, true)};
            const auto r = AttributeOceaEvidence(false, opportunity, diagnostic);
            NS_TEST_ASSERT_MSG_EQ(OceaMassesAreConserved(r),
                                  true,
                                  "conservation rompue a poids w=" << w);
        }
    }
};

/**
 * @brief Le predicat de conservation doit pouvoir ECHOUER.
 *
 * Une garde qui ne peut pas se declencher se lit comme une verification
 * reussie. Ce projet a deja recense cinq occurrences de ce motif ; celle-ci
 * est verrouillee.
 */
class OceaConservationPredicateTestCase : public TestCase
{
  public:
    OceaConservationPredicateTestCase()
        : TestCase("Le predicat de conservation accepte le vrai et rejette le faux")
    {
    }

  private:
    void DoRun() override
    {
        const auto good = AttributeOceaEvidence(false,
                                                Pair(0.81, true, 0.49, true),
                                                Pair(0.25, true, 0.75, true));
        NS_TEST_ASSERT_MSG_EQ(OceaMassesAreConserved(good), true, "une vraie attribution");

        {
            OceaAttribution broken = good;
            broken.uncertainEvidenceMass += 0.5; // somme != 1
            NS_TEST_ASSERT_MSG_EQ(OceaMassesAreConserved(broken), false, "somme != 1 acceptee");
        }
        {
            OceaAttribution broken = good;
            broken.maliciousEvidenceMass = -0.25;
            broken.uncertainEvidenceMass += 0.25 + good.maliciousEvidenceMass;
            NS_TEST_ASSERT_MSG_EQ(OceaMassesAreConserved(broken), false, "masse negative acceptee");
        }
        {
            OceaAttribution broken = good;
            broken.benignLossMass = std::nan("");
            NS_TEST_ASSERT_MSG_EQ(OceaMassesAreConserved(broken), false, "NaN accepte");
        }
    }
};

/** @brief Les trois branches fail-closed, plus la garde d'entree. */
class OceaFailClosedTestCase : public TestCase
{
  public:
    OceaFailClosedTestCase()
        : TestCase("Fail closed : couverture nulle, diagnostic nul, entrees refusees")
    {
    }

  private:
    void DoRun() override
    {
        // --- A3.3 ligne 4 : aucune caracteristique disponible. -------------
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(0.9, false, 0.9, false),
                                                 Pair(0.5, true, 0.5, true));
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 1.0, TOL, "u attendu 1");
            NS_TEST_ASSERT_MSG_EQ(r.inputsValid, true, "les entrees etaient valides");
            NS_TEST_ASSERT_MSG_EQ(r.computed, true, "c_e = 0 est une MESURE, pas un non-calcul");
        }

        // --- A3.3 ligne 7 : aucun diagnostic disponible. -------------------
        // C'est la branche empruntee AUJOURD'HUI par tous les evenements reels.
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(1.0, true, 1.0, true),
                                                 Pair(0.5, false, 0.5, false));
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 1.0, TOL, "u attendu 1");
            // L'opportunite reste calculee et rapportee : sans elle on ne
            // saurait pas que SEUL d_e manque.
            NS_TEST_ASSERT_MSG_EQ_TOL(r.forwardingOpportunity, 1.0, TOL, "O doit rester mesure");
            NS_TEST_ASSERT_MSG_EQ(r.computed, true, "d_e = 0 est une MESURE");
        }

        // --- Garde d'entree : valeur hors [0,1], REFUSEE et non ecretee. ---
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(1.5, true, 0.5, true),
                                                 Pair(0.5, true, 0.5, true));
            NS_TEST_ASSERT_MSG_EQ(r.inputsValid, false, "1,5 aurait du etre refuse");
            NS_TEST_ASSERT_MSG_EQ(r.computed, false, "rien ne doit avoir ete calcule");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 1.0, TOL, "u attendu 1");
        }

        // --- Garde d'entree : NaN. -----------------------------------------
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(std::nan(""), true, 0.5, true),
                                                 Pair(0.5, true, 0.5, true));
            NS_TEST_ASSERT_MSG_EQ(r.inputsValid, false, "NaN aurait du etre refuse");
        }

        // --- Une valeur INDISPONIBLE n'est pas examinee. -------------------
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(42.0, false, 0.5, true),
                                                 Pair(0.5, true, 0.5, true));
            NS_TEST_ASSERT_MSG_EQ(r.inputsValid, true, "une valeur indisponible n'a pas de sens");
        }

        // --- Poids non normalises : refuses, jamais renormalises en douce. -
        {
            const std::vector<OceaFeature> bad = {Feat(0.9, 1.0, true), Feat(0.9, 1.0, true)};
            const auto r = AttributeOceaEvidence(false, bad, Pair(0.0, true, 0.0, true));
            NS_TEST_ASSERT_MSG_EQ(r.inputsValid, false, "somme des poids 1,8 acceptee");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 1.0, TOL, "u attendu 1");
        }

        // --- Predicats de validite, exerces directement. -------------------
        NS_TEST_ASSERT_MSG_EQ(OceaWeightsPartitionUnity({}), false, "ensemble vide accepte");
        NS_TEST_ASSERT_MSG_EQ(OceaWeightsPartitionUnity({Feat(0.5, 0, false), Feat(0.6, 0, false)}),
                              false,
                              "somme 1,1 acceptee");
        NS_TEST_ASSERT_MSG_EQ(OceaWeightsPartitionUnity({Feat(-0.5, 0, false), Feat(1.5, 0, false)}),
                              false,
                              "poids negatif accepte");
        NS_TEST_ASSERT_MSG_EQ(OceaWeightsPartitionUnity({Feat(0.5, 0, false), Feat(0.5, 0, false)}),
                              true,
                              "partition legitime refusee");
    }
};

/**
 * @brief Le veto de l'Eq. (7) — le point le plus glissant de l'algorithme.
 *
 * Une caracteristique DISPONIBLE valant exactement 0 annule l'opportunite quel
 * que soit son poids, car \f$0^{\omega/c} = 0\f$ pour tout exposant positif.
 * Une caracteristique INDISPONIBLE valant 0 n'annule rien. La confusion entre
 * les deux a deja coute 85 % des evenements de ce projet.
 */
class OceaVetoTestCase : public TestCase
{
  public:
    OceaVetoTestCase()
        : TestCase("Veto de l'Eq. (7) : disponible-et-nul annule, indisponible n'annule pas")
    {
    }

  private:
    void DoRun() override
    {
        // --- Un poids minuscule vetoe quand meme. --------------------------
        {
            const std::vector<OceaFeature> opportunity = {Feat(1e-6, 0.0, true),
                                                          Feat(1.0 - 1e-6, 1.0, true)};
            const auto r =
                AttributeOceaEvidence(false, opportunity, Pair(0.0, true, 0.0, true));
            NS_TEST_ASSERT_MSG_EQ(r.opportunityVetoed, true, "veto attendu a poids 1e-6");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.forwardingOpportunity, 0.0, TOL, "O attendu 0");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.uncertainEvidenceMass, 1.0, TOL, "u attendu 1");
        }

        // --- Un zero INDISPONIBLE ne vetoe pas. ----------------------------
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(0.0, false, 1.0, true),
                                                 Pair(0.0, true, 0.0, true));
            NS_TEST_ASSERT_MSG_EQ(r.opportunityVetoed, false, "veto sur une valeur indisponible");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.opportunityCoverage, 0.5, TOL, "c attendu 0,5");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.forwardingOpportunity, 0.5, TOL, "O attendu 0,5");
        }

        // --- Poids nul : exclu du produit comme de la somme. ---------------
        // Regle d'implementation, statut Propose. Sans elle, pow(0,0) = 1
        // rendrait un poids nul inoffensif tandis qu'un poids de 1e-4 vetoerait :
        // discontinuite arbitraire.
        {
            const std::vector<OceaFeature> opportunity = {Feat(0.0, 0.0, true),
                                                          Feat(1.0, 0.8, true)};
            const auto r =
                AttributeOceaEvidence(false, opportunity, Pair(0.0, true, 0.0, true));
            NS_TEST_ASSERT_MSG_EQ(r.opportunityVetoed, false, "un poids nul ne doit pas vetoer");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.opportunityCoverage, 1.0, TOL, "c attendu 1");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.forwardingOpportunity, 0.8, TOL, "O attendu 0,8");
        }

        // --- Le veto exige un zero EXACT ; 1e-12 attenue, il n'annule pas. -
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(1e-12, true, 1.0, true),
                                                 Pair(0.0, true, 0.0, true));
            NS_TEST_ASSERT_MSG_EQ(r.opportunityVetoed, false, "veto sur une valeur non nulle");
            NS_TEST_ASSERT_MSG_GT(r.forwardingOpportunity, 0.0, "O devrait rester positif");
            NS_TEST_ASSERT_MSG_EQ_TOL(r.forwardingOpportunity, 1e-6, 1e-15, "O attendu 1e-6");
        }
    }
};

/**
 * @brief Distinguer « intermediaire nul mesure » de « intermediaire non calcule ».
 *
 * Ce n'est pas de la pedanterie. Un exportateur qui agregerait les \f$c_e\f$
 * conventionnels des evenements \f$z_e = 1\f$ avec les \f$c_e\f$ reellement
 * calcules ferait chuter la couverture moyenne rapportee sans qu'aucune
 * couverture n'ait baisse.
 */
class OceaComputedFlagTestCase : public TestCase
{
  public:
    OceaComputedFlagTestCase()
        : TestCase("Le drapeau computed separe le zero mesure du zero conventionnel")
    {
    }

  private:
    void DoRun() override
    {
        const auto observed = AttributeOceaEvidence(true,
                                                    Pair(1.0, true, 1.0, true),
                                                    Pair(1.0, true, 1.0, true));
        NS_TEST_ASSERT_MSG_EQ(observed.computed, false, "z=1 court-circuite : rien n'est calcule");
        NS_TEST_ASSERT_MSG_EQ_TOL(observed.opportunityCoverage, 0.0, TOL, "c non calcule");

        const auto refused = AttributeOceaEvidence(false,
                                                   Pair(2.0, true, 1.0, true),
                                                   Pair(1.0, true, 1.0, true));
        NS_TEST_ASSERT_MSG_EQ(refused.computed, false, "entrees refusees : rien n'est calcule");
    }
};

/**
 * @brief Proprietes de SENS, au-dela de l'arithmetique.
 *
 * Les oracles verifient des nombres ; ceux-ci verifient que ces nombres vont
 * dans la direction que la specification leur prete. Une inversion de signe
 * dans l'Eq. (10) passerait la conservation sans etre detectee.
 */
class OceaMonotonicityTestCase : public TestCase
{
  public:
    OceaMonotonicityTestCase()
        : TestCase("Monotonies : m croit quand les causes benignes refluent, u quand O baisse")
    {
    }

  private:
    void DoRun() override
    {
        double previous = -1.0;
        for (double y : {1.0, 0.75, 0.5, 0.25, 0.0})
        {
            const auto r =
                AttributeOceaEvidence(false, Pair(1.0, true, 1.0, true), Pair(y, true, y, true));
            NS_TEST_ASSERT_MSG_GT(r.maliciousEvidenceMass,
                                  previous,
                                  "m devrait croitre quand y decroit, a y=" << y);
            previous = r.maliciousEvidenceMass;
        }

        previous = -1.0;
        for (double x : {1.0, 0.75, 0.5, 0.25, 0.0})
        {
            const auto r = AttributeOceaEvidence(false,
                                                 Pair(x, true, x, true),
                                                 Pair(0.5, true, 0.5, true));
            NS_TEST_ASSERT_MSG_GT(r.uncertainEvidenceMass,
                                  previous,
                                  "u devrait croitre quand x decroit, a x=" << x);
            previous = r.uncertainEvidenceMass;
        }
    }
};

/** @brief Suite de tests de l'attribution OCEA (STEP 4, A3.3). */
class OceaAttributionTestSuite : public TestSuite
{
  public:
    OceaAttributionTestSuite()
        : TestSuite("mtcaodv-ocea-attribution", Type::UNIT)
    {
        AddTestCase(new OceaOracleTestCase, TestCase::Duration::QUICK);
        AddTestCase(new OceaConservationTestCase, TestCase::Duration::QUICK);
        AddTestCase(new OceaConservationPredicateTestCase, TestCase::Duration::QUICK);
        AddTestCase(new OceaFailClosedTestCase, TestCase::Duration::QUICK);
        AddTestCase(new OceaVetoTestCase, TestCase::Duration::QUICK);
        AddTestCase(new OceaComputedFlagTestCase, TestCase::Duration::QUICK);
        AddTestCase(new OceaMonotonicityTestCase, TestCase::Duration::QUICK);
    }
};

static OceaAttributionTestSuite g_oceaAttributionTestSuite;
