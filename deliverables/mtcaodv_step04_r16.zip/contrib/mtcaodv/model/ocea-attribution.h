/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef MTCAODV_OCEA_ATTRIBUTION_H
#define MTCAODV_OCEA_ATTRIBUTION_H

#include <vector>

/**
 * @file
 * @ingroup mtcaodv
 * @brief Algorithme A3.3 — attribution OCEA d'un evenement en quatre masses.
 *
 * UNITE PURE, SANS NS-3
 * ---------------------
 * Ce fichier n'inclut AUCUN en-tete ns-3 et ne depend d'aucun simulateur.
 * Ce n'est pas une coquetterie : les Eq. (6)-(10) sont de l'arithmetique, et
 * une arithmetique qui exige un `Simulator::Run()` pour etre testee n'est pas
 * testee — elle est constatee.  Toute la validation numerique tient dans des
 * tests sans simulation, ou chaque valeur attendue a ete calculee ailleurs.
 *
 * Les valeurs attendues des tests proviennent de `experiments/ocea_reference.py`,
 * ecrit AVANT cet encodage.  Voir `python3 experiments/ocea_reference.py --oracles`.
 *
 * LES EQUATIONS, TELLES QUE SPECIFIEES
 * ------------------------------------
 * \f[ (6)\quad c_e = \sum_k \omega_k a_k(e) \f]
 * \f[ (7)\quad O_e = c_e \prod_k x_k(e)^{\omega_k a_k(e) / c_e} \f]
 * \f[ (8)\quad d_e = \sum_\ell \nu_\ell a_\ell(e), \qquad
 *              \bar B_e = \frac{\sum_\ell \nu_\ell a_\ell(e) y_\ell(e)}{d_e} \f]
 * \f[ (9)\quad z_e = 1 \Rightarrow (g,m,b,u) = (1,0,0,0) \f]
 * \f[ (10)\quad I_e = \mathrm{clip}(O_e d_e, 0, 1), \qquad
 *              (g,m,b,u) = (0,\; I_e(1-\bar B_e),\; I_e \bar B_e,\; 1-I_e) \f]
 *
 * BRANCHES FAIL-CLOSED D'A3.3
 * ---------------------------
 * - ligne 2 : \f$z_e = 1\f$ -> \f$(1,0,0,0)\f$, sortie AVANT toute couverture ;
 * - ligne 4 : \f$c_e = 0\f$ -> \f$(0,0,0,1)\f$ ;
 * - ligne 7 : \f$d_e = 0\f$ -> \f$(0,0,0,1)\f$ ;
 * - ligne 9 : \f$I_e = \mathrm{clip}(O_e d_e, 0, 1)\f$ ;
 * - lignes 13-14 : assertions de conservation.
 *
 * @note ETAT DE L'INSTRUMENTATION AU MOMENT DE CET ENCODAGE.  Aucun diagnostic
 *       \f$y_\ell\f$ n'est instrumente (STEP 4 partie B).  La ligne 7 est donc
 *       la branche empruntee par la TOTALITE des evenements reels.  Ce fichier
 *       traite correctement ce cas ; il ne le resout pas.  Le critere de
 *       fermeture n^o 7 du STEP 4 (« si la fraction d'evenements non
 *       interpretables vaut 1, l'etape est FAIL ») reste donc NON SATISFAIT
 *       par ce seul fichier, et c'est enonce ici pour que personne — moi
 *       compris — ne lise « A3.3 implemente » comme « STEP 4 ferme ».
 */

namespace ns3
{
namespace mtcaodv
{

/**
 * @ingroup mtcaodv
 * @brief Tolerance de conservation des masses (lignes 13-14 d'A3.3).
 *
 * Le calcul enchaine un `log`, un `exp` et deux produits.  1e-12 est trois
 * ordres de grandeur au-dessus de l'erreur d'arrondi attendue sur quelques
 * termes, et trois ordres en dessous de toute erreur de modelisation qui
 * changerait une conclusion.
 */
constexpr double OCEA_CONSERVATION_TOLERANCE = 1e-12;

/**
 * @ingroup mtcaodv
 * @brief Tolerance sur \f$\sum_k \omega_k = 1\f$. Voir OceaWeightsPartitionUnity().
 */
constexpr double OCEA_WEIGHT_SUM_TOLERANCE = 1e-9;

/**
 * @ingroup mtcaodv
 * @brief Un triplet (poids, valeur, disponibilite) — une entree des Eq. (6)-(8).
 */
struct OceaFeature
{
    /** @brief \f$\omega_k\f$ (opportunite) ou \f$\nu_\ell\f$ (diagnostic). Doit etre >= 0. */
    double weight{0.0};

    /**
     * @brief \f$x_k(e)\f$ ou \f$y_\ell(e)\f$, dans [0,1].
     *
     * N'a de sens que si @c available est vrai.  Sa valeur est ignoree sinon,
     * et n'est meme pas controlee : lui imposer un domaine reviendrait a lui
     * preter un sens qu'elle n'a pas.
     */
    double value{0.0};

    /**
     * @brief \f$a_k(e)\f$ — la grandeur a-t-elle ete REELLEMENT observee ?
     *
     * @warning `available = false` et `value = 0.0` ne sont PAS
     *          interchangeables.  Le premier retire la caracteristique de la
     *          couverture (6) ; le second est un VETO ABSOLU dans l'Eq. (7),
     *          car \f$0^{\omega/c} = 0\f$ pour tout exposant positif.  Les
     *          confondre est exactement la faute que l'Eq. (6) existe pour
     *          empecher, et elle a deja ete commise une fois dans ce projet
     *          (`passiveVisibility`, 85 % des evenements annules).
     */
    bool available{false};

    /** @brief Poids effectif \f$\omega_k a_k\f$ — zero si indisponible. */
    double Mass() const
    {
        return available ? weight : 0.0;
    }
};

/**
 * @ingroup mtcaodv
 * @brief Sortie complete d'A3.3 : les quatre masses ET tous les intermediaires.
 *
 * Les intermediaires ne sont pas du confort de deverminage.  Sans \f$c_e\f$ et
 * \f$d_e\f$ separes, une incertitude totale ne dit pas SI elle vient de
 * l'absence d'opportunite ou de l'absence de diagnostic — deux problemes
 * d'instrumentation opposes, avec deux corrections opposees.
 */
struct OceaAttribution
{
    /** @brief \f$g_e\f$ — preuve positive de relais (Eq. 9). */
    double positiveEvidenceMass{0.0};

    /** @brief \f$m_e\f$ — masse imputee a une suppression deliberee (Eq. 10). */
    double maliciousEvidenceMass{0.0};

    /** @brief \f$b_e\f$ — masse imputee a une perte benigne (Eq. 10). */
    double benignLossMass{0.0};

    /** @brief \f$u_e\f$ — masse non attribuee. Vaut 1 dans tous les cas fail-closed. */
    double uncertainEvidenceMass{1.0};

    /**
     * @brief \f$c_e\f$ — couverture d'opportunite (Eq. 6).
     * @note Vaut 0 PAR CONVENTION, non par mesure, quand la ligne 2 court-circuite
     *       (\f$z_e = 1\f$) ou quand les entrees sont refusees. Voir @c computed.
     */
    double opportunityCoverage{0.0};

    /** @brief \f$O_e\f$ — opportunite de relais (Eq. 7). */
    double forwardingOpportunity{0.0};

    /** @brief \f$d_e\f$ — couverture diagnostique (Eq. 8). */
    double diagnosticCoverage{0.0};

    /** @brief \f$\bar B_e\f$ — vraisemblance de cause benigne (Eq. 8). */
    double benignLossLikelihood{0.0};

    /** @brief \f$I_e\f$ — evidence interpretable (Eq. 10, ligne 9). */
    double interpretableEvidence{0.0};

    /**
     * @brief Une caracteristique d'opportunite DISPONIBLE valait exactement 0.
     *
     * A rapporter separement : un \f$O_e = 0\f$ par veto et un \f$O_e\f$ nul
     * faute de couverture sont deux etats differents que les masses seules ne
     * distinguent pas — toutes deux donnent \f$(0,0,0,1)\f$.
     */
    bool opportunityVetoed{false};

    /**
     * @brief Les entrees ont-elles passe la garde de validite ?
     *
     * Faux = l'evenement a ete REFUSE (poids non normalises, valeur hors [0,1],
     * NaN).  Ce n'est pas une incertitude legitime mais un defaut d'appelant,
     * et il doit etre compte comme tel.
     */
    bool inputsValid{true};

    /**
     * @brief Les intermediaires \f$c_e, O_e, d_e\f$ ont-ils ete CALCULES ?
     *
     * Faux quand la ligne 2 court-circuite ou quand les entrees sont refusees.
     * Distinguer ce zero-la d'un zero mesure n'est pas de la pedanterie : un
     * exportateur qui moyennerait les deux ferait chuter la couverture
     * rapportee sans qu'aucune couverture n'ait baisse — le meme motif de
     * defaut, « valeur structurellement constante lue comme une mesure », a
     * deja ete recense cinq fois dans ce projet.
     */
    bool computed{false};

    /** @brief \f$g+m+b+u\f$ — doit valoir 1 a OCEA_CONSERVATION_TOLERANCE pres. */
    double TotalMass() const
    {
        return positiveEvidenceMass + maliciousEvidenceMass + benignLossMass +
               uncertainEvidenceMass;
    }
};

/**
 * @brief Les poids forment-ils une partition de l'unite ?
 *
 * PRECONDITION NORMATIVE.  L'Eq. (7) borne \f$O_e\f$ par \f$c_e \le \sum_k
 * \omega_k\f$.  Des poids sommant a plus de 1 laisseraient \f$I_e > 1\f$, donc
 * une masse d'incertitude NEGATIVE apres \f$1 - I_e\f$.  Le `clip` de la ligne 9
 * masquerait alors le defaut au lieu de le signaler.  On refuse en amont.
 *
 * Un ensemble VIDE est refuse : il n'exprime pas « rien de disponible » — c'est
 * le role de @c available — mais « le modele n'a aucune caracteristique »,
 * qui est une erreur de configuration.
 *
 * @param features Caracteristiques a controler.
 * @return Vrai si tous les poids sont finis, >= 0, et somment a 1.
 */
bool OceaWeightsPartitionUnity(const std::vector<OceaFeature>& features);

/**
 * @brief Les valeurs DISPONIBLES sont-elles finies et dans [0,1] ?
 * @param features Caracteristiques a controler.
 * @return Vrai si aucune valeur disponible n'est NaN, infinie ou hors [0,1].
 */
bool OceaValuesAreValid(const std::vector<OceaFeature>& features);

/**
 * @brief Les quatre masses sont-elles dans [0,1] et de somme 1 ?
 *
 * A3.3 se termine par deux ASSERTIONS (lignes 13-14). Elles sont exposees ici
 * comme un PREDICAT, non comme un `assert()`.
 *
 * La raison n'est pas stylistique : `assert()` disparait sous NDEBUG, donc
 * dans toute construction optimisee — exactement le motif « verification
 * structurellement inerte » recense cinq fois dans ce projet, ou une garde
 * silencieuse se lit comme une verification reussie. Un predicat, lui,
 * s'appelle dans les tests ET dans l'exportateur, et un echec s'y COMPTE au
 * lieu d'y avorter le simulateur au milieu d'une campagne.
 *
 * @param attribution Sortie d'AttributeOceaEvidence().
 * @return Vrai si la conservation tient a OCEA_CONSERVATION_TOLERANCE pres.
 */
bool OceaMassesAreConserved(const OceaAttribution& attribution);

/**
 * @brief Algorithme A3.3 — attribue un evenement d'observation en quatre masses.
 *
 * Fonction PURE : meme entree, meme sortie, aucun etat, aucune horloge, aucune
 * source aleatoire.  Elle ne connait ni les identites des noeuds, ni la liste
 * des attaquants, ni le temps de simulation — et ne peut donc pas en dependre.
 *
 * @param forwardingObserved \f$z_e\f$, le fait etabli par A3.2.
 * @param opportunity Les \f$x_k\f$ avec leurs \f$\omega_k\f$ (Eq. 6-7).
 * @param diagnostic Les \f$y_\ell\f$ avec leurs \f$\nu_\ell\f$ (Eq. 8).
 * @return L'attribution complete ; masses toujours dans [0,1] et de somme 1.
 */
OceaAttribution AttributeOceaEvidence(bool forwardingObserved,
                                      const std::vector<OceaFeature>& opportunity,
                                      const std::vector<OceaFeature>& diagnostic);

} // namespace mtcaodv
} // namespace ns3

#endif // MTCAODV_OCEA_ATTRIBUTION_H
