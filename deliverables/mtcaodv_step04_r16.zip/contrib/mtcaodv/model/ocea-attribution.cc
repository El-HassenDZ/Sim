/* SPDX-License-Identifier: GPL-2.0-only */

#include "ocea-attribution.h"

#include <cmath>

namespace ns3
{
namespace mtcaodv
{

namespace
{

/**
 * @brief La sortie fail-closed : toute la masse sur l'incertitude.
 *
 * Une seule fonction pour les trois branches (entrees refusees, ligne 4,
 * ligne 7) afin qu'aucune ne puisse deriver silencieusement vers une autre
 * valeur « par defaut ».
 */
OceaAttribution
FullUncertainty()
{
    OceaAttribution result;
    result.positiveEvidenceMass = 0.0;
    result.maliciousEvidenceMass = 0.0;
    result.benignLossMass = 0.0;
    result.uncertainEvidenceMass = 1.0;
    return result;
}

} // namespace

bool
OceaWeightsPartitionUnity(const std::vector<OceaFeature>& features)
{
    if (features.empty())
    {
        return false;
    }
    double total = 0.0;
    for (const auto& feature : features)
    {
        if (!std::isfinite(feature.weight) || feature.weight < 0.0)
        {
            return false;
        }
        total += feature.weight;
    }
    return std::fabs(total - 1.0) <= OCEA_WEIGHT_SUM_TOLERANCE;
}

bool
OceaValuesAreValid(const std::vector<OceaFeature>& features)
{
    for (const auto& feature : features)
    {
        if (!feature.available)
        {
            // Une valeur indisponible n'entre dans aucune somme ni dans aucun
            // produit. On ne lui impose rien, volontairement.
            continue;
        }
        if (!std::isfinite(feature.value) || feature.value < 0.0 || feature.value > 1.0)
        {
            return false;
        }
    }
    return true;
}

bool
OceaMassesAreConserved(const OceaAttribution& attribution)
{
    const double masses[4] = {attribution.positiveEvidenceMass,
                              attribution.maliciousEvidenceMass,
                              attribution.benignLossMass,
                              attribution.uncertainEvidenceMass};
    for (const double mass : masses)
    {
        if (!std::isfinite(mass) || mass < -OCEA_CONSERVATION_TOLERANCE ||
            mass > 1.0 + OCEA_CONSERVATION_TOLERANCE)
        {
            return false;
        }
    }
    return std::fabs(attribution.TotalMass() - 1.0) <= OCEA_CONSERVATION_TOLERANCE;
}

OceaAttribution
AttributeOceaEvidence(bool forwardingObserved,
                      const std::vector<OceaFeature>& opportunity,
                      const std::vector<OceaFeature>& diagnostic)
{
    // ---- Garde d'implementation (HORS A3.3), direction fail-closed. --------
    // A3.3 suppose ses entrees propres. Les accepter sans controle laisserait
    // un x_k = 1.5 produire une masse d'incertitude negative en silence. On
    // refuse, et le refus est MARQUE (`inputsValid`) pour etre compte : un
    // evenement refuse et un evenement legitimement incertain produisent les
    // memes quatre masses, et seul ce drapeau les distingue.
    const bool inputsValid = OceaWeightsPartitionUnity(opportunity) &&
                             OceaWeightsPartitionUnity(diagnostic) &&
                             OceaValuesAreValid(opportunity) && OceaValuesAreValid(diagnostic);
    if (!inputsValid)
    {
        OceaAttribution refused = FullUncertainty();
        refused.inputsValid = false;
        refused.computed = false;
        return refused;
    }

    // ---- A3.3 ligne 2 / Eq. (9) : z_e = 1 -> (1,0,0,0). -------------------
    // Sortie AVANT toute couverture : une retransmission POSITIVEMENT observee
    // est une preuve, qu'on ait su ou non pourquoi elle etait possible.
    //
    // FINDING HERITE DU STEP 3, non corrige ici : 1 272 des 6 739 evenements
    // d'attaquant (18,9 %) portaient z_e = 1 alors que la retransmission venait
    // d'un TIERS. L'Eq. (9) leur accorde quand meme (1,0,0,0). C'est ce que la
    // specification demande ; la variante `z_e ET attribue` est mesuree en
    // parallele, en appelant cette meme fonction avec un z_e conjonctif — elle
    // n'est PAS cablee ici, pour que la forme normative reste identifiable.
    if (forwardingObserved)
    {
        OceaAttribution positive;
        positive.positiveEvidenceMass = 1.0;
        positive.maliciousEvidenceMass = 0.0;
        positive.benignLossMass = 0.0;
        positive.uncertainEvidenceMass = 0.0;
        positive.computed = false; // les intermediaires ne sont pas calcules
        return positive;
    }

    // ---- Eq. (6) : c_e = somme des poids DISPONIBLES. ---------------------
    double coverage = 0.0;
    for (const auto& feature : opportunity)
    {
        coverage += feature.Mass();
    }

    // ---- A3.3 ligne 4 : c_e = 0 -> (0,0,0,1). -----------------------------
    if (coverage <= 0.0)
    {
        OceaAttribution result = FullUncertainty();
        result.computed = true;
        return result;
    }

    // ---- Eq. (7) : O_e = c_e * prod x_k^(w_k a_k / c_e). ------------------
    // Le cas x_k = 0 est traite AVANT tout appel a std::log, conformement a
    // l'arbitrage sur epsilon : un zero REELLEMENT DISPONIBLE est une
    // information (« observer etait impossible »), pas une singularite a
    // masquer par un plancher arbitraire. std::log(0.0) vaut -inf et
    // std::exp(-inf) vaut 0, donc la voie logarithmique donnerait le meme
    // resultat — mais par accident d'IEEE-754, en franchissant l'infini. Un
    // test explicite dit ce qu'on veut dire.
    //
    // REGLE D'IMPLEMENTATION (statut : Propose, absente de la specification).
    // Une caracteristique de poids w_k = 0 est exclue du PRODUIT comme elle
    // l'est de la SOMME (6). Sans cette regle, un poids nul valant 0 donnerait
    // std::pow(0,0) = 1 — soit aucune contribution — tandis qu'un poids de
    // 0,0001 valant 0 vetoerait tout. La discontinuite serait arbitraire. Le
    // critere retenu est donc `w_k a_k > 0`, le meme que celui de la somme.
    bool vetoed = false;
    for (const auto& feature : opportunity)
    {
        if (feature.Mass() > 0.0 && feature.value == 0.0)
        {
            vetoed = true;
            break;
        }
    }

    double opportunityValue = 0.0;
    if (!vetoed)
    {
        double logSum = 0.0;
        for (const auto& feature : opportunity)
        {
            const double mass = feature.Mass();
            if (mass > 0.0)
            {
                logSum += (mass / coverage) * std::log(feature.value);
            }
        }
        opportunityValue = coverage * std::exp(logSum);
    }

    // ---- Eq. (8) : d_e, puis B_e. -----------------------------------------
    double diagnosticCoverage = 0.0;
    double weightedBenign = 0.0;
    for (const auto& feature : diagnostic)
    {
        const double mass = feature.Mass();
        diagnosticCoverage += mass;
        weightedBenign += mass * feature.value;
    }

    // ---- A3.3 ligne 7 : d_e = 0 -> (0,0,0,1). -----------------------------
    // Sans aucun diagnostic, on ne peut pas distinguer « perdu par le canal »
    // de « supprime deliberement ». L'incertitude totale est la reponse
    // honnete. C'est aujourd'hui la branche empruntee par TOUS les evenements
    // reels : aucun y_l n'est encore instrumente.
    if (diagnosticCoverage <= 0.0)
    {
        OceaAttribution result = FullUncertainty();
        result.opportunityCoverage = coverage;
        result.forwardingOpportunity = opportunityValue;
        result.opportunityVetoed = vetoed;
        result.computed = true;
        return result;
    }

    const double benign = weightedBenign / diagnosticCoverage;

    // ---- Eq. (10) + A3.3 ligne 9. -----------------------------------------
    double interpretable = opportunityValue * diagnosticCoverage;
    interpretable = std::fmin(1.0, std::fmax(0.0, interpretable));

    OceaAttribution result;
    result.positiveEvidenceMass = 0.0;
    result.maliciousEvidenceMass = interpretable * (1.0 - benign);
    result.benignLossMass = interpretable * benign;
    result.uncertainEvidenceMass = 1.0 - interpretable;
    result.opportunityCoverage = coverage;
    result.forwardingOpportunity = opportunityValue;
    result.diagnosticCoverage = diagnosticCoverage;
    result.benignLossLikelihood = benign;
    result.interpretableEvidence = interpretable;
    result.opportunityVetoed = vetoed;
    result.inputsValid = true;
    result.computed = true;
    return result;
}

} // namespace mtcaodv
} // namespace ns3
