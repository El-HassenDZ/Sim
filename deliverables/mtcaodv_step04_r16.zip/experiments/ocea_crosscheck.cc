/* SPDX-License-Identifier: GPL-2.0-only */

/**
 * @file
 * @brief Contre-controle numerique de l'Eq. (6)-(10) : C++ face a Python.
 *
 * POURQUOI CE PILOTE EXISTE
 * -------------------------
 * `contrib/mtcaodv/model/ocea-attribution.{h,cc}` n'inclut AUCUN en-tete ns-3.
 * Cette purete a un benefice concret : l'arithmetique peut etre compilee et
 * EXECUTEE par un simple `g++`, sans arbre ns-3, donc partout — y compris la ou
 * la suite `mtcaodv-ocea-attribution` ne peut pas tourner.
 *
 * Le pilote imprime les memes huit oracles que
 * `python3 experiments/ocea_reference.py --machine`, dans le meme format, pour
 * que `check_ocea_arithmetic.sh` compare les deux implementations champ par
 * champ. Il ne remplace PAS la suite ns-3 : celle-ci teste davantage (grille
 * T-13, predicat de conservation, monotonies) et doit etre executee sur l'arbre
 * ns-3.48 de l'utilisateur.
 *
 * Les huit cas sont TRANSCRITS ici a la main depuis le tableau des oracles, et
 * non generes : deux transcriptions independantes d'un meme tableau se
 * contredisent si l'une derive.
 */

#include "ocea-attribution.h"

#include <cstdio>
#include <string>
#include <vector>

using ns3::mtcaodv::AttributeOceaEvidence;
using ns3::mtcaodv::OceaAttribution;
using ns3::mtcaodv::OceaFeature;

namespace
{

OceaFeature
Feat(double weight, double value, bool available)
{
    OceaFeature f;
    f.weight = weight;
    f.value = value;
    f.available = available;
    return f;
}

std::vector<OceaFeature>
Pair(double v0, bool a0, double v1, bool a1)
{
    return {Feat(0.5, v0, a0), Feat(0.5, v1, a1)};
}

/** @brief Imprime une ligne au format attendu par le comparateur. */
void
Emit(const std::string& name, const OceaAttribution& a)
{
    std::printf("%s;%.17g;%.17g;%.17g;%.17g;%.17g;%.17g;%.17g;%.17g;%.17g;%d;%d;%d\n",
                name.c_str(),
                a.opportunityCoverage,
                a.forwardingOpportunity,
                a.diagnosticCoverage,
                a.benignLossLikelihood,
                a.interpretableEvidence,
                a.positiveEvidenceMass,
                a.maliciousEvidenceMass,
                a.benignLossMass,
                a.uncertainEvidenceMass,
                a.opportunityVetoed ? 1 : 0,
                a.inputsValid ? 1 : 0,
                a.computed ? 1 : 0);
}

} // namespace

int
main()
{
    Emit("z=1 : preuve positive, Eq. (9)",
         AttributeOceaEvidence(true, Pair(0.81, true, 0.49, true), Pair(0.25, true, 0.75, true)));

    Emit("c=0 : aucune caracteristique disponible",
         AttributeOceaEvidence(false,
                               Pair(0.81, false, 0.49, false),
                               Pair(0.25, true, 0.75, true)));

    Emit("d=0 : aucun diagnostic disponible",
         AttributeOceaEvidence(false,
                               Pair(1.0, true, 0.25, false),
                               Pair(0.25, false, 0.75, false)));

    Emit("veto : x_k = 0 DISPONIBLE",
         AttributeOceaEvidence(false, Pair(0.0, true, 0.49, true), Pair(0.25, true, 0.75, true)));

    Emit("nominal : deux x, deux y",
         AttributeOceaEvidence(false, Pair(0.81, true, 0.49, true), Pair(0.25, true, 0.75, true)));

    {
        const std::vector<OceaFeature> opportunity = {Feat(0.4, 0.6, true), Feat(0.6, 0.9, false)};
        Emit("une seule x disponible, poids 0,4",
             AttributeOceaEvidence(false, opportunity, Pair(1.0, true, 1.0, true)));
    }

    Emit("B=1 : cause benigne certaine",
         AttributeOceaEvidence(false, Pair(1.0, true, 1.0, true), Pair(1.0, true, 1.0, true)));

    Emit("B=0 : aucune cause benigne",
         AttributeOceaEvidence(false, Pair(1.0, true, 1.0, true), Pair(0.0, true, 0.0, true)));

    return 0;
}
