#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Contre-contrôle numérique de l'Algorithme A3.3 : C++ face à Python.
#
# POURQUOI CE SCRIPT EXISTE
# `contrib/mtcaodv/model/ocea-attribution.{h,cc}` n'inclut aucun en-tête ns-3.
# Cette pureté paie ici : l'arithmétique des Éq. (6)-(10) se compile et
# s'EXÉCUTE avec un simple `g++`, sans arbre ns-3, en une seconde. On peut donc
# vérifier les huit oracles PARTOUT — y compris là où `./test.py` ne peut pas
# tourner, et avant même d'avoir construit ns-3.
#
# CE QU'IL NE REMPLACE PAS
# La suite ns-3 `mtcaodv-ocea-attribution` teste davantage : la grille T-13
# complète (2 048 combinaisons), le prédicat de conservation, les monotonies,
# les gardes d'entrée. Ce script vérifie que les DEUX implémentations
# indépendantes — Python d'abord, C++ ensuite — donnent les mêmes nombres.
# Il est complémentaire, pas substitut.
#
# Usage :  bash experiments/check_ocea_arithmetic.sh [racine-du-module]
#          (défaut : le répertoire courant, supposé racine ns-3)
# ---------------------------------------------------------------------------
set -u

ROOT="${1:-$(pwd)}"
SRC="$ROOT/contrib/mtcaodv/model/ocea-attribution.cc"
HDR="$ROOT/contrib/mtcaodv/model/ocea-attribution.h"
DRIVER="$ROOT/experiments/ocea_crosscheck.cc"
REFERENCE="$ROOT/experiments/ocea_reference.py"

printf '== Contre-contrôle arithmétique A3.3 (%s) ==\n' "$ROOT"

for path in "$SRC" "$HDR" "$DRIVER" "$REFERENCE"; do
    if [ ! -f "$path" ]; then
        printf 'FAIL  fichier absent : %s\n' "$path"
        exit 1
    fi
done

CXX="${CXX:-g++}"
if ! command -v "$CXX" >/dev/null 2>&1; then
    printf 'FAIL  compilateur introuvable : %s (exportez CXX)\n' "$CXX"
    exit 1
fi

WORK="$(mktemp -d)"
# shellcheck disable=SC2064  # on veut l'expansion immédiate de $WORK
trap "rm -rf '$WORK'" EXIT

# -Wall -Wextra -Wpedantic mais PAS -Werror : une version de compilateur plus
# récente peut introduire un avertissement nouveau et légitime, et une garde qui
# rejette du code correct se fait désactiver — ce qui est pire que son absence.
# Les avertissements sont affichés, et comptés.
if ! "$CXX" -std=c++17 -Wall -Wextra -Wpedantic -O2 \
        -I "$ROOT/contrib/mtcaodv/model" \
        -o "$WORK/ocea_crosscheck" "$DRIVER" "$SRC" 2>"$WORK/build.log"; then
    printf 'FAIL  la compilation a échoué :\n'
    cat "$WORK/build.log"
    exit 1
fi
printf 'ok    compilation sans ns-3 (%s, C++17)\n' "$CXX"

if [ -s "$WORK/build.log" ]; then
    printf 'WARN  le compilateur a émis des avertissements :\n'
    cat "$WORK/build.log"
else
    printf 'ok    aucun avertissement (-Wall -Wextra -Wpedantic)\n'
fi

if ! "$WORK/ocea_crosscheck" >"$WORK/cpp.txt" 2>"$WORK/run.log"; then
    printf 'FAIL  le pilote a terminé anormalement :\n'
    cat "$WORK/run.log"
    exit 1
fi

LINES=$(wc -l <"$WORK/cpp.txt")
printf 'ok    pilote exécuté, %s lignes produites\n' "$LINES"

# Le comparateur refuse aussi un fichier TRONQUÉ : un pilote qui planterait
# après deux oracles ne doit pas passer pour un accord.
if ! python3 "$REFERENCE" --compare "$WORK/cpp.txt"; then
    printf 'FAIL  désaccord entre le C++ et la référence Python\n'
    exit 1
fi

printf '== Contre-contrôle : ACCORD ==\n'
exit 0
