#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Garde post-build STEP 3 : refuse de laisser passer un arbre de compilation
# incohérent vers une simulation.
#
# POURQUOI CE SCRIPT EXISTE
# Deux échecs consécutifs, de nature différente, ont eu la même conséquence :
# une commande de simulation atteignable avec un build qui ne correspondait pas
# aux sources.
#
#   1. `./ns3 build` déclenche une ré-exécution automatique de CMake quand un
#      CMakeLists.txt change, et cette ré-exécution REMET les options aux
#      défauts : examples et tests repassent à OFF. Les suites deviennent
#      « unknown test suite name » et le pilote « program not found ».
#
#   2. `unzip` restaure les horodatages de l'archive. Une source restaurée peut
#      être PLUS ANCIENNE que l'objet déjà compilé ; ninja la considère à jour
#      et ne la recompile jamais. On obtient alors un exécutable neuf lié contre
#      une bibliothèque périmée -- ou, si les signatures ont changé, cinq
#      `undefined reference` incompréhensibles à la lecture des sources.
#
# Ni l'un ni l'autre n'est visible dans les sources : il faut interroger le
# BUILD. C'est ce que fait ce script, et il échoue fermé (exit != 0).
#
# Usage :  bash experiments/check_step03_build.sh [racine-ns3]
#          (défaut : le répertoire courant)
# ---------------------------------------------------------------------------
set -u

ROOT="${1:-$(pwd)}"
LIB="$ROOT/build/lib/libns3.48-mtcaodv-default.so"
FAILURES=0

fail() { printf 'FAIL  %s\n' "$1"; FAILURES=$((FAILURES + 1)); }
pass() { printf 'ok    %s\n' "$1"; }
# WARN signale sans bloquer. Réservé aux contrôles dont l'ARTEFACT attendu n'est
# pas vérifié sur cette installation : une garde qui rejette un build correct
# coûte un cycle et se fait désactiver, ce qui est pire que de ne pas exister.
# Ne bloquent que les pannes SILENCIEUSES -- celles qu'aucun message d'erreur
# ultérieur ne signalerait.
warn() { printf 'WARN  %s\n' "$1"; }

printf '== Garde post-build STEP 3 (%s) ==\n' "$ROOT"

# --- 0. LES SOURCES SUR DISQUE SONT-ELLES LA BONNE VERSION ? --------------
# Panne observée deux fois : le navigateur n'écrase pas un téléchargement de
# même nom, il enregistre `...(1).zip`, `...(2).zip`. On ré-extrait alors
# toujours la PREMIERE archive, et l'arbre source RÉGRESSE silencieusement --
# un fichier récent est remplacé par un plus ancien, sans aucun avertissement.
#
# Deux marqueurs suffisent à dater l'arbre. La correction « mauvais bout du
# chemin » a supprimé le couplage entre le protocole de routage et
# l'observateur : l'observateur se pilote désormais seul depuis les traces
# Ipv4L3Protocol. Toute trace résiduelle de ce couplage prouve un arbre
# antérieur à cette correction.
RP_HEADER="$ROOT/contrib/mtcaodv/model/mtc-aodv-routing-protocol.h"
PILOT="$ROOT/contrib/mtcaodv/examples/mtcaodv-pilot-attack.cc"
STALE_SOURCE=0
if [ -f "$RP_HEADER" ] && grep -q 'SetForwardingObserver' "$RP_HEADER"; then
    fail "mtc-aodv-routing-protocol.h déclare encore SetForwardingObserver()"
    STALE_SOURCE=1
fi
if [ -f "$PILOT" ] && grep -q 'rp->SetForwardingObserver' "$PILOT"; then
    fail "le pilote appelle encore rp->SetForwardingObserver()"
    STALE_SOURCE=1
fi
if [ "$STALE_SOURCE" -eq 1 ]; then
    printf '      => ARBRE SOURCE PERIME : vous avez extrait une archive antérieure\n'
    printf '         à la correction « mauvais bout du chemin ». Le navigateur\n'
    printf '         n a pas écrasé le zip, il l a enregistré sous ...(1).zip.\n'
    printf '         Cherchez l archive PAR EMPREINTE, jamais par nom :\n'
    printf '            md5sum ~/Downloads/mtcaodv_step03*.zip\n'
    printf '         puis extrayez celle dont le md5 correspond à la livraison.\n'
    printf '\nRIEN D AUTRE N EST VERIFIE : le reste porterait sur le mauvais code.\n'
    exit 1
fi
pass "les sources sur disque sont postérieures à la correction du chemin"

# --- 1. La bibliothèque du module existe-t-elle ? -------------------------
if [ ! -f "$LIB" ]; then
    fail "bibliothèque absente : $LIB (le module n'a jamais été construit)"
    printf '\nRIEN D AUTRE NE PEUT ETRE VERIFIE. Lancez :\n'
    printf '  ./ns3 configure --enable-examples --enable-tests && ./ns3 build\n'
    exit 1
fi
pass "bibliothèque présente : $(basename "$LIB")"

# --- 2. Les symboles STEP 3 sont-ils réellement exportés ? ----------------
# On interroge la bibliothèque, pas la source : c'est la seule façon de
# détecter un objet périmé. Les cinq compteurs de rejet sont ceux ajoutés par
# la correction « mauvais bout du chemin » ; leur absence signifie que l'objet
# provient de la version antérieure de forwarding-observer.cc.
if ! command -v nm >/dev/null 2>&1; then
    fail "nm introuvable (paquet binutils) : impossible de vérifier les symboles"
else
    SYMBOLS="GetTransmissionsInspected GetSkippedLastHop GetSkippedNoRoute \
GetSkippedControlPlane GetSkippedNonUnicast GetWindowsOpened GetWindowsMatched"
    MISSING=""
    EXPORTED="$(nm -DC "$LIB" 2>/dev/null)"
    for symbol in $SYMBOLS; do
        case "$EXPORTED" in
            *"ForwardingObserver::$symbol"*) ;;
            *) MISSING="$MISSING $symbol" ;;
        esac
    done
    if [ -n "$MISSING" ]; then
        fail "symboles absents de la bibliothèque :$MISSING"
        printf '      => objet périmé. Correction :\n'
        printf '         find build -name "forwarding-observer.cc.o" -delete\n'
        printf '         touch contrib/mtcaodv/model/forwarding-observer.{cc,h}\n'
        printf '         ./ns3 build\n'
    else
        pass "les 7 accesseurs STEP 3 sont exportés par la bibliothèque"
    fi
fi

# --- 3. Aucune source n'est plus récente que la bibliothèque -------------
# Une source plus récente que la bibliothèque signifie une modification non
# compilée. C'est le symptôme inverse du cas 2, et tout aussi silencieux.
NEWER="$(find "$ROOT/contrib/mtcaodv/model" "$ROOT/contrib/mtcaodv/helper" \
              -name '*.cc' -o -name '*.h' 2>/dev/null \
         | while read -r f; do [ "$f" -nt "$LIB" ] && echo "  $f"; done)"
if [ -n "$NEWER" ]; then
    fail "sources plus récentes que la bibliothèque (non compilées) :"
    printf '%s\n' "$NEWER"
    printf '      => lancez ./ns3 build\n'
else
    pass "aucune source du module n'est plus récente que la bibliothèque"
fi

# --- 4. Examples et tests sont-ils activés ? ------------------------------
# Vérifié par la présence des artefacts, pas par la lecture d'un fichier de
# configuration : ce sont les artefacts qui décident si la commande marchera.
if [ -x "$ROOT/build/contrib/mtcaodv/examples/ns3.48-mtcaodv-pilot-attack-default" ]; then
    pass "l'exécutable du pilote existe (examples: ON)"
else
    fail "exécutable du pilote absent (examples: OFF)"
    printf '      => ./ns3 configure --enable-examples --enable-tests && ./ns3 build\n'
fi

# ns-3 nomme les bibliothèques de test PAR MODULE :
#   libns3.48-<module>-test-default.so
# La question utile n'est pas « des tests existent-ils quelque part » mais
# « la suite de CE module est-elle construite », car c'est elle que
# `./test.py -s mtcaodv-forwarding-observer` doit trouver. On cherche donc
# d'abord celle du module, puis, à défaut, n'importe quelle bibliothèque de
# test : si d'autres modules en ont une et pas mtcaodv, le diagnostic n'est pas
# « tests: OFF » mais « le module n'expose pas ses suites », ce qui appelle une
# correction différente. Le contenu réel de build/lib est affiché en cas
# d'échec, pour que la panne suivante soit lue sur des données et non devinée.
MODULE_TEST="$(ls "$ROOT"/build/lib/ 2>/dev/null | grep -E 'mtcaodv.*test.*\.so$' | head -1)"
ANY_TEST="$(ls "$ROOT"/build/lib/ 2>/dev/null | grep -E -- '-test-.*\.so$' | head -1)"
if [ -n "$MODULE_TEST" ]; then
    pass "la bibliothèque de test du module existe (tests: ON) : $MODULE_TEST"

    # --- 5. Les sources de test sont-elles compilées dans CETTE bibliothèque ? -
    # Panne SILENCIEUSE, donc bloquante : une suite de test périmée s'exécute
    # sans erreur et échoue -- ou pire, réussit -- pour des raisons qui
    # n'existent plus dans les sources. On a perdu un cycle exactement dessus :
    # un `touch` limité à model/ a laissé test/ intact, et l'ancienne suite a
    # été exécutée contre la nouvelle bibliothèque.
    TEST_LIB="$ROOT/build/lib/$MODULE_TEST"
    STALE_TESTS="$(find "$ROOT/contrib/mtcaodv/test" -name '*.cc' 2>/dev/null \
                   | while read -r f; do [ "$f" -nt "$TEST_LIB" ] && echo "  $f"; done)"
    if [ -n "$STALE_TESTS" ]; then
        fail "sources de test plus récentes que la bibliothèque de test :"
        printf '%s\n' "$STALE_TESTS"
        printf '      => vous exécuteriez une suite périmée. Lancez ./ns3 build\n'
    else
        pass "les sources de test ne sont pas plus récentes que leur bibliothèque"
    fi

    # --- 6. La bibliothèque de test contient-elle la SUITE ACTUELLE ? --------
    # Le contrôle 5 ne voit qu'un sens de la péremption : une source plus
    # récente que son objet. Le sens INVERSE lui échappe entièrement -- unzip
    # restaure une date ANCIENNE, l'objet paraît à jour, et une suite périmée
    # est exécutée sans que rien ne le signale. Aucun horodatage ne peut le
    # détecter : il faut interroger le CONTENU de l'artefact.
    #
    # On cherche donc dans la bibliothèque un message d'assertion qui n'existe
    # que dans la version actuelle de la suite : celui de l'anti-régression qui
    # vérifie que le RELAIS n'ouvre aucune fenêtre sur le saut final. C'est la
    # formulation d'après la correction « mauvais bout du chemin » ET d'après la
    # correction de l'assertion mal placée. Son absence prouve un objet antérieur.
    MARKER='le relais a ouvert une fenetre sur le saut final'
    if ! command -v strings >/dev/null 2>&1; then
        warn "strings introuvable (binutils) : contenu de la suite non vérifié"
    elif strings "$TEST_LIB" 2>/dev/null | grep -qF "$MARKER"; then
        pass "la bibliothèque de test contient la suite ACTUELLE (marqueur présent)"
    else
        fail "la bibliothèque de test ne contient PAS la suite actuelle"
        printf '      marqueur absent : \"%s\"\n' "$MARKER"
        printf '      => objet de test périmé, non détectable par horodatage.\n'
        printf '         unzip a restauré une date ancienne, ninja croit à jour.\n'
        printf '         Correction :\n'
        printf '         find contrib/mtcaodv -name "*.cc" -o -name "*.h" | xargs touch\n'
        printf '         ./ns3 build\n'
    fi
elif [ -n "$ANY_TEST" ]; then
    warn "tests activés ($ANY_TEST) mais aucune bibliothèque de test repérée pour mtcaodv"
    printf '      => les suites du module ne sont pas déclarées dans son CMakeLists.txt,\n'
    printf '         ou le module n a pas été reconstruit depuis leur ajout. Lancez :\n'
    printf '         ./ns3 configure --enable-examples --enable-tests && ./ns3 build\n'
else
    warn "aucune bibliothèque de test repérée dans build/lib (tests probablement OFF)"
    printf '      => ./ns3 configure --enable-examples --enable-tests && ./ns3 build\n'
    printf '      contenu de build/lib contenant \"test\" :\n'
    ls "$ROOT"/build/lib/ 2>/dev/null | grep -i test | sed 's/^/        /' || true
    printf '      (aucune ligne ci-dessus = réellement aucun artefact de test)\n'
    printf '      Non bloquant : le contrôle qui fait autorité est ./test.py -s <suite>,\n'
    printf '      qui dit franchement \"unknown test suite name\" le cas échéant.\n'
fi

printf '\n'
if [ "$FAILURES" -eq 0 ]; then
    printf 'AUCUNE PANNE SILENCIEUSE DETECTEE -- le scénario STEP 3 peut être exécuté.\n'
    printf 'Un WARN ci-dessus, le cas échéant, reste à lever mais ne fausse aucun chiffre.\n'
    exit 0
fi
printf '%d VERIFICATION(S) EN ECHEC -- NE LANCEZ PAS LA SIMULATION.\n' "$FAILURES"
printf 'Un run sur un build incohérent produit des chiffres qui ne correspondent\n'
printf 'à aucune version du code. Corrigez, relancez cette garde, puis exécutez.\n'
exit 1
