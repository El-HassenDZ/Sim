#!/usr/bin/env python3
"""Tests standard-library de analyze_forwarding.py (aucun ns-3 requis)."""

from __future__ import annotations

import contextlib
import io
import json
import math
import tempfile
import unittest
from pathlib import Path

import analyze_forwarding as a

_HEADER = ("openTime_s,closeTime_s,observerNodeId,neighborNodeId,neighborIp,"
           "forwardingObserved,closureReason,senderAttributed,passiveVisibility,"
           "passiveVisibilityAvailable")


def _row(observer=0, neighbor=1, observed=1, reason="MATCHED", attributed=1,
         open_t=10.0, close_t=10.005, visibility=1.0):
    return (f"{open_t},{close_t},{observer},{neighbor},10.1.0.{neighbor+1},"
            f"{observed},{reason},{attributed},{visibility},1")


def _write(rows, manifest=None):
    tmp = Path(tempfile.mkdtemp())
    csv_path = tmp / "obs.csv"
    csv_path.write_text(_HEADER + "\n" + "\n".join(rows) + "\n", encoding="utf-8")
    man_path = tmp / "man.json"
    man_path.write_text(json.dumps(manifest if manifest is not None else {
        "attack": {"attackerNodeIds": [5]},
        "configuration": {"nodes": 30, "attackStart": 10.0},
        "observation": {"observationRowsDropped": 0},
    }), encoding="utf-8")
    return csv_path, man_path



# Les tests bout-en-bout appellent main(), qui ECRIT son rapport sur stdout. Sans
# capture, `python3 -m unittest -q` deverse plusieurs ecrans de rapport et la
# ligne « Ran N tests OK » devient introuvable. On capture donc la sortie : ces
# tests verifient le CODE DE RETOUR, pas la mise en page.
def _silent(callable_, *args):
    """Execute en capturant stdout ; renvoie le code de retour."""
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        return callable_(*args)


class SummariseTests(unittest.TestCase):
    def test_rates_and_latency(self):
        rows = [{"open": 1.0, "close": 1.01, "observer": 0, "neighbor": 1,
                 "observed": True, "reason": "MATCHED", "attributed": True,
                 "visibility": 1.0},
                {"open": 2.0, "close": 2.15, "observer": 0, "neighbor": 1,
                 "observed": False, "reason": "DEADLINE", "attributed": False,
                 "visibility": 0.0}]
        summary = a.summarise(rows, "x")
        self.assertEqual(summary["total"], 2)
        self.assertAlmostEqual(summary["rate"], 0.5)
        self.assertAlmostEqual(summary["attributionRate"], 1.0)
        self.assertAlmostEqual(summary["latencyMedian"], 0.01)
        self.assertEqual(summary["reasons"], {"MATCHED": 1, "DEADLINE": 1})

    def test_empty_is_nan_never_zero(self):
        """Une baseline absente doit rester indefinie, jamais valoir 0."""
        summary = a.summarise([], "vide")
        self.assertEqual(summary["total"], 0)
        self.assertTrue(math.isnan(summary["rate"]))
        self.assertTrue(math.isnan(summary["latencyMedian"]))

    def test_attribution_rate_is_over_observed_not_total(self):
        """Attribuer se fait sur un appariement ; le denominateur est z_e = 1."""
        rows = [{"open": 1.0, "close": 1.01, "observer": 0, "neighbor": 1,
                 "observed": True, "reason": "MATCHED", "attributed": False,
                 "visibility": 1.0},
                {"open": 2.0, "close": 2.15, "observer": 0, "neighbor": 1,
                 "observed": False, "reason": "DEADLINE", "attributed": False,
                 "visibility": 0.0}]
        self.assertAlmostEqual(a.summarise(rows, "x")["attributionRate"], 0.0)


class LoadTests(unittest.TestCase):
    def test_reads_rows_and_manifest(self):
        csv_path, man_path = _write([_row(), _row(neighbor=5, observed=0,
                                                  reason="DEADLINE", attributed=0)])
        rows = a.load_observations(csv_path)
        attackers, nodes, start = a.load_manifest(man_path)
        self.assertEqual(len(rows), 2)
        self.assertEqual(attackers, {5})
        self.assertEqual(nodes, 30)
        self.assertAlmostEqual(start, 10.0)

    def test_truncated_stream_is_refused(self):
        """Un flux tronque biaise l'echantillon : on refuse de conclure."""
        _csv, man_path = _write([_row()], manifest={
            "attack": {"attackerNodeIds": [5]},
            "configuration": {"nodes": 30, "attackStart": 10.0},
            "observation": {"observationRowsDropped": 17},
        })
        with self.assertRaises(a.ForwardingAnalysisError):
            a.load_manifest(man_path)

    def test_empty_file_is_refused(self):
        tmp = Path(tempfile.mkdtemp())
        path = tmp / "empty.csv"
        path.write_text(_HEADER + "\n", encoding="utf-8")
        with self.assertRaises(a.ForwardingAnalysisError):
            a.load_observations(path)


class EndToEndTests(unittest.TestCase):
    def test_attacker_less_observed_returns_zero(self):
        rows = ([_row(neighbor=1) for _ in range(9)] +
                [_row(neighbor=1, observed=0, reason="DEADLINE", attributed=0)] +
                [_row(neighbor=5, observed=0, reason="DEADLINE", attributed=0)
                 for _ in range(10)])
        csv_path, man_path = _write(rows)
        self.assertEqual(_silent(a.main, ["--observations", str(csv_path),
                                 "--manifest", str(man_path)]), 0)

    def test_no_honest_observation_is_inconclusive(self):
        """Sans baseline honnete, l'etape ne peut rien calibrer : code 2."""
        rows = [_row(neighbor=5, observed=0, reason="DEADLINE", attributed=0)]
        csv_path, man_path = _write(rows)
        self.assertEqual(_silent(a.main, ["--observations", str(csv_path),
                                 "--manifest", str(man_path)]), 2)


if __name__ == "__main__":
    unittest.main()
