#!/usr/bin/env python3
"""Mesure les caractéristiques OCEA disponibles AVANT d'écrire A3.3.

Pourquoi ce script existe
-------------------------
L'Éq. (7) est annulée par une seule caractéristique disponible valant zéro :
O_e = 0, donc I_e = 0, donc masse entièrement incertaine. Aujourd'hui
`passiveVisibility` est la SEULE caractéristique d'opportunité renseignée, et
elle est binaire. Le plafond d'attribution d'OCEA est donc entièrement fixé par
sa distribution -- avant même qu'un seul diagnostic y_l soit instrumenté.

Ce script mesure ce plafond sur des données déjà produites, pour que la
conception de STEP 4 parte d'une mesure et non d'une intuition.

La question de la circularité
-----------------------------
`passiveVisibility` ne doit pas être un déguisement de z_e. Si un voisin était
déclaré non visible PARCE QUE sa retransmission n'a pas été entendue, alors
toute non-observation donnerait O_e = 0 et AUCUNE évidence malveillante ne
pourrait jamais être produite : le mécanisme s'auto-annulerait.

Le code l'évite par construction -- `m_lastHeardFromNeighbor` n'est écrit que
depuis une trame BROADCAST, alors que l'appariement porte sur un relais UNICAST,
deux classes de trames disjointes. Ce script le vérifie sur les données, parce
qu'une garantie lue dans le code n'est pas une garantie mesurée.

ATTENTION à l'interprétation. P(visible | z=1) > P(visible | z=0) est ATTENDU et
ne prouve PAS une circularité : un voisin réellement joignable par radio a plus
de chances à la fois d'être entendu diffusant ET de voir son relais entendu. La
corrélation est une conséquence de la visibilité physique commune. Ce script
rapporte donc l'écart, il ne le juge pas -- aucun seuil n'est préenregistré.

Évaluation HORS LIGNE : le regroupement honnête/attaquant lit le manifeste.
L'observateur, lui, n'a jamais accès à cette information.

Bibliothèque standard uniquement.
"""

from __future__ import annotations

import argparse
import csv
import math
import sys
from pathlib import Path
from typing import Sequence

from analyze_forwarding import ForwardingAnalysisError, load_manifest


def load_rows(path: Path) -> list[dict]:
    """Lit le CSV des observations, y compris le drapeau de disponibilité."""
    try:
        with path.open("r", encoding="utf-8", newline="") as handle:
            raw = list(csv.DictReader(handle))
    except OSError as error:
        raise ForwardingAnalysisError(f"lecture impossible de {path}: {error}") from error
    if not raw:
        raise ForwardingAnalysisError(
            f"{path} ne contient aucune observation. Un fichier vide et une "
            "observation desactivee sont deux cas differents : le manifeste "
            "permet de les distinguer. On ne conclut sur aucun des deux."
        )
    rows = []
    for row in raw:
        try:
            rows.append({
                "neighbor": int(row["neighborNodeId"]),
                "observed": int(row["forwardingObserved"]) == 1,
                "attributed": int(row["senderAttributed"]) == 1,
                "visibility": float(row["passiveVisibility"]),
                "visibilityAvailable": int(row["passiveVisibilityAvailable"]) == 1,
                # Colonnes ajoutees par la mesure ACTIVE du lien. Absentes d'un
                # CSV anterieur : on les declare INDISPONIBLES plutot que de
                # supposer une valeur, et le rapport le signalera de lui-meme.
                "linkReliability": float(row.get("linkReliability", 0.0) or 0.0),
                "linkAvailable": int(row.get("linkReliabilityAvailable", 0) or 0) == 1,
                "reason": row["closureReason"],
            })
        except (KeyError, ValueError) as error:
            raise ForwardingAnalysisError(f"ligne malformee: {error}") from error
    return rows


def _ratio(numerator: int, denominator: int) -> float:
    """Un dénominateur nul rend NaN, jamais 0 : l'absence n'est pas un zéro."""
    return numerator / denominator if denominator else math.nan


def _fmt(value: float) -> str:
    return "indefini" if math.isnan(value) else f"{value:.4f}"


def summarise(rows: Sequence[dict], label: str) -> dict:
    """Distribution de la caractéristique, et plafond d'attribution qui en découle."""
    n = len(rows)
    available = sum(1 for r in rows if r["visibilityAvailable"])
    visible = sum(1 for r in rows if r["visibilityAvailable"] and r["visibility"] > 0.0)

    matched = [r for r in rows if r["observed"]]
    missed = [r for r in rows if not r["observed"]]
    visible_matched = sum(1 for r in matched if r["visibility"] > 0.0)
    visible_missed = sum(1 for r in missed if r["visibility"] > 0.0)

    # Detection d'un CSV produit AVANT la correction de l'encodage. Une
    # caracteristique declaree disponible avec la valeur 0 est un veto dans
    # l'Eq. (7) ; l'encodage correct est INDISPONIBLE. Un tel CSV reste
    # lisible, mais ses taux ne veulent pas dire la meme chose.
    available_and_zero = sum(
        1 for r in rows if r["visibilityAvailable"] and r["visibility"] == 0.0)

    # ---- Couverture combinee des caracteristiques d'opportunite (Eq. 6-7) ----
    # O_e > 0 exige DEUX conditions : au moins une caracteristique disponible
    # (sinon c_e = 0), ET aucune caracteristique disponible valant exactement 0
    # (sinon le produit geometrique s'annule quel que soit le poids).
    #
    # `passiveVisibility` ne vaut jamais 0 quand elle est disponible depuis la
    # correction d'encodage ; `linkReliability` le peut, et ce zero est
    # LEGITIME : si aucune emission recente vers j n'a ete acquittee, il n'y
    # avait reellement aucune opportunite d'observer un transfert.
    def has_coverage(r):
        return r["visibilityAvailable"] or r["linkAvailable"]

    def is_vetoed(r):
        return r["linkAvailable"] and r["linkReliability"] == 0.0

    link_available = sum(1 for r in rows if r["linkAvailable"])
    covered = sum(1 for r in rows if has_coverage(r))
    vetoed = sum(1 for r in rows if is_vetoed(r))
    interpretable = [r for r in rows if has_coverage(r) and not is_vetoed(r)]
    interpretable_missed = [r for r in interpretable if not r["observed"]]

    return {
        "label": label,
        "n": n,
        "availableAndZero": available_and_zero,
        "linkAvailable": link_available,
        "linkAvailableRate": _ratio(link_available, n),
        "coverageRate": _ratio(covered, n),
        "vetoedByZeroLink": vetoed,
        "interpretableRate": _ratio(len(interpretable), n),
        "realCeiling": len(interpretable_missed),
        "available": available,
        "availableRate": _ratio(available, n),
        "visibleRate": _ratio(visible, available),
        "matched": len(matched),
        "missed": len(missed),
        "visibleGivenMatched": _ratio(visible_matched, len(matched)),
        "visibleGivenMissed": _ratio(visible_missed, len(missed)),
        # LE nombre qui compte : parmi les non-observations, celles dont la
        # visibilite est non nulle sont les SEULES qui pourraient un jour
        # recevoir une masse malveillante, puisque les autres donnent O_e = 0
        # donc I_e = 0 quels que soient les diagnostics ajoutes ensuite.
        "attributableCeiling": visible_missed,
        "attributableCeilingRate": _ratio(visible_missed, len(missed)),
    }


def print_summary(s: dict) -> None:
    print(f"\n  {s['label']:<22} n={s['n']}")
    # Sous l'encodage corrige, `disponible` EQUIVAUT a « audibilite prouvee » :
    # c'est donc directement la contribution de cette caracteristique a la
    # couverture c_e de l'Eq. (6). C'est le chiffre qui compte.
    print(f"    disponibilite passiveVisibility = {_fmt(s['availableRate'])} "
          f"({s['available']}/{s['n']})")
    if s["availableAndZero"]:
        print(f"    /!\\ {s['availableAndZero']} evenements DISPONIBLES avec valeur 0 :")
        print( "        CSV anterieur a la correction d'encodage. Une valeur 0")
        print( "        disponible est un VETO dans l'Eq. (7) ; l'encodage correct")
        print( "        est INDISPONIBLE. Les taux ci-dessous restent lisibles mais")
        print( "        ne portent pas le meme sens qu'apres correction.")
    else:
        print( "    encodage : disponible => valeur non nulle (correct)")
    print(f"    visible (parmi disponibles)     = {_fmt(s['visibleRate'])}")
    print(f"    visible | retransmission vue    = {_fmt(s['visibleGivenMatched'])} "
          f"(n={s['matched']})")
    print(f"    visible | AUCUNE retransmission = {_fmt(s['visibleGivenMissed'])} "
          f"(n={s['missed']})")
    print(f"    disponibilite linkReliability   = {_fmt(s['linkAvailableRate'])} "
          f"({s['linkAvailable']}/{s['n']})")
    print(f"    COUVERTURE c_e > 0              = {_fmt(s['coverageRate'])}")
    if s["vetoedByZeroLink"]:
        print(f"    dont vetoees par linkReliability = 0 : {s['vetoedByZeroLink']} "
              f"(zero LEGITIME : lien injoignable, donc aucune opportunite)")
    print(f"    O_e > 0 possible                = {_fmt(s['interpretableRate'])}")
    print(f"    PLAFOND d'attribution REEL      = {s['realCeiling']} non-observations")
    print(f"      (ancien plafond, visibilite seule : {s['attributableCeiling']})")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--observations", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)

    try:
        rows = load_rows(arguments.observations)
        attackers, nodes, _ = load_manifest(arguments.manifest)
    except ForwardingAnalysisError as error:
        print(f"ANALYSE IMPOSSIBLE : {error}", file=sys.stderr)
        return 1

    honest = [r for r in rows if r["neighbor"] >= 0 and r["neighbor"] not in attackers]
    malicious = [r for r in rows if r["neighbor"] in attackers]

    print("=== STEP 4 : caracteristiques OCEA disponibles, mesurees ===")
    print(f"  noeuds={nodes}  attaquants={sorted(attackers)}  observations={len(rows)}")

    honest_summary = summarise(honest, "voisin HONNETE")
    malicious_summary = summarise(malicious, "voisin ATTAQUANT")
    print_summary(honest_summary)
    print_summary(malicious_summary)

    print("\n=== Ce que cela impose a OCEA ===")
    print("  `passiveVisibility` est aujourd'hui la SEULE caracteristique")
    print("  d'opportunite renseignee. L'Eq. (7) etant une moyenne geometrique,")
    print("  une visibilite nulle donne O_e = 0, donc I_e = 0, donc masse")
    print("  entierement incertaine -- QUELS QUE SOIENT les diagnostics y_l")
    print("  instrumentes ensuite. Le plafond ci-dessus n'est donc pas une")
    print("  estimation : c'est une borne dure sur ce qu'OCEA peut attribuer")
    print("  tant qu'aucune autre caracteristique d'opportunite n'existe.")

    ceiling = malicious_summary["attributableCeiling"]
    missed = malicious_summary["missed"]
    if missed == 0:
        print("\n  Aucun attaquant n'a produit de non-observation : plafond INDEFINI.")
    elif ceiling == 0:
        print("\n  PLAFOND NUL chez l'attaquant : aucune non-observation malveillante")
        print("  ne pourrait recevoir de masse. Instrumenter les diagnostics y_l")
        print("  SANS ajouter de caracteristique d'opportunite serait sans effet.")
    else:
        print(f"\n  Au plus {ceiling} des {missed} non-observations d'attaquant")
        print("  pourraient recevoir une masse malveillante avec l'instrumentation")
        print("  actuelle. Les autres resteront incertaines par construction.")

    print("\n=== Circularite : verification ===")
    print("  `passiveVisibility` est lu depuis les trames BROADCAST du voisin ;")
    print("  z_e vient d'un appariement sur trame UNICAST. Classes disjointes,")
    print("  donc pas de circularite par construction.")
    print("  L'ecart visible|vue vs visible|non-vue est RAPPORTE, non juge :")
    print("  un voisin physiquement joignable a plus de chances des DEUX cotes.")
    print("  Aucun seuil n'est preenregistre pour cet ecart.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
