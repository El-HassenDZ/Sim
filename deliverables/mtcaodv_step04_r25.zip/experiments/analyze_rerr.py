#!/usr/bin/env python3
# MTCAODV_DELIVERY_REVISION: r25
"""Joint le flux des RERR COHERENTS aux non-observations (second y_l, Eq. 8).

POURQUOI UNE JOINTURE HORS LIGNE
--------------------------------
Le RERR qui explique une non-observation arrive APRES elle : le voisin doit
d'abord echouer a relayer, puis detecter la rupture, puis emettre. Une fenetre
d'observation close ne peut donc pas le porter, et aucun champ de
`ForwardingObservation` ne pourrait le contenir sans retarder la cloture.

Les deux flux sont donc exportes separement et joints ici. Le DELAI reste ainsi
un PARAMETRE LIBRE de l'analyse au lieu d'etre fige dans le C++ par un seuil
choisi d'avance. C'est la meme discipline qui a fixe `--observationWindow` sur
la distribution mesuree des latences d'appariement, et non sur l'intuition.

CE QUE « COHERENT » VEUT DIRE
-----------------------------
Trois conditions, toutes verifiees ici :
  1. meme noeud observateur ;
  2. l'emetteur du RERR est le voisin OBSERVE ;
  3. la destination declaree injoignable est celle du paquet suivi.
Un RERR quelconque du meme voisin ne suffit pas : il serait du bruit correle,
pas une explication. La condition (3) est ce qui separe les deux.

CE QUE CE SCRIPT NE FAIT PAS
----------------------------
Il ne choisit AUCUN delai. Il rapporte la couverture pour une grille, et c'est
la mesure qui devra trancher -- ou etablir qu'aucun delai ne convient.
"""

from __future__ import annotations

import argparse
import bisect
import csv
import json
import math
import sys
from pathlib import Path
from typing import Sequence

from analyze_forwarding import ForwardingAnalysisError, load_manifest

#: Grille de delais, en secondes. Couvre trois ordres de grandeur, de la fenetre
#: d'observation (150 ms) a l'expiration d'un voisin AODV
#: (AllowedHelloLoss x HelloInterval = 2 s) et au-dela.
DELAY_GRID = (0.05, 0.15, 0.5, 1.0, 2.0, 5.0)


def load_observations(path: Path) -> list[dict]:
    """Lit les non-observations ET leur destination.

    La colonne `destinationIp` est OBLIGATOIRE : sans elle, la condition de
    coherence (3) ne peut pas etre testee, et le script refuse plutot que de
    rabattre la jointure sur le seul voisin -- ce qui correlerait sans expliquer.
    """
    try:
        with path.open("r", encoding="utf-8", newline="") as handle:
            raw = list(csv.DictReader(handle))
    except OSError as error:
        raise ForwardingAnalysisError(f"lecture impossible de {path}: {error}") from error
    if not raw:
        raise ForwardingAnalysisError(f"{path} ne contient aucune observation")
    if "destinationIp" not in raw[0]:
        raise ForwardingAnalysisError(
            f"{path} n'a pas de colonne `destinationIp` : CSV anterieur a r24. "
            "La coherence se teste sur la destination ; sans elle, la jointure "
            "ne mesurerait qu'une correlation avec le voisin.")
    rows = []
    for row in raw:
        try:
            rows.append({
                "observer": int(row["observerNodeId"]),
                "neighbor": int(row["neighborNodeId"]),
                "neighborIp": row["neighborIp"],
                "destinationIp": row["destinationIp"],
                "observed": int(row["forwardingObserved"]) == 1,
                "close": float(row["closeTime_s"]),
            })
        except (KeyError, ValueError) as error:
            raise ForwardingAnalysisError(f"ligne malformee: {error}") from error
    return rows


def load_rerr(path: Path) -> dict[tuple[int, str, str], list[float]]:
    """Indexe le flux RERR par (observateur, origine, destination injoignable).

    Un fichier VIDE n'est pas une erreur : c'est la mesure « aucun RERR coherent
    n'a circule ». Le rapport le dira ; il ne l'assimilera pas a un echec de
    lecture, qui appellerait une correction toute differente.
    """
    try:
        with path.open("r", encoding="utf-8", newline="") as handle:
            raw = list(csv.DictReader(handle))
    except OSError as error:
        raise ForwardingAnalysisError(f"lecture impossible de {path}: {error}") from error
    index: dict[tuple[int, str, str], list[float]] = {}
    for row in raw:
        try:
            key = (int(row["observerNodeId"]), row["originIp"], row["unreachableIp"])
            index.setdefault(key, []).append(float(row["time_s"]))
        except (KeyError, ValueError) as error:
            raise ForwardingAnalysisError(f"ligne RERR malformee: {error}") from error
    for times in index.values():
        times.sort()
    return index


def delay_to_next_coherent_rerr(row: dict,
                                index: dict[tuple[int, str, str], list[float]]) -> float:
    """Delai jusqu'au premier RERR coherent APRES la cloture, ou NaN.

    Strictement POSTERIEUR ou egal a la cloture : un RERR anterieur ne peut pas
    expliquer un evenement qui ne s'etait pas encore produit. Confondre les deux
    sens ferait passer une coincidence pour une cause.
    """
    times = index.get((row["observer"], row["neighborIp"], row["destinationIp"]))
    if not times:
        return math.nan
    position = bisect.bisect_left(times, row["close"])
    if position >= len(times):
        return math.nan
    return times[position] - row["close"]


def summarise(rows: Sequence[dict],
              index: dict[tuple[int, str, str], list[float]],
              label: str) -> dict:
    missed = [r for r in rows if not r["observed"]]
    delays = [delay_to_next_coherent_rerr(r, index) for r in missed]
    finite = sorted(d for d in delays if not math.isnan(d))
    coverage = {}
    for limit in DELAY_GRID:
        coverage[limit] = sum(1 for d in finite if d <= limit)
    return {
        "label": label,
        "missed": len(missed),
        "withAnyRerr": len(finite),
        "coverage": coverage,
        "minDelay": finite[0] if finite else math.nan,
        "medianDelay": finite[len(finite) // 2] if finite else math.nan,
    }


def _ratio(numerator: int, denominator: int) -> float:
    return numerator / denominator if denominator else math.nan


def _fmt(value: float) -> str:
    return "indefini" if math.isnan(value) else f"{value:.4f}"


def print_summary(summary: dict) -> None:
    print(f"\n  {summary['label']:<22} non-observations={summary['missed']}")
    if summary["missed"] == 0:
        print("    aucune non-observation : rien a expliquer")
        return
    print(f"    suivies d'un RERR coherent, delai quelconque = "
          f"{summary['withAnyRerr']} "
          f"({_fmt(_ratio(summary['withAnyRerr'], summary['missed']))})")
    for limit in DELAY_GRID:
        count = summary["coverage"][limit]
        print(f"      dans {limit:>5.2f} s : {count:>6d} "
              f"({_fmt(_ratio(count, summary['missed']))})")
    if summary["withAnyRerr"]:
        print(f"    delai : min {summary['minDelay'] * 1e3:.1f} ms, "
              f"mediane {summary['medianDelay'] * 1e3:.1f} ms")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--observations", required=True, type=Path)
    parser.add_argument("--rerr", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)

    rows = load_observations(arguments.observations)
    index = load_rerr(arguments.rerr)
    attackers, _nodes, _start = load_manifest(arguments.manifest)

    print("=== STEP 4 : second diagnostic y_l -- RERR coherent ===")
    print(f"  attaquants={sorted(attackers)}  observations={len(rows)}  "
          f"cles RERR={len(index)}")
    if not index:
        print("\n  AUCUN RERR COHERENT dans le flux.")
        print("  C'est une MESURE, pas une panne de lecture : aucun voisin n'a")
        print("  declare injoignable une destination que l'observateur routait")
        print("  par lui. Ce diagnostic serait alors structurellement muet, et")
        print("  l'instrumenter dans l'Eq. (8) ajouterait une couverture sans")
        print("  contenu -- exactement la faute commise avec passiveVisibility.")

    honest = [r for r in rows if r["neighbor"] not in attackers]
    malicious = [r for r in rows if r["neighbor"] in attackers]
    print_summary(summarise(honest, index, "voisin HONNETE"))
    print_summary(summarise(malicious, index, "voisin ATTAQUANT"))

    print_verdict(summarise(honest, index, "h"), summarise(malicious, index, "a"))
    return 0


def print_verdict(honest: dict, malicious: dict) -> None:
    """Confronte la grille au critere preenregistre, sans le quantifier apres coup.

    Le critere avait ete ecrit AVANT la mesure : « un delai n'est retenu que si
    la couverture HONNETE y est substantielle ET nettement superieure a la
    couverture ATTAQUANT ». Il etait QUALITATIF, et le quantifier maintenant
    serait choisir un seuil en connaissant la reponse.

    Ce bloc ne le quantifie donc pas : il imprime les deux grandeurs et laisse
    voir si un seuil quelconque pourrait changer l'issue.
    """
    print("\n=== Confrontation au critere preenregistre ===")
    print("  critere (ecrit AVANT la mesure) : couverture HONNETE substantielle")
    print("  ET nettement superieure a la couverture ATTAQUANT.")
    print(f"\n  {'delai':>7s} {'honnete':>9s} {'attaquant':>10s} {'rapport':>9s}")
    worst_ratio = 0.0
    best_honest = 0.0
    for limit in DELAY_GRID:
        rh = _ratio(honest["coverage"][limit], honest["missed"])
        ra = _ratio(malicious["coverage"][limit], malicious["missed"])
        ratio = (rh / ra) if (ra and not math.isnan(ra) and ra > 0) else math.nan
        if not math.isnan(rh):
            best_honest = max(best_honest, rh)
        if not math.isnan(ratio):
            worst_ratio = max(worst_ratio, ratio)
        print(f"  {limit:7.2f} {_fmt(rh):>9s} {_fmt(ra):>10s} "
              f"{('indefini' if math.isnan(ratio) else f'{ratio:.2f}x'):>9s}")
    print(f"\n  couverture honnete MAXIMALE sur la grille : {best_honest:.4f}")
    print(f"  rapport honnete/attaquant MAXIMAL          : {worst_ratio:.2f}x")

    # LE PIEGE QUE LA GRILLE EVITE. Sans borne de delai, la couverture honnete
    # est bien plus forte que celle de l'attaquant et paraitrait probante. Mais
    # un RERR survenu des SECONDES apres n'explique pas la non-observation : il
    # constate que la route a fini par rompre, ce qui est un fait de mobilite.
    rh_any = _ratio(honest["withAnyRerr"], honest["missed"])
    ra_any = _ratio(malicious["withAnyRerr"], malicious["missed"])
    print(f"\n  A DELAI NON BORNE : honnete {_fmt(rh_any)}, attaquant {_fmt(ra_any)}")
    if not math.isnan(honest["medianDelay"]):
        print(f"  mediane du delai honnete : {honest['medianDelay'] * 1e3:.0f} ms")
    print("  Ce chiffre-la separe, et il ne prouve RIEN : un RERR survenu des")
    print("  secondes apres constate que la route a fini par rompre -- un fait")
    print("  de mobilite, pas la cause de CETTE non-observation. Sans la grille,")
    print("  il aurait ete lu comme un diagnostic fort.")


if __name__ == "__main__":
    sys.exit(main())
