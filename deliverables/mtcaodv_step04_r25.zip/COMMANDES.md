# Commandes de test et d'exécution

Racine ns-3 supposée : `/home/hassen/res/ns-3.48`. Adaptez si nécessaire.

---

## 0bis. Tampon de révision — pourquoi l'extraction doit être COMPLÈTE

Chaque fichier livré porte `MTCAODV_DELIVERY_REVISION: rN` ;
`DELIVERY_REVISION.txt` fait foi. La garde de build refuse de continuer si un
seul fichier est d'une autre révision, et **nomme le fichier fautif**.

Cette garde existe parce que le cas s'est produit : en r18, le module, les
scripts Python et le pilote étaient à jour, mais `run_all.sh` était resté en
r17 et a imprimé une conclusion périmée sous des chiffres qui la démentaient.
Aucune autre garde ne pouvait le voir — elles comparent toutes des **sources** à
des **artefacts compilés**, et un script shell n'est pas compilé.

**Conséquence pratique : ne relancez jamais `run_all.sh` sans avoir ré-extrait
l'archive en entier.**

## 0. Installation — vérifier l'empreinte AVANT d'extraire

Les archives sont **numérotées** (`_r7`, `_r8`, …) parce qu'un navigateur
n'écrase pas un téléchargement homonyme : il écrit `...(1).zip`. Avec un nom
fixe, on ré-extrait toujours la **première** archive et l'arbre source régresse
silencieusement. C'est arrivé deux fois.

```bash
md5sum ~/Downloads/mtcaodv_step03_r*.zip
```

Comparez au md5 annoncé dans le message de livraison. **Puis seulement** :

```bash
cd /home/hassen/res/ns-3.48 && unzip -o ~/Downloads/mtcaodv_step03_rN.zip -d . && find contrib/mtcaodv experiments -type f -exec touch {} +
```

Le `touch` n'est pas décoratif : `unzip` restaure les horodatages de l'archive,
une source peut se retrouver plus ancienne que son objet déjà compilé, et ninja
ne la recompile alors jamais.

---

## 1. Tout, en une commande

```bash
cd /home/hassen/res/ns-3.48 && bash run_all.sh
```

Enchaîne : contre-contrôle arithmétique A3.3 (sans ns-3) → construction →
garde de cohérence → 12 suites ns-3 → tests Python →
vérification que `src/aodv` est intact → les deux bras d'exécution → comparaison
automatique des PDR → validation → analyse.

**Fail closed** : arrêt à la première anomalie, aucune simulation lancée sur un
arbre incohérent. Un chiffre produit par un build qui ne correspond pas aux
sources n'appartient à aucune version du code — c'est pire qu'une erreur
franche, car cela ressemble à une donnée.

---

## 2. Les mêmes étapes, séparément

### Construction

```bash
cd /home/hassen/res/ns-3.48 && ./ns3 configure --enable-examples --enable-tests && ./ns3 build
```

`configure` est **obligatoire**, jamais optionnel : tout changement de
`CMakeLists.txt` fait ré-exécuter CMake au premier `build`, et cette
ré-exécution remet les options aux défauts — `Examples: OFF`, `Tests: OFF`.

### Contre-contrôle arithmétique A3.3 — **sans ns-3, une seconde**

```bash
cd /home/hassen/res/ns-3.48 && bash experiments/check_ocea_arithmetic.sh
```

`contrib/mtcaodv/model/ocea-attribution.{h,cc}` n'inclut **aucun en-tête ns-3**.
L'arithmétique des Éq. (6)–(10) se compile donc avec un simple `g++` et
s'exécute sans arbre ns-3 construit. Le script compile
`experiments/ocea_crosscheck.cc`, l'exécute, et compare ses huit sorties à
l'implémentation de référence Python **champ par champ**.

Deux implémentations indépendantes — Python écrite en premier, C++ ensuite —
donnant les mêmes nombres est une vérification ; le C++ comparé à lui-même n'en
serait pas une.

La comparaison est **numérique** (tolérance 1e-12), pas textuelle : deux `libm`
peuvent différer d'un ulp sur `exp`/`log` sans qu'aucune soit fausse, et une
garde qui se déclenche pour de mauvaises raisons finit par être désactivée.

Pour lire les oracles eux-mêmes, avec le calcul à la main de chacun :

```bash
cd /home/hassen/res/ns-3.48 && python3 experiments/ocea_reference.py --oracles
```

### Garde de cohérence du build

```bash
cd /home/hassen/res/ns-3.48 && bash experiments/check_step03_build.sh
```

Interroge les **artefacts**, pas les sources. Bloque sur les pannes silencieuses
(arbre source périmé, objet périmé, source non compilée) ; avertit seulement sur
celles qu'une commande ultérieure signalerait franchement.

### Suites ns-3 — les douze noms exacts

```bash
cd /home/hassen/res/ns-3.48 && for s in \
  routing-aodv routing-aodv-loopback routing-aodv-regression aodv-routing-id-cache \
  mtcaodv-routing-protocol mtcaodv-attack-manager mtcaodv-blackhole-behavior \
  mtcaodv-step00-baseline-metrics mtcaodv-rrep-anomaly-detector \
  mtcaodv-packet-fingerprint mtcaodv-forwarding-observer \
  mtcaodv-ocea-attribution ; do ./test.py -s $s; done
```

La douzième, `mtcaodv-ocea-attribution`, est nouvelle : elle porte l'Algorithme
A3.3 (Éq. 6–10). Elle ne démarre **aucune simulation**.

Les quatre premières sont **AODV amont**. Deux pièges de nommage : la suite
amont s'appelle `routing-aodv`, **pas** `aodv` ; et `mtcaodv-rrep-screening`
**n'existe pas** — les tests de dépistage STEP 2 sont dans
`mtcaodv-rrep-anomaly-detector`.

### Tests Python

```bash
cd /home/hassen/res/ns-3.48/experiments && python3 -m unittest test_validate_step03 test_analyze_forwarding test_analyze_features test_analyze_baseline_seeds test_ocea_reference test_analyze_rerr -q
```

Attendu : `Ran 128 tests ... OK`.

### Contrainte « préserver AODV »

```bash
cd /home/hassen/res/ns-3.48 && find src/aodv -type f -newer src/olsr/CMakeLists.txt
```

**Sortie vide = contrainte respectée.** `olsr` sert de témoin non touché. Le
passage des suites amont prouve que le module se comporte bien ; il ne prouve
pas que ses sources sont intactes. Deux affirmations différentes, et seule la
seconde est la contrainte.

### Exécution — bras ON

```bash
cd /home/hassen/res/ns-3.48 && ./ns3 run "mtcaodv-pilot-attack --nodes=30 --areaSize=600 --maxRange=200 --minSpeed=1 --maxSpeed=5 --simTime=300 --flowCount=5 --dataRate=51.2kbps --attackerRatio=0.20 --attackStart=10 --seed=1 --run=1 --observationsCsv=obs-atk.csv"
```

### Exécution — bras OFF (preuve de non-intrusion)

```bash
cd /home/hassen/res/ns-3.48 && ./ns3 run "mtcaodv-pilot-attack --nodes=30 --areaSize=600 --maxRange=200 --minSpeed=1 --maxSpeed=5 --simTime=300 --flowCount=5 --dataRate=51.2kbps --attackerRatio=0.20 --attackStart=10 --seed=1 --run=1 --enableObservation=false" 2>&1 | grep -E "^pdr|^windowsOpened|^transmissionsInspected"
```

Le `pdr` doit être **identique au dernier chiffre** à celui du bras ON. Le
pilote n'installe aucun observateur dans ce bras : l'égalité prouve donc que
l'appareil complet — mise en promiscuité de chaque MAC comprise — est sans effet
sur la livraison. Un gain serait un **bug**, pas un succès.

### Validation

```bash
cd /home/hassen/res/ns-3.48 && cp mtcaodv-step01-manifest.json man-atk.json && cp mtcaodv-step01-results.csv res-atk.csv && python3 experiments/validate_step03.py --csv res-atk.csv --manifest man-atk.json
```

### La mesure qui porte l'étape

```bash
cd /home/hassen/res/ns-3.48 && python3 experiments/analyze_forwarding.py --observations obs-atk.csv --manifest man-atk.json --after-attack-start
```

**Aucun seuil n'est préenregistré** pour la baseline de non-observation honnête.
Elle est rapportée, jamais comparée à une valeur attendue. Une baseline absente
reste indéfinie (`NaN`), jamais 0.

### Le chiffre à lire AVANT tous les autres

```
matchedFromSelf=0
```

**Doit valoir 0.** Un appariement sur la propre émission de l'observateur
fabriquerait \(z_e = 1\) : l'Éq. (9) accorderait \((1,0,0,0)\) — preuve
positive pleine — à un voisin qui n'a rien relayé, et toutes les masses
calculées en aval seraient fausses **sans le paraître**. `run_all.sh` et le
validateur s'arrêtent net si le compteur est non nul.

La latence d'appariement est désormais rapportée **en microsecondes**. En
millisecondes, 1 272 événements s'affichaient « 0.00 ms » — un arrondi qui
cachait précisément ce qu'il fallait voir.

### Le défaut corrigé en r22 — et la baseline qui change

```
matchesRejectedSameInstant=...  matchedAtZeroLatency=0
```

`matchedAtZeroLatency` **doit valoir 0** : la séquence s'arrête sinon. Un
appariement dans le même instant de simulation que l'ouverture est la **trame
entrante du paquet lui-même**, pas une retransmission de \(j\).

`matchesRejectedSameInstant` compte les rejets ; il est **attendu non nul** dès
qu'un nœud relaie.

**Baseline PROPRE, mesurée après correction (r22)** — ce sont ces chiffres-là
qui peuvent être cités :

| | valeur |
|---|---|
| honnête : taux de non-observation | **0,0114** (48 / 4 223) |
| attaquant : taux de non-observation | **1,0000** (0 appariement sur 6 739) |
| émetteur attribuable à \(j\) | **1,0000** (4 175 / 4 175) |
| latence d'appariement, min honnête | **1 518,9 µs** |

Les valeurs antérieures — 0,0071, 0,8112, +0,8041 — sont **retirées**, pas
révisées.

### Second diagnostic \(y_\ell\) : le RERR cohérent

```bash
cd /home/hassen/res/ns-3.48 && python3 experiments/analyze_rerr.py --observations obs-atk.csv --rerr rerr-atk.csv --manifest man-atk.json
```

**Cohérent** signifie trois conditions, toutes vérifiées : même observateur ;
l'émetteur du RERR est le voisin observé ; **la destination déclarée
injoignable est celle du paquet suivi**. La troisième est ce qui sépare une
explication d'une simple corrélation — un voisin qui a des ruptures ailleurs
n'explique pas ce paquet-ci.

La condition est établie dans `RecvError()` **sur la table de routage locale**
de \(i\) : aucune lecture de l'état du voisin.

Le flux RERR est exporté **séparément** (`--rerrCsv`) parce que le RERR qui
explique une non-observation arrive **après** elle. Une fenêtre close ne peut
donc pas le porter, et joindre hors ligne laisse le **délai libre** au lieu de
figer un seuil dans le C++.

Le script rapporte la couverture pour une grille de délais (50 ms → 5 s).
**Aucun seuil n'est préenregistré** : un délai ne sera retenu que si la
couverture honnête y est substantielle *et* nettement supérieure à la
couverture attaquant.

### Le chiffre qui décide de STEP 4 : la couverture diagnostique

Dans la sortie du pilote, quatre lignes nouvelles :

```
windowsWithLinkOutcome=...       a_l = 1 : le diagnostic était ÉVALUABLE  -> d_e > 0
windowsWithLinkFailure=...       y_l = 1 : une cause bénigne a été constatée
windowsPeerMacUnknownAtOpen=...  cause n°1 d'indisponibilité
windowsMultipleLinkOutcomes=...  ambiguïté de l'attribution par PAIR
```

**Lisez-les ensemble.** `windowsWithLinkFailure` seul ne dit pas si un zéro
signifie « aucune cause bénigne » ou « diagnostic jamais évalué » ; c'est
`windowsWithLinkOutcome` qui tranche. Si celui-ci vaut 0, \(d_e = 0\) partout et
A3.3 renverrait \((0,0,0,1)\) pour **tous** les événements — le cas que le
critère de fermeture n° 7 déclare FAIL. `run_all.sh` le signale.

`windowsMultipleLinkOutcomes` **borne l'erreur** d'une attribution par PAIR et
non par PAQUET. **Mesuré : 66,7 % des fenêtres évaluables** — l'ambiguïté est la
règle, pas l'exception.

Ce taux global ne dit toutefois rien de la fiabilité des attributions bénignes.
Le chiffre qui compte est le **croisement** : parmi les événements où
\(y_\ell = 1\), combien venaient d'une fenêtre à issue **unique** ? Le rapport
l'imprime désormais :

```
dont y_l = 1 EXACT (1 issue) = ..., AMBIGU (>1) = ...
```

Noter le sens de l'erreur : une fenêtre ambiguë ne peut qu'**excuser à tort**,
jamais accuser à tort — l'ambiguïté joue donc en faveur du voisin observé.

### Mesure préalable STEP 4 — le plafond d'attribution

```bash
cd /home/hassen/res/ns-3.48 && python3 experiments/analyze_features.py --observations obs-atk.csv --manifest man-atk.json
```

Mesure, sur les données **déjà produites**, ce qu'OCEA pourra attribuer au
maximum avec l'instrumentation actuelle. L'Éq. (7) étant une moyenne
géométrique, une visibilité nulle donne \(O_e = 0\) donc \(I_e = 0\) — quels
que soient les diagnostics ajoutés ensuite. Le nombre de non-observations
d'attaquant **avec** visibilité non nulle est donc une **borne dure**, pas une
estimation.

Si ce plafond est faible, instrumenter les \(y_\ell\) sans corriger d'abord la
caractéristique d'opportunité serait sans effet. Cette mesure décide l'ordre des
travaux de STEP 4.

Aucun seuil n'est préenregistré pour l'écart entre
\(P(\text{visible} \mid z_e{=}1)\) et \(P(\text{visible} \mid z_e{=}0)\) :
un voisin physiquement joignable a plus de chances des deux côtés, donc un écart
est **attendu** et ne prouve pas une circularité. Le script rapporte, il ne juge
pas.

### Jeu de calibration multi-seeds

Le seed 1 est réservé à l'**évaluation**. La calibration des poids \(\nu_\ell\)
exige des seeds **distincts** — le script refuse le seed d'évaluation plutôt que
de laisser la contamination passer.

**Chaque run doit écrire son propre manifeste** : la liste d'attaquants diffère
d'un seed à l'autre, et sans elle aucun regroupement honnête/attaquant n'est
possible. Les options `--outputCsv` et `--outputManifest` existent pour cela.

```bash
cd /home/hassen/res/ns-3.48 && for s in 2 3 4 5 6 7 8 9 10 11; do ./ns3 run "mtcaodv-pilot-attack --nodes=30 --areaSize=600 --maxRange=200 --minSpeed=1 --maxSpeed=5 --simTime=300 --flowCount=5 --dataRate=51.2kbps --attackerRatio=0.20 --attackStart=10 --seed=$s --run=1 --observationsCsv=obs-s$s.csv --outputCsv=res-s$s.csv --outputManifest=man-s$s.json" > /dev/null 2>&1 && echo "seed $s ok"; done
```

```bash
cd /home/hassen/res/ns-3.48 && python3 experiments/analyze_baseline_seeds.py --observations obs-s{2,3,4,5,6,7,8,9,10,11}.csv --manifests man-s{2,3,4,5,6,7,8,9,10,11}.json
```

L'appariement est **positionnel** ; des longueurs différentes sont refusées, car
elles associeraient un seed au manifeste d'un autre.

Ce que le rapport donne, et qui manquait :

- la **taille du jeu de calibration** — le total des non-observations honnêtes ;
- la **dispersion inter-seed**, inconnue jusqu'ici : un seed unique ne dit pas
  si 0,0071 est représentatif ;
- le **taux groupé** (rapport des totaux), distinct de la moyenne des taux par
  seed — les seeds n'ont pas le même volume d'observations.

Si la dispersion inter-seed dépasse largement l'erreur binomiale, les événements
d'un même seed ne sont pas indépendants — topologie et mobilité sont partagées —
et **toute barre d'erreur publiée doit venir de la dispersion inter-seed**, jamais
de la formule binomiale qui la sous-estimerait.

---

## 3. Diagnostic si quelque chose casse

| symptôme | cause | correction |
|---|---|---|
| `unknown test suite name` | `Tests: OFF`, ou nom de suite faux | `./ns3 configure --enable-examples --enable-tests` ; vérifier les noms au § 2 |
| `Couldn't find the specified program` | `Examples: OFF` | idem |
| `undefined reference` que les sources contredisent | objet périmé | `find build -name '*.cc.o' -newer <source> -delete` puis `touch` + `./ns3 build` |
| erreurs de compilation sur du code déjà corrigé | **archive périmée extraite** | `md5sum ~/Downloads/mtcaodv_step03_r*.zip`, extraire celle dont l'empreinte correspond |
| `ninja: no work to do` après extraction | horodatages restaurés | `find contrib/mtcaodv experiments -type f -exec touch {} +` |

Dans tous les cas, `bash experiments/check_step03_build.sh` nomme la panne et sa
correction avant que vous ne lanciez quoi que ce soit.

<!-- MTCAODV_DELIVERY_REVISION: r25 -->
