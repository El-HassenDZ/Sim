/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * STEP 1: reproducible, mobile, MULTIPLE FULL-BLACKHOLE scenario for MTC-AODV.
 *
 * Every node runs the forked ns3::mtcaodv::RoutingProtocol (identical AODV
 * semantics to the stock module).  A reproducibly selected attacker subset has
 * a BlackholeBehavior attached, so it forges attractive RREPs (Algorithm A2.3,
 * Eq. (23)) and silently drops transit data (Algorithm A2.4).  No detection or
 * defence is present yet; this step only demonstrates and measures the attack.
 *
 * attackerRatio=0 attaches no policy anywhere, giving a healthy fork sanity run
 * that should track the STEP 0 stock-AODV baseline closely.
 */

#include "ns3/blackhole-behavior.h"
#include "ns3/applications-module.h"
#include "ns3/baseline-metrics.h"
#include "ns3/core-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/internet-module.h"
#include "ns3/ipv4-list-routing.h"
#include "ns3/ipv4-address-generator.h"
#include "ns3/mobility-module.h"
#include "ns3/forwarding-observer.h"
#include "ns3/mtc-aodv-helper.h"
#include "ns3/mtc-aodv-routing-protocol.h"
#include "ns3/network-module.h"
#include "ns3/wifi-module.h"

#include "ns3/attack-manager.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <map>
#include <set>
#include <string>
#include <vector>

using namespace ns3;

namespace
{

/** First RNG stream reserved for RandomWaypoint position, speed, and pause. */
constexpr int64_t MOBILITY_STREAM_BASE = 10000;

/** Number of explicitly assigned RandomWaypoint streams per node. */
constexpr int64_t MOBILITY_STREAMS_PER_NODE = 4;

/** First RNG stream reserved for stock AODV. */
constexpr int64_t AODV_STREAM_BASE = 20000;

/** First RNG stream reserved for Wi-Fi PHY/MAC processes. */
constexpr int64_t WIFI_STREAM_BASE = 30000;

/** First RNG stream reserved for the UDP OnOff applications. */
constexpr int64_t TRAFFIC_STREAM_BASE = 40000;

/**
 * @brief Default RNG stream reserved for reproducible attacker selection.
 *
 * Deliberately far from the 10,000-spaced mobility/AODV/Wi-Fi/traffic blocks so
 * the attacker draw never shares state with the exogenous scenario streams.
 * The value 73001 matches the AttackManager Gate 1A validation stream.
 */
constexpr int64_t DEFAULT_ATTACKER_SELECTION_STREAM = 73001;

/** UDP destination port reserved for the useful-data flows. */
constexpr uint16_t APPLICATION_DESTINATION_PORT = 9000;

/** IPv4 protocol number assigned to UDP. */
constexpr uint8_t UDP_PROTOCOL_NUMBER = 17;

/** IPv4 network required by the project pilot. */
constexpr const char* IPV4_NETWORK = "10.1.0.0";

/** IPv4 mask required by the project pilot. */
constexpr const char* IPV4_MASK = "255.255.255.0";

/**
 * @brief Configurable scientific coordinates of the STEP 1 simulation.
 *
 * Values not fixed by the specification (area, range, flow load, and warm-up)
 * remain visible command-line parameters.  Their defaults are pilot values,
 * not confirmatory values, and must be frozen only after baseline diagnosis.
 */
struct PilotConfiguration
{
    /** @brief Number of MANET nodes. Unit: nodes. FROZEN pilot value (STEP 1 calibration). */
    uint32_t nodes{30};

    /** @brief Complete simulation duration. Unit: s. */
    double simulationTimeSeconds{60.0};

    /** @brief Minimum RandomWaypoint speed. Unit: m/s. */
    double minimumSpeedMetersPerSecond{1.0};

    /** @brief Maximum RandomWaypoint speed. Unit: m/s. */
    double maximumSpeedMetersPerSecond{20.0};

    /** @brief RandomWaypoint pause duration. Unit: s. */
    double pauseTimeSeconds{0.0};

    /** @brief Requested attacker fraction in [0,1); STEP 1 installs Blackholes. */
    double attackerRatio{0.0};

    /** @brief RNG stream index for the reproducible attacker draw. */
    int64_t attackerSelectionStream{DEFAULT_ATTACKER_SELECTION_STREAM};

    /** @brief STEP 2: enable RREP anomaly screening on every node (defence). */
    bool enableScreening{true};

    /** @brief STEP 2: WATCH threshold theta_R on A_RREP. Pilot value (C-04). */
    double watchThreshold{0.5};

    /**
     * @brief STEP 2 diagnostic: path of the raw A_RREP score stream (empty = off).
     *
     * Every comparative score computed by any node is exported, so the offline
     * analysis can measure whether the score separates attackers from honest
     * nodes AT ALL — something the WATCH counters cannot answer, because WATCH
     * is sticky and collapses every repeat trip into a single transition.
     */
    std::string scoresCsv{""};

    /** @brief Bound on stored score rows (Invariant 20.4.2: bounded structures). */
    uint32_t maxScoreRows{500000};

    // ---- C-19 WATCH lifecycle (pilot values; calibrate offline, then freeze) ----
    /** @brief Size M of the per-neighbour observation window. */
    uint32_t watchWindowSize{20};
    /** @brief Minimum anomalies in the window before WATCH may be raised. */
    uint32_t watchMinimumAnomalies{3};
    /** @brief Minimum anomaly rate in the window. */
    double watchAnomalyFraction{0.20};
    /** @brief WATCH clears after this long without a new anomaly. Unit: s. */
    double watchExpirySeconds{15.0};
    /**
     * @brief Hard bound on the number of tracked neighbours per node.
     *
     * Invariant 20.4.2 ("structures bornees"): the per-neighbour WATCH map must
     * not grow with the number of addresses a node happens to hear from, so the
     * protocol evicts the least-recently-updated record past this bound.
     */
    uint32_t maximumTrackedNeighbors{256};

    // ---- STEP 3: next-hop forwarding observation (A3.2) ----
    /**
     * @brief Enable the ForwardingObserver on every node.
     *
     * Setting this false must leave the PDR RIGOROUSLY unchanged at the same
     * seed. That equality is the PASS criterion of STEP 3: the observer is
     * strictly observational, so a PDR *gain* here would be a bug, not a result.
     */
    bool enableForwardingObservation{true};

    /** @brief Observation window before a window closes unmatched. Unit: s. */
    double observationWindowSeconds{0.150};

    /** @brief Sweep period for expiring windows. Unit: s. */
    double observationSweepSeconds{0.050};

    /** @brief Hard bound on simultaneously open windows per node. */
    uint32_t maximumActiveWindows{256};

    /**
     * @brief Path of the raw closed-observation export (empty = off).
     *
     * The offline equivalent of --scoresCsv: it lets STEP 4 calibrate the OCEA
     * weights without recompiling, and it is where the honest-neighbour
     * non-observation baseline is measured.
     */
    std::string observationsCsv{""};

    /** @brief Bound on exported observation rows (Invariant 20.4.2). */
    uint32_t maxObservationRows{500000};

    /** @brief Attack activation time t_attack (inclusive). Unit: s. */
    double attackStartSeconds{10.0};

    /** @brief Global ns-3 seed. */
    uint32_t seed{12345};

    /** @brief ns-3 independent replication number. */
    uint64_t run{1};

    /** @brief Width and height of the square mobility area. Unit: m. FROZEN (STEP 1). */
    double areaSizeMeters{600.0};

    /** @brief Deterministic maximum communication distance. Unit: m. FROZEN (STEP 1). */
    double maximumRangeMeters{200.0};

    /** @brief Number of concurrent UDP sources. Unit: flows. */
    uint32_t flowCount{4};

    /** @brief Useful payload per generated application unit. Unit: bytes. */
    uint32_t packetPayloadBytes{512};

    /** @brief Constant offered data rate of each source. */
    std::string dataRate{"64kbps"};

    /** @brief Start of the earliest source after mobility warm-up. Unit: s. */
    double applicationStartSeconds{10.0};

    /** @brief Deterministic separation between source starts. Unit: s. */
    double sourceStartStaggerSeconds{0.1};

    /** @brief Destination CSV path. */
    std::string outputCsv{"mtcaodv-step01-results.csv"};

    /** @brief Destination JSON manifest path. */
    std::string outputManifest{"mtcaodv-step01-manifest.json"};

    /** @brief Destination FlowMonitor XML path. */
    std::string flowMonitorXml{"mtcaodv-step01-flowmon.xml"};
};

/**
 * @brief Counts and stream allocations observed during one pilot run.
 */
struct PilotRunResult
{
    /** @brief Derived application/network metrics. */
    mtcaodv::BaselineMetricSummary metrics;

    /** @brief Number of application five-tuples found by FlowMonitor. */
    uint32_t monitoredApplicationFlows{0};

    /** @brief Explicit RandomWaypoint streams allocated. */
    int64_t mobilityStreamsConsumed{0};

    /** @brief Wi-Fi streams allocated by WifiHelper. */
    int64_t wifiStreamsConsumed{0};

    /** @brief Forked MTC-AODV routing streams allocated by MtcAodvHelper. */
    int64_t aodvStreamsConsumed{0};

    /** @brief OnOffApplication streams allocated across all sources. */
    int64_t trafficStreamsConsumed{0};

    /** @brief Earliest application start used as the evaluation-window origin. */
    double evaluationStartSeconds{0.0};

    /** @brief Common application stop used as the evaluation-window end. */
    double evaluationStopSeconds{0.0};

    /** @brief Number of Blackhole attackers actually selected/installed. Unit: nodes. */
    uint32_t attackerCount{0};

    /** @brief Sorted node IDs configured as attackers (experiment ground truth). */
    std::vector<uint32_t> attackerNodeIds;

    /** @brief RNG streams consumed by the attacker draw (>=1 when ratio>0). */
    int64_t attackerSelectionStreamsConsumed{0};

    /** @brief Total forged Blackhole RREPs across all attackers. Unit: RREPs. */
    uint32_t forgedRrepCount{0};

    /** @brief Total transit data packets silently dropped. Unit: packets. */
    uint32_t blackholeDropCount{0};

    /** @brief STEP 2: sum over nodes of NORMAL->WATCH transitions (activity). */
    uint32_t watchCount{0};

    /** @brief STEP 2 offline eval: distinct nodes WATCH'd by anyone that ARE attackers. */
    uint32_t watchTruePositives{0};

    /** @brief STEP 2 offline eval: distinct nodes WATCH'd by anyone that are HONEST. */
    uint32_t watchFalsePositives{0};

    /** @brief Same, restricted to nodes still in WATCH at the end (C-19 live view). */
    uint32_t watchTruePositivesCurrent{0};
    uint32_t watchFalsePositivesCurrent{0};

    /**
     * @brief Score rows actually exported, and rows discarded at the bound.
     *
     * These two numbers decide whether the offline replica of the C-19 rule
     * (experiments/analyze_rrep_scores.py --verify-against) can be trusted: the
     * replica replays the exported stream, so if any row was dropped it is
     * replaying a DIFFERENT stream than the one the simulator used and its
     * agreement or disagreement means nothing. Publishing them makes that
     * check decidable instead of assumed.
     */
    uint64_t scoreRowsExported{0};
    uint64_t scoreRowsDropped{0};

    // ---- STEP 3 forwarding-observation counters, summed over all nodes ----
    /** @brief Whether observation was active in this run. */
    bool observationEnabled{false};
    /** @brief Observation windows opened. */
    uint64_t windowsOpened{0};
    /** @brief Closed by a positive match: z_e = 1. */
    uint64_t windowsMatched{0};
    /** @brief Closed by deadline: z_e = 0. */
    uint64_t windowsDeadline{0};
    /** @brief Closed because the neighbour was lost. */
    /** @brief Evicted at the bound: NOT interpretable as an observation. */
    uint64_t windowsEvicted{0};
    /** @brief Fingerprint collisions measured, never assumed zero. */
    uint64_t fingerprintCollisions{0};
    /** @brief Fragmented packets excluded from tracking. */
    uint64_t fragmentedPacketsExcluded{0};
    /** @brief Promiscuous frames inspected across all observers. */
    uint64_t promiscuousFramesInspected{0};
    /** @brief IPv4 transmissions the observer examined (source and relay). */
    uint64_t transmissionsInspected{0};
    // STEP 4 : mesure ACTIVE du lien i -> j, la caracteristique d'opportunite
    // qui remplace `passiveVisibility` mesuree sans pouvoir discriminant.
    uint64_t linkOutcomesRecorded{0};
    // Succes et echecs SEPARES. Un total seul masquerait une instrumentation
    // borgne : si le chemin d'echec n'est jamais emprunte, la fiabilite vaut
    // structurellement 1 et ne mesure plus rien -- ce qui s'est produit quand
    // seule `AckedMpdu` etait branchee.
    uint64_t linkSuccesses{0};
    uint64_t linkFailures{0};
    // Ventilation par raison : sans elle, « 0 echec » serait indiscernable de
    // « la trace n'est pas branchee ». Une seule raison compte comme
    // defaillance de LIEN ; les deux raisons de congestion decrivent l'etat
    // local de i et sont rapportees SEPAREMENT, jamais fondues ici.
    uint64_t macDropsRetryLimit{0};
    uint64_t macDropsFailedEnqueue{0};
    uint64_t macDropsExpiredLifetime{0};
    uint64_t macDropsOther{0};
    uint64_t linkReliabilityChangedDuringWindow{0};
    uint64_t linkReliabilityAvailableCount{0};
    // --- y_l : couverture diagnostique de l'Eq. (8) -----------------------
    // Les quatre se lisent ENSEMBLE. `windowsWithLinkFailure` seul ne dit pas
    // si un zero signifie « aucune cause benigne » ou « diagnostic jamais
    // evalue » ; `windowsWithLinkOutcome` tranche. `peerMacUnknown` donne la
    // premiere cause d'indisponibilite, `multipleLinkOutcomes` borne
    // l'ambiguite d'une attribution par PAIR et non par PAQUET.
    uint64_t windowsWithLinkOutcome{0};
    uint64_t windowsWithLinkFailure{0};
    uint64_t windowsPeerMacUnknownAtOpen{0};
    uint64_t windowsMultipleLinkOutcomes{0};
    /** @brief Skipped because the next hop WAS the final destination. */
    uint64_t skippedLastHop{0};
    /** @brief Skipped because no valid route existed at that instant. */
    uint64_t skippedNoRoute{0};
    /** @brief Skipped as AODV control plane. */
    uint64_t skippedControlPlane{0};
    /** @brief Skipped as broadcast or multicast. */
    uint64_t skippedNonUnicast{0};
    /** @brief Observation rows exported, and rows dropped at the bound. */
    uint64_t observationRowsExported{0};
    uint64_t observationRowsDropped{0};

    /** @brief STEP 2: whether screening was enabled for this run. */
    bool screeningEnabled{true};
};

/**
 * @brief Validate all command-line values before ns-3 objects are created.
 * @param configuration Candidate pilot configuration.
 * @throws std::invalid_argument when a coordinate is outside its valid domain.
 */
void
ValidateConfiguration(const PilotConfiguration& configuration)
{
    // The required /24 network exposes exactly 254 usable host addresses.
    // Keeping this bound explicit prevents an address allocator failure from
    // being mistaken for a routing or mobility failure.
    if (configuration.nodes < 2 || configuration.nodes > 254)
    {
        throw std::invalid_argument("nodes must be in [2, 254] for 10.1.0.0/24");
    }

    if (!std::isfinite(configuration.simulationTimeSeconds) ||
        configuration.simulationTimeSeconds <= 0.0)
    {
        throw std::invalid_argument("simTime must be finite and positive");
    }

    if (!std::isfinite(configuration.minimumSpeedMetersPerSecond) ||
        !std::isfinite(configuration.maximumSpeedMetersPerSecond) ||
        configuration.minimumSpeedMetersPerSecond <= 0.0 ||
        configuration.maximumSpeedMetersPerSecond <
            configuration.minimumSpeedMetersPerSecond)
    {
        throw std::invalid_argument("minSpeed and maxSpeed must satisfy 0 < minSpeed <= maxSpeed");
    }

    if (!std::isfinite(configuration.pauseTimeSeconds) ||
        configuration.pauseTimeSeconds < 0.0)
    {
        throw std::invalid_argument("pauseTime must be finite and non-negative");
    }

    // STEP 1 accepts a real attacker fraction.  The upper bound stays below 1
    // so at least one node remains honest (a full-attacker network is not a
    // meaningful routing scenario).  Fail closed rather than silently clamp.
    if (!std::isfinite(configuration.attackerRatio) ||
        configuration.attackerRatio < 0.0 || configuration.attackerRatio >= 1.0)
    {
        throw std::invalid_argument("attackerRatio must be finite and in [0, 1)");
    }

    if (configuration.attackerSelectionStream < 0)
    {
        throw std::invalid_argument("attackerSelectionStream must be non-negative");
    }

    if (!std::isfinite(configuration.attackStartSeconds) ||
        configuration.attackStartSeconds < 0.0)
    {
        throw std::invalid_argument("attackStart must be finite and non-negative");
    }

    // The attack must start inside the measured window to be observable; warn
    // via exception if it would only activate after the sources stop.
    if (configuration.attackerRatio > 0.0 &&
        configuration.attackStartSeconds >= configuration.simulationTimeSeconds - 1.0)
    {
        throw std::invalid_argument("attackStart must be before the application stop time");
    }

    if (configuration.seed == 0)
    {
        throw std::invalid_argument("seed must be positive");
    }

    if (!std::isfinite(configuration.areaSizeMeters) ||
        configuration.areaSizeMeters <= 0.0 ||
        !std::isfinite(configuration.maximumRangeMeters) ||
        configuration.maximumRangeMeters <= 0.0)
    {
        throw std::invalid_argument("areaSize and maxRange must be finite and positive");
    }

    // The last node is the common destination; each source must be distinct
    // from it.  This check also prevents an empty workload.
    if (configuration.flowCount == 0 || configuration.flowCount >= configuration.nodes)
    {
        throw std::invalid_argument("flowCount must be in [1, nodes-1]");
    }

    SeqTsSizeHeader instrumentationHeader;
    const uint32_t instrumentationBytes = instrumentationHeader.GetSerializedSize();
    constexpr uint32_t MAXIMUM_IPV4_UDP_PAYLOAD_BYTES = 65507;

    // packetPayloadBytes denotes useful data.  The instrumentation header is
    // added transparently and the combined IPv4 UDP payload must remain legal.
    if (configuration.packetPayloadBytes == 0 ||
        configuration.packetPayloadBytes >
            MAXIMUM_IPV4_UDP_PAYLOAD_BYTES - instrumentationBytes)
    {
        throw std::invalid_argument("packetPayloadBytes is outside the IPv4 UDP payload limit");
    }

    if (configuration.dataRate.empty())
    {
        throw std::invalid_argument("dataRate must not be empty");
    }

    if (!std::isfinite(configuration.applicationStartSeconds) ||
        configuration.applicationStartSeconds <= 0.5 ||
        !std::isfinite(configuration.sourceStartStaggerSeconds) ||
        configuration.sourceStartStaggerSeconds < 0.0)
    {
        throw std::invalid_argument("application timing values are invalid");
    }

    const double applicationStopSeconds = configuration.simulationTimeSeconds - 1.0;
    const double lastSourceStartSeconds =
        configuration.applicationStartSeconds +
        configuration.sourceStartStaggerSeconds * (configuration.flowCount - 1);

    // One second is reserved after application stop so packets still in flight
    // can arrive and FlowMonitor can classify losses before Simulator::Stop().
    if (applicationStopSeconds <= configuration.applicationStartSeconds ||
        lastSourceStartSeconds >= applicationStopSeconds)
    {
        throw std::invalid_argument("simTime is too short for the configured application window");
    }

    if (configuration.outputCsv.empty() || configuration.outputManifest.empty() ||
        configuration.flowMonitorXml.empty())
    {
        throw std::invalid_argument("all output paths must be non-empty");
    }
}

/**
 * @brief Install one independently-streamed RandomWaypoint model per node.
 * @param nodes MANET nodes.
 * @param configuration Validated mobility coordinates.
 * @return Number of explicitly reserved RNG streams.
 */
int64_t
InstallRandomWaypointMobility(const NodeContainer& nodes,
                              const PilotConfiguration& configuration)
{
    // Each iteration assigns exactly four disjoint streams to one node: X, Y,
    // speed, and pause.  The invariant after node i is 4*(i+1) reserved streams.
    for (uint32_t nodeIndex = 0; nodeIndex < nodes.GetN(); ++nodeIndex)
    {
        const int64_t nodeStreamBase =
            MOBILITY_STREAM_BASE + MOBILITY_STREAMS_PER_NODE * nodeIndex;

        Ptr<UniformRandomVariable> xCoordinate = CreateObject<UniformRandomVariable>();
        xCoordinate->SetAttribute("Min", DoubleValue(0.0));
        xCoordinate->SetAttribute("Max", DoubleValue(configuration.areaSizeMeters));
        xCoordinate->SetStream(nodeStreamBase);

        Ptr<UniformRandomVariable> yCoordinate = CreateObject<UniformRandomVariable>();
        yCoordinate->SetAttribute("Min", DoubleValue(0.0));
        yCoordinate->SetAttribute("Max", DoubleValue(configuration.areaSizeMeters));
        yCoordinate->SetStream(nodeStreamBase + 1);

        Ptr<RandomRectanglePositionAllocator> positionAllocator =
            CreateObject<RandomRectanglePositionAllocator>();
        positionAllocator->SetAttribute("X", PointerValue(xCoordinate));
        positionAllocator->SetAttribute("Y", PointerValue(yCoordinate));

        Ptr<UniformRandomVariable> speed = CreateObject<UniformRandomVariable>();
        speed->SetAttribute("Min", DoubleValue(configuration.minimumSpeedMetersPerSecond));
        speed->SetAttribute("Max", DoubleValue(configuration.maximumSpeedMetersPerSecond));
        speed->SetStream(nodeStreamBase + 2);

        Ptr<ConstantRandomVariable> pause = CreateObject<ConstantRandomVariable>();
        pause->SetAttribute("Constant", DoubleValue(configuration.pauseTimeSeconds));
        pause->SetStream(nodeStreamBase + 3);

        MobilityHelper mobility;
        mobility.SetPositionAllocator(positionAllocator);
        mobility.SetMobilityModel("ns3::RandomWaypointMobilityModel",
                                  "Speed",
                                  PointerValue(speed),
                                  "Pause",
                                  PointerValue(pause),
                                  "PositionAllocator",
                                  PointerValue(positionAllocator));
        mobility.Install(nodes.Get(nodeIndex));
    }

    return MOBILITY_STREAMS_PER_NODE * static_cast<int64_t>(nodes.GetN());
}

/**
 * @brief Install range-bounded IEEE 802.11b ad hoc devices.
 * @param nodes MANET nodes.
 * @param configuration Validated radio coordinates.
 * @param streamsConsumed Output number of RNG streams consumed by Wi-Fi.
 * @return Installed devices in node order.
 */
NetDeviceContainer
InstallAdHocWifi(const NodeContainer& nodes,
                 const PilotConfiguration& configuration,
                 int64_t& streamsConsumed)
{
    YansWifiChannelHelper channel;
    channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    channel.AddPropagationLoss("ns3::RangePropagationLossModel",
                               "MaxRange",
                               DoubleValue(configuration.maximumRangeMeters));

    YansWifiPhyHelper phy;
    phy.SetChannel(channel.Create());

    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211b);
    wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                 "DataMode",
                                 StringValue("DsssRate11Mbps"),
                                 "ControlMode",
                                 StringValue("DsssRate1Mbps"));

    WifiMacHelper mac;
    mac.SetType("ns3::AdhocWifiMac");

    NetDeviceContainer devices = wifi.Install(phy, mac, nodes);
    streamsConsumed = WifiHelper::AssignStreams(devices, WIFI_STREAM_BASE);
    return devices;
}

/**
 * @brief Install the forked MTC-AODV routing protocol on every node.
 * @param nodes Complete MANET node set.
 * @param helper Output helper kept alive so attack policies can be attached.
 * @return Number of RNG streams consumed by the forked protocol.
 *
 * The fork shares stock AODV's RNG usage, so the same AODV_STREAM_BASE keeps
 * the exogenous randomness aligned with the STEP 0 baseline for pairing.
 */
int64_t
InstallMtcAodv(const NodeContainer& nodes, mtcaodv::MtcAodvHelper& helper)
{
    InternetStackHelper internet;
    internet.SetRoutingHelper(helper);
    internet.Install(nodes);

    return helper.AssignStreams(nodes, AODV_STREAM_BASE);
}

/**
 * @brief Reproducibly select attackers and attach a Blackhole policy to each.
 * @param nodes Complete MANET node set.
 * @param configuration Validated coordinates (ratio, stream, attack start).
 * @param helper Helper already used to install the forked protocol.
 * @param result Run result receiving attacker count, IDs and consumed streams.
 *
 * The traffic endpoints (sources 0..flowCount-1 and destination nodes-1) are
 * excluded so the attack targets relays, matching the "endpoints excluded by
 * default" rule.  Each attacker receives its OWN BlackholeBehavior instance
 * (no shared mutable state / counters), per spec Section 8.2.
 *
 * Scientific-integrity boundary: attacker IDs live only in this scenario-layer
 * routine and in the manifest; no detector/trust/ledger component exists yet
 * and none may ever read them.
 */
void
SelectAndInstallAttackers(const NodeContainer& nodes,
                          const PilotConfiguration& configuration,
                          const mtcaodv::MtcAodvHelper& helper,
                          PilotRunResult& result)
{
    if (configuration.attackerRatio <= 0.0)
    {
        // attackerRatio=0: no policy attached anywhere -> pure AODV fork.
        result.attackerCount = 0;
        result.attackerSelectionStreamsConsumed = 0;
        return;
    }

    // Exclude the fixed traffic endpoints from the eligible attacker set.
    std::set<uint32_t> excluded;
    for (uint32_t flowIndex = 0; flowIndex < configuration.flowCount; ++flowIndex)
    {
        excluded.insert(nodes.Get(flowIndex)->GetId());
    }
    excluded.insert(nodes.Get(nodes.GetN() - 1)->GetId());

    // AttackManager performs Eq. (2) rounding + sampling without replacement on
    // an explicitly assigned ns-3 stream (never std::rand()).
    mtcaodv::AttackManager manager;
    manager.AssignStream(configuration.attackerSelectionStream);
    const mtcaodv::AttackSelectionResult selection =
        manager.SelectAttackers(nodes, configuration.attackerRatio, excluded);
    selection.Validate();

    result.attackerCount = selection.attackerCount;
    result.attackerNodeIds = selection.attackerNodeIds;
    // One deterministic UniformRandomVariable stream is reserved for the draw.
    result.attackerSelectionStreamsConsumed = 1;

    // Attach a distinct Blackhole policy, configured with this run's t_attack,
    // to each selected node.  Node id == container index in this pilot.
    for (const uint32_t attackerId : selection.attackerNodeIds)
    {
        Ptr<mtcaodv::BlackholeBehavior> behavior =
            CreateObject<mtcaodv::BlackholeBehavior>();
        behavior->SetAttribute("AttackStartTime",
                               TimeValue(Seconds(configuration.attackStartSeconds)));
        helper.InstallAttackBehavior(nodes.Get(attackerId), behavior);
    }
}

/**
 * @brief Install one sink and deterministic constant-rate UDP sources.
 * @param nodes MANET node set.
 * @param interfaces Assigned IPv4 interfaces.
 * @param configuration Validated traffic coordinates.
 * @param collector Metrics callback target that remains alive through Run().
 * @return Number of application RNG streams explicitly assigned.
 */
int64_t
InstallUdpTraffic(const NodeContainer& nodes,
                  const Ipv4InterfaceContainer& interfaces,
                  const PilotConfiguration& configuration,
                  mtcaodv::BaselineMetricsCollector& collector)
{
    const uint32_t destinationNodeIndex = nodes.GetN() - 1;
    const Ipv4Address destinationAddress = interfaces.GetAddress(destinationNodeIndex);
    const double applicationStopSeconds = configuration.simulationTimeSeconds - 1.0;

    PacketSinkHelper sinkHelper(
        "ns3::UdpSocketFactory",
        InetSocketAddress(Ipv4Address::GetAny(), APPLICATION_DESTINATION_PORT));
    sinkHelper.SetAttribute("EnableSeqTsSizeHeader", BooleanValue(true));
    ApplicationContainer sinkApplications =
        sinkHelper.Install(nodes.Get(destinationNodeIndex));
    sinkApplications.Start(Seconds(0.5));
    sinkApplications.Stop(Seconds(configuration.simulationTimeSeconds));

    Ptr<PacketSink> sink = DynamicCast<PacketSink>(sinkApplications.Get(0));
    if (!sink)
    {
        throw std::logic_error("Installed sink is not an ns3::PacketSink");
    }

    const bool sinkTraceConnected = sink->TraceConnectWithoutContext(
        "RxWithSeqTsSize",
        MakeCallback(&mtcaodv::BaselineMetricsCollector::ObserveApplicationRxWithSeqTsSize,
                     &collector));
    if (!sinkTraceConnected)
    {
        throw std::logic_error("Could not connect PacketSink RxWithSeqTsSize trace");
    }

    SeqTsSizeHeader instrumentationHeader;
    const uint32_t encodedApplicationDataUnitBytes =
        configuration.packetPayloadBytes + instrumentationHeader.GetSerializedSize();
    const DataRate sourceDataRate(configuration.dataRate);
    int64_t nextTrafficStream = TRAFFIC_STREAM_BASE;

    // Sources are nodes [0, flowCount-1] and the destination is nodes-1.  The
    // loop preserves distinct endpoints and sequential, non-overlapping stream
    // allocation for every already-installed source.
    for (uint32_t flowIndex = 0; flowIndex < configuration.flowCount; ++flowIndex)
    {
        OnOffHelper sourceHelper(
            "ns3::UdpSocketFactory",
            InetSocketAddress(destinationAddress, APPLICATION_DESTINATION_PORT));
        sourceHelper.SetAttribute("DataRate", DataRateValue(sourceDataRate));
        sourceHelper.SetAttribute("PacketSize", UintegerValue(encodedApplicationDataUnitBytes));
        sourceHelper.SetAttribute("OnTime",
                                  StringValue(
                                      "ns3::ConstantRandomVariable[Constant=1000000000.0]"));
        sourceHelper.SetAttribute("OffTime",
                                  StringValue("ns3::ConstantRandomVariable[Constant=0.0]"));
        sourceHelper.SetAttribute("EnableSeqTsSizeHeader", BooleanValue(true));

        ApplicationContainer sourceApplications =
            sourceHelper.Install(nodes.Get(flowIndex));
        const double sourceStartSeconds =
            configuration.applicationStartSeconds +
            configuration.sourceStartStaggerSeconds * flowIndex;
        sourceApplications.Start(Seconds(sourceStartSeconds));
        sourceApplications.Stop(Seconds(applicationStopSeconds));

        Ptr<OnOffApplication> source =
            DynamicCast<OnOffApplication>(sourceApplications.Get(0));
        if (!source)
        {
            throw std::logic_error("Installed source is not an ns3::OnOffApplication");
        }

        const bool sourceTraceConnected = source->TraceConnectWithoutContext(
            "Tx",
            MakeCallback(
                &mtcaodv::BaselineMetricsCollector::ObserveSuccessfulApplicationTx,
                &collector));
        if (!sourceTraceConnected)
        {
            throw std::logic_error("Could not connect OnOffApplication Tx trace");
        }

        // Constant On/Off variables do not alter the offered pattern, but their
        // streams are still explicitly assigned and recorded for future pairing.
        const int64_t applicationStreamCount = source->AssignStreams(nextTrafficStream);
        if (applicationStreamCount <= 0)
        {
            throw std::logic_error("OnOffApplication did not report assigned RNG streams");
        }
        nextTrafficStream += applicationStreamCount;
    }

    return nextTrafficStream - TRAFFIC_STREAM_BASE;
}

/**
 * @brief Extract received network bytes for only the configured data flows.
 * @param helper FlowMonitor helper owning the IPv4 classifier.
 * @param monitor Completed FlowMonitor instance.
 * @param flowCount Output number of matched UDP five-tuples with Tx activity.
 * @return Sum of FlowStats::rxBytes for destination port 9000. Unit: bytes.
 */
uint64_t
CollectApplicationNetworkBytes(FlowMonitorHelper& helper,
                               Ptr<FlowMonitor> monitor,
                               uint32_t& flowCount)
{
    Ptr<Ipv4FlowClassifier> classifier =
        DynamicCast<Ipv4FlowClassifier>(helper.GetClassifier());
    if (!classifier || !monitor)
    {
        throw std::logic_error("FlowMonitor IPv4 classifier is unavailable");
    }

    uint64_t networkReceivedBytes = 0;
    flowCount = 0;
    const FlowMonitor::FlowStatsContainer statistics = monitor->GetFlowStats();

    // Only UDP five-tuples terminating at the pilot application port are part
    // of Equation (25).  This excludes AODV's UDP control port 654 and avoids
    // inflating useful network throughput with routing traffic.
    for (const auto& flowEntry : statistics)
    {
        const Ipv4FlowClassifier::FiveTuple tuple = classifier->FindFlow(flowEntry.first);
        if (tuple.protocol == UDP_PROTOCOL_NUMBER &&
            tuple.destinationPort == APPLICATION_DESTINATION_PORT)
        {
            networkReceivedBytes += flowEntry.second.rxBytes;
            if (flowEntry.second.txPackets > 0)
            {
                ++flowCount;
            }
        }
    }

    return networkReceivedBytes;
}

/**
 * @brief Escape a string for a JSON string literal.
 * @param value Untrusted command-line value.
 * @return Escaped content without surrounding quotation marks.
 */
std::string
EscapeJson(const std::string& value)
{
    std::ostringstream escaped;

    // The loop emits a valid escape for every control or structural character;
    // ordinary UTF-8 bytes are preserved byte-for-byte.
    for (const unsigned char character : value)
    {
        switch (character)
        {
        case '"':
            escaped << "\\\"";
            break;
        case '\\':
            escaped << "\\\\";
            break;
        case '\b':
            escaped << "\\b";
            break;
        case '\f':
            escaped << "\\f";
            break;
        case '\n':
            escaped << "\\n";
            break;
        case '\r':
            escaped << "\\r";
            break;
        case '\t':
            escaped << "\\t";
            break;
        default:
            if (character < 0x20)
            {
                escaped << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                        << static_cast<unsigned int>(character) << std::dec;
            }
            else
            {
                escaped << static_cast<char>(character);
            }
            break;
        }
    }

    return escaped.str();
}

/**
 * @brief Escape a value for one CSV field.
 * @param value Raw field text.
 * @return RFC-4180-compatible field text.
 */
std::string
EscapeCsv(const std::string& value)
{
    const bool requiresQuotes =
        value.find_first_of(",\"\n\r") != std::string::npos;
    if (!requiresQuotes)
    {
        return value;
    }

    std::string escaped = "\"";
    for (const char character : value)
    {
        // CSV represents a literal quotation mark by doubling it.
        if (character == '"')
        {
            escaped += "\"\"";
        }
        else
        {
            escaped += character;
        }
    }
    escaped += '"';
    return escaped;
}

/**
 * @brief Write a floating-point CSV field without fabricating undefined values.
 * @param output Open output stream.
 * @param value Metric or configuration value.
 */
void
WriteCsvDouble(std::ostream& output, double value)
{
    if (std::isfinite(value))
    {
        output << std::setprecision(17) << value;
    }
    else
    {
        output << "NaN";
    }
}

/**
 * @brief Write a JSON number or null for an undefined numerical metric.
 * @param output Open output stream.
 * @param value Candidate numerical value.
 */
void
WriteJsonDouble(std::ostream& output, double value)
{
    if (std::isfinite(value))
    {
        output << std::setprecision(17) << value;
    }
    else
    {
        output << "null";
    }
}

/**
 * @brief Persist the STEP 1 CSV (STEP 0 prefix + append-only security columns).
 * @param configuration Executed coordinates.
 * @param result Observed run result.
 * @throws std::runtime_error when the file cannot be written.
 */
void
WriteCsvResult(const PilotConfiguration& configuration, const PilotRunResult& result)
{
    std::ofstream output(configuration.outputCsv, std::ios::out | std::ios::trunc);
    if (!output)
    {
        throw std::runtime_error("Cannot open CSV output: " + configuration.outputCsv);
    }

    // The first nineteen columns are the immutable prefix requested by the
    // project specification.  Diagnostic columns are append-only after it.
    output << "protocol,nodes,simTime,minSpeed,maxSpeed,seed,run,attackerRatio,"
              "attackerCount,attackStart,appTxPackets,appRxPackets,appTxBytes,"
              "appRxBytes,pdr,plr,throughput_bps,goodput_bps,meanDelay_s,"
              "networkRxBytes,evaluationDuration_s,flowCount,packetPayloadBytes,"
              "dataRate,areaSize_m,maxRange_m,appStart_s,appStop_s,ipv4Network,"
              "ipv4Mask,mobilityStreamBase,wifiStreamBase,aodvStreamBase,"
              "trafficStreamBase,mobilityStreamsConsumed,wifiStreamsConsumed,"
              "aodvStreamsConsumed,trafficStreamsConsumed,monitoredApplicationFlows,"
              "pauseTime_s,sourceStartStagger_s,wifiStandard,wifiMac,"
              "propagationModel,"
              // ---- STEP 1 append-only security columns ----
              "forgedRrepCount,blackholeDropCount,attackStream,"
              "attackerSelectionStreamsConsumed,"
              // ---- STEP 2 append-only defence columns ----
              "screeningEnabled,watchThreshold,watchCount,"
              "watchTruePositives,watchFalsePositives,"
              // ---- STEP 2 / C-19 append-only WATCH-lifecycle columns ----
              // The two "...Current" counters report the *live* surveillance set at
              // the end of the run (neighbours still in WATCH under the C-19 expiry
              // rule), whereas the two columns above are cumulative ("ever watched").
              // Keeping both makes the effect of persistence + expiry measurable
              // without breaking the pre-C-19 column contract.
              "watchTruePositivesCurrent,watchFalsePositivesCurrent,"
              "watchWindowSize,watchMinimumAnomalies,watchAnomalyFraction,"
              "watchExpiry_s,maxTrackedNeighbors,"
              // ---- STEP 3 append-only forwarding-observation columns (A3.2) ----
              // Strictly observational: none of these can move the PDR. If the
              // PDR changes when observationEnabled flips, that is a bug.
              "observationEnabled,windowsOpened,windowsMatched,windowsDeadline,"
              "windowsEvicted,fingerprintCollisions,"
              "fragmentedPacketsExcluded,promiscuousFramesInspected,"
              "observationWindow_s,observationSweep_s,maxActiveWindows,"
              // Why a window did NOT open is as informative as the windows
              // themselves: without these, "few windows" is indistinguishable
              // from "the hook never fires" -- the exact defect that made the
              // first version of this step measure the wrong end of every path.
              "transmissionsInspected,skippedLastHop,skippedNoRoute,"
              "skippedControlPlane,skippedNonUnicast,"
              // STEP 4 : couverture diagnostique de l'Eq. (8). Append-only,
              // comme les colonnes STEP 3 : aucune colonne existante ne bouge.
              "windowsWithLinkOutcome,windowsWithLinkFailure,"
              "windowsPeerMacUnknownAtOpen,windowsMultipleLinkOutcomes\n";

    output << "MTC-AODV," << configuration.nodes << ',';
    WriteCsvDouble(output, configuration.simulationTimeSeconds);
    output << ',';
    WriteCsvDouble(output, configuration.minimumSpeedMetersPerSecond);
    output << ',';
    WriteCsvDouble(output, configuration.maximumSpeedMetersPerSecond);
    output << ',' << configuration.seed << ',' << configuration.run << ',';
    WriteCsvDouble(output, configuration.attackerRatio);
    output << ',' << result.attackerCount << ',';
    WriteCsvDouble(output, configuration.attackStartSeconds);
    output << ',' << result.metrics.appTxPackets << ',' << result.metrics.appRxPackets
           << ',' << result.metrics.appTxBytes << ',' << result.metrics.appRxBytes << ',';
    WriteCsvDouble(output, result.metrics.pdr);
    output << ',';
    WriteCsvDouble(output, result.metrics.plr);
    output << ',';
    WriteCsvDouble(output, result.metrics.throughputBitsPerSecond);
    output << ',';
    WriteCsvDouble(output, result.metrics.goodputBitsPerSecond);
    output << ',';
    WriteCsvDouble(output, result.metrics.meanDelaySeconds);
    output << ',' << result.metrics.networkRxBytes << ',';
    WriteCsvDouble(output, result.evaluationStopSeconds - result.evaluationStartSeconds);
    output << ',' << configuration.flowCount << ',' << configuration.packetPayloadBytes << ','
           << EscapeCsv(configuration.dataRate) << ',';
    WriteCsvDouble(output, configuration.areaSizeMeters);
    output << ',';
    WriteCsvDouble(output, configuration.maximumRangeMeters);
    output << ',';
    WriteCsvDouble(output, result.evaluationStartSeconds);
    output << ',';
    WriteCsvDouble(output, result.evaluationStopSeconds);
    output << ',' << IPV4_NETWORK << ',' << IPV4_MASK << ',' << MOBILITY_STREAM_BASE << ','
           << WIFI_STREAM_BASE << ',' << AODV_STREAM_BASE << ',' << TRAFFIC_STREAM_BASE
           << ',' << result.mobilityStreamsConsumed << ',' << result.wifiStreamsConsumed
           << ',' << result.aodvStreamsConsumed << ',' << result.trafficStreamsConsumed
           << ',' << result.monitoredApplicationFlows << ',';
    WriteCsvDouble(output, configuration.pauseTimeSeconds);
    output << ',';
    WriteCsvDouble(output, configuration.sourceStartStaggerSeconds);
    output << ",802.11b,ns3::AdhocWifiMac,ns3::RangePropagationLossModel,"
           << result.forgedRrepCount << ',' << result.blackholeDropCount << ','
           << configuration.attackerSelectionStream << ','
           << result.attackerSelectionStreamsConsumed << ','
           << (result.screeningEnabled ? 1 : 0) << ',';
    WriteCsvDouble(output, configuration.watchThreshold);
    output << ',' << result.watchCount << ',' << result.watchTruePositives << ','
           << result.watchFalsePositives << ',' << result.watchTruePositivesCurrent << ','
           << result.watchFalsePositivesCurrent << ',' << configuration.watchWindowSize
           << ',' << configuration.watchMinimumAnomalies << ',';
    WriteCsvDouble(output, configuration.watchAnomalyFraction);
    output << ',';
    WriteCsvDouble(output, configuration.watchExpirySeconds);
    output << ',' << configuration.maximumTrackedNeighbors << ','
           << (result.observationEnabled ? 1 : 0) << ',' << result.windowsOpened << ','
           << result.windowsMatched << ',' << result.windowsDeadline << ','
           << result.windowsEvicted << ','
           << result.fingerprintCollisions << ',' << result.fragmentedPacketsExcluded
           << ',' << result.promiscuousFramesInspected << ',';
    WriteCsvDouble(output, configuration.observationWindowSeconds);
    output << ',';
    WriteCsvDouble(output, configuration.observationSweepSeconds);
    output << ',' << configuration.maximumActiveWindows << ','
           << result.transmissionsInspected << ',' << result.skippedLastHop << ','
           << result.skippedNoRoute << ',' << result.skippedControlPlane << ','
           << result.skippedNonUnicast << ',' << result.windowsWithLinkOutcome << ','
           << result.windowsWithLinkFailure << ',' << result.windowsPeerMacUnknownAtOpen
           << ',' << result.windowsMultipleLinkOutcomes << '\n';

    if (!output)
    {
        throw std::runtime_error("Failed while writing CSV output: " +
                                 configuration.outputCsv);
    }
}

/**
 * @brief Persist a deterministic manifest for pairing and diagnosis.
 * @param configuration Executed coordinates.
 * @param result Observed run result.
 * @throws std::runtime_error when the file cannot be written.
 */
void
WriteManifest(const PilotConfiguration& configuration, const PilotRunResult& result)
{
    std::ofstream output(configuration.outputManifest, std::ios::out | std::ios::trunc);
    if (!output)
    {
        throw std::runtime_error("Cannot open manifest output: " +
                                 configuration.outputManifest);
    }

    output << "{\n"
           << "  \"schemaVersion\": \"mtcaodv-step01-v1\",\n"
           << "  \"targetNs3Version\": \"3.48\",\n"
           << "  \"validationStatus\": \"UNVALIDATED_UNTIL_USER_EXECUTION\",\n"
           << "  \"protocol\": \"MTC-AODV\",\n"
           << "  \"attackImplemented\": true,\n"
           << "  \"network\": {\n"
           << "    \"ipv4Network\": \"" << IPV4_NETWORK << "\",\n"
           << "    \"ipv4Mask\": \"" << IPV4_MASK << "\",\n"
           << "    \"wifiStandard\": \"802.11b\",\n"
           << "    \"wifiMac\": \"ns3::AdhocWifiMac\",\n"
           << "    \"propagationModel\": \"ns3::RangePropagationLossModel\"\n"
           << "  },\n"
           << "  \"configuration\": {\n"
           << "    \"nodes\": " << configuration.nodes << ",\n"
           << "    \"simTime\": ";
    WriteJsonDouble(output, configuration.simulationTimeSeconds);
    output << ",\n    \"minSpeed\": ";
    WriteJsonDouble(output, configuration.minimumSpeedMetersPerSecond);
    output << ",\n    \"maxSpeed\": ";
    WriteJsonDouble(output, configuration.maximumSpeedMetersPerSecond);
    output << ",\n    \"pauseTime\": ";
    WriteJsonDouble(output, configuration.pauseTimeSeconds);
    output << ",\n    \"attackerRatio\": ";
    WriteJsonDouble(output, configuration.attackerRatio);
    output << ",\n    \"attackerCount\": " << result.attackerCount << ",\n"
           << "    \"attackStart\": ";
    WriteJsonDouble(output, configuration.attackStartSeconds);
    output << ",\n    \"seed\": " << configuration.seed << ",\n"
           << "    \"run\": " << configuration.run << ",\n"
           << "    \"areaSizeMeters\": ";
    WriteJsonDouble(output, configuration.areaSizeMeters);
    output << ",\n    \"maximumRangeMeters\": ";
    WriteJsonDouble(output, configuration.maximumRangeMeters);
    output << ",\n    \"flowCount\": " << configuration.flowCount << ",\n"
           << "    \"packetPayloadBytes\": " << configuration.packetPayloadBytes << ",\n"
           << "    \"dataRate\": \"" << EscapeJson(configuration.dataRate) << "\",\n"
           << "    \"applicationStartSeconds\": ";
    WriteJsonDouble(output, result.evaluationStartSeconds);
    output << ",\n    \"applicationStopSeconds\": ";
    WriteJsonDouble(output, result.evaluationStopSeconds);
    output << ",\n    \"sourceStartStaggerSeconds\": ";
    WriteJsonDouble(output, configuration.sourceStartStaggerSeconds);
    output << "\n  },\n"
           << "  \"rng\": {\n"
           << "    \"seed\": " << configuration.seed << ",\n"
           << "    \"run\": " << configuration.run << ",\n"
           << "    \"mobilityStreamBase\": " << MOBILITY_STREAM_BASE << ",\n"
           << "    \"wifiStreamBase\": " << WIFI_STREAM_BASE << ",\n"
           << "    \"aodvStreamBase\": " << AODV_STREAM_BASE << ",\n"
           << "    \"trafficStreamBase\": " << TRAFFIC_STREAM_BASE << ",\n"
           << "    \"mobilityStreamsConsumed\": " << result.mobilityStreamsConsumed
           << ",\n"
           << "    \"wifiStreamsConsumed\": " << result.wifiStreamsConsumed << ",\n"
           << "    \"aodvStreamsConsumed\": " << result.aodvStreamsConsumed << ",\n"
           << "    \"trafficStreamsConsumed\": " << result.trafficStreamsConsumed
           << ",\n"
           << "    \"attackerSelectionStream\": " << configuration.attackerSelectionStream
           << ",\n"
           << "    \"attackerSelectionStreamsConsumed\": "
           << result.attackerSelectionStreamsConsumed << "\n  },\n"
           << "  \"attack\": {\n"
           << "    \"forgedRrepCount\": " << result.forgedRrepCount << ",\n"
           << "    \"blackholeDropCount\": " << result.blackholeDropCount << ",\n"
           << "    \"attackerNodeIds\": [";
    for (std::size_t i = 0; i < result.attackerNodeIds.size(); ++i)
    {
        output << (i == 0 ? "" : ", ") << result.attackerNodeIds[i];
    }
    output << "]\n  },\n"
           << "  \"defence\": {\n"
           << "    \"screeningEnabled\": " << (result.screeningEnabled ? "true" : "false")
           << ",\n    \"watchThreshold\": ";
    WriteJsonDouble(output, configuration.watchThreshold);
    output << ",\n    \"watchCount\": " << result.watchCount << ",\n"
           << "    \"watchTruePositives\": " << result.watchTruePositives << ",\n"
           << "    \"watchFalsePositives\": " << result.watchFalsePositives << ",\n"
           // C-19: the WATCH lifecycle parameters belong in the manifest because a
           // detection figure is only interpretable together with the persistence
           // rule that produced it.
           << "    \"watchTruePositivesCurrent\": " << result.watchTruePositivesCurrent
           << ",\n"
           << "    \"watchFalsePositivesCurrent\": " << result.watchFalsePositivesCurrent
           << ",\n"
           << "    \"watchWindowSize\": " << configuration.watchWindowSize << ",\n"
           << "    \"watchMinimumAnomalies\": " << configuration.watchMinimumAnomalies
           << ",\n    \"watchAnomalyFraction\": ";
    WriteJsonDouble(output, configuration.watchAnomalyFraction);
    output << ",\n    \"watchExpiry_s\": ";
    WriteJsonDouble(output, configuration.watchExpirySeconds);
    output << ",\n    \"maxTrackedNeighbors\": " << configuration.maximumTrackedNeighbors
           << ",\n    \"scoreRowsExported\": " << result.scoreRowsExported
           << ",\n    \"scoreRowsDropped\": " << result.scoreRowsDropped
           << "\n  },\n"
           // STEP 3: the observation block. Reported even when observation is
           // disabled, so a reader can tell "no windows because it was off" from
           // "no windows because nothing was relayed" -- two very different runs.
           << "  \"observation\": {\n"
           << "    \"observationEnabled\": "
           << (result.observationEnabled ? "true" : "false") << ",\n"
           << "    \"windowsOpened\": " << result.windowsOpened << ",\n"
           << "    \"windowsMatched\": " << result.windowsMatched << ",\n"
           << "    \"windowsDeadline\": " << result.windowsDeadline << ",\n"
           << "    \"windowsEvicted\": " << result.windowsEvicted << ",\n"
           << "    \"fingerprintCollisions\": " << result.fingerprintCollisions << ",\n"
           << "    \"fragmentedPacketsExcluded\": " << result.fragmentedPacketsExcluded
           << ",\n"
           << "    \"promiscuousFramesInspected\": " << result.promiscuousFramesInspected
           << ",\n    \"observationWindow_s\": ";
    WriteJsonDouble(output, configuration.observationWindowSeconds);
    output << ",\n    \"maxActiveWindows\": " << configuration.maximumActiveWindows
           << ",\n    \"observationRowsExported\": " << result.observationRowsExported
           << ",\n    \"observationRowsDropped\": " << result.observationRowsDropped
           // --- y_l : couverture diagnostique de l'Eq. (8) ------------------
           // Exportes dans le MANIFESTE et non seulement sur stdout : l'analyse
           // hors ligne doit pouvoir dire, a partir des fichiers seuls, si un
           // (0,0,0,1) vient d'une absence de diagnostic ou d'un diagnostic
           // negatif. Les deux se ressemblent dans les masses et ne se
           // ressemblent pas du tout dans ce qu'il faut corriger.
           << ",\n    \"windowsWithLinkOutcome\": " << result.windowsWithLinkOutcome
           << ",\n    \"windowsWithLinkFailure\": " << result.windowsWithLinkFailure
           << ",\n    \"windowsPeerMacUnknownAtOpen\": "
           << result.windowsPeerMacUnknownAtOpen
           << ",\n    \"windowsMultipleLinkOutcomes\": "
           << result.windowsMultipleLinkOutcomes
           << "\n  },\n"
           << "  \"metrics\": {\n"
           << "    \"appTxPackets\": " << result.metrics.appTxPackets << ",\n"
           << "    \"appRxPackets\": " << result.metrics.appRxPackets << ",\n"
           << "    \"appTxBytes\": " << result.metrics.appTxBytes << ",\n"
           << "    \"appRxBytes\": " << result.metrics.appRxBytes << ",\n"
           << "    \"networkRxBytes\": " << result.metrics.networkRxBytes << ",\n"
           << "    \"pdr\": ";
    WriteJsonDouble(output, result.metrics.pdr);
    output << ",\n    \"plr\": ";
    WriteJsonDouble(output, result.metrics.plr);
    output << ",\n    \"throughput_bps\": ";
    WriteJsonDouble(output, result.metrics.throughputBitsPerSecond);
    output << ",\n    \"goodput_bps\": ";
    WriteJsonDouble(output, result.metrics.goodputBitsPerSecond);
    output << ",\n    \"meanDelay_s\": ";
    WriteJsonDouble(output, result.metrics.meanDelaySeconds);
    output << ",\n    \"monitoredApplicationFlows\": "
           << result.monitoredApplicationFlows << "\n"
           << "  }\n"
           << "}\n";

    if (!output)
    {
        throw std::runtime_error("Failed while writing manifest: " +
                                 configuration.outputManifest);
    }
}

/**
 * @brief One exported closed forwarding observation (STEP 3, A3.2).
 *
 * Mirrors ForwardingObservation but flattened for CSV export. The attacker /
 * honest labelling is NOT here: it is applied OFFLINE by analyze_forwarding.py
 * from the manifest, exactly as the RREP score export does. The simulator never
 * labels anything.
 */
struct ForwardingObservationRow
{
    double openTimeSeconds{0.0};
    double closeTimeSeconds{0.0};
    uint32_t observerNodeId{0};
    Ipv4Address watchedNeighbor;
    bool forwardingObserved{false};
    const char* closureReason{"UNKNOWN"};
    bool senderAttributed{false};
    double passiveVisibility{0.0};
    bool passiveVisibilityAvailable{false};
    double linkReliability{0.0};          //!< x_link(e), GELE a l'ouverture.
    bool linkReliabilityAvailable{false};
    // DIAGNOSTIC UNIQUEMENT : n'entre dans aucune equation. Sert a mesurer sur
    // traces la fuite temporelle que le gel supprime.
    double linkReliabilityAtClose{0.0};
    bool linkReliabilityAtCloseAvailable{false};
    // y_l : PREMIER DIAGNOSTIC de perte benigne, entree de l'Eq. (8). Sans lui
    // d_e = 0 et A3.3 renvoie (0,0,0,1) pour TOUS les evenements.
    double linkFailureDuringWindow{0.0};
    bool linkFailureDuringWindowAvailable{false};
    // DIAGNOSTIC : n'entre dans aucune equation, mesure l'ambiguite PAR
    // EVENEMENT de l'attribution par pair.
    uint16_t linkOutcomesDuringWindow{0};
};

/**
 * @brief Bounded in-memory collector of closed observations.
 *
 * Bounded for the same reason as the score collector: an unbounded vector would
 * grow with traffic and silently dominate memory. Dropped rows are COUNTED and
 * published, because an offline analysis of a truncated stream is not an
 * analysis of the run.
 */
struct ForwardingObservationRecorder
{
    std::vector<ForwardingObservationRow> rows;
    uint64_t droppedRows{0};
    uint32_t maximumRows{500000};
};

/**
 * @brief TraceSource sink appending one closed observation.
 * @param recorder Collector (bound argument).
 * @param observation Closed event emitted by a ForwardingObserver.
 */
void
RecordForwardingObservation(ForwardingObservationRecorder* recorder,
                            const mtcaodv::ForwardingObservation& observation)
{
    if (recorder->rows.size() >= recorder->maximumRows)
    {
        ++recorder->droppedRows; // bounded structure: never grow without limit
        return;
    }
    ForwardingObservationRow row;
    row.openTimeSeconds = observation.openTimeSeconds;
    row.closeTimeSeconds = observation.closeTimeSeconds;
    row.observerNodeId = observation.observerNodeId;
    row.watchedNeighbor = observation.watchedNeighbor;
    row.forwardingObserved = observation.forwardingObserved;
    row.closureReason = mtcaodv::ForwardingClosureReasonName(observation.closureReason);
    row.senderAttributed = observation.senderAttributedToNeighbor;
    row.passiveVisibility = observation.passiveVisibility;
    row.passiveVisibilityAvailable = observation.passiveVisibilityAvailable;
    row.linkReliability = observation.linkReliability;
    row.linkReliabilityAvailable = observation.linkReliabilityAvailable;
    row.linkReliabilityAtClose = observation.linkReliabilityAtClose;
    row.linkReliabilityAtCloseAvailable = observation.linkReliabilityAtCloseAvailable;
    row.linkFailureDuringWindow = observation.linkFailureDuringWindow;
    row.linkFailureDuringWindowAvailable = observation.linkFailureDuringWindowAvailable;
    row.linkOutcomesDuringWindow = observation.linkOutcomesDuringWindow;
    recorder->rows.push_back(row);
}

/**
 * @brief One exported A_RREP score observation (STEP 2 diagnostic).
 *
 * Deliberately carries NO ground-truth label: the attacker/honest labelling is
 * done offline by the Python analysis from the manifest, so the measurement path
 * stays free of any oracle knowledge.
 */
struct RrepScoreRow
{
    double timeSeconds{0.0};     //!< Simulation time of the score.
    uint32_t observerNodeId{0};  //!< Node that computed the score.
    Ipv4Address destination;     //!< Advertised RREP destination.
    Ipv4Address neighbor;        //!< Neighbour the score is attributed to.
    double anomalyScore{0.0};    //!< A_RREP in [0,1] (Eq. 5).
};

/**
 * @brief Bounded in-memory collector of the exported score stream.
 */
struct RrepScoreRecorder
{
    std::vector<RrepScoreRow> rows;  //!< Retained observations.
    uint64_t droppedRows{0};         //!< Observations dropped once the bound was hit.
    std::size_t maximumRows{500000}; //!< Hard bound on retained rows.
};

/**
 * @brief TraceSource sink for ns3::mtcaodv::RoutingProtocol::RrepAnomaly.
 * @param recorder Destination collector (bound argument).
 * @param observerNodeId Node owning the routing protocol (bound argument).
 * @param destination Advertised RREP destination.
 * @param neighbor Neighbour the score is attributed to.
 * @param anomalyScore A_RREP in [0,1].
 */
void
RecordRrepAnomaly(RrepScoreRecorder* recorder,
                  uint32_t observerNodeId,
                  Ipv4Address destination,
                  Ipv4Address neighbor,
                  double anomalyScore)
{
    if (recorder->rows.size() >= recorder->maximumRows)
    {
        ++recorder->droppedRows; // bounded structure: never grow without limit
        return;
    }
    recorder->rows.push_back(RrepScoreRow{Simulator::Now().GetSeconds(),
                                          observerNodeId,
                                          destination,
                                          neighbor,
                                          anomalyScore});
}

/**
 * @brief Resolve the forked MTC-AODV routing protocol installed on a node.
 * @param node Node running the fork (possibly wrapped in Ipv4ListRouting).
 * @return The protocol, or nullptr if the node does not run the fork.
 */
Ptr<mtcaodv::RoutingProtocol>
ResolveMtcAodv(Ptr<Node> node)
{
    Ptr<Ipv4> ipv4Stack = node->GetObject<Ipv4>();
    if (!ipv4Stack)
    {
        return nullptr;
    }
    Ptr<Ipv4RoutingProtocol> proto = ipv4Stack->GetRoutingProtocol();
    Ptr<mtcaodv::RoutingProtocol> rp = DynamicCast<mtcaodv::RoutingProtocol>(proto);
    if (rp)
    {
        return rp;
    }
    Ptr<Ipv4ListRouting> list = DynamicCast<Ipv4ListRouting>(proto);
    if (list)
    {
        int16_t priority;
        for (uint32_t j = 0; j < list->GetNRoutingProtocols(); ++j)
        {
            Ptr<mtcaodv::RoutingProtocol> candidate =
                DynamicCast<mtcaodv::RoutingProtocol>(list->GetRoutingProtocol(j, priority));
            if (candidate)
            {
                return candidate;
            }
        }
    }
    return nullptr;
}

/**
 * @brief Execute the MTC-AODV multi-Blackhole pilot after configuration validation.
 * @param configuration Validated simulation coordinates.
 * @return Observed metrics and allocated-stream diagnostics.
 */
PilotRunResult
RunPilot(const PilotConfiguration& configuration)
{
    // Reset process-wide allocators before object construction so rerunning the
    // same seed/run in one process cannot inherit an implicit stream or address.
    RngSeedManager::SetSeed(configuration.seed);
    RngSeedManager::SetRun(configuration.run);
    RngSeedManager::ResetNextStreamIndex();
    Ipv4AddressGenerator::Reset();

    NodeContainer nodes;
    nodes.Create(configuration.nodes);

    PilotRunResult result;
    result.mobilityStreamsConsumed = InstallRandomWaypointMobility(nodes, configuration);

    NetDeviceContainer devices =
        InstallAdHocWifi(nodes, configuration, result.wifiStreamsConsumed);

    // Install the forked MTC-AODV protocol on ALL nodes.  The helper is kept
    // alive so attacker policies can be attached after stack installation.
    // STEP 2: configure RREP anomaly screening (defence) on every node.
    mtcaodv::MtcAodvHelper mtcAodvHelper;
    mtcAodvHelper.Set("EnableRrepScreening", BooleanValue(configuration.enableScreening));
    mtcAodvHelper.Set("WatchThreshold", DoubleValue(configuration.watchThreshold));
    mtcAodvHelper.Set("WatchWindowSize", UintegerValue(configuration.watchWindowSize));
    mtcAodvHelper.Set("WatchMinimumAnomalies",
                      UintegerValue(configuration.watchMinimumAnomalies));
    mtcAodvHelper.Set("WatchAnomalyFraction",
                      DoubleValue(configuration.watchAnomalyFraction));
    mtcAodvHelper.Set("WatchExpiry", TimeValue(Seconds(configuration.watchExpirySeconds)));
    mtcAodvHelper.Set("MaxTrackedNeighbors",
                      UintegerValue(configuration.maximumTrackedNeighbors));
    result.screeningEnabled = configuration.enableScreening;
    result.aodvStreamsConsumed = InstallMtcAodv(nodes, mtcAodvHelper);

    // This exact address helper sequence is normative for the project pilot.
    Ipv4AddressHelper ipv4;
    ipv4.SetBase("10.1.0.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);

    // Reproducibly select the attacker subset and attach Blackhole policies.
    SelectAndInstallAttackers(nodes, configuration, mtcAodvHelper, result);

    // STEP 2 diagnostic: export the raw A_RREP stream from every node.  The sink
    // receives only (destination, neighbour, score); it never sees who is an
    // attacker, so the measurement path stays oracle-free.
    RrepScoreRecorder scoreRecorder;
    scoreRecorder.maximumRows = configuration.maxScoreRows;
    if (!configuration.scoresCsv.empty())
    {
        for (uint32_t i = 0; i < nodes.GetN(); ++i)
        {
            Ptr<mtcaodv::RoutingProtocol> rp = ResolveMtcAodv(nodes.Get(i));
            if (!rp)
            {
                throw std::logic_error("A node is not running mtcaodv::RoutingProtocol");
            }
            const bool connected = rp->TraceConnectWithoutContext(
                "RrepAnomaly",
                MakeBoundCallback(&RecordRrepAnomaly, &scoreRecorder, i));
            if (!connected)
            {
                throw std::logic_error("Could not connect the RrepAnomaly trace");
            }
        }
    }

    // ---- STEP 3: install one ForwardingObserver per node (A3.2) ----
    // Installed on EVERY node, attackers included. That is deliberate and
    // harmless: the observer only listens, and running it uniformly avoids any
    // structural difference between honest and malicious nodes that a detector
    // could accidentally exploit. It receives no attacker list and has no way
    // to read one.
    ForwardingObservationRecorder observationRecorder;
    observationRecorder.maximumRows = configuration.maxObservationRows;
    std::vector<Ptr<mtcaodv::ForwardingObserver>> observers;
    result.observationEnabled = configuration.enableForwardingObservation;
    if (configuration.enableForwardingObservation)
    {
        observers.reserve(nodes.GetN());
        for (uint32_t i = 0; i < nodes.GetN(); ++i)
        {
            Ptr<mtcaodv::ForwardingObserver> observer =
                CreateObject<mtcaodv::ForwardingObserver>();
            observer->SetAttribute(
                "ObservationWindow",
                TimeValue(Seconds(configuration.observationWindowSeconds)));
            observer->SetAttribute(
                "SweepInterval",
                TimeValue(Seconds(configuration.observationSweepSeconds)));
            observer->SetAttribute("MaxActiveWindows",
                                   UintegerValue(configuration.maximumActiveWindows));
            if (!configuration.observationsCsv.empty())
            {
                const bool connected = observer->TraceConnectWithoutContext(
                    "ObservationClosed",
                    MakeBoundCallback(&RecordForwardingObservation, &observationRecorder));
                if (!connected)
                {
                    throw std::logic_error("Could not connect the ObservationClosed trace");
                }
            }
            // Install() resout lui-meme le protocole de routage et se branche
            // sur les traces Ipv4L3Protocol : le protocole de routage n'a plus
            // aucune connaissance de l'observateur, ce qui rend l'egalite
            // PDR(ON) == PDR(OFF) structurelle plutot que promise.
            observer->Install(nodes.Get(i));
            observers.push_back(observer);
        }
    }

    result.evaluationStartSeconds = configuration.applicationStartSeconds;
    result.evaluationStopSeconds = configuration.simulationTimeSeconds - 1.0;
    const Time evaluationDuration =
        Seconds(result.evaluationStopSeconds - result.evaluationStartSeconds);
    mtcaodv::BaselineMetricsCollector collector(evaluationDuration);

    result.trafficStreamsConsumed =
        InstallUdpTraffic(nodes, interfaces, configuration, collector);

    // Stream ranges are deliberately separated by 10,000.  Verify the actual
    // helper-reported consumption before the simulation starts so a future
    // topology increase or ns-3 implementation change cannot silently make
    // two stochastic components share a stream.
    if (MOBILITY_STREAM_BASE + result.mobilityStreamsConsumed > AODV_STREAM_BASE ||
        AODV_STREAM_BASE + result.aodvStreamsConsumed > WIFI_STREAM_BASE ||
        WIFI_STREAM_BASE + result.wifiStreamsConsumed > TRAFFIC_STREAM_BASE)
    {
        throw std::logic_error("Configured RNG stream ranges overlap");
    }

    FlowMonitorHelper flowMonitorHelper;
    Ptr<FlowMonitor> flowMonitor = flowMonitorHelper.InstallAll();

    Simulator::Stop(Seconds(configuration.simulationTimeSeconds));
    Simulator::Run();

    flowMonitor->CheckForLostPackets();
    const uint64_t networkReceivedBytes = CollectApplicationNetworkBytes(
        flowMonitorHelper,
        flowMonitor,
        result.monitoredApplicationFlows);
    collector.SetNetworkReceivedBytes(networkReceivedBytes);
    result.metrics = collector.BuildSummary();

    // Aggregate the fork-only attack counters from each attacker's routing
    // protocol.  Honest nodes never increment these, so reading only the
    // attacker set is exact and avoids touching every node.
    for (const uint32_t attackerId : result.attackerNodeIds)
    {
        Ptr<mtcaodv::RoutingProtocol> rp = ResolveMtcAodv(nodes.Get(attackerId));
        if (!rp)
        {
            throw std::logic_error("Attacker node is not running mtcaodv::RoutingProtocol");
        }
        result.forgedRrepCount += rp->GetForgedReplyCount();
        result.blackholeDropCount += rp->GetBlackholeTransitDropCount();
    }

    // STEP 2: aggregate WATCH activity across ALL nodes and, OFFLINE ONLY, cross
    // the detected set with the attacker ground truth for a TP/FP readout.  The
    // detector never performs this intersection; it happens here, in the
    // experiment layer, exactly like the attacker selection.
    std::map<Ipv4Address, uint32_t> addressToNodeIndex;
    for (uint32_t i = 0; i < nodes.GetN(); ++i)
    {
        addressToNodeIndex[interfaces.GetAddress(i)] = i;
    }
    const std::set<uint32_t> attackerSet(result.attackerNodeIds.begin(),
                                         result.attackerNodeIds.end());
    std::set<uint32_t> detectedNodeIds;         // WATCH'd by someone at any time
    std::set<uint32_t> currentlyWatchedNodeIds;  // still in WATCH at the end (C-19)
    for (uint32_t i = 0; i < nodes.GetN(); ++i)
    {
        Ptr<mtcaodv::RoutingProtocol> rp = ResolveMtcAodv(nodes.Get(i));
        if (!rp)
        {
            throw std::logic_error("A node is not running mtcaodv::RoutingProtocol");
        }
        result.watchCount += rp->GetWatchCount();
        // "Ever watched" keeps continuity with the pre-C-19 metric...
        for (const Ipv4Address& watched : rp->GetEverWatchedNeighbors())
        {
            const auto found = addressToNodeIndex.find(watched);
            if (found != addressToNodeIndex.end())
            {
                detectedNodeIds.insert(found->second);
            }
        }
        // ...while "currently watched" is the live surveillance set that C-19
        // actually maintains, i.e. what STEP 3 would observe.
        for (const Ipv4Address& watched : rp->GetWatchedNeighbors())
        {
            const auto found = addressToNodeIndex.find(watched);
            if (found != addressToNodeIndex.end())
            {
                currentlyWatchedNodeIds.insert(found->second);
            }
        }
    }
    for (const uint32_t detected : detectedNodeIds)
    {
        if (attackerSet.count(detected) != 0)
        {
            ++result.watchTruePositives;
        }
        else
        {
            ++result.watchFalsePositives;
        }
    }
    for (const uint32_t detected : currentlyWatchedNodeIds)
    {
        if (attackerSet.count(detected) != 0)
        {
            ++result.watchTruePositivesCurrent;
        }
        else
        {
            ++result.watchFalsePositivesCurrent;
        }
    }

    // STEP 2 diagnostic: persist the raw score stream, resolving each neighbour
    // address to its node id so the offline analysis can label it.
    if (!configuration.scoresCsv.empty())
    {
        std::ofstream scoreOutput(configuration.scoresCsv, std::ios::out | std::ios::trunc);
        if (!scoreOutput)
        {
            throw std::runtime_error("Cannot open scores CSV: " + configuration.scoresCsv);
        }
        scoreOutput << "time_s,observerNodeId,destination,neighborNodeId,neighborIp,"
                       "anomalyScore\n";
        for (const RrepScoreRow& row : scoreRecorder.rows)
        {
            const auto found = addressToNodeIndex.find(row.neighbor);
            // -1 marks an address that is not one of the scenario nodes.
            const long long neighborId =
                (found == addressToNodeIndex.end()) ? -1
                                                    : static_cast<long long>(found->second);
            scoreOutput << std::setprecision(17) << row.timeSeconds << ','
                        << row.observerNodeId << ',' << row.destination << ','
                        << neighborId << ',' << row.neighbor << ',' << row.anomalyScore
                        << '\n';
        }
        if (!scoreOutput)
        {
            throw std::runtime_error("Failed while writing scores CSV: " +
                                     configuration.scoresCsv);
        }
        result.scoreRowsExported = scoreRecorder.rows.size();
        result.scoreRowsDropped = scoreRecorder.droppedRows;
        std::cout << "rrepScoreRows=" << scoreRecorder.rows.size()
                  << " droppedScoreRows=" << scoreRecorder.droppedRows
                  << " scoresCsv=" << configuration.scoresCsv << std::endl;
    }

    // ---- STEP 3: aggregate the observation counters, then export the stream --
    // Counters are read from the observers themselves, not recomputed from the
    // exported rows: the export can be bounded away while the counters cannot,
    // so the two must never be conflated.
    for (const Ptr<mtcaodv::ForwardingObserver>& observer : observers)
    {
        result.windowsOpened += observer->GetWindowsOpened();
        result.windowsMatched += observer->GetWindowsMatched();
        result.windowsDeadline += observer->GetWindowsDeadline();
        result.windowsEvicted += observer->GetWindowsEvicted();
        result.fingerprintCollisions += observer->GetFingerprintCollisions();
        result.fragmentedPacketsExcluded += observer->GetFragmentedPacketsExcluded();
        result.promiscuousFramesInspected += observer->GetPromiscuousFramesInspected();
        result.transmissionsInspected += observer->GetTransmissionsInspected();
        result.skippedLastHop += observer->GetSkippedLastHop();
        result.skippedNoRoute += observer->GetSkippedNoRoute();
        result.skippedControlPlane += observer->GetSkippedControlPlane();
        result.skippedNonUnicast += observer->GetSkippedNonUnicast();
        result.linkOutcomesRecorded += observer->GetLinkOutcomesRecorded();
        result.linkSuccesses += observer->GetLinkSuccesses();
        result.linkFailures += observer->GetLinkFailures();
        result.macDropsRetryLimit += observer->GetMacDropsRetryLimit();
        result.macDropsFailedEnqueue += observer->GetMacDropsFailedEnqueue();
        result.macDropsExpiredLifetime += observer->GetMacDropsExpiredLifetime();
        result.macDropsOther += observer->GetMacDropsOther();
        result.linkReliabilityChangedDuringWindow +=
            observer->GetLinkReliabilityChangedDuringWindow();
        result.linkReliabilityAvailableCount +=
            observer->GetLinkReliabilityAvailableCount();
        result.windowsWithLinkOutcome += observer->GetWindowsWithLinkOutcome();
        result.windowsWithLinkFailure += observer->GetWindowsWithLinkFailure();
        result.windowsPeerMacUnknownAtOpen += observer->GetWindowsPeerMacUnknownAtOpen();
        result.windowsMultipleLinkOutcomes += observer->GetWindowsMultipleLinkOutcomes();
    }
    result.observationRowsExported = observationRecorder.rows.size();
    result.observationRowsDropped = observationRecorder.droppedRows;

    if (!configuration.observationsCsv.empty())
    {
        std::ofstream observationOutput(configuration.observationsCsv,
                                        std::ios::out | std::ios::trunc);
        if (!observationOutput)
        {
            throw std::runtime_error("Cannot open observations CSV for writing: " +
                                     configuration.observationsCsv);
        }
        // neighborNodeId is -1 when the neighbour address is not one of the
        // scenario nodes. It is NOT silently mapped to node 0.
        observationOutput << "openTime_s,closeTime_s,observerNodeId,neighborNodeId,"
                             "neighborIp,forwardingObserved,closureReason,"
                             "senderAttributed,passiveVisibility,"
                             "passiveVisibilityAvailable,"
                             "linkReliability,linkReliabilityAvailable,"
                             // Colonnes DIAGNOSTIC : n'entrent dans aucune
                             // equation, servent a mesurer la fuite temporelle.
                             "linkReliabilityAtClose,linkReliabilityAtCloseAvailable,"
                             // y_l : le premier diagnostic de l'Eq. (8).
                             "linkFailureDuringWindow,linkFailureDuringWindowAvailable,"
                             // Colonne DIAGNOSTIC : ambiguite PAR EVENEMENT.
                             "linkOutcomesDuringWindow\n";
        for (const ForwardingObservationRow& row : observationRecorder.rows)
        {
            const auto found = addressToNodeIndex.find(row.watchedNeighbor);
            const long long neighborId =
                (found == addressToNodeIndex.end()) ? -1
                                                    : static_cast<long long>(found->second);
            observationOutput << std::setprecision(17) << row.openTimeSeconds << ','
                              << row.closeTimeSeconds << ',' << row.observerNodeId << ','
                              << neighborId << ',' << row.watchedNeighbor << ','
                              << (row.forwardingObserved ? 1 : 0) << ','
                              << row.closureReason << ','
                              << (row.senderAttributed ? 1 : 0) << ','
                              << row.passiveVisibility << ','
                              << (row.passiveVisibilityAvailable ? 1 : 0) << ','
                              << row.linkReliability << ','
                              << (row.linkReliabilityAvailable ? 1 : 0) << ','
                              << row.linkReliabilityAtClose << ','
                              << (row.linkReliabilityAtCloseAvailable ? 1 : 0) << ','
                              << row.linkFailureDuringWindow << ','
                              << (row.linkFailureDuringWindowAvailable ? 1 : 0) << ','
                              << row.linkOutcomesDuringWindow << '\n';
        }
        if (!observationOutput)
        {
            throw std::runtime_error("Failed while writing observations CSV: " +
                                     configuration.observationsCsv);
        }
        std::cout << "observationRows=" << observationRecorder.rows.size()
                  << " droppedObservationRows=" << observationRecorder.droppedRows
                  << " observationsCsv=" << configuration.observationsCsv << std::endl;
    }

    // Preserve raw FlowMonitor data for diagnosis; the CSV still uses only the
    // explicitly filtered UDP data flows for its throughput calculation.
    flowMonitor->SerializeToXmlFile(configuration.flowMonitorXml, true, true);

    Simulator::Destroy();
    return result;
}

/**
 * @brief Print concise observed values after a completed simulation.
 * @param configuration Executed configuration.
 * @param result Actual result returned by RunPilot().
 */
void
PrintResult(const PilotConfiguration& configuration, const PilotRunResult& result)
{
    std::cout << std::setprecision(10)
              << "STEP 1 simulation completed with forked MTC-AODV\n"
              << "attackerCount=" << result.attackerCount << '\n'
              << "forgedRrepCount=" << result.forgedRrepCount << '\n'
              << "blackholeDropCount=" << result.blackholeDropCount << '\n'
              << "screeningEnabled=" << (result.screeningEnabled ? 1 : 0) << '\n'
              << "watchCount=" << result.watchCount << '\n'
              << "watchTruePositives=" << result.watchTruePositives << '\n'
              << "watchFalsePositives=" << result.watchFalsePositives << '\n'
              // C-19: cumulative counters answer "was it ever suspected?", the
              // "Current" pair answers "is it still under surveillance at t_end?".
              // A working expiry rule shows Current <= cumulative on false
              // positives while keeping the true positives.
              << "watchTruePositivesCurrent=" << result.watchTruePositivesCurrent << '\n'
              << "watchFalsePositivesCurrent=" << result.watchFalsePositivesCurrent << '\n'
              // STEP 3: windowsOpened is the first number to read. Zero means the
              // observer never saw a relay -- the run says nothing about
              // detection, only about the topology.
              << "observationEnabled=" << (result.observationEnabled ? 1 : 0) << '\n'
              << "windowsOpened=" << result.windowsOpened << '\n'
              << "windowsMatched=" << result.windowsMatched << '\n'
              << "windowsDeadline=" << result.windowsDeadline << '\n'
              << "windowsEvicted=" << result.windowsEvicted << '\n'
              << "fingerprintCollisions=" << result.fingerprintCollisions << '\n'
              << "promiscuousFramesInspected=" << result.promiscuousFramesInspected << '\n'
              << "linkOutcomesRecorded=" << result.linkOutcomesRecorded << '\n'
              << "linkSuccesses=" << result.linkSuccesses << '\n'
              << "linkFailures=" << result.linkFailures << '\n'
              // y_l : couverture diagnostique. `windowsWithLinkOutcome` est le
              // chiffre qui decide si A3.3 peut attribuer autre chose que
              // (0,0,0,1) -- c'est d_e > 0. A zero, l'Eq. (8) ne s'applique
              // jamais et STEP 4 n'aurait rien apporte.
              << "windowsWithLinkOutcome=" << result.windowsWithLinkOutcome << '\n'
              << "windowsWithLinkFailure=" << result.windowsWithLinkFailure << '\n'
              << "windowsPeerMacUnknownAtOpen=" << result.windowsPeerMacUnknownAtOpen
              << '\n'
              << "windowsMultipleLinkOutcomes=" << result.windowsMultipleLinkOutcomes
              << '\n'
              << "macDropsRetryLimit=" << result.macDropsRetryLimit << '\n'
              << "macDropsFailedEnqueue=" << result.macDropsFailedEnqueue << '\n'
              << "macDropsExpiredLifetime=" << result.macDropsExpiredLifetime << '\n'
              << "macDropsOther=" << result.macDropsOther << '\n'
              << "linkReliabilityChangedDuringWindow="
              << result.linkReliabilityChangedDuringWindow << '\n'
              << "linkReliabilityAvailable=" << result.linkReliabilityAvailableCount
              << '\n'
              << "transmissionsInspected=" << result.transmissionsInspected << '\n'
              << "skippedLastHop=" << result.skippedLastHop << '\n'
              << "skippedNoRoute=" << result.skippedNoRoute << '\n'
              << "skippedControlPlane=" << result.skippedControlPlane << '\n'
              << "appTxPackets=" << result.metrics.appTxPackets << '\n'
              << "appRxPackets=" << result.metrics.appRxPackets << '\n'
              << "appTxBytes=" << result.metrics.appTxBytes << '\n'
              << "appRxBytes=" << result.metrics.appRxBytes << '\n'
              << "pdr=" << result.metrics.pdr << '\n'
              << "plr=" << result.metrics.plr << '\n'
              << "throughput_bps=" << result.metrics.throughputBitsPerSecond << '\n'
              << "goodput_bps=" << result.metrics.goodputBitsPerSecond << '\n'
              << "meanDelay_s=" << result.metrics.meanDelaySeconds << '\n'
              << "csv=" << configuration.outputCsv << '\n'
              << "manifest=" << configuration.outputManifest << '\n'
              << "flowMonitorXml=" << configuration.flowMonitorXml << std::endl;
}

} // namespace

/**
 * @brief Configure, execute, and persist one STEP 1 multi-Blackhole realization.
 */
int
main(int argc, char* argv[])
{
    PilotConfiguration configuration;

    CommandLine commandLine(__FILE__);
    commandLine.AddValue("nodes", "Number of MANET nodes", configuration.nodes);
    commandLine.AddValue("simTime",
                         "Simulation duration in seconds",
                         configuration.simulationTimeSeconds);
    commandLine.AddValue("minSpeed",
                         "Minimum RandomWaypoint speed in m/s",
                         configuration.minimumSpeedMetersPerSecond);
    commandLine.AddValue("maxSpeed",
                         "Maximum RandomWaypoint speed in m/s",
                         configuration.maximumSpeedMetersPerSecond);
    commandLine.AddValue("pauseTime",
                         "RandomWaypoint pause duration in seconds",
                         configuration.pauseTimeSeconds);
    commandLine.AddValue("attackerRatio",
                         "Attacker fraction r_a in [0,1); 0 gives a healthy fork sanity run",
                         configuration.attackerRatio);
    commandLine.AddValue("attackStart",
                         "Attack activation time t_attack in seconds (inclusive)",
                         configuration.attackStartSeconds);
    commandLine.AddValue("seed", "Global ns-3 seed", configuration.seed);
    commandLine.AddValue("run", "ns-3 replication run number", configuration.run);
    commandLine.AddValue("areaSize",
                         "Square mobility-area side length in meters",
                         configuration.areaSizeMeters);
    commandLine.AddValue("maxRange",
                         "RangePropagationLossModel maximum range in meters",
                         configuration.maximumRangeMeters);
    commandLine.AddValue("flowCount",
                         "Number of concurrent UDP source flows",
                         configuration.flowCount);
    commandLine.AddValue("packetSize",
                         "Useful application payload per packet in bytes",
                         configuration.packetPayloadBytes);
    commandLine.AddValue("dataRate",
                         "Per-source constant application data rate",
                         configuration.dataRate);
    commandLine.AddValue("appStart",
                         "Earliest UDP source start in seconds",
                         configuration.applicationStartSeconds);
    commandLine.AddValue("sourceStartStagger",
                         "Deterministic source-start separation in seconds",
                         configuration.sourceStartStaggerSeconds);
    commandLine.AddValue("attackStream",
                         "RNG stream index for the reproducible attacker draw",
                         configuration.attackerSelectionStream);
    commandLine.AddValue("enableScreening",
                         "STEP 2: enable RREP anomaly screening (defence) on all nodes",
                         configuration.enableScreening);
    commandLine.AddValue("watchThreshold",
                         "STEP 2: WATCH threshold theta_R on the RREP anomaly score",
                         configuration.watchThreshold);
    // ---- C-19: the WATCH lifecycle knobs stay configurable ----
    // The specification leaves C-19 (the WATCH-clear rule) unfrozen, so these
    // four values must be swept offline and only then frozen. Exposing them on
    // the CLI is what makes a calibration campaign possible without recompiling.
    commandLine.AddValue("watchWindow",
                         "C-19: size M of the per-neighbour anomaly observation window",
                         configuration.watchWindowSize);
    commandLine.AddValue("watchMinAnomalies",
                         "C-19: minimum anomalies inside the window before WATCH is raised",
                         configuration.watchMinimumAnomalies);
    commandLine.AddValue("watchAnomalyFraction",
                         "C-19: minimum anomaly rate inside the window (0..1) before WATCH "
                         "is raised; a rate rather than a count because the number of "
                         "comparable RREPs per neighbour varies strongly across scenarios",
                         configuration.watchAnomalyFraction);
    commandLine.AddValue("watchExpiry",
                         "C-19: seconds without a new anomaly after which WATCH clears "
                         "back to NORMAL (surveillance is reinforced observation, never "
                         "a quarantine, so it must be revocable)",
                         configuration.watchExpirySeconds);
    commandLine.AddValue("maxTrackedNeighbors",
                         "Bound on the per-node WATCH map (Invariant 20.4.2)",
                         configuration.maximumTrackedNeighbors);
    // ---- STEP 3: forwarding-observation knobs ----
    commandLine.AddValue("enableObservation",
                         "STEP 3: enable the next-hop ForwardingObserver (A3.2). "
                         "Turning it off must leave the PDR bit-identical at the "
                         "same seed; that equality is the step's PASS criterion",
                         configuration.enableForwardingObservation);
    commandLine.AddValue("observationWindow",
                         "A3.2: seconds before an unmatched observation window "
                         "closes. Too short and an honest forward is missed and "
                         "counted as a non-observation -- the most insidious "
                         "failure mode of this step. Calibrate on the measured "
                         "match-latency distribution, never by intuition",
                         configuration.observationWindowSeconds);
    commandLine.AddValue("observationSweep",
                         "A3.2: period of the deadline sweep in seconds",
                         configuration.observationSweepSeconds);
    commandLine.AddValue("maxActiveWindows",
                         "Bound on simultaneously open observation windows per "
                         "node (Invariant 20.4.2)",
                         configuration.maximumActiveWindows);
    commandLine.AddValue("observationsCsv",
                         "STEP 3: export every closed observation to this CSV "
                         "(empty disables the export). This is where the "
                         "honest-neighbour non-observation baseline is measured",
                         configuration.observationsCsv);
    commandLine.AddValue("maxObservationRows",
                         "Bound on retained observation rows for the export",
                         configuration.maxObservationRows);
    commandLine.AddValue("scoresCsv",
                         "STEP 2 diagnostic: export every A_RREP score to this CSV "
                         "(empty disables the export)",
                         configuration.scoresCsv);
    commandLine.AddValue("maxScoreRows",
                         "Bound on retained score rows for the diagnostic export",
                         configuration.maxScoreRows);
    commandLine.AddValue("outputCsv", "STEP 1 CSV output path", configuration.outputCsv);
    commandLine.AddValue("outputManifest",
                         "STEP 1 JSON manifest output path",
                         configuration.outputManifest);
    commandLine.AddValue("flowMonitorXml",
                         "Raw FlowMonitor XML output path",
                         configuration.flowMonitorXml);
    commandLine.Parse(argc, argv);

    try
    {
        ValidateConfiguration(configuration);
        const PilotRunResult result = RunPilot(configuration);
        WriteCsvResult(configuration, result);
        WriteManifest(configuration, result);
        PrintResult(configuration, result);
    }
    catch (const std::exception& error)
    {
        // Destroy is safe after partial construction and prevents stale static
        // simulator state if this executable is invoked by a test harness.
        Simulator::Destroy();
        std::cerr << "STEP 1 execution failed: " << error.what() << std::endl;
        return 1;
    }

    return 0;
}
