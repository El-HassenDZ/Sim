/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef MTCAODV_FORWARDING_OBSERVER_H
#define MTCAODV_FORWARDING_OBSERVER_H

#include "forwarding-observation.h"
#include "packet-fingerprint.h"

#include "ns3/address.h"
#include "ns3/event-id.h"
#include "ns3/mac48-address.h"
#include "ns3/ipv4-address.h"
#include "ns3/ipv4-header.h"
#include "ns3/net-device.h"
#include "ns3/nstime.h"
#include "ns3/object.h"
#include "ns3/packet.h"
#include "ns3/traced-callback.h"
// wifi-mac.h porte l'enumeration WifiMacDropReason, employee dans les
// signatures ci-dessous. wifi-mpdu.h ne l'inclut PAS transitivement.
#include "ns3/wifi-mac.h"
#include "ns3/wifi-mpdu.h"

#include <cstdint>
#include <map>

namespace ns3
{

class Node;

namespace mtcaodv
{

class RoutingProtocol;

/**
 * @ingroup mtcaodv
 * @brief Algorithme A3.2 — fenêtre locale d'observation du prochain saut.
 *
 * CE QUE FAIT CETTE CLASSE
 * ------------------------
 * Quand le protocole de routage remet un paquet au voisin `j`, il appelle
 * OpenWindow(). L'observateur écoute alors passivement le canal ; s'il entend
 * `j` retransmettre le MEME paquet avant l'échéance, la fenêtre se referme avec
 * `z_e = 1`. Sinon elle se referme avec `z_e = 0` et les indices de perte
 * bénigne disponibles.
 *
 * CE QU'ELLE NE FAIT PAS, ET C'EST ESSENTIEL
 * ------------------------------------------
 * 1. Elle n'attribue AUCUNE masse et ne qualifie rien de malveillant. A3.2 se
 *    termine par « do not label it malicious here » ; l'attribution est A3.3,
 *    livrée à STEP 4.
 * 2. Elle ne consulte AUCUNE vérité terrain. Elle ne reçoit jamais la liste des
 *    attaquants et n'a aucun moyen de la lire. L'appariement attaquant/honnête
 *    se fait hors ligne, sur le manifeste, comme pour le criblage RREP.
 * 3. Elle ne modifie NI ne retarde AUCUN paquet. Le rappel promiscuité renvoie
 *    toujours false et travaille sur des copies. La preuve exigée à STEP 3 est
 *    `PDR(observateur actif) == PDR(observateur inactif)` au même germe.
 *
 * ATTRIBUTION DE L'EMETTEUR — APPRISE, PAS SUPPOSEE
 * -------------------------------------------------
 * Entendre la retransmission ne suffit pas : encore faut-il savoir qu'elle vient
 * bien de `j`. La trame fournit une adresse MAC ; la fenêtre connaît une adresse
 * IPv4. La correspondance est apprise **passivement** : toute trame diffusée
 * portant un en-tête IPv4 révèle que son adresse MAC émettrice appartient au
 * nœud dont l'adresse IP figure en source (le spike C-17 l'a vérifié — les
 * diffusions de contrôle AODV portent bien l'adresse du saut courant).
 *
 * Quand la correspondance est inconnue, `senderAttributedToNeighbor` reste faux
 * et l'observation le déclare. Supposer l'attribution serait fabriquer une
 * donnée.
 *
 * STRUCTURES BORNEES (Invariant 20.4.2)
 * -------------------------------------
 * `MaxActiveWindows` borne les fenêtres ouvertes ; au-delà, la plus ancienne est
 * évincée avec `EVICTED` — une raison distincte, jamais confondue avec une
 * non-observation. `MaxLearnedAddresses` borne la table MAC→IPv4.
 */
class ForwardingObserver : public Object
{
  public:
    /**
     * @brief Enregistre le TypeId de cette classe.
     * @return TypeId enregistré.
     */
    static TypeId GetTypeId();

    ForwardingObserver();
    ~ForwardingObserver() override;

    /**
     * @brief Attache l'observateur à un nœud et installe l'écoute passive.
     * @param node Nœud observateur.
     *
     * L'écoute est posée sur CHAQUE interface non-loopback via
     * NetDevice::SetPromiscReceiveCallback, dont le spike C-17 a confirmé qu'elle
     * remonte les trames étrangères avec l'émetteur du saut courant et un
     * en-tête IPv4 intact.
     *
     * @warning À n'appeler qu'une fois par nœud. Poser deux rappels promiscuité
     *          écraserait le premier ; ns-3 n'en conserve qu'un par interface.
     */
    void Install(Ptr<Node> node);

    /**
     * @brief Ouvre une fenêtre : « je viens de remettre ce paquet à `j` ».
     * @param header En-tête IPv4 COMPLET du paquet remis.
     * @param payloadLengthBytes Taille utile en octets.
     * @param nextHop Adresse IPv4 du prochain saut `j`.
     *
     * Publique pour être testable directement. En fonctionnement, elle est
     * appelée par OnIpv4Transmit() et non par le protocole de routage.
     */
    void OpenWindow(const Ipv4Header& header,
                    uint16_t payloadLengthBytes,
                    Ipv4Address nextHop);

    /** @brief Active ou désactive l'observation (preuve de non-intrusion). */
    void SetEnabled(bool enabled);

    /** @brief L'observation est-elle active ? */
    bool IsEnabled() const;

    // ---- Compteurs, tous mesurés, aucun supposé ----
    /** @brief Fenêtres ouvertes depuis le début. */
    uint64_t GetWindowsOpened() const;
    /** @brief Fenêtres closes par appariement positif (`z_e = 1`). */
    uint64_t GetWindowsMatched() const;
    /** @brief Fenêtres closes par échéance (`z_e = 0`). */
    uint64_t GetWindowsDeadline() const;
    /** @brief Fenêtres évincées par la borne : NON interprétables. */
    uint64_t GetWindowsEvicted() const;
    /** @brief Empreintes en collision détectées (jamais supposées nulles). */
    uint64_t GetFingerprintCollisions() const;
    /** @brief Paquets fragmentés rencontrés, exclus du suivi. */
    uint64_t GetFragmentedPacketsExcluded() const;
    /** @brief Trames promiscuité inspectées, tous types confondus. */
    uint64_t GetPromiscuousFramesInspected() const;

    // ---- Pourquoi une fenêtre n'a PAS été ouverte ----
    // Ces compteurs sont aussi informatifs que les fenêtres elles-mêmes : sans
    // eux, « peu de fenêtres » serait indiscernable de « l'accrochage ne se
    // déclenche pas », qui est exactement le défaut ayant motivé cette refonte.
    /** @brief Émissions où le prochain saut EST la destination finale. */
    uint64_t GetSkippedLastHop() const;
    /** @brief Émissions sans route valide au moment de l'observation. */
    uint64_t GetSkippedNoRoute() const;
    /** @brief Émissions de contrôle AODV, exclues du plan de données. */
    uint64_t GetSkippedControlPlane() const;
    /** @brief Émissions vers une adresse diffusée ou multicast. */
    uint64_t GetSkippedNonUnicast() const;
    /** @brief Total des émissions IPv4 examinées par l'observateur. */
    uint64_t GetTransmissionsInspected() const;

    // ---- Fiabilité de lien (x_k, Éq. 6-7) ----
    /** @brief Issues MAC enregistrées vers un voisin unicast, succès + échecs. */
    uint64_t GetLinkOutcomesRecorded() const;
    /** @brief Issues comptées comme SUCCÈS (MPDU acquitté). */
    uint64_t GetLinkSuccesses() const;
    /**
     * @brief Issues comptées comme ÉCHEC.
     *
     * Séparé des succès parce qu'un total seul masquerait une instrumentation
     * borgne : si le chemin d'échec n'est jamais emprunté, la fiabilité vaut
     * structurellement 1 et ne mesure plus rien. C'est exactement ce qui s'est
     * produit lorsque seule `AckedMpdu` était branchée — en 802.11b une émission
     * qui épuise ses retransmissions part dans `DroppedMpdu`, pas dans
     * `NAckedMpdu`, qui ne concerne que les NACK de *block ack*.
     */
    uint64_t GetLinkFailures() const;

    /**
     * @brief Cette raison de rejet MAC est-elle une défaillance de LIEN ?
     * @param reason Raison fournie par la trace `DroppedMpdu`.
     * @return Vrai pour l'épuisement des retransmissions, faux sinon.
     *
     * Seul `WIFI_MAC_DROP_REACHED_RETRY_LIMIT` atteste que le pair n'a pas
     * répondu malgré les retransmissions. `FAILED_ENQUEUE` et
     * `EXPIRED_LIFETIME` décrivent la **congestion locale de \c i** : les
     * inclure ferait de `linkReliability` une mesure de congestion déguisée,
     * portant deux phénomènes distincts sous un seul nom.
     *
     * Statique et publique pour être testable sans simulation.
     */
    static bool IsLinkFailureReason(WifiMacDropReason reason);

    /** @brief Rejets MAC observés, ventilés par raison (aucun n'est supposé nul). */
    uint64_t GetMacDropsRetryLimit() const;
    /** @brief Rejets pour file pleine : congestion LOCALE, pas défaillance de lien. */
    uint64_t GetMacDropsFailedEnqueue() const;
    /** @brief Rejets pour expiration en file : congestion LOCALE. */
    uint64_t GetMacDropsExpiredLifetime() const;
    /** @brief Rejets pour toute autre raison. */
    uint64_t GetMacDropsOther() const;

    /**
     * @brief Fenêtres où la fiabilité a CHANGÉ entre ouverture et clôture.
     *
     * Mesure directe de la fuite temporelle que le gel supprime. Une valeur
     * non nulle prouve que calculer \f$x_{link}\f$ à la clôture aurait fait
     * entrer, dans la caractéristique, des informations postérieures à
     * l'ouverture — dont l'issue de l'événement lui-même.
     */
    uint64_t GetLinkReliabilityChangedDuringWindow() const;

    /**
     * @brief Enregistre une issue MAC vers un pair. PUBLIQUE pour être testable.
     * @param peer MAC du destinataire ; les adresses de groupe sont ignorées.
     * @param success Vrai si le MPDU a été acquitté.
     *
     * Exposée pour la même raison qu'OpenWindow() : l'arithmétique de la
     * fenêtre glissante doit être vérifiable sans simulation. Une assertion
     * portée par une simulation aux liens parfaits ne peut pas échouer, et une
     * assertion qui ne peut pas échouer est pire que pas d'assertion.
     */
    void RecordLinkOutcome(const Mac48Address& peer, bool success);

    /**
     * @brief Fenêtres pour lesquelles \f$a_l = 1\f$ (diagnostic évaluable).
     *
     * Une issue MAC vers `j` au moins a été observée pendant la fenêtre, la MAC
     * de `j` étant connue à l'ouverture. C'est la couverture diagnostique
     * \f$d_e > 0\f$ de l'Éq. (8) — sans elle, A3.3 renvoie \f$(0,0,0,1)\f$.
     */
    uint64_t GetWindowsWithLinkOutcome() const;

    /**
     * @brief Fenêtres pour lesquelles \f$y_l = 1\f$ (cause bénigne constatée).
     * @note À rapporter TOUJOURS avec GetWindowsWithLinkOutcome(). Seul, ce
     *       compteur ne dit pas si un zéro signifie « aucune cause bénigne »
     *       ou « diagnostic jamais évalué ».
     */
    uint64_t GetWindowsWithLinkFailure() const;

    /**
     * @brief Fenêtres ouvertes alors que la MAC de `j` était inconnue.
     *
     * Cause n°1 d'indisponibilité du diagnostic. Rapportée séparément de
     * « aucune issue observée », qui a une signification différente.
     */
    uint64_t GetWindowsPeerMacUnknownAtOpen() const;

    /**
     * @brief Fenêtres ayant vu PLUSIEURS issues MAC vers `j`.
     *
     * MESURE DE L'AMBIGUÏTÉ d'attribution. L'attribution est par PAIR, non par
     * PAQUET : au-delà d'une issue, on ne sait plus laquelle concernait le
     * paquet suivi. Ce compteur borne l'erreur au lieu de la supposer nulle —
     * s'il est élevé, l'attribution par paquet devient nécessaire.
     */
    uint64_t GetWindowsMultipleLinkOutcomes() const;

    /**
     * @brief Fiabilité récente du lien vers un pair MAC. PUBLIQUE pour les tests.
     * @param peer MAC du pair.
     * @param reliability Reçoit la fraction d'ACK sur les issues connues.
     * @return Faux si l'historique est trop court : INDISPONIBLE, jamais une
     *         valeur par défaut.
     */
    bool TryGetLinkReliabilityForPeer(const Mac48Address& peer, double& reliability) const;
    /** @brief Clôtures où `linkReliability` était disponible. */
    uint64_t GetLinkReliabilityAvailableCount() const;

    /**
     * @brief Signature de la TraceSource émise à chaque fenêtre close.
     * @param observation Événement clos, sans aucune masse ni étiquette.
     */
    typedef void (*ObservationClosedTracedCallback)(
        const ForwardingObservation& observation);

  protected:
    void DoDispose() override;

  private:
    /**
     * @brief Historique borné des issues MAC vers UN voisin.
     *
     * Mémoire O(1) par voisin : les 32 dernières issues tiennent dans un mot,
     * le bit de poids faible étant la plus récente. Aucune allocation, aucune
     * croissance — la contrainte « structures bornées » est satisfaite par
     * construction et non par un élagage périodique qu'on pourrait oublier.
     */
    struct LinkHistory
    {
        uint32_t outcomes{0}; //!< Bit à 1 = ACK reçu, bit à 0 = pas d'ACK.
        uint8_t samples{0};   //!< Nombre d'issues connues, plafonné à 32.
    };

    /** @brief Une fenêtre ouverte, en attente d'appariement ou d'échéance. */
    struct OpenWindowRecord
    {
        Ipv4Address nextHop;      //!< Voisin `j` auquel le paquet a été remis.
        double openTimeSeconds;   //!< Instant d'ouverture, en secondes.
        uint32_t sourceAddress;   //!< Conservé pour détecter les collisions.
        uint32_t destinationAddress; //!< Idem.
        uint16_t identification;  //!< Idem.

        /**
         * @brief \f$\hat R_{ij}(t_e^-)\f$ : fiabilité GELÉE à l'ouverture.
         *
         * Capturée ici, et jamais recalculée, pour que la caractéristique
         * d'opportunité ne puisse pas incorporer l'issue de l'événement
         * qu'elle sert à interpréter.
         */
        double linkReliabilityAtOpen{0.0};
        bool linkReliabilityAvailableAtOpen{false};

        /**
         * @brief MAC de `j`, résolue et GELÉE à l'ouverture.
         *
         * Les issues MAC arrivent indexées par adresse MAC ; les fenêtres sont
         * indexées par empreinte et connaissent `j` par son IPv4. Ce champ est
         * le pont, et il est figé à l'ouverture pour la même raison que la
         * fiabilité : apprendre la correspondance EN COURS de fenêtre ferait
         * dépendre la DISPONIBILITÉ du diagnostic d'un fait postérieur à
         * l'ouverture.
         */
        Mac48Address peerMacAtOpen;
        bool peerMacKnownAtOpen{false}; //!< La MAC de `j` était-elle connue ?

        /** @brief Issues MAC vers `j` observées depuis l'ouverture. */
        uint16_t linkOutcomesDuringWindow{0};

        /** @brief Parmi elles, combien étaient des ÉCHECS (retry limit). */
        uint16_t linkFailuresDuringWindow{0};
    };

    /**
     * @brief Un MPDU émis par ce nœud a été acquitté par son destinataire.
     * @param mpdu MPDU concerné ; `GetHeader().GetAddr1()` porte la MAC du pair.
     *
     * Trace `AckedMpdu` de `ns3::WifiMac`. Mesure ACTIVE du lien `i -> j`,
     * la seule dont dispose `i` : l'écoute passive ne permet pas de distinguer
     * « `j` est inaudible » de « `j` est silencieux ».
     */
    void OnMpduAcked(Ptr<const WifiMpdu> mpdu);

    /**
     * @brief Un MPDU émis par ce nœud a été rejeté par la couche MAC.
     * @param reason Raison du rejet.
     * @param mpdu MPDU concerné.
     *
     * Trace `DroppedMpdu` de `ns3::WifiMac`. NÉCESSAIRE : en 802.11b avec ACK
     * normal, une émission qui épuise ses retransmissions arrive ICI et non
     * dans `NAckedMpdu`, qui ne concerne que les NACK de *block ack*. Sans ce
     * branchement, seuls les succès étaient comptés et la fiabilité valait
     * structurellement 1 — mesuré : 23 284 succès, 0 échec sur le run réel.
     */
    void OnMpduDropped(WifiMacDropReason reason, Ptr<const WifiMpdu> mpdu);

    /**
     * @brief Un MPDU émis par ce nœud n'a PAS été acquitté.
     * @param mpdu MPDU concerné.
     *
     * Trace `NAckedMpdu` de `ns3::WifiMac`.
     */
    void OnMpduNacked(Ptr<const WifiMpdu> mpdu);

    /**
     * @brief Fiabilité récente du lien vers `neighbor`, si elle est connue.
     * @param neighbor Adresse IPv4 du voisin surveillé.
     * @param reliability Reçoit la fraction d'ACK sur les issues connues.
     * @return Vrai si assez d'issues sont connues pour que la valeur ait un sens.
     *
     * Renvoie faux plutôt qu'une valeur par défaut quand l'historique est trop
     * court : `available = 0` avoue une ignorance et ne fait que réduire la
     * couverture `c_e`, alors qu'une valeur nulle déclarée disponible opposerait
     * un VETO dans l'Éq. (7), où `0^(w/c) = 0` quel que soit le poids.
     */
    bool TryGetLinkReliability(Ipv4Address neighbor, double& reliability) const;

    /**
     * @brief Rappel promiscuité : le cœur de l'observation.
     * @param device Interface réceptrice.
     * @param packet Trame reçue, en-tête LLC déjà retiré.
     * @param protocol EtherType.
     * @param from MAC de l'émetteur du saut courant.
     * @param to MAC destinataire.
     * @param packetType Classification ns-3.
     * @return Toujours false — l'observateur n'intercepte rien.
     */
    bool OnPromiscuousReceive(Ptr<NetDevice> device,
                              Ptr<const Packet> packet,
                              uint16_t protocol,
                              const Address& from,
                              const Address& to,
                              NetDevice::PacketType packetType);

    /**
     * @brief Une trame IPv4 vient d'être émise par ce nœud (source OU relais).
     * @param header En-tête IPv4 complet, tel que la couche 3 l'a construit.
     * @param packet Paquet sans son en-tête IPv4.
     * @param interface Index de l'interface sortante.
     *
     * POURQUOI CE POINT D'ACCROCHE, ET PAS LE PROTOCOLE DE ROUTAGE
     * ------------------------------------------------------------
     * Une première version accrochait `RoutingProtocol::Forwarding()`. C'était
     * faux : `Forwarding()` ne traite que le trafic EN TRANSIT, donc une source
     * ne l'appelle jamais pour ses propres paquets. Sur un chemin à deux sauts
     * — le cas dominant du scénario gelé, mesuré à 1,73 saut — cela accrochait
     * exactement le mauvais bout :
     *
     *   SOURCE → RELAIS → DESTINATION
     *     la SOURCE peut entendre le RELAIS retransmettre   → observable
     *     le RELAIS remet à la DESTINATION, qui CONSOMME    → rien à observer
     *
     * L'ancien accrochage n'ouvrait de fenêtre que chez le relais, c'est-à-dire
     * dans le seul cas sans rien à voir, et manquait le seul cas observable.
     * Toute clôture honnête serait devenue une non-observation.
     *
     * Les TraceSources `SendOutgoing` et `UnicastForward` d'`Ipv4L3Protocol`
     * couvrent les deux cas uniformément et fournissent l'en-tête COMPLET —
     * `RouteOutput()` ne le pourrait pas, le champ d'identification n'y étant
     * pas encore assigné, ce qui aurait rendu toute empreinte incomparable.
     */
    void OnIpv4Transmit(const Ipv4Header& header,
                        Ptr<const Packet> packet,
                        uint32_t interface);

    /** @brief Ferme toutes les fenêtres dont l'échéance est dépassée. */
    void SweepExpiredWindows();

    /** @brief Programme le prochain balayage périodique. */
    void ScheduleNextSweep();

    /**
     * @brief Clôt une fenêtre et émet la TraceSource.
     * @param fingerprint Empreinte de la fenêtre.
     * @param record Enregistrement à clore.
     * @param reason Raison de clôture.
     * @param observedSenderMac MAC appariée, si la clôture est un appariement.
     */
    void CloseWindow(uint64_t fingerprint,
                     const OpenWindowRecord& record,
                     ForwardingClosureReason reason,
                     const Address& observedSenderMac);

    /** @brief Enregistre passivement une correspondance MAC -> IPv4. */
    void LearnAddressMapping(const Address& mac, Ipv4Address ipv4);

    /** @brief Nœud observateur ; non possédé. */
    Ptr<Node> m_node;

    /** @brief Identifiant du nœud, mémorisé pour les traces. */
    uint32_t m_observerNodeId{0};

    /** @brief Interrupteur d'observation. */
    bool m_enabled{true};

    /** @brief Durée de la fenêtre d'observation. */
    Time m_observationWindow;

    /** @brief Période du balayage des échéances. */
    Time m_sweepInterval;

    /** @brief Borne dure sur les fenêtres actives. */
    uint32_t m_maxActiveWindows{256};

    /** @brief Borne dure sur la table MAC -> IPv4 apprise. */
    uint32_t m_maxLearnedAddresses{256};

    /**
     * @brief Port UDP du plan de contrôle AODV, exclu de l'observation.
     *
     * Un Blackhole complet DOIT relayer le contrôle pour rester attractif :
     * inclure ces paquets diluerait le signal du plan de données avec des
     * transferts que même un attaquant effectue fidèlement.
     */
    uint16_t m_controlPlanePort{654};

    /** @brief Protocole de routage, consulté pour le prochain saut uniquement. */
    Ptr<RoutingProtocol> m_routing;

    /** @brief Fenêtres ouvertes, indexées par empreinte. */
    std::map<uint64_t, OpenWindowRecord> m_openWindows;

    /** @brief Correspondances MAC -> IPv4 apprises passivement. */
    std::map<Address, Ipv4Address> m_learnedAddresses;

    /**
     * @brief Dernier instant où chaque voisin a été entendu. Unité : s.
     *
     * Alimente `passiveVisibility` : un silence alors que le voisin est audible
     * par ailleurs n'a pas la même signification qu'un silence total. C'est la
     * seule caractéristique d'opportunité que STEP 3 mesure réellement.
     */
    std::map<Ipv4Address, double> m_lastHeardFromNeighbor;

    /**
     * @brief Correspondance IPv4 -> MAC, l'inverse de `m_learnedAddresses`.
     *
     * Les issues MAC arrivent indexées par adresse MAC, alors qu'une fenêtre est
     * indexée par l'IPv4 du prochain saut. Sans cette table, relier les deux
     * exigerait un balayage linéaire à chaque clôture.
     */
    std::map<Ipv4Address, Mac48Address> m_neighborMac;

    /**
     * @brief Historique borné des issues MAC, par voisin.
     *
     * Alimente `linkReliability`. Plafonné par `m_maxLearnedAddresses`, comme
     * les autres tables apprises : aucune structure de l'observateur ne croît
     * avec la durée de la simulation.
     */
    std::map<Mac48Address, LinkHistory> m_linkHistory;

    /**
     * @brief Nombre minimal d'issues avant que la fiabilité ait un sens.
     *
     * En deçà, la caractéristique est déclarée INDISPONIBLE. Publier une
     * fraction calculée sur une ou deux émissions donnerait une valeur extrême
     * (0 ou 1) sur presque rien — et une valeur nulle DISPONIBLE est un veto
     * dans l'Éq. (7).
     */
    uint32_t m_linkReliabilityMinSamples{4};

    /** @brief Événement du balayage périodique. */
    EventId m_sweepEvent;

    // ---- Compteurs ----
    uint64_t m_windowsOpened{0};
    uint64_t m_windowsMatched{0};
    uint64_t m_windowsDeadline{0};
    uint64_t m_windowsEvicted{0};
    uint64_t m_fingerprintCollisions{0};

    /** @brief \f$a_l = 1\f$ : le diagnostic de lien était évaluable. */
    uint64_t m_windowsWithLinkOutcome{0};
    /** @brief \f$y_l = 1\f$ : une cause bénigne a été constatée. */
    uint64_t m_windowsWithLinkFailure{0};
    /** @brief MAC de `j` inconnue à l'ouverture : diagnostic indisponible. */
    uint64_t m_windowsPeerMacUnknownAtOpen{0};
    /** @brief Plusieurs issues vers `j` : attribution ambiguë, MESURÉE. */
    uint64_t m_windowsMultipleLinkOutcomes{0};
    uint64_t m_fragmentedPacketsExcluded{0};
    uint64_t m_promiscuousFramesInspected{0};
    uint64_t m_transmissionsInspected{0};
    uint64_t m_skippedLastHop{0};
    uint64_t m_skippedNoRoute{0};
    uint64_t m_skippedControlPlane{0};
    uint64_t m_skippedNonUnicast{0};
    uint64_t m_linkOutcomesRecorded{0};
    uint64_t m_linkSuccesses{0};
    uint64_t m_linkFailures{0};
    uint64_t m_macDropsRetryLimit{0};
    uint64_t m_macDropsFailedEnqueue{0};
    uint64_t m_macDropsExpiredLifetime{0};
    uint64_t m_macDropsOther{0};
    uint64_t m_linkReliabilityChangedDuringWindow{0};
    uint64_t m_linkReliabilityAvailableCount{0};

    /** @brief Émise à chaque fenêtre close ; entrée de l'attribution STEP 4. */
    TracedCallback<const ForwardingObservation&> m_observationClosedTrace;
};

} // namespace mtcaodv
} // namespace ns3

#endif // MTCAODV_FORWARDING_OBSERVER_H
