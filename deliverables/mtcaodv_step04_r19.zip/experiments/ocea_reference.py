#!/usr/bin/env python3
# MTCAODV_DELIVERY_REVISION: r19
# SPDX-License-Identifier: GPL-2.0-only
"""Implementation de reference INDEPENDANTE de l'algorithme A3.3 (Eq. 6-10).

POURQUOI CE FICHIER EXISTE
--------------------------
Un test qui compare le code C++ a lui-meme ne verifie rien.  Les valeurs
attendues du fichier `contrib/mtcaodv/test/ocea-attribution-test-suite.cc` ont
ete produites ICI, en Python, AVANT tout encodage C++, et chacune est
verifiable a la main (voir la colonne « calcul » du tableau imprime par
`--oracles`).  Meme discipline qu'aux Eq. (3)-(5) du STEP 2 et qu'a l'empreinte
de paquet du STEP 3.

Ce module n'est PAS une traduction du C++ : il a ete ecrit en premier.  Si les
deux divergent un jour, c'est une divergence a instruire, pas a arbitrer en
faveur du C++.

LES EQUATIONS, TELLES QUE SPECIFIEES
------------------------------------
  (6)  c_e     = sum_k  w_k a_k(e)                        couverture d'opportunite
  (7)  O_e     = c_e * prod_k x_k(e)^(w_k a_k(e) / c_e)   opportunite de relais
  (8)  d_e     = sum_l  v_l a_l(e)                        couverture diagnostique
       B_e     = sum_l  v_l a_l(e) y_l(e) / d_e           vraisemblance benigne
  (9)  z_e = 1 -> (g,m,b,u) = (1,0,0,0)
  (10) I_e     = clip(O_e * d_e, 0, 1)
       (g,m,b,u) = (0, I_e (1 - B_e), I_e B_e, 1 - I_e)

ALGORITHME A3.3, BRANCHES FAIL-CLOSED
-------------------------------------
  ligne 2 : z_e = 1   -> (1,0,0,0)   sortie immediate, avant toute couverture
  ligne 4 : c_e = 0   -> (0,0,0,1)   aucune caracteristique disponible
  ligne 7 : d_e = 0   -> (0,0,0,1)   aucun diagnostic disponible
  ligne 9 : I_e = clip(O_e d_e, 0, 1)
  l. 13-14: assertions — masses dans [0,1], somme = 1
"""

from __future__ import annotations

import argparse
import math
import sys
from dataclasses import dataclass
from typing import Sequence

#: Tolerance de conservation.  Le calcul enchaine un exp/log et deux produits ;
#: 1e-12 est trois ordres de grandeur au-dessus de l'erreur attendue et trois
#: ordres en dessous de toute erreur de modelisation qui compterait.
CONSERVATION_TOLERANCE = 1e-12

#: Tolerance sur la somme des poids.  Voir `validate_weights`.
WEIGHT_SUM_TOLERANCE = 1e-9


@dataclass(frozen=True)
class Feature:
    """Un triplet (poids, valeur, disponibilite) — une entree des Eq. (6)-(8).

    :param weight: w_k (opportunite) ou v_l (diagnostic).  Doit etre >= 0.
    :param value:  x_k(e) ou y_l(e), dans [0,1].  N'a de sens que si disponible.
    :param available: a_k(e) ou a_l(e).  Faux = la grandeur n'a PAS ete
        observee.  `available=False` et `value=0.0` ne sont PAS interchangeables :
        le premier retire la caracteristique de la couverture, le second est un
        veto absolu dans l'Eq. (7).  Confondre les deux est la faute que l'Eq. (6)
        existe pour empecher.
    """

    weight: float
    value: float = 0.0
    available: bool = False

    @property
    def mass(self) -> float:
        """Poids effectif w_k a_k — zero si indisponible."""
        return self.weight if self.available else 0.0


@dataclass(frozen=True)
class Attribution:
    """Sortie complete d'A3.3 : les quatre masses et tous les intermediaires."""

    positive: float          # g_e
    malicious: float         # m_e
    benign_loss: float       # b_e
    uncertain: float         # u_e
    opportunity_coverage: float   # c_e, Eq. (6)
    forwarding_opportunity: float # O_e, Eq. (7)
    diagnostic_coverage: float    # d_e, Eq. (8)
    benign_likelihood: float      # B_e, Eq. (8)
    interpretable: float          # I_e, Eq. (10)
    vetoed: bool                  # une caracteristique disponible valait 0
    inputs_valid: bool            # garde d'implementation, voir validate_*
    computed: bool                # les intermediaires c_e, O_e, d_e sont-ils CALCULES ?

    @property
    def masses(self) -> tuple[float, float, float, float]:
        return (self.positive, self.malicious, self.benign_loss, self.uncertain)


def masses_are_conserved(attribution: "Attribution") -> bool:
    """Les quatre masses sont-elles dans [0,1] et de somme 1 ?

    A3.3 se termine par deux assertions (lignes 13-14). Elles sont exposees ici
    comme un PREDICAT, pendant exact de `OceaMassesAreConserved` en C++, pour
    qu'un echec puisse etre COMPTE par un exportateur au lieu d'avorter une
    campagne — et pour qu'il ne disparaisse pas sous `python -O`.
    """
    for value in attribution.masses:
        if not math.isfinite(value):
            return False
        if value < -CONSERVATION_TOLERANCE or value > 1.0 + CONSERVATION_TOLERANCE:
            return False
    return abs(math.fsum(attribution.masses) - 1.0) <= CONSERVATION_TOLERANCE


def _uncertain() -> tuple[float, float, float, float]:
    """La sortie fail-closed : toute la masse sur l'incertitude."""
    return (0.0, 0.0, 0.0, 1.0)


def validate_weights(features: Sequence[Feature]) -> bool:
    """Les poids forment-ils une partition de l'unite ?

    PRECONDITION NORMATIVE, pas un detail : l'Eq. (7) borne O_e par c_e, et
    c_e <= sum_k w_k.  Si les poids ne sommaient pas a 1, un evenement de
    couverture complete pourrait donner O_e > 1, donc I_e > 1, donc une masse
    negative apres `1 - I_e`.  La ligne 9 d'A3.3 « clip » masquerait le defaut
    au lieu de le signaler.  On refuse en amont.

    Un ensemble vide est refuse : il n'exprime pas « rien de disponible »
    (c'est le role de `available=False`) mais « le modele n'a pas de
    caracteristiques », ce qui est une erreur de configuration.
    """
    if not features:
        return False
    total = 0.0
    for f in features:
        if not math.isfinite(f.weight) or f.weight < 0.0:
            return False
        total += f.weight
    return abs(total - 1.0) <= WEIGHT_SUM_TOLERANCE


def validate_values(features: Sequence[Feature]) -> bool:
    """Les valeurs DISPONIBLES sont-elles dans [0,1] et finies ?

    Une valeur indisponible n'est pas examinee : elle n'entre dans aucune
    somme ni dans aucun produit, et exiger qu'elle soit propre reviendrait a
    lui preter un sens qu'elle n'a pas.
    """
    for f in features:
        if not f.available:
            continue
        if not math.isfinite(f.value) or f.value < 0.0 or f.value > 1.0:
            return False
    return True


def attribute(
    forwarding_observed: bool,
    opportunity: Sequence[Feature],
    diagnostic: Sequence[Feature],
) -> Attribution:
    """Algorithme A3.3 — attribution d'un evenement d'observation en 4 masses.

    :param forwarding_observed: z_e, le fait observe par A3.2.
    :param opportunity: les x_k avec leurs w_k.
    :param diagnostic: les y_l avec leurs v_l.
    :return: :class:`Attribution`.
    """
    # --- Garde d'implementation (hors A3.3), direction fail-closed. ---
    # A3.3 suppose ses entrees propres.  Les accepter sans controle laisserait
    # un x_k = 1.5 produire une masse negative en silence.  On refuse, et on
    # marque le refus pour qu'il soit COMPTE, jamais confondu avec un evenement
    # legitimement incertain.
    inputs_valid = (
        validate_weights(opportunity)
        and validate_weights(diagnostic)
        and validate_values(opportunity)
        and validate_values(diagnostic)
    )
    if not inputs_valid:
        g, m, b, u = _uncertain()
        return Attribution(g, m, b, u, 0.0, 0.0, 0.0, 0.0, 0.0, False, False, False)

    # --- A3.3 ligne 2 : z_e = 1 -> (1,0,0,0). ---
    # Sortie AVANT toute couverture : une retransmission observee est une
    # preuve positive, qu'on ait su ou non pourquoi elle etait possible.
    # (Finding herite du STEP 3 : 18,9 % des z_e = 1 d'attaquant venaient d'un
    # tiers.  L'ecart est rapporte separement, il n'est PAS corrige ici.)
    if forwarding_observed:
        return Attribution(1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, False, True, False)

    # --- Eq. (6) : c_e = sum_k w_k a_k. ---
    coverage = math.fsum(f.mass for f in opportunity)

    # --- A3.3 ligne 4 : c_e = 0 -> (0,0,0,1). ---
    if coverage <= 0.0:
        g, m, b, u = _uncertain()
        return Attribution(g, m, b, u, 0.0, 0.0, 0.0, 0.0, 0.0, False, True, True)

    # --- Eq. (7) : O_e = c_e * prod x_k^(w_k a_k / c_e). ---
    # Le cas x_k = 0 est traite AVANT tout appel a log(), conformement a
    # l'arbitrage utilisateur sur epsilon : un zero reellement disponible est
    # une information (« observer etait impossible »), pas une singularite a
    # masquer par un plancher arbitraire.
    #
    # REGLE D'IMPLEMENTATION (statut : Propose).  Une caracteristique de poids
    # w_k = 0 est exclue du produit comme elle l'est de la somme (6).  Sans
    # cela, un poids nul disponible valant 0 donnerait pow(0,0) = 1 en IEEE-754,
    # soit une non-contribution — mais un x_k = 0 de poids 0,0001 vetoerait.
    # La discontinuite serait arbitraire.  Le critere retenu est w_k a_k > 0.
    vetoed = any(f.mass > 0.0 and f.value == 0.0 for f in opportunity)
    if vetoed:
        opportunity_value = 0.0
    else:
        log_sum = math.fsum(
            (f.mass / coverage) * math.log(f.value) for f in opportunity if f.mass > 0.0
        )
        opportunity_value = coverage * math.exp(log_sum)

    # --- Eq. (8) : d_e = sum_l v_l a_l, puis B_e. ---
    diagnostic_coverage = math.fsum(f.mass for f in diagnostic)

    # --- A3.3 ligne 7 : d_e = 0 -> (0,0,0,1). ---
    # Sans aucun diagnostic, on ne peut pas distinguer « perdu par le canal »
    # de « supprime deliberement ».  L'incertitude totale est la reponse
    # honnete, et c'est la branche que l'etat actuel de l'instrumentation
    # emprunte pour TOUS les evenements.
    if diagnostic_coverage <= 0.0:
        g, m, b, u = _uncertain()
        return Attribution(
            g, m, b, u, coverage, opportunity_value, 0.0, 0.0, 0.0, vetoed, True, True
        )

    benign = (
        math.fsum(f.mass * f.value for f in diagnostic) / diagnostic_coverage
    )

    # --- Eq. (10) + A3.3 ligne 9. ---
    interpretable = min(1.0, max(0.0, opportunity_value * diagnostic_coverage))
    masses = (
        0.0,
        interpretable * (1.0 - benign),
        interpretable * benign,
        1.0 - interpretable,
    )

    # --- A3.3 lignes 13-14 : assertions. ---
    for value in masses:
        assert -CONSERVATION_TOLERANCE <= value <= 1.0 + CONSERVATION_TOLERANCE, masses
    assert abs(math.fsum(masses) - 1.0) <= CONSERVATION_TOLERANCE, masses

    return Attribution(
        masses[0],
        masses[1],
        masses[2],
        masses[3],
        coverage,
        opportunity_value,
        diagnostic_coverage,
        benign,
        interpretable,
        vetoed,
        True,
        True,
    )


# ---------------------------------------------------------------------------
# Oracles — calcules ici, transcrits dans le test C++.
# ---------------------------------------------------------------------------

def _half(value: float, available: bool = True) -> Feature:
    return Feature(weight=0.5, value=value, available=available)


#: Chaque entree : (nom, z_e, opportunite, diagnostic, calcul a la main).
ORACLES = [
    (
        "z=1 : preuve positive, Eq. (9)",
        True,
        [_half(0.81), _half(0.49)],
        [_half(0.25), _half(0.75)],
        "ligne 2, sortie immediate",
    ),
    (
        "c=0 : aucune caracteristique disponible",
        False,
        [_half(0.81, False), _half(0.49, False)],
        [_half(0.25), _half(0.75)],
        "ligne 4",
    ),
    (
        "d=0 : aucun diagnostic disponible",
        False,
        [_half(1.0), _half(0.25, False)],
        [_half(0.25, False), _half(0.75, False)],
        "c=0,5 ; O=0,5*1^1=0,5 ; ligne 7",
    ),
    (
        "veto : x_k = 0 DISPONIBLE",
        False,
        [_half(0.0), _half(0.49)],
        [_half(0.25), _half(0.75)],
        "O=0 -> I=0 -> (0,0,0,1) sans branche dediee",
    ),
    (
        "nominal : deux x, deux y",
        False,
        [_half(0.81), _half(0.49)],
        [_half(0.25), _half(0.75)],
        "O=sqrt(0,81*0,49)=0,9*0,7=0,63 ; B=0,5 ; I=0,63",
    ),
    (
        "une seule x disponible, poids 0,4",
        False,
        [Feature(0.4, 0.6, True), Feature(0.6, 0.9, False)],
        [_half(1.0), _half(1.0)],
        "c=0,4 ; O=0,4*0,6^(0,4/0,4)=0,24 ; B=1 ; I=0,24",
    ),
    (
        "B=1 : cause benigne certaine",
        False,
        [_half(1.0), _half(1.0)],
        [_half(1.0), _half(1.0)],
        "O=1 ; d=1 ; I=1 ; toute la masse en perte benigne",
    ),
    (
        "B=0 : aucune cause benigne",
        False,
        [_half(1.0), _half(1.0)],
        [_half(0.0), _half(0.0)],
        "O=1 ; d=1 ; I=1 ; toute la masse en malveillance",
    ),
]


def print_oracles() -> None:
    header = f"{'cas':44s} {'c_e':>7s} {'O_e':>7s} {'d_e':>7s} {'B_e':>7s} {'I_e':>7s}   (g, m, b, u)"
    print(header)
    print("-" * len(header))
    for name, z, opp, diag, note in ORACLES:
        a = attribute(z, opp, diag)
        masses = " ".join(f"{v:.15f}" for v in a.masses)
        print(
            f"{name:44s} {a.opportunity_coverage:7.4f} {a.forwarding_opportunity:7.4f} "
            f"{a.diagnostic_coverage:7.4f} {a.benign_likelihood:7.4f} {a.interpretable:7.4f}   ({masses})"
        )
        print(f"{'':44s} calcul : {note}")
        total = math.fsum(a.masses)
        assert abs(total - 1.0) <= CONSERVATION_TOLERANCE, (name, total)
    print()
    print(f"conservation verifiee sur {len(ORACLES)} oracles, tolerance {CONSERVATION_TOLERANCE:g}")


def print_machine() -> None:
    """Sortie comparable octet a octet avec le pilote C++ `ocea_crosscheck.cc`.

    Un point-virgule separe les champs, `%.17g` garantit un aller-retour exact
    du double.  Format volontairement pauvre : il doit se comparer par `diff`,
    sans tolerance implicite ni bibliotheque tierce.
    """
    for name, z, opp, diag, _note in ORACLES:
        a = attribute(z, opp, diag)
        fields = (
            a.opportunity_coverage,
            a.forwarding_opportunity,
            a.diagnostic_coverage,
            a.benign_likelihood,
            a.interpretable,
            a.positive,
            a.malicious,
            a.benign_loss,
            a.uncertain,
        )
        print(name + ";" + ";".join(f"{v:.17g}" for v in fields)
              + f";{int(a.vetoed)};{int(a.inputs_valid)};{int(a.computed)}")


#: Noms des champs de la ligne machine, dans l'ordre d'emission.
MACHINE_NUMERIC_FIELDS = (
    "c_e", "O_e", "d_e", "B_e", "I_e", "g_e", "m_e", "b_e", "u_e",
)
MACHINE_FLAG_FIELDS = ("vetoed", "inputs_valid", "computed")


def _machine_rows() -> dict[str, list[str]]:
    rows = {}
    for name, z, opp, diag, _note in ORACLES:
        a = attribute(z, opp, diag)
        rows[name] = [
            f"{v:.17g}"
            for v in (
                a.opportunity_coverage,
                a.forwarding_opportunity,
                a.diagnostic_coverage,
                a.benign_likelihood,
                a.interpretable,
                a.positive,
                a.malicious,
                a.benign_loss,
                a.uncertain,
            )
        ] + [str(int(a.vetoed)), str(int(a.inputs_valid)), str(int(a.computed))]
    return rows


def compare(path: str, tolerance: float = 1e-12) -> int:
    """Compare la sortie du pilote C++ a cette reference, champ par champ.

    La comparaison est NUMERIQUE et non textuelle : deux `libm` differentes
    peuvent differer d'un ulp sur `exp`/`log` sans qu'aucune soit fausse.  Un
    `diff` brut transformerait cette difference legitime en echec, et un echec
    qui se declenche pour de mauvaises raisons finit par etre ignore.

    :param path: fichier produit par `ocea_crosscheck`.
    :param tolerance: ecart absolu tolere sur chaque champ numerique.
    :return: 0 si tout concorde, 1 sinon.
    """
    expected = _machine_rows()
    seen = set()
    failures = []
    worst = 0.0
    worst_where = "-"

    with open(path, encoding="utf-8") as handle:
        for lineno, line in enumerate(handle, start=1):
            line = line.rstrip("\n")
            if not line.strip():
                continue
            fields = line.split(";")
            name = fields[0]
            if name not in expected:
                failures.append(f"ligne {lineno} : cas inconnu de la reference : {name!r}")
                continue
            seen.add(name)
            want = expected[name]
            if len(fields) - 1 != len(want):
                failures.append(
                    f"{name} : {len(fields) - 1} champs recus, {len(want)} attendus"
                )
                continue
            for index, label in enumerate(MACHINE_NUMERIC_FIELDS):
                got = float(fields[1 + index])
                ref = float(want[index])
                delta = abs(got - ref)
                if delta > worst:
                    worst, worst_where = delta, f"{name}/{label}"
                if delta > tolerance:
                    failures.append(
                        f"{name} : {label} = {got!r}, reference {ref!r}, ecart {delta:.3g}"
                    )
            offset = len(MACHINE_NUMERIC_FIELDS)
            for index, label in enumerate(MACHINE_FLAG_FIELDS):
                got = fields[1 + offset + index]
                ref = want[offset + index]
                if got != ref:
                    failures.append(f"{name} : {label} = {got}, reference {ref}")

    # Un fichier tronque doit ECHOUER, pas passer en silence : c'est le mode de
    # panne le plus probable (pilote qui plante apres deux lignes).
    missing = sorted(set(expected) - seen)
    for name in missing:
        failures.append(f"cas absent de la sortie C++ : {name!r}")

    for message in failures:
        print("ECHEC : " + message)
    if failures:
        print(f"{len(failures)} desaccord(s) entre C++ et la reference Python")
        return 1
    print(
        f"{len(expected)} oracles concordants ; ecart maximal {worst:.3g} "
        f"({worst_where}), tolerance {tolerance:g}"
    )
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument(
        "--oracles",
        action="store_true",
        help="imprime le tableau des oracles transcrits dans le test C++",
    )
    parser.add_argument(
        "--compare",
        metavar="FICHIER",
        help="compare la sortie du pilote C++ (ocea_crosscheck) a cette reference",
    )
    parser.add_argument(
        "--tolerance",
        type=float,
        default=1e-12,
        help="ecart absolu tolere par --compare (defaut : 1e-12)",
    )
    parser.add_argument(
        "--machine",
        action="store_true",
        help="sortie comparable par diff avec le pilote C++ (contre-controle)",
    )
    args = parser.parse_args(argv)
    if args.compare:
        return compare(args.compare, args.tolerance)
    if args.machine:
        print_machine()
        return 0
    if args.oracles:
        print_oracles()
        return 0
    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
