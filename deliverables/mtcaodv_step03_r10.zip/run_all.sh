#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# MTC-AODV — sequence complete : construction, tests, execution, validation.
#
# Usage :  bash run_all.sh [racine-ns3]        (defaut : repertoire courant)
#
# Le script est FAIL CLOSED : il s'arrete a la premiere anomalie et n'execute
# jamais une simulation sur un arbre incoherent. Un chiffre produit par un build
# qui ne correspond pas aux sources n'appartient a aucune version du code, ce qui
# est pire qu'une erreur franche : cela ressemble a une donnee.
#
# Toutes les commandes ci-dessous ont ete executees et confirmees sur
# l'installation de l'utilisateur ; aucune n'est supposee.
# ---------------------------------------------------------------------------
set -u
ROOT="${1:-$(pwd)}"
cd "$ROOT" || { echo "racine introuvable : $ROOT"; exit 1; }

SEED=1
RUN=1
SCENARIO="--nodes=30 --areaSize=600 --maxRange=200 --minSpeed=1 --maxSpeed=5 \
--simTime=300 --flowCount=5 --dataRate=51.2kbps --attackerRatio=0.20 \
--attackStart=10 --seed=$SEED --run=$RUN"

# Les onze suites, verifiees par ./test.py -l sur l'installation utilisateur.
# Les quatre premieres sont AODV AMONT : elles verifient que le module officiel
# fonctionne toujours. ATTENTION : la suite amont s'appelle `routing-aodv`, pas
# `aodv`, et `mtcaodv-rrep-screening` N'EXISTE PAS (les tests de depistage
# STEP 2 sont dans mtcaodv-rrep-anomaly-detector).
SUITES="routing-aodv routing-aodv-loopback routing-aodv-regression \
aodv-routing-id-cache mtcaodv-routing-protocol mtcaodv-attack-manager \
mtcaodv-blackhole-behavior mtcaodv-step00-baseline-metrics \
mtcaodv-rrep-anomaly-detector mtcaodv-packet-fingerprint \
mtcaodv-forwarding-observer"

step() { printf '\n\033[1m== %s\033[0m\n' "$1"; }
die()  { printf '\n\033[1mARRET : %s\033[0m\n' "$1"; exit 1; }

# --- 1. Construction -------------------------------------------------------
# `configure` est obligatoire, pas optionnel : tout changement de CMakeLists.txt
# fait re-executer CMake au premier build, et cette re-execution REMET les
# options aux defauts (Examples: OFF, Tests: OFF).
step "1/7  Construction"
./ns3 configure --enable-examples --enable-tests >/dev/null || die "configure a echoue"
./ns3 build || die "build a echoue"

# --- 2. Garde post-build ---------------------------------------------------
step "2/7  Garde post-build (coherence de l'arbre)"
bash experiments/check_step03_build.sh "$ROOT" || die "build incoherent -- voir ci-dessus"

# --- 3. Suites ns-3 --------------------------------------------------------
step "3/7  Suites ns-3 (11)"
FAILED=""
for s in $SUITES; do
    if ./test.py -s "$s" 2>&1 | grep -q "^1 of 1 tests passed"; then
        printf '  ok    %s\n' "$s"
    else
        printf '  FAIL  %s\n' "$s"; FAILED="$FAILED $s"
    fi
done
[ -z "$FAILED" ] || die "suites en echec :$FAILED"

# --- 4. Tests Python -------------------------------------------------------
step "4/7  Tests Python"
( cd experiments && python3 -m unittest test_validate_step03 test_analyze_forwarding -q ) \
    || die "tests Python en echec"

# --- 5. AODV amont preserve ------------------------------------------------
# Le passage des suites amont prouve que le module se comporte bien ; il ne
# prouve PAS que ses sources sont intactes. Ce sont deux affirmations
# differentes et seule la seconde est la contrainte permanente.
step "5/7  Contrainte « preserver AODV »"
TOUCHED="$(find src/aodv -type f -newer src/olsr/CMakeLists.txt 2>/dev/null)"
if [ -n "$TOUCHED" ]; then
    printf '%s\n' "$TOUCHED"
    die "src/aodv a ete modifie -- violation de la contrainte"
fi
echo "  ok    src/aodv intact (temoin : src/olsr)"

# --- 6. Les deux bras, et la comparaison ----------------------------------
step "6/7  Execution : observation ON puis OFF"
./ns3 run "mtcaodv-pilot-attack $SCENARIO --observationsCsv=obs-atk.csv" \
    > /tmp/mtc_on.txt 2>&1 || { cat /tmp/mtc_on.txt; die "le run ON a echoue"; }
cp mtcaodv-step01-manifest.json man-atk.json
cp mtcaodv-step01-results.csv  res-atk.csv

./ns3 run "mtcaodv-pilot-attack $SCENARIO --enableObservation=false" \
    > /tmp/mtc_off.txt 2>&1 || { cat /tmp/mtc_off.txt; die "le run OFF a echoue"; }

PDR_ON="$(grep  -m1 '^pdr=' /tmp/mtc_on.txt  | cut -d= -f2)"
PDR_OFF="$(grep -m1 '^pdr=' /tmp/mtc_off.txt | cut -d= -f2)"
OPENED="$(grep  -m1 '^windowsOpened='  /tmp/mtc_on.txt | cut -d= -f2)"
MATCHED="$(grep -m1 '^windowsMatched=' /tmp/mtc_on.txt | cut -d= -f2)"
SKIPLH="$(grep  -m1 '^skippedLastHop=' /tmp/mtc_on.txt | cut -d= -f2)"

printf '  pdr(ON)=%s  pdr(OFF)=%s\n' "$PDR_ON" "$PDR_OFF"
printf '  windowsOpened=%s  windowsMatched=%s  skippedLastHop=%s\n' \
       "$OPENED" "$MATCHED" "$SKIPLH"

# Critere 3 : egalite EXACTE, comparee sur les chaines. L'observation est
# passive ; elle ne consomme aucun flux RNG et ne doit rien changer. Un gain
# serait un BUG, pas un succes.
[ -n "$PDR_ON" ] && [ -n "$PDR_OFF" ] || die "pdr illisible dans la sortie"
[ "$PDR_ON" = "$PDR_OFF" ] || die "pdr(ON) != pdr(OFF) : l'observation a modifie la livraison"
echo "  ok    critere 3 : pdr identique au chiffre pres"
[ "${OPENED:-0}" -gt 0 ] && [ "${MATCHED:-0}" -gt 0 ] \
    || die "critere 4 : aucune fenetre ouverte ou appariee"
echo "  ok    critere 4 : fenetres ouvertes et appariees"

# --- 7. Validation et analyse ---------------------------------------------
step "7/7  Validation et mesure"
python3 experiments/validate_step03.py --csv res-atk.csv --manifest man-atk.json \
    || die "le validateur a rejete le run"
python3 experiments/analyze_forwarding.py --observations obs-atk.csv \
    --manifest man-atk.json --after-attack-start || die "l'analyse a echoue"

printf '\n\033[1mSEQUENCE COMPLETE -- les cinq criteres STEP 3 sont satisfaits.\033[0m\n'
printf 'La baseline de non-observation honnete ci-dessus n a AUCUN seuil\n'
printf 'prevu : elle est rapportee, jamais comparee a une valeur attendue.\n'
