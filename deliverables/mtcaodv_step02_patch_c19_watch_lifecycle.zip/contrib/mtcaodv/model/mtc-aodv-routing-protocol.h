/*
 * Copyright (c) 2009 IITP RAS
 *
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * Based on
 *      NS-2 AODV model developed by the CMU/MONARCH group and optimized and
 *      tuned by Samir Das and Mahesh Marina, University of Cincinnati;
 *
 *      AODV-UU implementation by Erik Nordström of Uppsala University
 *      https://web.archive.org/web/20100527072022/http://core.it.uu.se/core/index.php/AODV-UU
 *
 * Authors: Elena Buchatskaia <borovkovaes@iitp.ru>
 *          Pavel Boyko <boyko@iitp.ru>
 */
#ifndef MTC_AODVROUTINGPROTOCOL_H
#define MTC_AODVROUTINGPROTOCOL_H

#include "mtc-aodv-dpd.h"
#include "mtc-aodv-neighbor.h"
#include "mtc-aodv-packet.h"
#include "mtc-aodv-rqueue.h"
#include "mtc-aodv-rtable.h"

// MTC-AODV STEP 1 fork extension: pluggable attack policy interface.
#include "attack-behavior.h"
// MTC-AODV STEP 2 fork extension: RREP anomaly screening (defence side).
#include "mtc-security-state.h"
#include "rrep-anomaly-detector.h"
#include "rrep-candidate-buffer.h"

#include "ns3/ipv4-interface.h"
#include "ns3/ipv4-l3-protocol.h"
#include "ns3/ipv4-routing-protocol.h"
#include "ns3/node.h"
#include "ns3/output-stream-wrapper.h"
#include "ns3/random-variable-stream.h"
#include "ns3/traced-callback.h"

#include <cstdint>
#include <deque>
#include <map>
#include <memory>
#include <vector>

namespace ns3
{

class WifiMpdu;
enum WifiMacDropReason : uint8_t; // opaque enum declaration

namespace mtcaodv
{
/**
 * @ingroup mtcaodv
 *
 * @brief AODV routing protocol
 */
class RoutingProtocol : public Ipv4RoutingProtocol
{
  public:
    /**
     * @brief Get the type ID.
     * @return the object TypeId
     */
    static TypeId GetTypeId();
    static const uint32_t AODV_PORT;

    /// constructor
    RoutingProtocol();
    ~RoutingProtocol() override;
    void DoDispose() override;

    // Inherited from Ipv4RoutingProtocol
    Ptr<Ipv4Route> RouteOutput(Ptr<Packet> p,
                               const Ipv4Header& header,
                               Ptr<NetDevice> oif,
                               Socket::SocketErrno& sockerr) override;
    bool RouteInput(Ptr<const Packet> p,
                    const Ipv4Header& header,
                    Ptr<const NetDevice> idev,
                    const UnicastForwardCallback& ucb,
                    const MulticastForwardCallback& mcb,
                    const LocalDeliverCallback& lcb,
                    const ErrorCallback& ecb) override;
    void NotifyInterfaceUp(uint32_t interface) override;
    void NotifyInterfaceDown(uint32_t interface) override;
    void NotifyAddAddress(uint32_t interface, Ipv4InterfaceAddress address) override;
    void NotifyRemoveAddress(uint32_t interface, Ipv4InterfaceAddress address) override;
    void SetIpv4(Ptr<Ipv4> ipv4) override;
    void PrintRoutingTable(Ptr<OutputStreamWrapper> stream,
                           Time::Unit unit = Time::S) const override;

    // Handle protocol parameters
    /**
     * Get maximum queue time
     * @returns the maximum queue time
     */
    Time GetMaxQueueTime() const
    {
        return m_maxQueueTime;
    }

    /**
     * Set the maximum queue time
     * @param t the maximum queue time
     */
    void SetMaxQueueTime(Time t);

    /**
     * Get the maximum queue length
     * @returns the maximum queue length
     */
    uint32_t GetMaxQueueLen() const
    {
        return m_maxQueueLen;
    }

    /**
     * Set the maximum queue length
     * @param len the maximum queue length
     */
    void SetMaxQueueLen(uint32_t len);

    /**
     * Get destination only flag
     * @returns the destination only flag
     */
    bool GetDestinationOnlyFlag() const
    {
        return m_destinationOnly;
    }

    /**
     * Set destination only flag
     * @param f the destination only flag
     */
    void SetDestinationOnlyFlag(bool f)
    {
        m_destinationOnly = f;
    }

    /**
     * Get gratuitous reply flag
     * @returns the gratuitous reply flag
     */
    bool GetGratuitousReplyFlag() const
    {
        return m_gratuitousReply;
    }

    /**
     * Set gratuitous reply flag
     * @param f the gratuitous reply flag
     */
    void SetGratuitousReplyFlag(bool f)
    {
        m_gratuitousReply = f;
    }

    /**
     * Set hello enable
     * @param f the hello enable flag
     */
    void SetHelloEnable(bool f)
    {
        m_enableHello = f;
    }

    /**
     * Get hello enable flag
     * @returns the enable hello flag
     */
    bool GetHelloEnable() const
    {
        return m_enableHello;
    }

    /**
     * Set broadcast enable flag
     * @param f enable broadcast flag
     */
    void SetBroadcastEnable(bool f)
    {
        m_enableBroadcast = f;
    }

    /**
     * Get broadcast enable flag
     * @returns the broadcast enable flag
     */
    bool GetBroadcastEnable() const
    {
        return m_enableBroadcast;
    }

    /**
     * Assign a fixed random variable stream number to the random variables
     * used by this model.  Return the number of streams (possibly zero) that
     * have been assigned.
     *
     * @param stream first stream index to use
     * @return the number of stream indices assigned by this model
     */
    int64_t AssignStreams(int64_t stream);

    // =====================================================================
    // MTC-AODV STEP 1 attack extension (fork-only additions).
    //
    // These members are the ONLY behavioural difference between this fork and
    // the stock ns-3.48 AODV routing protocol.  When no attack policy is
    // attached (m_attackBehavior == nullptr) every code path below is inert
    // and the protocol behaves exactly like stock AODV, which preserves the
    // STEP 0 baseline.  See Algorithms A2.3 (forged RREP) and A2.4 (silent
    // transit drop) and Eq. (23) (forged sequence number) in the spec.
    //
    // Scientific-integrity note: the attack policy is supplied by the
    // experiment/scenario layer.  The routing protocol never exposes attacker
    // ground truth to any detector, trust or ledger component (there are none
    // in STEP 1); it only *executes* the configured behaviour.
    // =====================================================================

    /**
     * @brief Attach (or detach) a full-Blackhole / generic attack policy.
     * @param behavior Attack policy to execute, or nullptr to behave honestly.
     *
     * Ownership is shared (ns-3 Ptr).  Passing nullptr restores stock-AODV
     * behaviour, which is what honest nodes and the attackerRatio=0 sanity
     * run use.
     */
    void SetAttackBehavior(Ptr<AttackBehavior> behavior);

    /**
     * @brief Return the attached attack policy (may be nullptr).
     * @return The current attack policy or nullptr for an honest node.
     */
    Ptr<AttackBehavior> GetAttackBehavior() const;

    /**
     * @brief Count of forged Blackhole RREPs actually serialized and unicast.
     * @return Cumulative forgedReplyCount for this node. Unit: RREPs.
     *
     * Implements the observable counter of Algorithm A2.3 / Eq. (23).
     */
    uint32_t GetForgedReplyCount() const;

    /**
     * @brief Count of transit data packets silently consumed by this node.
     * @return Cumulative blackholeTransitDropCount. Unit: packets.
     *
     * Implements the observable counter of Algorithm A2.4.
     */
    uint32_t GetBlackholeTransitDropCount() const;

    // =====================================================================
    // MTC-AODV STEP 2 defence extension (fork-only additions): robust RREP
    // anomaly screening (Section 5.3, Algorithm A3.1, Eq. (3)-(5)).  This side
    // is strictly separate from the attack side above and NEVER sees attacker
    // ground truth: it observes only protocol-valid RREP header values and
    // arrival times.  A high anomaly score raises a neighbour to WATCH and
    // nothing else — routing is UNCHANGED (Invariant 20.2.1 / 20.3.3).  When
    // EnableRrepScreening is false the whole path is inert (stock behaviour).
    // =====================================================================

    /**
     * @brief Local security state currently held for a neighbour.
     * @param neighbor Neighbour IPv4 address.
     * @return WATCH if the neighbour was flagged by screening, else NORMAL.
     */
    SecurityState GetNeighborSecurityState(Ipv4Address neighbor) const;

    /**
     * @brief Number of NORMAL->WATCH transitions this node has made.
     * @return watchCount for this node. Unit: neighbours flagged.
     *
     * Counts distinct neighbours raised to WATCH, not events, so a repeatedly
     * suspicious neighbour is counted once.
     */
    uint32_t GetWatchCount() const;

    /**
     * @brief Neighbours currently in WATCH (for offline TP/FP evaluation).
     * @return Sorted-by-insertion list of WATCH'd neighbour addresses.
     *
     * The caller (offline evaluation only) may intersect this with the scenario
     * attacker set to compute true/false positives; the detector itself never
     * performs that intersection.
     */
    std::vector<Ipv4Address> GetWatchedNeighbors() const;

    /**
     * @brief Neighbours that were in WATCH at any point during the run.
     * @return Addresses ever raised to WATCH, even if the state later expired.
     *
     * With the C-19 lifecycle a neighbour can leave WATCH again, so the offline
     * evaluation needs both views: "currently watched" (the live surveillance
     * set) and "ever watched" (the cumulative one used by the earlier metric).
     */
    std::vector<Ipv4Address> GetEverWatchedNeighbors() const;



  protected:
    void DoInitialize() override;

  private:
    /**
     * Notify that an MPDU was dropped.
     *
     * @param reason the reason why the MPDU was dropped
     * @param mpdu the dropped MPDU
     */
    void NotifyTxError(WifiMacDropReason reason, Ptr<const WifiMpdu> mpdu);

    // Protocol parameters.
    uint32_t m_rreqRetries; ///< Maximum number of retransmissions of RREQ with TTL = NetDiameter to
                            ///< discover a route
    uint16_t m_ttlStart;    ///< Initial TTL value for RREQ.
    uint16_t m_ttlIncrement; ///< TTL increment for each attempt using the expanding ring search for
                             ///< RREQ dissemination.
    uint16_t m_ttlThreshold; ///< Maximum TTL value for expanding ring search, TTL = NetDiameter is
                             ///< used beyond this value.
    uint16_t m_timeoutBuffer;  ///< Provide a buffer for the timeout.
    uint16_t m_rreqRateLimit;  ///< Maximum number of RREQ per second.
    uint16_t m_rerrRateLimit;  ///< Maximum number of REER per second.
    Time m_activeRouteTimeout; ///< Period of time during which the route is considered to be valid.
    uint32_t m_netDiameter; ///< Net diameter measures the maximum possible number of hops between
                            ///< two nodes in the network
    /**
     * NodeTraversalTime is a conservative estimate of the average one hop traversal time for
     * packets and should include queuing delays, interrupt processing times and transfer times.
     */
    Time m_nodeTraversalTime;
    Time m_netTraversalTime;  ///< Estimate of the average net traversal time.
    Time m_pathDiscoveryTime; ///< Estimate of maximum time needed to find route in network.
    Time m_myRouteTimeout;    ///< Value of lifetime field in RREP generating by this node.
    /**
     * Every HelloInterval the node checks whether it has sent a broadcast  within the last
     * HelloInterval. If it has not, it MAY broadcast a  Hello message
     */
    Time m_helloInterval;
    uint32_t m_allowedHelloLoss; ///< Number of hello messages which may be loss for valid link
    /**
     * DeletePeriod is intended to provide an upper bound on the time for which an upstream node A
     * can have a neighbor B as an active next hop for destination D, while B has invalidated the
     * route to D.
     */
    Time m_deletePeriod;
    Time m_nextHopWait;      ///< Period of our waiting for the neighbour's RREP_ACK
    Time m_blackListTimeout; ///< Time for which the node is put into the blacklist
    uint32_t m_maxQueueLen;  ///< The maximum number of packets that we allow a routing protocol to
                             ///< buffer.
    Time m_maxQueueTime;     ///< The maximum period of time that a routing protocol is allowed to
                             ///< buffer a packet for.
    bool m_destinationOnly;  ///< Indicates only the destination may respond to this RREQ.
    bool m_gratuitousReply;  ///< Indicates whether a gratuitous RREP should be unicast to the node
                             ///< originated route discovery.
    bool m_enableHello;      ///< Indicates whether a hello messages enable
    bool m_enableBroadcast;  ///< Indicates whether a a broadcast data packets forwarding enable

    /// IP protocol
    Ptr<Ipv4> m_ipv4;
    /// Raw unicast socket per each IP interface, map socket -> iface address (IP + mask)
    std::map<Ptr<Socket>, Ipv4InterfaceAddress> m_socketAddresses;
    /// Raw subnet directed broadcast socket per each IP interface, map socket -> iface address (IP
    /// + mask)
    std::map<Ptr<Socket>, Ipv4InterfaceAddress> m_socketSubnetBroadcastAddresses;
    /// Loopback device used to defer RREQ until packet will be fully formed
    Ptr<NetDevice> m_lo;

    /// Routing table
    RoutingTable m_routingTable;
    /// A "drop-front" queue used by the routing layer to buffer packets to which it does not have a
    /// route.
    RequestQueue m_queue;
    /// Broadcast ID
    uint32_t m_requestId;
    /// Request sequence number
    uint32_t m_seqNo;
    /// Handle duplicated RREQ
    IdCache m_rreqIdCache;
    /// Handle duplicated broadcast/multicast packets
    DuplicatePacketDetection m_dpd;
    /// Handle neighbors
    Neighbors m_nb;
    /// Number of RREQs used for RREQ rate control
    uint16_t m_rreqCount;
    /// Number of RERRs used for RERR rate control
    uint16_t m_rerrCount;

  private:
    /// Start protocol operation
    void Start();
    /**
     * Queue packet and send route request
     *
     * @param p the packet to route
     * @param header the IP header
     * @param ucb the UnicastForwardCallback function
     * @param ecb the ErrorCallback function
     */
    void DeferredRouteOutput(Ptr<const Packet> p,
                             const Ipv4Header& header,
                             UnicastForwardCallback ucb,
                             ErrorCallback ecb);
    /**
     * If route exists and is valid, forward packet.
     *
     * @param p the packet to route
     * @param header the IP header
     * @param ucb the UnicastForwardCallback function
     * @param ecb the ErrorCallback function
     * @returns true if forwarded
     */
    bool Forwarding(Ptr<const Packet> p,
                    const Ipv4Header& header,
                    UnicastForwardCallback ucb,
                    ErrorCallback ecb);
    /**
     * Repeated attempts by a source node at route discovery for a single destination
     * use the expanding ring search technique.
     * @param dst the destination IP address
     */
    void ScheduleRreqRetry(Ipv4Address dst);
    /**
     * Set lifetime field in routing table entry to the maximum of existing lifetime and lt, if the
     * entry exists
     * @param addr destination address
     * @param lt proposed time for lifetime field in routing table entry for destination with
     * address addr.
     * @return true if route to destination address addr exist
     */
    bool UpdateRouteLifeTime(Ipv4Address addr, Time lt);
    /**
     * Update neighbor record.
     * @param receiver is supposed to be my interface
     * @param sender is supposed to be IP address of my neighbor.
     */
    void UpdateRouteToNeighbor(Ipv4Address sender, Ipv4Address receiver);
    /**
     * Test whether the provided address is assigned to an interface on this node
     * @param src the source IP address
     * @returns true if the IP address is the node's IP address
     */
    bool IsMyOwnAddress(Ipv4Address src);
    /**
     * Find unicast socket with local interface address iface
     *
     * @param iface the interface
     * @returns the socket associated with the interface
     */
    Ptr<Socket> FindSocketWithInterfaceAddress(Ipv4InterfaceAddress iface) const;
    /**
     * Find subnet directed broadcast socket with local interface address iface
     *
     * @param iface the interface
     * @returns the socket associated with the interface
     */
    Ptr<Socket> FindSubnetBroadcastSocketWithInterfaceAddress(Ipv4InterfaceAddress iface) const;
    /**
     * Process hello message
     *
     * @param rrepHeader RREP message header
     * @param receiverIfaceAddr receiver interface IP address
     */
    void ProcessHello(const RrepHeader& rrepHeader, Ipv4Address receiverIfaceAddr);
    /**
     * Create loopback route for given header
     *
     * @param header the IP header
     * @param oif the output interface net device
     * @returns the route
     */
    Ptr<Ipv4Route> LoopbackRoute(const Ipv4Header& header, Ptr<NetDevice> oif) const;

    /**
     * @name Receive control packets
     * @{
     */
    /**
     * Receive and process control packet
     * @param socket input socket
     */
    void RecvAodv(Ptr<Socket> socket);
    /**
     * Receive RREQ
     * @param p packet
     * @param receiver receiver address
     * @param src sender address
     */
    void RecvRequest(Ptr<Packet> p, Ipv4Address receiver, Ipv4Address src);
    /**
     * Receive RREP
     * @param p packet
     * @param my destination address
     * @param src sender address
     */
    void RecvReply(Ptr<Packet> p, Ipv4Address my, Ipv4Address src);
    /**
     * Receive RREP_ACK
     * @param neighbor neighbor address
     */
    void RecvReplyAck(Ipv4Address neighbor);
    /**
     * Receive RERR
     * @param p packet
     * @param src sender address
     */
    /// Receive  from node with address src
    void RecvError(Ptr<Packet> p, Ipv4Address src);
    /** @} */

    /**
     * @name Send
     * @{
     */
    /** Forward packet from route request queue
     * @param dst destination address
     * @param route route to use
     */
    void SendPacketFromQueue(Ipv4Address dst, Ptr<Ipv4Route> route);
    /// Send hello
    void SendHello();
    /** Send RREQ
     * @param dst destination address
     */
    void SendRequest(Ipv4Address dst);
    /** Send RREP
     * @param rreqHeader route request header
     * @param toOrigin routing table entry to originator
     */
    void SendReply(const RreqHeader& rreqHeader, const RoutingTableEntry& toOrigin);
    /**
     * @brief STEP 1: send a forged Blackhole RREP (Algorithm A2.3, Eq. (23)).
     * @param rreqHeader The received RREQ that is being answered maliciously.
     * @param toOrigin Valid reverse route back to the RREQ originator.
     *
     * Builds a *standard-format* RrepHeader whose destination sequence number
     * is (observedDstSeqno + Delta_seq) mod 2^32, advertises h_fake hops and a
     * T_fake lifetime, and unicasts it to the reverse-route next hop on
     * AODV_PORT (654).  It intentionally reuses the exact packaging of
     * SendReply() so that an honest receiver cannot distinguish the packet
     * format from a legitimate reply.
     */
    void SendForgedReply(const RreqHeader& rreqHeader, const RoutingTableEntry& toOrigin);

    /**
     * @brief STEP 2: lazily build the screening buffer/detector from Attributes.
     *
     * Called on the first observed RREP so that Attribute values set by the
     * helper are already final.  Idempotent.
     */
    void EnsureScreeningInitialized();

    /**
     * @brief STEP 2: screen one received RREP (Algorithm A3.1).
     * @param rrepHeader Decoded reply header (advertised dst/seq/hop).
     * @param sender Neighbour that relayed the reply (the WATCH candidate).
     *
     * Observation only: buffers the reply, and once at least n_R^min comparable
     * replies exist for the destination, scores each and raises WATCH on any
     * neighbour whose A_RREP >= WatchThreshold.  Never alters routing.
     */
    void ScreenReceivedReply(const RrepHeader& rrepHeader, Ipv4Address sender);
    /** Send RREP by intermediate node
     * @param toDst routing table entry to destination
     * @param toOrigin routing table entry to originator
     * @param gratRep indicates whether a gratuitous RREP should be unicast to destination
     */
    void SendReplyByIntermediateNode(RoutingTableEntry& toDst,
                                     RoutingTableEntry& toOrigin,
                                     bool gratRep);
    /** Send RREP_ACK
     * @param neighbor neighbor address
     */
    void SendReplyAck(Ipv4Address neighbor);
    /** Initiate RERR
     * @param nextHop next hop address
     */
    void SendRerrWhenBreaksLinkToNextHop(Ipv4Address nextHop);
    /** Forward RERR
     * @param packet packet
     * @param precursors list of addresses of the visited nodes
     */
    void SendRerrMessage(Ptr<Packet> packet, std::vector<Ipv4Address> precursors);
    /**
     * Send RERR message when no route to forward input packet. Unicast if there is reverse route to
     * originating node, broadcast otherwise.
     * @param dst destination node IP address
     * @param dstSeqNo destination node sequence number
     * @param origin originating node IP address
     */
    void SendRerrWhenNoRouteToForward(Ipv4Address dst, uint32_t dstSeqNo, Ipv4Address origin);
    /** @} */

    /**
     * Send packet to destination socket
     * @param socket destination node socket
     * @param packet packet to send
     * @param destination destination node IP address
     */
    void SendTo(Ptr<Socket> socket, Ptr<Packet> packet, Ipv4Address destination);

    /// Hello timer
    Timer m_htimer;
    /// Schedule next send of hello message
    void HelloTimerExpire();
    /// RREQ rate limit timer
    Timer m_rreqRateLimitTimer;
    /// Reset RREQ count and schedule RREQ rate limit timer with delay 1 sec.
    void RreqRateLimitTimerExpire();
    /// RERR rate limit timer
    Timer m_rerrRateLimitTimer;
    /// Reset RERR count and schedule RERR rate limit timer with delay 1 sec.
    void RerrRateLimitTimerExpire();
    /// Map IP address + RREQ timer.
    std::map<Ipv4Address, Timer> m_addressReqTimer;
    /**
     * Handle route discovery process
     * @param dst the destination IP address
     */
    void RouteRequestTimerExpire(Ipv4Address dst);
    /**
     * Mark link to neighbor node as unidirectional for blacklistTimeout
     *
     * @param neighbor the IP address of the neighbor node
     * @param blacklistTimeout the black list timeout time
     */
    void AckTimerExpire(Ipv4Address neighbor, Time blacklistTimeout);

    /// Provides uniform random variables.
    Ptr<UniformRandomVariable> m_uniformRandomVariable;
    /// Keep track of the last bcast time
    Time m_lastBcastTime;

    // ---- STEP 1 attack state (fork-only) --------------------------------
    /// Attached attack policy, or nullptr for an honest node.
    Ptr<AttackBehavior> m_attackBehavior;
    /// Number of forged RREPs actually unicast (Algorithm A2.3 / Eq. (23)).
    uint32_t m_forgedReplyCount{0};
    /// Number of transit data packets silently dropped (Algorithm A2.4).
    uint32_t m_blackholeTransitDropCount{0};

    /// Experiment TraceSource fired for every forged RREP.
    /// Signature: (destination, forgedDstSeqno, reverseNextHop).
    TracedCallback<Ipv4Address, uint32_t, Ipv4Address> m_forgedReplyTrace;
    /// Experiment TraceSource fired for every silently dropped transit packet.
    /// Signature: (packetUid, ipSource, ipDestination).
    TracedCallback<uint64_t, Ipv4Address, Ipv4Address> m_blackholeDropTrace;

    // ---- STEP 2 defence state (fork-only) -------------------------------
    /// Master switch for RREP screening; false = stock behaviour, zero cost.
    bool m_enableRrepScreening{true};
    /// Comparison window W_R (Attribute, pilot value; C-01).
    Time m_rrepWindow{Seconds(1.0)};
    /// Minimum comparable replies n_R^min (>=2; C-02). Raised to 3 after the
    /// STEP 2 pilot: with 2 candidates the MAD degenerates to zero.
    uint32_t m_minComparableReplies{3};
    /// Logistic weights and bias w_s,w_h,w_t,b_R (C-03) and stabiliser eps (C-06).
    double m_seqWeight{1.0};
    double m_hopWeight{1.0};
    double m_timeWeight{0.5};
    double m_logisticBias{2.0};
    double m_screeningEpsilon{1e-9};
    /// Dispersion floors in the physical unit of each quantity (C-06 fix): they
    /// replace a dimensionless epsilon as the normalisation scale, so the common
    /// MAD=0 case can no longer saturate the logistic on honest replies.
    double m_seqMadFloor{2.0};
    double m_hopMadFloor{1.0};
    Time m_timeMadFloor{MilliSeconds(10)};
    /// Upper clip on each anomaly z_s,z_h,z_t.
    double m_maxAnomaly{20.0};
    /// WATCH threshold theta_R (C-04): A_RREP >= this raises WATCH.
    double m_watchThreshold{0.5};
    /// Per-destination and destination-count bounds of the candidate buffer.
    uint32_t m_rrepBufferCapacity{16};
    uint32_t m_maxTrackedDestinations{64};

    /// Lazily built bounded candidate buffer (Algorithm A3.1 input).
    std::unique_ptr<RrepCandidateBuffer> m_rrepBuffer;
    /// Stateless scorer configured from the Attributes above.
    RrepAnomalyDetector m_rrepDetector;
    /**
     * @brief Per-neighbour WATCH bookkeeping (specification point C-19).
     *
     * A single anomalous RREP is expected noise in a mobile MANET, so WATCH is
     * no longer raised on one trip.  The record keeps a bounded sliding window
     * of the neighbour's last observations (anomalous or not), which yields a
     * RATE rather than an absolute count — necessary because the number of
     * scoring opportunities varies strongly with traffic and with the attack
     * itself (measured: 7422 scores without attack vs 1618 with).
     */
    struct NeighborWatchRecord
    {
        /// Bounded window of recent outcomes: true = score >= theta_R.
        std::deque<bool> window;
        /// Simulation time (s) of the most recent anomalous score.
        double lastAnomalyTimeSeconds{0.0};
        /// Last time this record was touched, for bounded-map eviction.
        double lastUpdateTimeSeconds{0.0};
        /// True once WATCH has been raised (may since have expired).
        bool raised{false};
        /// True if WATCH was raised at least once during the whole run.
        bool everWatched{false};
    };

    /// Per-neighbour WATCH records (NORMAL/WATCH only in STEP 2).
    std::map<Ipv4Address, NeighborWatchRecord> m_neighborWatch;
    /// Number of NORMAL->WATCH transitions (a neighbour may re-trigger after expiry).
    uint32_t m_watchCount{0};

    // ---- C-19 WATCH lifecycle parameters (all pilot values, not frozen) ----
    /// Size M of the per-neighbour observation window.
    uint32_t m_watchWindowSize{20};
    /// Minimum number of anomalies in the window before WATCH may be raised.
    uint32_t m_watchMinimumAnomalies{3};
    /// Minimum anomaly RATE in the window (anomalies / observations).
    double m_watchAnomalyFraction{0.20};
    /// WATCH returns to NORMAL after this long without a new anomaly.
    Time m_watchExpiry{Seconds(15)};
    /// Bound on tracked neighbours (Invariant 20.4.2).
    uint32_t m_maxTrackedNeighbors{256};

    /// TraceSource: every computed RREP anomaly score.
    /// Signature: (destination, neighbor, anomalyScore).
    TracedCallback<Ipv4Address, Ipv4Address, double> m_rrepAnomalyTrace;
    /// TraceSource: a neighbour transitions NORMAL->WATCH.
    /// Signature: (neighbor, anomalyScore).
    TracedCallback<Ipv4Address, double> m_watchTrace;
};

} // namespace mtcaodv
} // namespace ns3

#endif /* MTC_AODVROUTINGPROTOCOL_H */
