#!/usr/bin/env python3
"""STEP 2 diagnostic: does the A_RREP score separate attackers from honest nodes?

The WATCH counters cannot answer this. WATCH is sticky, so `watchCount` only
records the FIRST time a neighbour trips; a node that produced one incidental
anomaly and a node that produced fifty are indistinguishable. This tool consumes
the RAW score stream exported by the pilot (`--scoresCsv`) and measures the
actual separability of the score, independently of any threshold.

Ground truth (`attackerNodeIds`) is read from the run manifest and applied HERE,
offline. The simulator never labelled anything.

Reported:
  * per-class score distributions (attacker-neighbour vs honest-neighbour),
  * AUC = P(score_attacker > score_honest) + 0.5 P(equal), threshold-free,
  * how often each node trips a given threshold (the number WATCH hides),
  * FAR/recall as a function of theta_R under a FAITHFUL OFFLINE REPLICA of the
    C-19 WATCH lifecycle implemented in mtc-aodv-routing-protocol.cc, so a grid
    of (theta_R, minAnomalies, anomalyFraction) can be calibrated WITHOUT
    recompiling ns-3 and without re-running the simulator.

The replica is only useful if it is exact. It reproduces, event by event and in
the recorded order:
  * a per-(observer, neighbour) sliding window of `window` outcomes,
  * WATCH raised iff anomalies >= minAnomalies AND anomalies/len(window) >= fraction,
  * WATCH cleared once `expiry` seconds elapse without a new anomaly,
  * "ever watched" (cumulative) and "still watched at t_end" (live) sets.
The one C++ behaviour it does NOT model is the LRU eviction of the bounded
neighbour map; the tool checks that no observer ever tracks more than
`maxTrackedNeighbors` neighbours and refuses to report otherwise, rather than
silently producing numbers the simulator would not reproduce.

A verdict is printed against a pre-registered decision rule. Standard library only.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path
from typing import Sequence


class ScoreAnalysisError(ValueError):
    """Raised when the diagnostic inputs are unusable."""


def compute_auc(positive: Sequence[float], negative: Sequence[float]) -> float:
    """Rank-based AUC = P(pos > neg) + 0.5 P(pos == neg).

    Args:
        positive: scores attributed to attacker neighbours.
        negative: scores attributed to honest neighbours.

    Returns:
        AUC in [0,1]; 0.5 means no discriminative power at all. NaN when either
        class is empty (undefined, never silently 0.5).
    """

    if not positive or not negative:
        return float("nan")
    merged = sorted([(s, 1) for s in positive] + [(s, 0) for s in negative])
    # Average ranks over ties so equal scores contribute exactly 0.5.
    ranks: list[float] = [0.0] * len(merged)
    i = 0
    while i < len(merged):
        j = i
        while j + 1 < len(merged) and merged[j + 1][0] == merged[i][0]:
            j += 1
        average_rank = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[k] = average_rank
        i = j + 1
    rank_sum_positive = sum(r for r, (_, label) in zip(ranks, merged) if label == 1)
    n_pos, n_neg = len(positive), len(negative)
    return (rank_sum_positive - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)


def quantile(values: Sequence[float], q: float) -> float:
    """Empirical quantile with linear interpolation; NaN on an empty sample."""
    if not values:
        return float("nan")
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    position = q * (len(ordered) - 1)
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return ordered[int(position)]
    return ordered[low] + (ordered[high] - ordered[low]) * (position - low)


def describe(name: str, values: Sequence[float]) -> str:
    """One-line distribution summary."""
    if not values:
        return f"  {name:22} n=0  (aucun score)"
    return (
        f"  {name:22} n={len(values):<7} "
        f"min={min(values):.3f} q25={quantile(values,0.25):.3f} "
        f"med={quantile(values,0.5):.3f} q75={quantile(values,0.75):.3f} "
        f"max={max(values):.3f} moy={sum(values)/len(values):.3f}"
    )


def histogram(name: str, values: Sequence[float], bins: int = 10, width: int = 40) -> str:
    """Text histogram over [0,1] so no plotting dependency is needed."""
    if not values:
        return f"  {name}: (vide)\n"
    counts = [0] * bins
    for v in values:
        index = min(bins - 1, max(0, int(v * bins)))
        counts[index] += 1
    peak = max(counts) or 1
    lines = [f"  {name} (n={len(values)}):"]
    for b in range(bins):
        lo, hi = b / bins, (b + 1) / bins
        bar = "#" * int(width * counts[b] / peak)
        lines.append(f"    [{lo:.1f},{hi:.1f}) {counts[b]:>7} |{bar}")
    return "\n".join(lines) + "\n"


def load_scores(path: Path) -> list[dict]:
    """Read the pilot's raw score CSV."""
    try:
        with path.open("r", encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
    except OSError as error:
        raise ScoreAnalysisError(f"cannot read scores CSV {path}: {error}") from error
    if not rows:
        raise ScoreAnalysisError(
            f"{path} contains no score row: the run produced no comparative score "
            "(check that screening was enabled and that n_R^min was reached)"
        )
    parsed = []
    for row in rows:
        try:
            parsed.append(
                {
                    "t": float(row["time_s"]),
                    "observer": int(row["observerNodeId"]),
                    "neighbor": int(row["neighborNodeId"]),
                    "score": float(row["anomalyScore"]),
                }
            )
        except (KeyError, ValueError) as error:
            raise ScoreAnalysisError(f"malformed score row: {error}") from error
    return parsed


def load_manifest(path: Path) -> tuple[set[int], int, float, float]:
    """Return (attackerNodeIds, nodeCount, attackStart, simTime) from the manifest."""
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ScoreAnalysisError(f"cannot read manifest {path}: {error}") from error
    attackers = manifest.get("attack", {}).get("attackerNodeIds", [])
    configuration = manifest.get("configuration", {})
    if not isinstance(attackers, list):
        raise ScoreAnalysisError("manifest attackerNodeIds must be a list")
    # simTime is the instant at which the C++ aggregation reads the live WATCH
    # set, so the replica must evaluate expiry at exactly that instant. Fail
    # closed: without it the "currently watched" figure is not defined.
    if "simTime" not in configuration:
        raise ScoreAnalysisError("manifest configuration is missing simTime")
    return (set(int(a) for a in attackers),
            int(configuration.get("nodes", 0)),
            float(configuration.get("attackStart", 0.0)),
            float(configuration["simTime"]))


def per_node_trips(rows: Sequence[dict], threshold: float) -> dict[int, int]:
    """Count, per scored neighbour, how many scores reach the threshold."""
    trips: dict[int, int] = defaultdict(int)
    for row in rows:
        if row["score"] >= threshold:
            trips[row["neighbor"]] += 1
    return trips


class WatchLifecycleReplica:
    """Offline replica of the C-19 WATCH lifecycle of the ns-3 implementation.

    This class exists so that (theta_R, minAnomalies, anomalyFraction) can be
    calibrated on an already-recorded score stream, without recompiling ns-3.
    Its value depends entirely on being FAITHFUL to
    ``RoutingProtocol::ScreenReceivedReply()``; every field below mirrors one
    member of ``NeighborWatchRecord`` in mtc-aodv-routing-protocol.h.

    Deliberate deviation: the bounded-map LRU eviction is not modelled. Instead
    the caller checks ``max_tracked_exceeded``; if it ever fires, the replica's
    numbers are not the simulator's and must not be used.

    Args:
        threshold: theta_R, the per-observation anomaly threshold (C-04).
        window: M, size of the per-(observer, neighbour) sliding window.
        minimum_anomalies: minimum anomalies inside the window (C-19).
        fraction: minimum anomaly RATE inside the window (C-19). A rate rather
            than a bare count because the number of comparable RREPs per
            neighbour varies by several-fold between scenarios, so a fixed count
            is not transferable.
        expiry: seconds without a new anomaly after which WATCH clears.
        max_tracked: bound on tracked neighbours per observer (Invariant 20.4.2).
    """

    def __init__(self, threshold: float, window: int, minimum_anomalies: int,
                 fraction: float, expiry: float, max_tracked: int = 256) -> None:
        self.threshold = threshold
        self.window = window
        self.minimum_anomalies = minimum_anomalies
        self.fraction = fraction
        self.expiry = expiry
        self.max_tracked = max_tracked
        # Key: (observerNodeId, neighborNodeId) -- the C++ map is per node, so
        # the observer id must be part of the key here.
        self._records: dict[tuple[int, int], dict] = {}
        self.watch_count = 0            # mirrors m_watchCount summed over nodes
        self.ever_watched: set[int] = set()
        self.max_tracked_exceeded = False

    def observe(self, observer: int, neighbor: int, time_s: float, score: float) -> None:
        """Consume one scored candidate, in recorded simulation order."""
        anomalous = score >= self.threshold
        key = (observer, neighbor)
        record = self._records.get(key)
        if record is None:
            record = {"window": [], "last_anomaly": 0.0, "raised": False}
            self._records[key] = record
            tracked = sum(1 for k in self._records if k[0] == observer)
            if tracked > self.max_tracked:
                self.max_tracked_exceeded = True
        record["window"].append(anomalous)
        while len(record["window"]) > self.window:
            record["window"].pop(0)
        if anomalous:
            record["last_anomaly"] = time_s

        anomalies = sum(1 for flag in record["window"] if flag)
        rate = anomalies / len(record["window"]) if record["window"] else 0.0
        persistent = anomalies >= self.minimum_anomalies and rate >= self.fraction
        currently = record["raised"] and (time_s - record["last_anomaly"]) <= self.expiry

        if persistent and not currently:
            record["raised"] = True
            self.watch_count += 1
            self.ever_watched.add(neighbor)
        elif record["raised"] and not currently:
            record["raised"] = False

    def live_watched(self, end_time: float) -> set[int]:
        """Neighbours still in WATCH at ``end_time`` (derived, as in C++)."""
        live = set()
        for (_observer, neighbor), record in self._records.items():
            if record["raised"] and (end_time - record["last_anomaly"]) <= self.expiry:
                live.add(neighbor)
        return live


def replay(rows: Sequence[dict], threshold: float, window: int, minimum_anomalies: int,
           fraction: float, expiry: float, end_time: float,
           max_tracked: int = 256) -> tuple[set[int], set[int], int, bool]:
    """Replay the whole score stream through the replica.

    Args:
        rows: score rows in recorded order (the CSV is written in event order,
            so it is NOT re-sorted; re-sorting could change the outcome of a
            sliding-window rule).
        end_time: instant at which the live WATCH set is read (t = simTime).

    Returns:
        (ever_watched, live_watched, watch_count, max_tracked_exceeded).
    """
    replica = WatchLifecycleReplica(threshold, window, minimum_anomalies, fraction,
                                    expiry, max_tracked)
    for row in rows:
        if row["neighbor"] < 0:
            continue
        replica.observe(row["observer"], row["neighbor"], row["t"], row["score"])
    return (replica.ever_watched, replica.live_watched(end_time), replica.watch_count,
            replica.max_tracked_exceeded)


def sweep(rows: Sequence[dict], attackers: set[int], nodes: int, end_time: float,
          thresholds: Sequence[float], minimum_anomalies_grid: Sequence[int],
          fractions: Sequence[float], window: int, expiry: float,
          max_tracked: int = 256) -> None:
    """Print FAR/recall over the (theta_R, minAnomalies, fraction) grid.

    The numbers printed here are the numbers the ns-3 run would produce with the
    same CLI values, because they come from the replica of the implemented rule
    -- not from a proxy such as "trips at least K times". Choosing a cell here
    and passing it to --watchThreshold/--watchMinAnomalies/--watchAnomalyFraction
    is therefore a calibration, not an extrapolation.

    Both views are reported: 'ever' is the cumulative set (comparable with the
    pre-C-19 columns) and 'live' is the surveillance set still active at t_end,
    which is what the expiry rule is meant to shrink.
    """
    honest_universe = max(1, nodes - len(attackers))
    print("\n=== FAR / rappel -- replique fidele de la regle C-19 implementee ===")
    print(f"  (fenetre M={window}, expiry={expiry:g}s, t_end={end_time:g}s, "
          f"univers honnete={honest_universe})")
    header = (f"{'theta_R':>8} {'minAn':>6} {'frac':>6} {'watch':>6} "
              f"{'TPever':>7} {'FPever':>7} {'TPlive':>7} {'FPlive':>7} "
              f"{'rappel':>8} {'FARlive':>8} {'precLive':>9}")
    print(header)
    for threshold in thresholds:
        for minimum_anomalies in minimum_anomalies_grid:
            if minimum_anomalies > window:
                continue  # unreachable rule: WATCH could never be raised
            for fraction in fractions:
                ever, live, watch_count, exceeded = replay(
                    rows, threshold, window, minimum_anomalies, fraction, expiry,
                    end_time, max_tracked)
                if exceeded:
                    print("  ABANDON: un observateur suit plus de "
                          f"{max_tracked} voisins; la replique ne modelise pas "
                          "l'eviction LRU et ses chiffres ne seraient pas ceux du "
                          "simulateur.")
                    return
                tp_ever = len(ever & attackers)
                fp_ever = len(ever - attackers)
                tp_live = len(live & attackers)
                fp_live = len(live - attackers)
                recall = tp_live / len(attackers) if attackers else float("nan")
                far_live = fp_live / honest_universe
                precision = (tp_live / (tp_live + fp_live)
                             if (tp_live + fp_live) else float("nan"))
                print(f"{threshold:>8.2f} {minimum_anomalies:>6} {fraction:>6.2f} "
                      f"{watch_count:>6} {tp_ever:>7} {fp_ever:>7} {tp_live:>7} "
                      f"{fp_live:>7} {recall:>8.3f} {far_live:>8.3f} {precision:>9.3f}")


def verify_against_run(rows: Sequence[dict], attackers: set[int], end_time: float,
                       results_csv: Path, manifest_path: Path) -> int:
    """Check that the offline replica reproduces the simulator's own WATCH counters.

    This is the equivalence test that makes the calibration sweep meaningful. It
    replays the exported score stream with the parameters the run actually used
    (read from its results CSV) and compares the outcome against the counters the
    ns-3 run reported. Agreement means a cell chosen in the sweep will be
    reproduced by the simulator; disagreement means the replica is wrong and the
    sweep must not be used to freeze anything.

    Fail closed: if any score row was dropped at the bound, the replica is
    replaying a truncated stream and the comparison is declared invalid rather
    than reported as a pass.

    Returns:
        0 when the replica matches, 1 when it does not or cannot be checked.
    """
    try:
        with results_csv.open("r", encoding="utf-8", newline="") as handle:
            csv_rows = list(csv.DictReader(handle))
    except OSError as error:
        raise ScoreAnalysisError(f"cannot read results CSV {results_csv}: {error}") from error
    if len(csv_rows) != 1:
        raise ScoreAnalysisError("results CSV must contain exactly one data row")
    run = csv_rows[0]

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    defence = manifest.get("defence", {})
    dropped = int(defence.get("scoreRowsDropped", -1))
    if dropped < 0:
        print("VERIFICATION IMPOSSIBLE: le manifeste ne publie pas scoreRowsDropped ; "
              "impossible de savoir si le flux de scores est complet.")
        return 1
    if dropped > 0:
        print(f"VERIFICATION IMPOSSIBLE: {dropped} lignes de score ont ete abandonnees "
              "a la borne ; la replique rejouerait un flux tronque.")
        return 1
    exported = int(defence.get("scoreRowsExported", -1))
    if exported >= 0 and exported != len(rows):
        print(f"VERIFICATION IMPOSSIBLE: {len(rows)} lignes lues mais {exported} exportees "
              "(un filtre a-t-il ete applique ? --after-attack-start est incompatible "
              "avec la verification).")
        return 1

    try:
        threshold = float(run["watchThreshold"])
        window = int(run["watchWindowSize"])
        minimum_anomalies = int(run["watchMinimumAnomalies"])
        fraction = float(run["watchAnomalyFraction"])
        expiry = float(run["watchExpiry_s"])
        max_tracked = int(run["maxTrackedNeighbors"])
        observed_watch_count = int(run["watchCount"])
        observed_tp = int(run["watchTruePositives"])
        observed_fp = int(run["watchFalsePositives"])
        observed_tp_live = int(run["watchTruePositivesCurrent"])
        observed_fp_live = int(run["watchFalsePositivesCurrent"])
    except (KeyError, ValueError) as error:
        raise ScoreAnalysisError(f"results CSV lacks a C-19 column: {error}") from error

    ever, live, watch_count, exceeded = replay(rows, threshold, window, minimum_anomalies,
                                               fraction, expiry, end_time, max_tracked)
    if exceeded:
        print("VERIFICATION IMPOSSIBLE: la borne maxTrackedNeighbors a ete atteinte ; "
              "la replique ne modelise pas l'eviction LRU.")
        return 1

    predicted = {
        "watchCount": watch_count,
        "watchTruePositives": len(ever & attackers),
        "watchFalsePositives": len(ever - attackers),
        "watchTruePositivesCurrent": len(live & attackers),
        "watchFalsePositivesCurrent": len(live - attackers),
    }
    observed = {
        "watchCount": observed_watch_count,
        "watchTruePositives": observed_tp,
        "watchFalsePositives": observed_fp,
        "watchTruePositivesCurrent": observed_tp_live,
        "watchFalsePositivesCurrent": observed_fp_live,
    }
    print("\n=== Verification replique offline vs simulateur ns-3 ===")
    print(f"  parametres du run : theta_R={threshold:g} M={window} minAn={minimum_anomalies} "
          f"frac={fraction:g} expiry={expiry:g}s")
    print(f"  {'compteur':>30} {'ns-3':>8} {'replique':>10}")
    mismatched = []
    for name in observed:
        flag = "" if observed[name] == predicted[name] else "   <-- ECART"
        print(f"  {name:>30} {observed[name]:>8} {predicted[name]:>10}{flag}")
        if observed[name] != predicted[name]:
            mismatched.append(name)
    if mismatched:
        print("\n  VERIFICATION FAIL : la replique ne reproduit pas le simulateur "
              f"({', '.join(mismatched)}).")
        print("  Le balayage ci-dessus ne doit PAS servir a geler des parametres.")
        return 1
    print("\n  VERIFICATION PASS : la replique reproduit exactement les compteurs ns-3.")
    print("  Le balayage est donc une calibration valide, pas une extrapolation.")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--scores", required=True, type=Path, help="CSV from --scoresCsv")
    parser.add_argument("--manifest", required=True, type=Path, help="run manifest")
    parser.add_argument("--after-attack-start", action="store_true",
                        help="keep only scores at or after attackStart (attacked runs)")
    parser.add_argument("--auc-floor", type=float, default=0.60,
                        help="pre-registered AUC above which the score is deemed informative")
    # ---- C-19 replica grid: these must mirror the ns-3 CLI names/semantics ----
    parser.add_argument("--window", type=int, default=20,
                        help="C-19 window size M (must equal the ns-3 --watchWindow)")
    parser.add_argument("--expiry", type=float, default=15.0,
                        help="C-19 expiry in seconds (must equal the ns-3 --watchExpiry)")
    parser.add_argument("--max-tracked", type=int, default=256,
                        help="bound on tracked neighbours per observer (ns-3 "
                             "--maxTrackedNeighbors); the replica refuses to report "
                             "if the bound is reached, since it omits LRU eviction")
    parser.add_argument("--thresholds", type=float, nargs="+",
                        default=[0.30, 0.50, 0.70, 0.90, 0.99],
                        help="theta_R grid to sweep")
    parser.add_argument("--min-anomalies", type=int, nargs="+", default=[1, 3, 5, 10],
                        help="C-19 minAnomalies grid to sweep")
    parser.add_argument("--verify-against", type=Path, default=None,
                        help="results CSV of the SAME run: replays the score stream with "
                             "that run's own C-19 parameters and checks that the offline "
                             "replica reproduces the simulator's WATCH counters exactly")
    parser.add_argument("--fractions", type=float, nargs="+",
                        default=[0.0, 0.20, 0.50, 0.80],
                        help="C-19 anomaly-rate grid to sweep")
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)

    try:
        rows = load_scores(arguments.scores)
        attackers, nodes, attack_start, sim_time = load_manifest(arguments.manifest)
    except ScoreAnalysisError as error:
        print(f"ANALYSE FAIL: {error}", file=sys.stderr)
        return 1

    if arguments.after_attack_start:
        rows = [r for r in rows if r["t"] >= attack_start]
        if not rows:
            print("ANALYSE FAIL: aucun score apres attackStart", file=sys.stderr)
            return 1

    positive = [r["score"] for r in rows if r["neighbor"] in attackers]
    negative = [r["score"] for r in rows if r["neighbor"] not in attackers and r["neighbor"] >= 0]

    print("=== Separabilite du score A_RREP (diagnostic STEP 2) ===")
    print(f"  nodes={nodes}  attaquants={sorted(attackers)}  scores retenus={len(rows)}")
    print(describe("voisin ATTAQUANT", positive))
    print(describe("voisin HONNETE", negative))
    print()
    print(histogram("voisin ATTAQUANT", positive), end="")
    print(histogram("voisin HONNETE", negative), end="")

    auc = compute_auc(positive, negative)
    print(f"\n  AUC = {auc:.4f}   (0.5 = aucun pouvoir discriminant)")

    # The live WATCH set is read at t = simTime, exactly as the C++ aggregation
    # does after Simulator::Run() returns.
    sweep(rows, attackers, nodes, end_time=sim_time,
          thresholds=arguments.thresholds,
          minimum_anomalies_grid=arguments.min_anomalies,
          fractions=arguments.fractions,
          window=arguments.window,
          expiry=arguments.expiry,
          max_tracked=arguments.max_tracked)

    verification_status = 0
    if arguments.verify_against is not None:
        if arguments.after_attack_start:
            print("\nVERIFICATION IGNOREE: --after-attack-start filtre le flux, alors que "
                  "le simulateur a vu toutes les lignes.")
            verification_status = 1
        else:
            try:
                verification_status = verify_against_run(
                    rows, attackers, sim_time, arguments.verify_against, arguments.manifest)
            except ScoreAnalysisError as error:
                print(f"VERIFICATION FAIL: {error}", file=sys.stderr)
                verification_status = 1

    print("\n=== Verdict (regle preenregistree) ===")
    if not attackers:
        print("  Run SANS attaque : pas d'AUC definie. Lire les colonnes FPever / FPlive")
        print("  du balayage comme la baseline de fausse alarme sous la regle C-19.")
        return verification_status
    if math.isnan(auc):
        print("  AUC indefinie (une des deux classes est vide) -> diagnostic non concluant.")
        return 2
    if auc < arguments.auc_floor:
        print(f"  AUC {auc:.4f} < {arguments.auc_floor:.2f} : le score A_RREP ne separe PAS")
        print("  les attaquants des honnetes dans ce scenario. Aucun seuil ni regle de")
        print("  persistance ne le sauvera. Conclusion actee : le stage 1 est une simple")
        print("  porte d'observation NON discriminante ; la detection revient a STEP 3-5.")
        return verification_status
    print(f"  AUC {auc:.4f} >= {arguments.auc_floor:.2f} : le score porte du signal.")
    print("  La regle de persistance (C-19) est justifiee ; choisir")
    print("  (theta_R, minAnomalies, anomalyFraction) dans le balayage ci-dessus, sur des")
    print("  seeds DISTINCTS de ceux de l'evaluation finale, puis geler ces valeurs.")
    print("  Le balayage etant une replique fidele de la regle implementee, la cellule")
    print("  choisie se transpose telle quelle en --watchThreshold / --watchMinAnomalies /")
    print("  --watchAnomalyFraction (avec le meme --watchWindow et --watchExpiry).")
    return verification_status


if __name__ == "__main__":
    raise SystemExit(main())
