#!/usr/bin/env python3
"""Unit tests for the STEP 2 score-separability analysis (no ns-3 required)."""

from __future__ import annotations

import json
import math
import tempfile
import unittest
from pathlib import Path

import analyze_rrep_scores as a


class AucTests(unittest.TestCase):
    """AUC must be exact on cases whose value is known analytically."""

    def test_perfect_separation(self):
        self.assertAlmostEqual(a.compute_auc([0.9, 0.8, 0.7], [0.1, 0.2, 0.3]), 1.0)

    def test_perfect_inversion(self):
        self.assertAlmostEqual(a.compute_auc([0.1, 0.2], [0.8, 0.9]), 0.0)

    def test_all_ties_is_one_half(self):
        # Every score identical => no discriminative power whatsoever.
        self.assertAlmostEqual(a.compute_auc([0.5] * 5, [0.5] * 7), 0.5)

    def test_known_intermediate_value(self):
        # pos={2,4}, neg={1,3,5}: pairs pos>neg = (2>1),(4>1),(4>3) = 3 of 6.
        self.assertAlmostEqual(a.compute_auc([2.0, 4.0], [1.0, 3.0, 5.0]), 0.5)

    def test_half_ties(self):
        # pos={1,2}, neg={2,3}: 1>2 no, 1>3 no, 2>2 tie(0.5), 2>3 no => 0.5/4
        self.assertAlmostEqual(a.compute_auc([1.0, 2.0], [2.0, 3.0]), 0.125)

    def test_empty_class_is_nan(self):
        self.assertTrue(math.isnan(a.compute_auc([], [0.1])))
        self.assertTrue(math.isnan(a.compute_auc([0.1], [])))


class TripTests(unittest.TestCase):
    """Per-node trip counting is what WATCH's stickiness hides."""

    def test_counts_repeats_not_just_first(self):
        rows = [
            {"t": 1.0, "observer": 0, "neighbor": 4, "score": 0.9},
            {"t": 2.0, "observer": 1, "neighbor": 4, "score": 0.8},
            {"t": 3.0, "observer": 2, "neighbor": 7, "score": 0.9},
            {"t": 4.0, "observer": 0, "neighbor": 7, "score": 0.1},
        ]
        trips = a.per_node_trips(rows, 0.5)
        self.assertEqual(trips[4], 2)  # tripped twice
        self.assertEqual(trips[7], 1)  # tripped once
        # A stricter threshold changes the counts.
        self.assertEqual(a.per_node_trips(rows, 0.85)[4], 1)


class QuantileTests(unittest.TestCase):
    def test_median(self):
        self.assertAlmostEqual(a.quantile([1, 2, 3], 0.5), 2.0)
        self.assertAlmostEqual(a.quantile([1, 2, 3, 4], 0.5), 2.5)

    def test_empty_is_nan(self):
        self.assertTrue(math.isnan(a.quantile([], 0.5)))


class EndToEndTests(unittest.TestCase):
    def test_reads_scores_and_manifest(self):
        tmp = Path(tempfile.mkdtemp())
        scores = tmp / "s.csv"
        scores.write_text(
            "time_s,observerNodeId,destination,neighborNodeId,neighborIp,anomalyScore\n"
            "11.0,0,10.1.0.9,4,10.1.0.5,0.95\n"
            "12.0,1,10.1.0.9,7,10.1.0.8,0.10\n",
            encoding="utf-8",
        )
        manifest = tmp / "m.json"
        manifest.write_text(json.dumps({
            "attack": {"attackerNodeIds": [4]},
            "configuration": {"nodes": 30, "attackStart": 10.0, "simTime": 60.0},
        }), encoding="utf-8")
        rows = a.load_scores(scores)
        attackers, nodes, start, sim_time = a.load_manifest(manifest)
        self.assertEqual(len(rows), 2)
        self.assertEqual(attackers, {4})
        self.assertEqual(nodes, 30)
        self.assertAlmostEqual(start, 10.0)
        self.assertAlmostEqual(sim_time, 60.0)
        pos = [r["score"] for r in rows if r["neighbor"] in attackers]
        neg = [r["score"] for r in rows if r["neighbor"] not in attackers]
        self.assertAlmostEqual(a.compute_auc(pos, neg), 1.0)

    def test_empty_scores_file_is_rejected(self):
        tmp = Path(tempfile.mkdtemp())
        scores = tmp / "s.csv"
        scores.write_text(
            "time_s,observerNodeId,destination,neighborNodeId,neighborIp,anomalyScore\n",
            encoding="utf-8")
        with self.assertRaises(a.ScoreAnalysisError):
            a.load_scores(scores)


class WatchReplicaTests(unittest.TestCase):
    """The offline replica is only useful if it matches the C++ rule exactly.

    These cases pin the four behaviours the ns-3 implementation exhibits:
    persistence by count, persistence by rate, expiry, and observer isolation.
    """

    @staticmethod
    def _rows(pairs, observer=0, neighbor=4, start=10.0, step=1.0):
        """Build a score stream: `pairs` is a list of scores in event order."""
        return [{"t": start + i * step, "observer": observer, "neighbor": neighbor,
                 "score": score} for i, score in enumerate(pairs)]

    def test_single_anomaly_does_not_raise_watch(self):
        """One anomalous observation is not persistence: WATCH must stay clear."""
        rows = self._rows([0.9, 0.1, 0.1, 0.1])
        ever, live, count, _ = a.replay(rows, threshold=0.5, window=20,
                                        minimum_anomalies=3, fraction=0.20,
                                        expiry=15.0, end_time=60.0)
        self.assertEqual(ever, set())
        self.assertEqual(live, set())
        self.assertEqual(count, 0)

    def test_persistent_anomalies_raise_watch(self):
        rows = self._rows([0.9, 0.9, 0.9])
        ever, live, count, _ = a.replay(rows, threshold=0.5, window=20,
                                        minimum_anomalies=3, fraction=0.20,
                                        expiry=15.0, end_time=13.0)
        self.assertEqual(ever, {4})
        self.assertEqual(live, {4})
        self.assertEqual(count, 1)

    def test_rate_gate_is_inactive_during_window_warm_up(self):
        """Documented limitation, verified rather than assumed.

        The window is evaluated as soon as it holds any observation, so while
        len(window) < M the denominator of the rate is the number of
        observations seen SO FAR, not M. A leading burst of `minimumAnomalies`
        anomalies therefore yields rate = 1.0 and raises WATCH whatever the
        configured fraction is; the fraction only starts to bite once enough
        normal observations have accumulated. This is intentional -- requiring a
        full window of M would make WATCH unreachable for the many neighbours
        that are scored only a handful of times -- but it means the fraction is
        a DILUTION gate, not an admission gate.
        """
        rows = self._rows([0.9, 0.9, 0.9] + [0.1] * 17)
        ever, _live, _count, _ = a.replay(rows, threshold=0.5, window=20,
                                          minimum_anomalies=3, fraction=0.20,
                                          expiry=15.0, end_time=60.0)
        self.assertEqual(ever, {4}, "leading burst trips on a partial window")

    def test_rate_gate_blocks_diluted_anomalies_on_a_full_window(self):
        """With the window already full of normal outcomes, the rate gate holds.

        17 normal observations arrive first, so when the 3 anomalies land the
        window holds 20 outcomes and the rate is 3/20 = 0.15 < 0.20.
        """
        rows = self._rows([0.1] * 17 + [0.9, 0.9, 0.9])
        ever, _live, _count, _ = a.replay(rows, threshold=0.5, window=20,
                                          minimum_anomalies=3, fraction=0.20,
                                          expiry=15.0, end_time=60.0)
        self.assertEqual(ever, set())
        # Relaxing ONLY the rate makes the very same stream trip, which proves
        # the rate -- not the count -- is what suppressed it.
        ever2, _l2, _c2, _ = a.replay(rows, threshold=0.5, window=20,
                                      minimum_anomalies=3, fraction=0.10,
                                      expiry=15.0, end_time=60.0)
        self.assertEqual(ever2, {4})

    def test_watch_expires_but_stays_in_ever(self):
        """C-19: WATCH clears with time, yet the cumulative view remembers it."""
        rows = self._rows([0.9, 0.9, 0.9], start=10.0, step=1.0)
        ever, live, _count, _ = a.replay(rows, threshold=0.5, window=20,
                                         minimum_anomalies=3, fraction=0.20,
                                         expiry=15.0, end_time=60.0)
        self.assertEqual(ever, {4})     # was watched at t=12
        self.assertEqual(live, set())   # 60 - 12 = 48s > 15s expiry

    def test_observers_are_independent(self):
        """Windows are per (observer, neighbour): two observers must not pool."""
        rows = (self._rows([0.9, 0.9], observer=0)
                + self._rows([0.9], observer=1, start=12.0))
        ever, _live, _count, _ = a.replay(rows, threshold=0.5, window=20,
                                          minimum_anomalies=3, fraction=0.20,
                                          expiry=15.0, end_time=60.0)
        self.assertEqual(ever, set())

    def test_max_tracked_bound_is_reported(self):
        rows = [{"t": 10.0 + i, "observer": 0, "neighbor": i, "score": 0.9}
                for i in range(5)]
        _ever, _live, _count, exceeded = a.replay(rows, threshold=0.5, window=20,
                                                  minimum_anomalies=1, fraction=0.0,
                                                  expiry=15.0, end_time=60.0,
                                                  max_tracked=3)
        self.assertTrue(exceeded)


if __name__ == "__main__":
    unittest.main()
