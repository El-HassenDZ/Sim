#!/usr/bin/env python3
"""Validate one MTC-AODV STEP 2 CSV row and manifest (RREP anomaly screening).

STEP 2 adds the defence-side WATCH screening on top of the STEP 1 attack. This
validator is fail closed and checks, in addition to the STEP 1 network/attack
invariants:

  * the STEP 0 prefix is intact and the STEP 1 + STEP 2 columns are present;
  * screening bookkeeping is consistent:
      - watchTruePositives + watchFalsePositives = distinct WATCH'd nodes,
      - watchTruePositives <= attackerCount,
      - watchTP + watchFP <= nodes,
      - screeningEnabled=0  =>  watchCount = watchTP = watchFP = 0,
      - attackerRatio=0     =>  watchTruePositives = 0  (no attacker to detect;
        watchFalsePositives MAY be > 0 — that is the false-alarm baseline).

C-19 (WATCH lifecycle) additionally requires:
      - the live counters are a subset of the cumulative ones:
        watch*PositivesCurrent <= watch*Positives,
      - the lifecycle parameters are usable: 1 <= minAnomalies <= window,
        0 <= anomalyFraction <= 1, expiry > 0 (WATCH must be able to clear),
        maxTrackedNeighbors >= 1 (bounded structures),
      - the manifest repeats the same counters and parameters as the CSV.

Standard library only.  No metric is fabricated; a missing required column or a
violated invariant rejects the run.
"""

from __future__ import annotations

import argparse
import csv
import math
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence


class Step2ValidationError(ValueError):
    """Raised when a STEP 2 artifact violates a required invariant."""


def round_half_up(value: float) -> int:
    """Equation (2): floor(x + 0.5)."""
    return math.floor(value + 0.5)


REQUIRED_PREFIX = [
    "protocol", "nodes", "simTime", "minSpeed", "maxSpeed", "seed", "run",
    "attackerRatio", "attackerCount", "attackStart", "appTxPackets",
    "appRxPackets", "appTxBytes", "appRxBytes", "pdr", "plr", "throughput_bps",
    "goodput_bps", "meanDelay_s",
]
REQUIRED_STEP1 = ["forgedRrepCount", "blackholeDropCount", "attackStream",
                  "attackerSelectionStreamsConsumed"]
REQUIRED_STEP2 = ["screeningEnabled", "watchThreshold", "watchCount",
                  "watchTruePositives", "watchFalsePositives"]
# C-19 (WATCH lifecycle: persistence + expiry).  These columns are appended after
# the STEP 2 block; they report the LIVE surveillance set at t_end plus the
# lifecycle parameters that produced it.  A detection figure without its rule is
# not interpretable, so both the counters and the parameters are mandatory.
REQUIRED_C19 = ["watchTruePositivesCurrent", "watchFalsePositivesCurrent",
                "watchWindowSize", "watchMinimumAnomalies", "watchAnomalyFraction",
                "watchExpiry_s", "maxTrackedNeighbors"]


def _read_single_csv_row(path: Path) -> tuple[list[str], dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            header = list(reader.fieldnames or [])
            rows = list(reader)
    except OSError as error:
        raise Step2ValidationError(f"cannot read CSV {path}: {error}") from error
    if len(rows) != 1:
        raise Step2ValidationError(f"CSV must contain exactly one data row; found {len(rows)}")
    if len(header) != len(set(header)):
        raise Step2ValidationError("CSV header contains duplicate column names")
    return header, rows[0]


def _load_json(path: Path) -> dict[str, Any]:
    import json
    try:
        with path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
    except (OSError, ValueError) as error:
        raise Step2ValidationError(f"cannot read valid JSON {path}: {error}") from error
    if not isinstance(value, dict):
        raise Step2ValidationError(f"JSON root must be an object: {path}")
    return value


def _f(row: Mapping[str, str], name: str) -> float:
    try:
        return float(row[name])
    except (KeyError, ValueError) as error:
        raise Step2ValidationError(f"invalid float field {name}: {error}") from error


def _i(row: Mapping[str, str], name: str) -> int:
    try:
        return int(row[name])
    except (KeyError, ValueError) as error:
        raise Step2ValidationError(f"invalid int field {name}: {error}") from error


def validate(csv_path: Path,
             manifest_path: Path | None,
             *,
             expect_frozen_scenario: bool = False) -> dict[str, Any]:
    """Validate the STEP 2 CSV (and manifest when given). Returns a summary."""

    header, row = _read_single_csv_row(csv_path)

    # Column presence (prefix first and in order, then required columns).
    if header[: len(REQUIRED_PREFIX)] != REQUIRED_PREFIX:
        raise Step2ValidationError("CSV required prefix is missing, reordered, or renamed")
    for column in REQUIRED_STEP1 + REQUIRED_STEP2 + REQUIRED_C19:
        if column not in header:
            raise Step2ValidationError(f"CSV missing required column: {column}")

    if row["protocol"] != "MTC-AODV":
        raise Step2ValidationError("STEP 2 must use protocol=MTC-AODV")

    nodes = _i(row, "nodes")
    ratio = _f(row, "attackerRatio")
    attacker_count = _i(row, "attackerCount")
    pdr = _f(row, "pdr")
    plr = _f(row, "plr")
    tx = _i(row, "appTxPackets")
    rx = _i(row, "appRxPackets")

    # Core STEP 1 invariants (subset; the full set lives in validate_step01.py).
    if not 0.0 <= ratio < 1.0:
        raise Step2ValidationError("attackerRatio must be in [0,1)")
    if attacker_count != round_half_up(ratio * nodes):
        raise Step2ValidationError("attackerCount violates Equation (2)")
    if tx <= 0 or not 0 <= rx <= tx:
        raise Step2ValidationError("appRxPackets must be in [0, appTxPackets] with appTxPackets>0")
    if math.isfinite(pdr):
        if not 0.0 <= pdr <= 1.0:
            raise Step2ValidationError("pdr must be in [0,1]")
        if not math.isclose(pdr, rx / tx, rel_tol=1e-9, abs_tol=1e-12):
            raise Step2ValidationError("pdr does not match appRxPackets/appTxPackets (Eq. 20)")
    if math.isfinite(plr) and not math.isclose(plr, 1.0 - rx / tx, rel_tol=1e-9, abs_tol=1e-12):
        raise Step2ValidationError("plr does not match 1 - pdr (Eq. 24)")

    # STEP 2 screening invariants.
    screening = _i(row, "screeningEnabled")
    threshold = _f(row, "watchThreshold")
    watch_count = _i(row, "watchCount")
    watch_tp = _i(row, "watchTruePositives")
    watch_fp = _i(row, "watchFalsePositives")

    if screening not in (0, 1):
        raise Step2ValidationError("screeningEnabled must be 0 or 1")
    if not 0.0 <= threshold <= 1.0:
        raise Step2ValidationError("watchThreshold must be in [0,1]")
    if min(watch_count, watch_tp, watch_fp) < 0:
        raise Step2ValidationError("WATCH counters must be non-negative")
    if watch_tp > attacker_count:
        raise Step2ValidationError("watchTruePositives cannot exceed attackerCount")
    if watch_tp + watch_fp > nodes:
        raise Step2ValidationError("distinct WATCH'd nodes cannot exceed the population")
    # A distinct node is WATCH'd only if at least one observer flagged it, which
    # requires at least one WATCH transition somewhere.
    if (watch_tp + watch_fp) > 0 and watch_count == 0:
        raise Step2ValidationError("detected nodes exist but watchCount is zero")
    if screening == 0 and (watch_count or watch_tp or watch_fp):
        raise Step2ValidationError("screeningEnabled=0 must produce zero WATCH activity")
    if ratio == 0.0 and watch_tp != 0:
        raise Step2ValidationError("attackerRatio=0 cannot yield a true positive")

    # ---- C-19 WATCH-lifecycle invariants ----
    watch_tp_current = _i(row, "watchTruePositivesCurrent")
    watch_fp_current = _i(row, "watchFalsePositivesCurrent")
    window_size = _i(row, "watchWindowSize")
    minimum_anomalies = _i(row, "watchMinimumAnomalies")
    anomaly_fraction = _f(row, "watchAnomalyFraction")
    expiry_seconds = _f(row, "watchExpiry_s")
    max_tracked = _i(row, "maxTrackedNeighbors")

    if min(watch_tp_current, watch_fp_current) < 0:
        raise Step2ValidationError("current WATCH counters must be non-negative")
    # The live set is a subset of the cumulative set by construction: a node can
    # only be "still watched" if it was watched at least once.  A violation means
    # the two aggregations disagree, i.e. a bookkeeping bug, not a scientific
    # result -- so it is rejected rather than reported.
    if watch_tp_current > watch_tp:
        raise Step2ValidationError(
            "watchTruePositivesCurrent cannot exceed the cumulative watchTruePositives"
        )
    if watch_fp_current > watch_fp:
        raise Step2ValidationError(
            "watchFalsePositivesCurrent cannot exceed the cumulative watchFalsePositives"
        )
    if screening == 0 and (watch_tp_current or watch_fp_current):
        raise Step2ValidationError("screeningEnabled=0 must produce no live WATCH set")
    if ratio == 0.0 and watch_tp_current != 0:
        raise Step2ValidationError("attackerRatio=0 cannot yield a live true positive")
    # Parameter sanity: an unusable rule would silently disable the defence.
    if window_size < 1:
        raise Step2ValidationError("watchWindowSize must be >= 1")
    if minimum_anomalies < 1:
        raise Step2ValidationError("watchMinimumAnomalies must be >= 1")
    if minimum_anomalies > window_size:
        raise Step2ValidationError(
            "watchMinimumAnomalies > watchWindowSize would make WATCH unreachable"
        )
    if not 0.0 <= anomaly_fraction <= 1.0:
        raise Step2ValidationError("watchAnomalyFraction must be in [0,1]")
    if not math.isfinite(expiry_seconds) or expiry_seconds <= 0.0:
        # At expiry = 0 a raised WATCH survives only until the neighbour's very
        # next observation, so the live surveillance set is empty in practice and
        # the defence is silently a no-op. That is a misconfiguration, not a
        # result, so it is rejected rather than reported as a low false-alarm rate.
        raise Step2ValidationError(
            "watchExpiry_s must be finite and > 0: at 0 the WATCH state cannot "
            "survive a single subsequent observation, silently voiding the defence"
        )
    if max_tracked < 1:
        raise Step2ValidationError("maxTrackedNeighbors must be >= 1 (bounded structures)")

    if expect_frozen_scenario:
        area = _f(row, "areaSize_m")
        max_range = _f(row, "maxRange_m")
        if nodes != 30 or not math.isclose(area, 600.0) or not math.isclose(max_range, 200.0):
            raise Step2ValidationError(
                "frozen STEP 1 scenario expected: nodes=30, area=600, maxRange=200"
            )

    if manifest_path is not None:
        manifest = _load_json(manifest_path)
        if manifest.get("schemaVersion") != "mtcaodv-step01-v1":
            raise Step2ValidationError("manifest schemaVersion mismatch")
        defence = manifest.get("defence")
        if not isinstance(defence, dict):
            raise Step2ValidationError("manifest is missing the 'defence' block")
        if int(defence.get("watchCount", -1)) != watch_count:
            raise Step2ValidationError("manifest watchCount differs from CSV")
        if int(defence.get("watchTruePositives", -1)) != watch_tp:
            raise Step2ValidationError("manifest watchTruePositives differs from CSV")
        if int(defence.get("watchFalsePositives", -1)) != watch_fp:
            raise Step2ValidationError("manifest watchFalsePositives differs from CSV")
        if int(defence.get("watchTruePositivesCurrent", -1)) != watch_tp_current:
            raise Step2ValidationError("manifest watchTruePositivesCurrent differs from CSV")
        if int(defence.get("watchFalsePositivesCurrent", -1)) != watch_fp_current:
            raise Step2ValidationError("manifest watchFalsePositivesCurrent differs from CSV")
        if int(defence.get("watchWindowSize", -1)) != window_size:
            raise Step2ValidationError("manifest watchWindowSize differs from CSV")
        if int(defence.get("watchMinimumAnomalies", -1)) != minimum_anomalies:
            raise Step2ValidationError("manifest watchMinimumAnomalies differs from CSV")

    return {
        "nodes": nodes, "attackerCount": attacker_count, "pdr": pdr,
        "screeningEnabled": screening, "watchCount": watch_count,
        "watchTP": watch_tp, "watchFP": watch_fp,
        "watchTPCurrent": watch_tp_current, "watchFPCurrent": watch_fp_current,
        "watchWindowSize": window_size, "watchMinimumAnomalies": minimum_anomalies,
        "watchAnomalyFraction": anomaly_fraction, "watchExpiry_s": expiry_seconds,
    }


def _parse_arguments(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--csv", required=True, type=Path)
    parser.add_argument("--manifest", type=Path, default=None)
    parser.add_argument("--expect-frozen-scenario", action="store_true",
                        help="require nodes=30, area=600, maxRange=200 (the STEP 1 freeze)")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        summary = validate(arguments.csv, arguments.manifest,
                           expect_frozen_scenario=arguments.expect_frozen_scenario)
    except Step2ValidationError as error:
        print(f"STEP 2 validation FAIL: {error}", file=sys.stderr)
        return 1
    print(
        "STEP 2 validation PASS: "
        f"{arguments.csv} (attackers={summary['attackerCount']}, PDR={summary['pdr']:.6f}, "
        f"screening={summary['screeningEnabled']}, watchCount={summary['watchCount']}, "
        f"TP={summary['watchTP']}, FP={summary['watchFP']})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
