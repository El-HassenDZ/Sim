#!/usr/bin/env python3
"""Standard-library unit tests for calibrate_step01.py (no ns-3 required).

The focus is the hop-count measurement that replaced the refuted delay proxy.
That replacement only improves the calibration if the estimator is right about
the two things that actually broke in practice: the FlowMonitor XML structure,
and what to do when the measurement is unavailable.
"""

from __future__ import annotations

import math
import tempfile
import unittest
from pathlib import Path

import calibrate_step01 as c


class MeanHopsTests(unittest.TestCase):
    """The estimator must survive the real XML shape, and fail closed otherwise."""

    def _write(self, text: str) -> Path:
        path = Path(tempfile.mkdtemp()) / "fm.xml"
        path.write_text(text, encoding="utf-8")
        return path

    def test_classifier_flows_are_not_counted(self):
        """<Flow> exists in BOTH FlowStats and Ipv4FlowClassifier.

        Iterating the whole document mixes classifier entries (addresses only,
        no counters) into the statistics and crashes or corrupts the estimate.
        This is the concrete bug that produced a TypeError in practice, so it is
        pinned here rather than left to code review.
        """
        path = self._write(
            '<FlowMonitor><FlowStats>'
            '<Flow flowId="1" rxPackets="100" timesForwarded="150"/>'
            '</FlowStats><Ipv4FlowClassifier>'
            '<Flow flowId="1" sourceAddress="10.1.0.1" destinationAddress="10.1.0.9"/>'
            '</Ipv4FlowClassifier></FlowMonitor>'
        )
        self.assertAlmostEqual(c.mean_hops_from_flowmonitor(path), 2.5)

    def test_small_flows_are_excluded(self):
        """AODV control traffic must not dilute the data-flow hop count."""
        path = self._write(
            '<FlowMonitor><FlowStats>'
            '<Flow flowId="1" rxPackets="100" timesForwarded="100"/>'
            '<Flow flowId="2" rxPackets="10" timesForwarded="900"/>'
            '</FlowStats></FlowMonitor>'
        )
        self.assertAlmostEqual(c.mean_hops_from_flowmonitor(path), 2.0)

    def test_single_hop_network_reads_as_one(self):
        """A network with no relaying must report exactly 1 hop, not 0."""
        path = self._write(
            '<FlowMonitor><FlowStats>'
            '<Flow flowId="1" rxPackets="500" timesForwarded="0"/>'
            '</FlowStats></FlowMonitor>'
        )
        self.assertAlmostEqual(c.mean_hops_from_flowmonitor(path), 1.0)

    def test_unmeasurable_cases_are_nan_never_zero(self):
        """Fail closed: a missing measurement is NaN, never a fabricated number."""
        no_attribute = self._write(
            '<FlowMonitor><FlowStats><Flow flowId="1" rxPackets="100"/>'
            '</FlowStats></FlowMonitor>'
        )
        no_flow = self._write('<FlowMonitor><FlowStats/></FlowMonitor>')
        no_stats = self._write('<FlowMonitor/>')
        malformed = self._write('<FlowMonitor><FlowStats>')
        for path in (no_attribute, no_flow, no_stats, malformed):
            self.assertTrue(math.isnan(c.mean_hops_from_flowmonitor(path)))
        self.assertTrue(math.isnan(c.mean_hops_from_flowmonitor(Path("/nonexistent.xml"))))


class HopCorrectionTests(unittest.TestCase):
    """The raw estimator is inflated by loss; the correction must remove that."""

    @staticmethod
    def _summary(raw_hops: float, pdr: float) -> c.NodeSummary:
        summary = c.NodeSummary(nodes=30)
        for seed in (1, 2):
            summary.seeds.append(seed)
            summary.baseline_pdr.append(pdr)
            summary.attack_pdr.append(pdr / 2)
            summary.baseline_delay.append(0.006)
            summary.baseline_hops.append(raw_hops)
            summary.attack_drops.append(500)
        return summary

    def test_lossless_run_is_unchanged(self):
        """With no loss there is no inflation term, so nothing to correct."""
        self.assertAlmostEqual(self._summary(2.50, 1.0).hops_corrected(), 2.50)

    def test_heavy_loss_collapses_an_apparently_multi_hop_value(self):
        """Real case from the sweep: PDR 0.074 reported 4.02 raw hops.

        Almost all of that was the inflation term. Judging on the raw value
        would have selected the worst-delivering scenario in the sweep.
        """
        corrected = self._summary(4.02, 0.074).hops_corrected()
        self.assertLess(corrected, 1.5)

    def test_correction_is_monotone_in_loss(self):
        """More loss at the same raw value must correct further downward."""
        low = self._summary(2.40, 0.90).hops_corrected()
        high = self._summary(2.40, 0.50).hops_corrected()
        self.assertGreater(low, high)

    def test_unusable_inputs_are_nan(self):
        self.assertTrue(math.isnan(self._summary(float("nan"), 0.9).hops_corrected()))
        self.assertTrue(math.isnan(self._summary(2.4, 0.0).hops_corrected()))


class SelectHopCriterionTests(unittest.TestCase):
    """Criterion 2 is now the measured hop count, and it must fail closed."""

    @staticmethod
    def _summary(nodes: int, hops: float, baseline: float = 0.95,
                 attack: float = 0.60) -> c.NodeSummary:
        summary = c.NodeSummary(nodes=nodes)
        for seed in (1, 2, 3):
            summary.seeds.append(seed)
            summary.baseline_pdr.append(baseline)
            summary.attack_pdr.append(attack)
            summary.baseline_delay.append(0.006)
            summary.baseline_hops.append(hops)
            summary.attack_drops.append(500)
        return summary

    def test_single_hop_scenario_is_rejected(self):
        """1.6 raw hops is the measured value of the previously frozen scenario."""
        summaries = {30: self._summary(30, hops=1.6)}
        self.assertEqual(
            c.select(summaries, min_baseline=0.80, min_hops=3.0, min_effect=0.05), []
        )

    def test_multi_hop_scenario_is_accepted(self):
        """A genuinely multi-hop scenario must survive the correction.

        baseline 0.95 keeps the inflation term small, so 3.4 raw stays above 3.0
        once corrected -- which is what "genuinely multi-hop" has to mean.
        """
        summaries = {64: self._summary(64, hops=3.4)}
        self.assertEqual(
            c.select(summaries, min_baseline=0.80, min_hops=3.0, min_effect=0.05), [64]
        )

    def test_unmeasured_hops_are_not_multi_hop(self):
        """A scenario whose hop count could not be measured must not be selected.

        Silently treating NaN as passing would let an unverifiable scenario be
        frozen, which is the exact failure mode this criterion exists to prevent.
        """
        summaries = {30: self._summary(30, hops=float("nan"))}
        self.assertEqual(
            c.select(summaries, min_baseline=0.80, min_hops=3.0, min_effect=0.05), []
        )

    def test_raw_multi_hop_from_pure_loss_is_rejected(self):
        """A high raw hop count produced by heavy loss must NOT be selected.

        Without the correction this scenario -- 4.0 raw hops at a 0.25 baseline --
        would look like the best multi-hop candidate in a sweep while actually
        being the one that delivers almost nothing.
        """
        summaries = {84: self._summary(84, hops=4.0, baseline=0.25, attack=0.05)}
        self.assertEqual(
            c.select(summaries, min_baseline=0.20, min_hops=3.0, min_effect=0.05), []
        )

    def test_low_delay_no_longer_blocks_a_multi_hop_scenario(self):
        """The refuted proxy must not veto a scenario the direct measure accepts."""
        summary = self._summary(64, hops=3.4)
        summary.baseline_delay = [0.001, 0.001, 0.001]  # far below the old 10 ms bar
        self.assertEqual(
            c.select({64: summary}, min_baseline=0.80, min_hops=3.0, min_effect=0.05),
            [64],
        )


if __name__ == "__main__":
    unittest.main()
