# STEP 4 — Attribution OCEA en quatre masses (A3.3, Éq. 6–10)

Document de **spécification**, pas d'implémentation. Il fixe le périmètre, les
sources de données, les ambiguïtés non résolues et les critères PASS/FAIL
**avant** que du code soit écrit. À valider avant la livraison suivante.

Source normative : `MTCAODV_Mathematical_Algorithms_Specification.md`,
§ 5.4 et algorithme A3.3. Aucune méthode spécifiée n'est remplacée ici ; les
points laissés ouverts par la spécification sont signalés comme tels, avec leur
marqueur de statut d'origine.

---

## 1. Le fait qui détermine le périmètre

L'observateur livré au STEP 3 ne renseigne **qu'une seule** caractéristique
d'opportunité, `passiveVisibility`. Les cinq indicateurs de perte bénigne
\(y_\ell\) sont tous marqués explicitement indisponibles
(`forwarding-observer.cc`, bloc de commentaire précédant la clôture) :

> `linkReliability`, `predictedContactPersistence`, `mobilityBreak`,
> `queuePressure` et `coherentRerr` exigent respectivement un historique de
> lien, un modèle de contact, la table de voisinage, l'état des files et le flux
> RERR. Aucun n'est câblé à STEP 3.

Or A3.3 ligne 7 : `if d = 0 then return (0,0,0,1)`.

**Conséquence, dérivée et non supposée : sur le run validé au STEP 3, OCEA
renverrait une incertitude totale pour les 10 962 observations.**
\(m_e = b_e = 0\), \(u_e = 1\), aucune attribution.

Ce n'est pas un défaut. C'est le *fail closed* de la spécification qui
fonctionne : une non-observation dont aucune cause bénigne n'est diagnostiquée
ne **peut pas** être attribuée, et remplir une valeur par défaut ferait passer
une observation partielle pour complète — ce que l'Éq. (6) existe précisément
pour empêcher.

**Mais il s'ensuit que « implémenter les Éq. (6)–(10) » ne produirait rien de
mesurable.** Les équations sont une trentaine de lignes arithmétiques. Le
travail réel de STEP 4 est l'**instrumentation des diagnostics** qui les
alimentent. Toute livraison qui présenterait A3.3 seul comme « STEP 4 terminé »
serait une livraison creuse.

---

## 2. Périmètre en trois parties

### Partie A — A3.3 exactement (Éq. 6–10)

Fonction pure, sans ns-3, testable avec des oracles calculés à la main.

| équation | contenu | note d'implémentation |
|---|---|---|
| (6) | \(c_e=\sum_k\omega_k a_k(e)\) | somme des poids **disponibles** |
| (7) | \(O_e=c_e\prod_{k:a_k=1}x_k^{\omega_k a_k/c_e}\) | moyenne géométrique pondérée × couverture |
| (8) | \(d_e=\sum_\ell\nu_\ell a_\ell(e)\), \(\bar B_e=\frac{\sum_\ell\nu_\ell a_\ell y_\ell}{d_e}\) | moyenne arithmétique pondérée |
| (9) | \(z_e=1 \Rightarrow (1,0,0,0)\) | **\(z_e\) seul** — voir § 5 |
| (10) | \(I_e=O_ed_e\); \((0,\,I_e(1-\bar B_e),\,I_e\bar B_e,\,1-I_e)\) | |

Sorties nommées comme la table des variables de la spécification :
`opportunityCoverage`, `forwardingOpportunity`, `diagnosticCoverage`,
`benignLossLikelihood`, `interpretableEvidence`, `positiveEvidenceMass`,
`maliciousEvidenceMass`, `benignLossMass`, `uncertainEvidenceMass`.

### Partie B — Instrumentation des \(x_k\) et \(y_\ell\)

**C'est le corps de l'étape.** Chaque grandeur exige une source distincte, et
chacune pose une question d'observabilité qui doit être tranchée explicitement
plutôt que contournée.

| grandeur | type | source | observable par l'observateur ? |
|---|---|---|---|
| `passiveVisibility` | \(x_k\) | déjà mesuré (STEP 3) | **oui**, directement |
| `linkReliability` | \(x_k\) | historique des émissions de \(i\) vers \(j\) | **oui**, local à \(i\) |
| `predictedContactPersistence` | \(x_k\) | modèle de contact | **non** — voir § 3 |
| `mobilityBreak` | \(y_\ell\) | table de voisinage AODV de \(i\) | **oui**, local |
| `coherentRerr` | \(y_\ell\) | flux RERR reçu par \(i\) | **oui**, local |
| `queuePressure` | \(y_\ell\) | état des files | **non** — voir § 3 |

### Partie C — Calibration de \(\omega_k\) et \(\nu_\ell\)

Les deux jeux de poids sont marqués **À confirmer C-05** dans la spécification :
ils ne sont pas gelés. Ils doivent être calibrés, et la calibration doit se faire
sur des **seeds distincts** de ceux de l'évaluation. Cette partie n'est pas
livrable dans la même livraison que B, faute de données pour la conduire.

---

## 3. La tension d'observabilité, énoncée et non contournée

Deux grandeurs de la spécification décrivent l'état du **voisin**, que
l'observateur ne peut pas voir :

- **`queuePressure`** : la file pertinente pour expliquer une non-retransmission
  est celle de \(j\), pas celle de \(i\). \(i\) n'y a aucun accès en MANET réel.
- **`predictedContactPersistence`** : prédire la persistance du contact suppose
  un modèle de mobilité de \(j\). Lire `MobilityModel` de \(j\) dans ns-3 donnerait
  un résultat qu'aucun nœud réel ne pourrait obtenir.

Trois issues possibles, à trancher par vous :

1. **Proxy local honnête** — \(i\) substitue sa propre grandeur (sa file, sa
   propre persistance de contact estimée depuis ses propres réceptions). Faible
   mais réaliste et implémentable. Le proxy doit être **nommé comme tel** dans
   le code et dans tout texte publié.
2. **Grandeur déclarée indisponible** — \(a_\ell(e)=0\) en permanence. L'Éq. (8)
   sait le traiter : la couverture diagnostique baisse, l'incertitude monte.
   C'est le choix le plus conservateur et le plus défendable scientifiquement.
3. **Lecture directe de l'état de \(j\)** — techniquement trivial en simulation,
   **scientifiquement invalide** : ce serait une information qu'un nœud réel ne
   possède pas. Ce n'est pas une « connaissance oracle » au sens de la liste des
   attaquants, mais c'est la même faute de méthode.

**Ma recommandation : (2) pour `predictedContactPersistence`, (1) pour
`queuePressure` avec le proxy explicitement nommé.** Justification : la
persistance de contact n'a aucun proxy local crédible, alors que la pression de
file locale de \(i\) est corrélée à la congestion du voisinage partagé — support
faible, mais non nul, et mesurable.

---

## 4. Points laissés ouverts par la spécification

| point | statut d'origine | ce qu'il faut trancher |
|---|---|---|
| \(\omega_k,\nu_\ell\) | **À confirmer C-05** | valeurs et liste des features |
| \(\varepsilon\) | **À confirmer C-06** | A3.3 le liste en paramètre, mais le pseudocode ne l'utilise pas. Rôle le plus plausible : plancher sur \(x_k\) pour éviter \(\ln 0\) dans l'Éq. (7). **Non tranché ici.** |

### Le zéro annihilant de l'Éq. (7)

Si une seule caractéristique disponible vaut \(x_k = 0\), le produit
géométrique s'annule, donc \(O_e = 0\), donc \(I_e = 0\), donc masse
entièrement incertaine — **quelles que soient les autres caractéristiques**.

Sur les données du STEP 3, `passiveVisibility` est binaire : un voisin non
entendu dans la fenêtre donne \(x=0\). Tant qu'elle est la seule caractéristique
disponible, **toute non-observation d'un voisin silencieux est non
interprétable**. C'est cohérent (on ne sait rien d'un nœud dont on n'entend
rien), mais il faut mesurer quelle fraction des événements tombe dans ce cas
avant de conclure quoi que ce soit.

Implémentation numérique : calculer via \(\exp\left(\sum \frac{\omega_k}{c_e}\ln
x_k\right)\) exige de traiter \(x_k=0\) explicitement — retour anticipé à 0,
jamais un \(\ln\) de zéro laissé à l'arithmétique flottante.

---

## 5. Le finding hérité du STEP 3, et son traitement

L'Éq. (9) accorde \((1,0,0,0)\) — évidence positive **complète** — dès que
\(z_e=1\). Or le STEP 3 a mesuré que **1 272 des 6 739 événements concernant un
attaquant (18,9 %) présentent \(z_e=1\) avec une attribution nulle** : la
retransmission entendue provenait d'un **tiers**, pas de l'attaquant.

Sous l'Éq. (9) telle que spécifiée, ces 1 272 événements créditent l'attaquant
d'une évidence positive complète.

**Traitement retenu :** implémenter l'Éq. (9) telle que spécifiée. Le champ
`senderAttributedToNeighbor` étant déjà enregistré à chaque événement, STEP 4
**rapportera en parallèle** les masses qu'on obtiendrait sous la conjonction
\(z_e \wedge \text{attribué}\), en diagnostic séparé. Implémenter la
spécification, instrumenter l'alternative, mesurer l'écart. Aucune substitution
silencieuse, aucun finding enterré.

La spécification se garde elle-même par la locution « **dans la formalisation
actuelle** », qui a valeur de marqueur de statut.

---

## 6. Critères PASS / FAIL préenregistrés

**PASS exige les six :**

1. **T-13 (test prescrit par la spécification)** : sur une grille de valeurs,
   toutes les masses dans \([0,1]\) et \(g+m+b+u = 1\) à la tolérance
   numérique près.
2. **Fail closed vérifié** : \(c_e=0 \Rightarrow (0,0,0,1)\) et
   \(d_e=0 \Rightarrow (0,0,0,1)\), testés explicitement.
3. **Oracles calculés à la main** : au moins trois cas d'attribution complets
   vérifiés hors machine avant encodage, comme pour `packet-fingerprint`.
4. **Non-intrusion préservée** : `PDR` inchangé au chiffre près par rapport au
   STEP 3, même seed. OCEA ne fait qu'attribuer.
5. **Non-régression** : les 11 suites du STEP 3 restent vertes, `src/aodv/`
   toujours intact.
6. **Couverture diagnostique non nulle mesurée** : la fraction d'événements
   avec \(d_e>0\) est **rapportée**, et si elle vaut 0, l'étape est déclarée
   **FAIL** — l'instrumentation de la partie B n'aurait alors rien apporté.

**Rapporté sans seuil** (aucune valeur n'est prédictible) : la distribution des
quatre masses chez un voisin honnête et chez un attaquant, la fraction
d'événements non interprétables, et l'écart entre l'Éq. (9) spécifiée et la
variante avec attribution.

**FAIL :** une masse hors \([0,1]\) ; une somme différente de 1 ;
une valeur par défaut substituée à une caractéristique indisponible ; la
lecture de l'état interne d'un voisin ; toute utilisation de la liste des
attaquants hors évaluation hors ligne.

---

## 7. Ce que STEP 4 ne fera PAS

- **Pas de MOBeta-Trust.** Les Éq. (11)–(12) et le posterior Beta
  \((\alpha_{ij},\beta_{ij})\) consomment les masses OCEA ; ils constituent
  l'étape suivante, pas celle-ci.
- **Pas de calibration finale de \(\omega,\nu\).** Elle exige des seeds
  distincts et vient après l'instrumentation.
- **Pas de changement de machine à états.** WATCH reste une surveillance
  renforcée, ACCUSED n'est pas une quarantaine, QUARANTINED exige un certificat.
- **Pas de correction de `IsBroadcast()`** (faiblesse enregistrée au STEP 3) :
  sans effet sur ce périmètre, à traiter avant tout scénario multicast.
