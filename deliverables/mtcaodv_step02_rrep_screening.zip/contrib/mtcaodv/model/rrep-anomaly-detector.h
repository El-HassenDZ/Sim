/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * This file is part of the MTC-AODV research prototype.
 *
 * STEP 2 — Robust RREP anomaly screening (specification Section 5.3,
 * Algorithm A3.1, Equations (3)-(5)).  This class is deliberately a plain C++
 * class (no ns3::Object): it owns no simulator lifecycle and is pure, so it can
 * be unit-tested against the numerical oracle for Eq. (3)-(5).  The forked
 * RoutingProtocol owns one instance and exposes its parameters as Attributes.
 *
 * Scientific-integrity boundary: this detector consumes ONLY the header values
 * and arrival times of protocol-valid RREPs.  It never receives the attacker
 * ground truth; it produces a suspicion score, nothing more.  A high score
 * authorises WATCH only — never a route exclusion (Invariant 20.2.1).
 */

#ifndef MTC_AODV_RREP_ANOMALY_DETECTOR_H
#define MTC_AODV_RREP_ANOMALY_DETECTOR_H

#include <cstdint>
#include <vector>

namespace ns3
{
namespace mtcaodv
{

/**
 * @ingroup mtcaodv
 * @brief One protocol-valid RREP observed during a route discovery.
 *
 * These are the only observables the screening uses.  @a sequenceNumber is the
 * advertised destination sequence number (32-bit AODV serial-number space);
 * @a hopCount the advertised distance in hops; @a arrivalTimeSeconds the local
 * reception instant used for the earliness anomaly.
 */
struct RrepCandidate
{
    uint32_t sequenceNumber{0};      //!< Advertised destination sequence number.
    uint8_t hopCount{0};             //!< Advertised hop count.
    double arrivalTimeSeconds{0.0};  //!< Local reception time, in seconds.
};

/**
 * @ingroup mtcaodv
 * @brief Calibrated parameters of the RREP screening (all "À confirmer").
 *
 * Every value is a pilot default, NOT a frozen confirmatory parameter
 * (specification Annex C, C-01..C-06).  Weights and bias are calibrated on
 * separate scenarios before any confirmatory claim.
 */
struct RrepAnomalyParameters
{
    /** @brief Minimum comparable RREPs @f$n_R^{min}@f$ (>= 2). Below this, no score. */
    uint32_t minimumComparableReplies{2};
    /** @brief Weight @f$w_s@f$ of the freshness anomaly. */
    double sequenceWeight{1.0};
    /** @brief Weight @f$w_h@f$ of the low-hop anomaly. */
    double hopWeight{1.0};
    /** @brief Weight @f$w_t@f$ of the earliness anomaly. */
    double timingWeight{0.5};
    /** @brief Logistic bias @f$b_R@f$. */
    double logisticBias{2.0};
    /** @brief Strictly positive numerical stabiliser @f$\varepsilon@f$. */
    double epsilon{1e-6};
};

/**
 * @ingroup mtcaodv
 * @brief Result of scoring one candidate against a comparable set.
 *
 * @a available is false when fewer than @f$n_R^{min}@f$ comparable RREPs exist
 * (decision D-07): the caller must NOT treat this as a score of zero
 * (specification C-16 — absence of comparison is not observed normality).
 */
struct RrepAnomalyResult
{
    bool available{false};          //!< True only when a comparative score exists.
    double sequenceAnomaly{0.0};    //!< @f$z_s@f$, Eq. (3).
    double hopAnomaly{0.0};         //!< @f$z_h@f$, Eq. (4a).
    double timingAnomaly{0.0};      //!< @f$z_t@f$, Eq. (4b).
    double anomalyScore{0.0};       //!< @f$A_{RREP}\in[0,1]@f$, Eq. (5).
};

/**
 * @ingroup mtcaodv
 * @brief Robust, wrap-around-aware RREP anomaly screening (Algorithm A3.1).
 */
class RrepAnomalyDetector
{
  public:
    /** @brief Construct with default (pilot) parameters. */
    RrepAnomalyDetector() = default;

    /** @brief Construct with explicit parameters. */
    explicit RrepAnomalyDetector(const RrepAnomalyParameters& parameters);

    /** @brief Replace the calibrated parameters. */
    void SetParameters(const RrepAnomalyParameters& parameters);

    /** @brief Return the current calibrated parameters. */
    const RrepAnomalyParameters& GetParameters() const;

    /**
     * @brief Score one candidate against the comparable set (Eq. (3)-(5)).
     * @param candidates The comparable set @f$\mathcal R_r@f$ for this discovery.
     * @param evaluatedIndex Index in @p candidates of the RREP being scored.
     * @return A result whose @c available is false when
     *         @f$|\mathcal R_r|<n_R^{min}@f$; otherwise the anomalies and
     *         @f$A_{RREP}\in[0,1]@f$.
     *
     * The sequence anomaly (Eq. 3) uses the AODV modular serial-number order:
     * differences are taken as signed 32-bit values relative to a reference,
     * so a forged sequence number that has wrapped past @f$2^{32}@f$ is still
     * recognised as "fresher", unlike a naive unsigned subtraction (test T-10).
     */
    RrepAnomalyResult Score(const std::vector<RrepCandidate>& candidates,
                            std::size_t evaluatedIndex) const;

    // ---- Building blocks, exposed for unit testing --------------------------

    /**
     * @brief Median of a sample.
     * @param values Non-empty sample (a copy is sorted internally).
     * @return The median; for an even count, the mean of the two central values.
     */
    static double Median(std::vector<double> values);

    /**
     * @brief Median absolute deviation @f$\operatorname{MAD}(X)@f$.
     * @param values Non-empty sample.
     * @return @f$\operatorname{med}(|X-\operatorname{med}(X)|)@f$.
     */
    static double MedianAbsoluteDeviation(const std::vector<double>& values);

    /**
     * @brief Signed 32-bit interpretation of an unsigned difference.
     * @param unsignedDifference @f$(a-b)\bmod 2^{32}@f$ as a uint32.
     * @return The value mapped into @f$[-2^{31},2^{31})@f$ — the AODV freshness
     *         order, so a small positive result means "a is fresher than b".
     */
    static int64_t SignedSequenceDelta(uint32_t unsignedDifference);

  private:
    RrepAnomalyParameters m_parameters; //!< Calibrated screening parameters.
};

} // namespace mtcaodv
} // namespace ns3

#endif // MTC_AODV_RREP_ANOMALY_DETECTOR_H
