#!/usr/bin/env python3
"""Calibrate the STEP 1 multiple-Blackhole pilot scenario.

Problem this solves
-------------------
The 20-node / 300 m pilot cannot be simultaneously well-connected and
multi-hop: at long radio range the network is single-hop and the Blackhole
attack has no measurable effect on PDR; at short range the network partitions
and the *healthy* baseline PDR collapses and swings wildly by seed.  Choosing a
"good-looking" seed to hide that is scientifically invalid (it measures
disconnection, not attack).

This tool sweeps node count (and optionally area / range), runs REAL paired
no-attack vs attack ns-3.48 simulations for several seeds, aggregates the
results, and selects the (nodes, area, maxRange) triple that satisfies three
pre-registered criteria at once:

  1. Baseline (no-attack) PDR is healthy on EVERY seed (min > --min-baseline),
     so the scenario is not silently partitioned for some seeds.
  2. The baseline is genuinely multi-hop (mean hop count > --min-hops), so
     relays — and therefore Blackholes on the path — actually matter.

     REVISED after measurement. This criterion used to be "mean end-to-end
     delay > --min-delay". That proxy is refuted: at the same seed, the SPARSER
     scenario (600 m, 1.60 hops) showed a LOWER delay (6.7 ms) than the denser
     one (350 m, 1.25 hops, 8.0 ms). If delay tracked hop count that ordering is
     impossible. Two confounders explain it: contention (a dense 802.11b ad-hoc
     network inflates queueing delay regardless of path length) and survivorship
     bias (delay is measured only over DELIVERED packets, and long paths lose
     more). The delay is still reported for the record, but the criterion is now
     evaluated on the directly measured hop count.

     The verdict of the old criterion was nevertheless correct: both scenarios
     failed it, and the direct measurement confirms both are near-single-hop.
     The proxy was replaced, the requirement was NOT relaxed.
  3. The attack degrades delivery consistently: mean PDR drop > --min-effect
     AND attack PDR < baseline PDR on every seed.

No number is fabricated: a failed or non-finite run is reported and excluded,
never replaced by zero.  The tool only *reads* what ns-3 actually produced.

It shells out to `./ns3 run "mtcaodv-pilot-attack ..."` with per-run output
paths (so runs never clobber each other) and parses the pilot's own CSV.

Standard library only.
"""

from __future__ import annotations

import argparse
import csv
import math
import statistics
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
import xml.etree.ElementTree as ElementTree
from pathlib import Path
from typing import Sequence


# ----------------------------------------------------------------------------
# Data model
# ----------------------------------------------------------------------------
@dataclass(frozen=True)
class RunOutcome:
    """One executed simulation (one node count, one seed, attack on/off)."""

    nodes: int
    seed: int
    attack: bool
    ok: bool
    pdr: float = float("nan")
    mean_delay_s: float = float("nan")
    forged: int = 0
    drops: int = 0
    attacker_count: int = 0
    app_tx: int = 0
    app_rx: int = 0
    mean_hops: float = float("nan")
    #: Delivery ratio of the SAME flow set mean_hops was computed over. Kept
    #: separate from `pdr` (which comes from the pilot's CSV) so the loss
    #: correction cannot be applied with a ratio from a different sample.
    flow_delivery: float = float("nan")
    area: float = float("nan")
    max_speed: float = float("nan")
    error: str = ""


@dataclass
class NodeSummary:
    """Aggregated paired result for one node count over all seeds."""

    nodes: int
    #: Area this node count was run at. With --scenarios each node count has its
    #: own area, so it cannot be read off a single global argument any more.
    area: float = float("nan")
    #: Maximum node speed, swept independently of the geometry.
    max_speed: float = float("nan")
    seeds: list[int] = field(default_factory=list)
    baseline_pdr: list[float] = field(default_factory=list)
    attack_pdr: list[float] = field(default_factory=list)
    baseline_delay: list[float] = field(default_factory=list)
    baseline_hops: list[float] = field(default_factory=list)
    baseline_flow_delivery: list[float] = field(default_factory=list)
    attack_drops: list[int] = field(default_factory=list)
    failures: int = 0

    # --- derived, healthy-only helpers -------------------------------------
    def _finite(self, xs: Sequence[float]) -> list[float]:
        return [x for x in xs if math.isfinite(x)]

    def baseline_min(self) -> float:
        vals = self._finite(self.baseline_pdr)
        return min(vals) if vals else float("nan")

    def baseline_mean(self) -> float:
        vals = self._finite(self.baseline_pdr)
        return statistics.fmean(vals) if vals else float("nan")

    def baseline_std(self) -> float:
        vals = self._finite(self.baseline_pdr)
        return statistics.pstdev(vals) if len(vals) > 1 else 0.0

    def attack_mean(self) -> float:
        vals = self._finite(self.attack_pdr)
        return statistics.fmean(vals) if vals else float("nan")

    def delay_mean(self) -> float:
        vals = self._finite(self.baseline_delay)
        return statistics.fmean(vals) if vals else float("nan")

    def hops_corrected(self) -> float:
        """Hop count corrected for the loss-inflation of the raw estimator.

        The raw FlowMonitor estimate decomposes exactly as

            hops_est = mean_hops_delivered + (lost / delivered) * mean_forwards_of_lost

        because ``timesForwarded`` counts relays of every packet while
        ``rxPackets`` counts only the delivered ones. The second term is pure
        inflation and it grows without bound as delivery falls: measured on this
        project's own sweep, one seed with PDR = 0.074 reported 4.02 hops, of
        which essentially all was inflation.

        Assuming lost packets travelled about as far as delivered ones before
        dying (``mean_forwards_of_lost ~= h - 1``) gives

            h = (hops_est + L/D) / (1 + L/D),      L/D = (1 - pdr) / pdr

        STATED ASSUMPTION, AND ITS DIRECTION. Lost packets plausibly travelled
        FURTHER than delivered ones — that is often why they were lost — in
        which case the inflation is larger and the true hop count is even lower.
        This correction is therefore itself an UPPER BOUND, and a scenario that
        fails the multi-hop criterion under it fails conclusively.

        Returns:
            Corrected mean hop count, or NaN when either input is unavailable.
        """
        raw = self.hops_mean()
        # SELF-CONSISTENCY: the delivery ratio must describe exactly the flows
        # the hop count was measured over. Using the pilot's CSV PDR here would
        # mix two samples whenever the two disagree about which flows count.
        delivered = self._finite(self.baseline_flow_delivery)
        if not delivered:
            return float("nan")
        ratio = statistics.fmean(delivered)
        if not (math.isfinite(raw) and math.isfinite(ratio)) or ratio <= 0.0:
            return float("nan")
        loss_ratio = (1.0 - ratio) / ratio
        return (raw + loss_ratio) / (1.0 + loss_ratio)

    def hops_mean(self) -> float:
        """Mean baseline hop count. NaN when no run yielded a usable estimate.

        Fail closed: a scenario whose hop count could not be measured is NOT
        treated as multi-hop by default; select() rejects a NaN.
        """
        vals = self._finite(self.baseline_hops)
        return statistics.fmean(vals) if vals else float("nan")

    def effect_mean(self) -> float:
        return self.baseline_mean() - self.attack_mean()

    def seeds_with_effect(self) -> int:
        """Count seeds where attack PDR is strictly below baseline PDR."""
        count = 0
        for base, atk in zip(self.baseline_pdr, self.attack_pdr):
            if math.isfinite(base) and math.isfinite(atk) and atk < base:
                count += 1
        return count


# ----------------------------------------------------------------------------
# Pure aggregation / selection (unit-testable without ns-3)
# ----------------------------------------------------------------------------
#: A calibration cell is identified by everything that was varied, not by the
#: node count alone. Keying on nodes was fine while only nodes changed; once
#: area and speed are swept too, distinct configurations would silently collide
#: into one summary and produce a meaningless average.
ConfigKey = tuple[int, float, float]  # (nodes, area, max_speed)


def config_label(key: ConfigKey) -> str:
    """Readable identifier for one calibration cell."""
    nodes, area, max_speed = key
    return f"n{nodes}_L{area:g}_v{max_speed:g}"


def aggregate(outcomes: Sequence[RunOutcome]) -> dict[ConfigKey, NodeSummary]:
    """Group paired outcomes by configuration, aligning attack/no-attack by seed."""

    by_config: dict[ConfigKey, NodeSummary] = {}
    index: dict[tuple[ConfigKey, int, bool], RunOutcome] = {}
    config_seeds: dict[ConfigKey, list[int]] = {}
    for outcome in outcomes:
        key: ConfigKey = (outcome.nodes, outcome.area, outcome.max_speed)
        index[(key, outcome.seed, outcome.attack)] = outcome
        config_seeds.setdefault(key, [])
        if outcome.seed not in config_seeds[key]:
            config_seeds[key].append(outcome.seed)

    for key, seeds in config_seeds.items():
        nodes, area, max_speed = key
        summary = NodeSummary(nodes=nodes, area=area, max_speed=max_speed)
        for seed in sorted(seeds):
            base = index.get((key, seed, False))
            atk = index.get((key, seed, True))
            if base is None or atk is None or not base.ok or not atk.ok:
                summary.failures += 1
                continue
            summary.seeds.append(seed)
            summary.baseline_pdr.append(base.pdr)
            summary.attack_pdr.append(atk.pdr)
            summary.baseline_delay.append(base.mean_delay_s)
            summary.baseline_hops.append(base.mean_hops)
            summary.baseline_flow_delivery.append(base.flow_delivery)
            summary.attack_drops.append(atk.drops)
        by_config[key] = summary
    return by_config


def select(
    summaries: dict[ConfigKey, NodeSummary],
    *,
    min_baseline: float,
    min_hops: float,
    min_effect: float,
) -> list[ConfigKey]:
    """Return configurations meeting all three pre-registered criteria, best first.

    "Best" is ordered by (all seeds show the effect, larger mean effect, higher
    baseline min) so the most convincing scenario surfaces first.
    """

    winners: list[ConfigKey] = []
    for key, summary in summaries.items():
        if not summary.seeds:
            continue
        healthy = summary.baseline_min() > min_baseline
        # Fail closed: an unmeasurable hop count (NaN) is NOT multi-hop.
        # NaN > x is False in Python, which is the behaviour we want here, but
        # it is stated explicitly so the intent survives a refactor.
        # The CORRECTED value is used, not the raw one. The raw estimate is
        # inflated in proportion to packet loss, so judging on it would reward
        # exactly the scenarios that deliver worst -- the opposite of the intent.
        hops = summary.hops_corrected()
        multihop = math.isfinite(hops) and hops > min_hops
        effective = (
            summary.effect_mean() > min_effect
            and summary.seeds_with_effect() == len(summary.seeds)
        )
        if healthy and multihop and effective:
            winners.append(key)

    winners.sort(
        key=lambda k: (
            summaries[k].seeds_with_effect() == len(summaries[k].seeds),
            summaries[k].effect_mean(),
            summaries[k].baseline_min(),
        ),
        reverse=True,
    )
    return winners


#: UDP destination port of the pilot's data flows. Must match
#: APPLICATION_DESTINATION_PORT in mtcaodv-pilot-attack.cc: the hop estimate has
#: to be computed over exactly the flows the pilot counts as useful data, or the
#: two disagree about what "the traffic" is.
APPLICATION_DESTINATION_PORT = 9000


def mean_hops_from_flowmonitor(
    path: Path, destination_port: int = APPLICATION_DESTINATION_PORT
) -> float:
    """Estimate the mean hop count of data packets from a FlowMonitor XML.

    Why this exists
    ---------------
    The scenario must be genuinely multi-hop, otherwise a Blackhole has almost
    no on-path position to occupy and a forwarding observer (STEP 3) has almost
    nothing to observe. The end-to-end delay was used as a proxy for that and is
    refuted (see the module docstring), so the hop count is measured instead.

    Identifying the data flows
    --------------------------
    Flows are selected by DESTINATION PORT, exactly as the pilot's own
    throughput calculation does. An earlier version selected them by reception
    count (``rxPackets > 50``), which silently dropped the flows that failed --
    precisely the ones that carry the information about a partitioned network.
    Measured consequence of that bug: on one run the pilot reported PDR 0.293
    while the estimator, seeing only the surviving flow, reported 1.000 and a
    hop count of 1.00. Selecting on the port keeps dead flows in the sample.

    Method and its bias
    -------------------
    FlowMonitor increments ``timesForwarded`` once per intermediate relay, so
    across the retained flows

        hops_est = timesForwarded / rxPackets + 1
                 = mean_hops_delivered + (lost/delivered) * mean_forwards_of_lost

    The second term is inflation, removed by :meth:`NodeSummary.hops_corrected`.
    The delivery ratio used for that correction must be computed over THE SAME
    flow set, which is why this function and the correction now agree on what
    the data flows are.

    Args:
        path: FlowMonitor XML written by the pilot.
        destination_port: UDP port identifying the data flows.

    Returns:
        Mean hop count over the data flows, or NaN when the file is unreadable,
        has no FlowStats, lacks ``timesForwarded``, or matches no flow. NaN is
        never silently turned into a number.
    """
    forwarded, received, _sent = _flow_totals(path, destination_port)
    if received == 0:
        return float("nan")
    return forwarded / received + 1.0


def delivery_ratio_from_flowmonitor(
    path: Path, destination_port: int = APPLICATION_DESTINATION_PORT
) -> float:
    """Delivery ratio of the SAME data flows the hop estimate is computed over.

    The loss correction is only self-consistent when its delivery ratio comes
    from the identical flow set; taking it from elsewhere over- or
    under-corrects. Returns NaN when nothing was sent.
    """
    _forwarded, received, sent = _flow_totals(path, destination_port)
    if sent == 0:
        return float("nan")
    return received / sent


def _flow_totals(path: Path, destination_port: int) -> tuple[int, int, int]:
    """Sum (timesForwarded, rxPackets, txPackets) over the data flows.

    Returns (0, 0, 0) when the file is unusable, so callers produce NaN rather
    than a fabricated number.
    """
    try:
        root = ElementTree.parse(path).getroot()
    except (OSError, ElementTree.ParseError):
        return (0, 0, 0)
    # <Flow> appears BOTH under <FlowStats> (packet counters) and under
    # <Ipv4FlowClassifier> (the five-tuple). The port lives in the classifier
    # and the counters in the stats, so the two must be joined on flowId --
    # iterating the whole document instead would mix them.
    stats = root.find("FlowStats")
    classifier = root.find("Ipv4FlowClassifier")
    if stats is None or classifier is None:
        return (0, 0, 0)
    data_flow_ids = set()
    for entry in classifier.findall("Flow"):
        port = entry.get("destinationPort")
        flow_id = entry.get("flowId")
        if port is None or flow_id is None:
            continue
        try:
            if int(port) == destination_port:
                data_flow_ids.add(flow_id)
        except ValueError:
            continue
    forwarded = received = sent = 0
    for flow in stats.findall("Flow"):
        if flow.get("flowId") not in data_flow_ids:
            continue
        raw = (flow.get("timesForwarded"), flow.get("rxPackets"), flow.get("txPackets"))
        if any(value is None for value in raw):
            continue
        try:
            fw, rx, tx = (int(value) for value in raw)
        except ValueError:
            continue
        forwarded += fw
        received += rx
        sent += tx
    return (forwarded, received, sent)


# ----------------------------------------------------------------------------
# ns-3 execution
# ----------------------------------------------------------------------------
def run_one(
    ns3_dir: Path,
    exe: str,
    tmpdir: Path,
    *,
    nodes: int,
    seed: int,
    attack: bool,
    area: float,
    max_range: float,
    ratio: float,
    attack_start: float,
    sim_time: float,
    min_speed: float,
    max_speed: float,
    run: int,
    timeout_s: int,
    flow_count: int,
    data_rate: str,
) -> RunOutcome:
    """Execute one ns-3 pilot run and parse its CSV. Never fabricates numbers."""

    # The tag must contain EVERY swept dimension. With area and speed now swept,
    # a tag of only (nodes, seed, attack) would make two different runs write to
    # the same paths -- and since the CSV is read back after the run, a failed
    # run would silently be scored using the previous run's file.
    tag = (f"n{nodes}_L{area:g}_v{max_speed:g}_s{seed}_"
           f"{'atk' if attack else 'base'}")
    csv_path = tmpdir / f"{tag}.csv"
    man_path = tmpdir / f"{tag}.json"
    fm_path = tmpdir / f"{tag}.xml"
    effective_ratio = ratio if attack else 0.0

    program_args = (
        f"{exe} --nodes={nodes} --simTime={sim_time} --minSpeed={min_speed} "
        f"--maxSpeed={max_speed} --areaSize={area} --maxRange={max_range} "
        f"--attackerRatio={effective_ratio} --attackStart={attack_start} "
        f"--seed={seed} --run={run} "
        # Traffic sampling is part of the measurement instrument, not a detail:
        # PDR is a mean over flow_count source-destination pairs, so it is
        # quantised in units of 1/flow_count and its sampling error scales as
        # 1/sqrt(flow_count). At the previous default of 4 flows the quantum was
        # 0.25 -- larger than most of the differences the sweep was trying to
        # resolve. Both values are passed explicitly so a sweep cannot silently
        # compare scenarios measured with different instruments.
        f"--flowCount={flow_count} --dataRate={data_rate} "
        f"--outputCsv={csv_path} --outputManifest={man_path} --flowMonitorXml={fm_path}"
    )
    try:
        proc = subprocess.run(
            ["./ns3", "run", program_args],
            cwd=str(ns3_dir),
            capture_output=True,
            text=True,
            timeout=timeout_s,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        return RunOutcome(nodes, seed, attack, ok=False, area=area,
                          error=f"launch failed: {error}")

    if proc.returncode != 0 or not csv_path.exists():
        tail = (proc.stderr or proc.stdout or "").strip().splitlines()[-3:]
        return RunOutcome(
            nodes, seed, attack, ok=False, area=area,
            error=" | ".join(tail) or "no CSV produced"
        )

    try:
        with csv_path.open("r", encoding="utf-8", newline="") as handle:
            row = next(csv.DictReader(handle))
    except (OSError, StopIteration, csv.Error) as error:
        return RunOutcome(nodes, seed, attack, ok=False, area=area,
                          error=f"CSV parse: {error}")

    def as_float(name: str) -> float:
        try:
            return float(row[name])
        except (KeyError, ValueError):
            return float("nan")

    def as_int(name: str) -> int:
        try:
            return int(row[name])
        except (KeyError, ValueError):
            return 0

    return RunOutcome(
        nodes=nodes,
        seed=seed,
        attack=attack,
        ok=True,
        pdr=as_float("pdr"),
        mean_delay_s=as_float("meanDelay_s"),
        forged=as_int("forgedRrepCount"),
        drops=as_int("blackholeDropCount"),
        attacker_count=as_int("attackerCount"),
        app_tx=as_int("appTxPackets"),
        app_rx=as_int("appRxPackets"),
        # Measured from this run's own FlowMonitor output, not inferred from the
        # geometry: the geometric estimate proved wrong by a factor of ~2.
        mean_hops=mean_hops_from_flowmonitor(fm_path),
        flow_delivery=delivery_ratio_from_flowmonitor(fm_path),
        area=area,
        max_speed=max_speed,
    )


def build_scenarios(arguments: argparse.Namespace) -> list[tuple[int, float]]:
    """Resolve the (nodes, area) pairs to sweep.

    Why pairs and not a cross product
    ---------------------------------
    Sweeping node count at a FIXED area only changes the node degree: adding
    nodes makes the network denser, which SHORTENS paths and adds contention.
    That is why an earlier node sweep found 50 nodes worse than 30 -- it was
    moving along the wrong axis. Reaching a genuinely multi-hop network requires
    increasing the ratio ``area / range`` while holding the degree roughly
    constant, which means scaling nodes and area TOGETHER:

        degree = nodes * pi * range^2 / area^2

    ``--scenarios "30:600,64:900"`` expresses exactly that. Node counts must be
    distinct across scenarios because results are aggregated by node count.

    Returns:
        List of (nodes, area) pairs, in the given order.
    """
    if arguments.scenarios:
        pairs: list[tuple[int, float]] = []
        seen: set[int] = set()
        for item in arguments.scenarios.replace(" ", "").split(","):
            if not item:
                continue
            try:
                nodes_text, area_text = item.split(":")
                nodes, area = int(nodes_text), float(area_text)
            except ValueError as error:
                raise SystemExit(
                    f"--scenarios entry '{item}' is not of the form NODES:AREA"
                ) from error
            if nodes in seen:
                raise SystemExit(
                    f"--scenarios repeats node count {nodes}; results are aggregated "
                    "by node count, so each scenario needs a distinct one"
                )
            seen.add(nodes)
            pairs.append((nodes, area))
        return pairs
    return [(nodes, arguments.area) for nodes in arguments.nodes_list]


def run_grid(arguments: argparse.Namespace) -> list[RunOutcome]:
    """Run the full scenario x seed x {no-attack, attack} grid."""

    ns3_dir = Path(arguments.ns3_dir).resolve()
    if not (ns3_dir / "ns3").exists():
        raise SystemExit(f"'{ns3_dir}/ns3' not found; pass --ns3-dir pointing at ns-3.48")

    outcomes: list[RunOutcome] = []
    with tempfile.TemporaryDirectory(prefix="mtcaodv-calib-") as tmp:
        tmpdir = Path(tmp)
        scenarios = build_scenarios(arguments)
        # Speed is swept as an independent axis because it acts on a different
        # mechanism than geometry: geometry sets how many hops a path NEEDS,
        # speed sets how long a link SURVIVES. A route of h hops survives only
        # while all h links do, so the two compose multiplicatively and cannot
        # be diagnosed from a geometry sweep alone.
        #
        # The comparison across speeds is PAIRED: RandomWaypointMobilityModel
        # draws positions, speeds and pauses from separate RandomVariableStreams
        # and AssignStreams gives each its own index, so changing --max-speed
        # changes only the speed draws. The waypoint sequence for a given seed
        # is identical across speeds; the nodes simply traverse it faster or
        # slower.
        speeds = arguments.speeds or [arguments.max_speed]
        total = len(scenarios) * len(speeds) * len(arguments.seeds) * 2
        done = 0
        for nodes, area in scenarios:
          for max_speed in speeds:
              # Degree is printed so the sweep's design intent (hold density,
              # raise area/range) is visible in the log, not just in the code.
              degree = nodes * math.pi * arguments.max_range ** 2 / (area ** 2)
              print(f"--- scenario nodes={nodes} area={area:g} range={arguments.max_range:g} "
                    f"maxSpeed={max_speed:g} "
                    f"(L/r={area/arguments.max_range:.2f}, degre~{degree:.1f}) ---",
                    file=sys.stderr, flush=True)
              for seed in arguments.seeds:
                  for attack in (False, True):
                      done += 1
                      label = (f"[{done}/{total}] nodes={nodes} v{max_speed:g} seed={seed} "
                               f"{'attack' if attack else 'baseline'}")
                      print(label + " ...", file=sys.stderr, flush=True)
                      outcome = run_one(
                          ns3_dir,
                          arguments.exe,
                          tmpdir,
                          nodes=nodes,
                          seed=seed,
                          attack=attack,
                          area=area,
                          max_range=arguments.max_range,
                          ratio=arguments.ratio,
                          attack_start=arguments.attack_start,
                          sim_time=arguments.sim_time,
                          min_speed=arguments.min_speed,
                          max_speed=max_speed,
                          run=arguments.run,
                          timeout_s=arguments.timeout,
                          flow_count=arguments.flow_count,
                          data_rate=arguments.data_rate,
                      )
                      if not outcome.ok:
                          print(f"    FAILED: {outcome.error}", file=sys.stderr, flush=True)
                      else:
                          kind = (
                              f"pdr={outcome.pdr:.3f} delay={outcome.mean_delay_s*1000:.1f}ms"
                              + (f" hops<={outcome.mean_hops:.2f}" if not attack else "")
                              + (f" forged={outcome.forged} drops={outcome.drops}" if attack else "")
                          )
                          print("    " + kind, file=sys.stderr, flush=True)
                      outcomes.append(outcome)
    return outcomes


# ----------------------------------------------------------------------------
# Reporting
# ----------------------------------------------------------------------------
def print_report(
    summaries: dict[int, NodeSummary],
    winners: Sequence[int],
    arguments: argparse.Namespace,
) -> None:
    """Print the aggregated table and the calibration verdict."""

    print("\n=== STEP 1 calibration summary "
          f"(maxRange={arguments.max_range} m, ratio={arguments.ratio}, "
          f"flows={arguments.flow_count}x{arguments.data_rate}) ===")
    header = (
        f"{'nodes':>5} {'area':>6} {'vmax':>5} {'seeds':>5} {'baseMean':>8} {'baseMin':>7} {'baseStd':>7} "
        f"{'atkMean':>7} {'dropPP':>6} {'hopsRaw':>8} {'hopsCorr':>9} {'delayMs':>7} "
        f"{'effSeeds':>8} {'fails':>5}"
    )
    print(header)
    print("-" * len(header))
    for key in sorted(summaries):
        s = summaries[key]
        nodes = s.nodes
        n_ok = len(s.seeds)
        if n_ok == 0:
            print(f"{nodes:>5} {s.area:>6.0f} {s.max_speed:>5.0f} {'0':>5}  "
                  f"(all runs failed: {s.failures})")
            continue
        print(
            f"{nodes:>5} {s.area:>6.0f} {s.max_speed:>5.0f} {n_ok:>5} "
            f"{s.baseline_mean():>8.3f} {s.baseline_min():>7.3f} "
            f"{s.baseline_std():>7.3f} {s.attack_mean():>7.3f} "
            f"{100*s.effect_mean():>6.1f} {s.hops_mean():>8.2f} "
            f"{s.hops_corrected():>9.2f} {1000*s.delay_mean():>7.1f} "
            f"{s.seeds_with_effect()}/{n_ok:<6} {s.failures:>5}"
        )

    print(
        f"\nCriteria: baseline_min > {arguments.min_baseline:.2f}, "
        f"mean_hops > {arguments.min_hops:.1f}, "
        f"mean_effect > {100*arguments.min_effect:.0f} pp AND attack<baseline on every seed."
    )
    # The hop column is an UPPER BOUND (timesForwarded counts relays of lost
    # packets too), so a value at or below the threshold is conclusive evidence
    # AGAINST the scenario, while a value just above it is not yet proof for it.
    print("Note: hopsRaw is inflated by packet loss (timesForwarded counts relays of "
          "lost packets\n      too); hopsCorr removes that term and IS the criterion. "
          "Both are upper bounds.\n      delayMs is reported for the record only "
          "(refuted as a multi-hop proxy).")
    if winners:
        best = winners[0]
        s = summaries[best]
        print(
            f"\nSELECTED: {config_label(best)} -> nodes={s.nodes}, area={s.area:.0f}, "
            f"maxSpeed={s.max_speed:.0f}, maxRange={arguments.max_range} "
            f"-> baseline {s.baseline_mean():.3f} (min {s.baseline_min():.3f}), "
            f"attack {s.attack_mean():.3f}, drop {100*s.effect_mean():.1f} pp, "
            f"hopsCorr<={s.hops_corrected():.2f} (raw {s.hops_mean():.2f}), "
            f"effect on {s.seeds_with_effect()}/{len(s.seeds)} seeds."
        )
        if len(winners) > 1:
            others = ", ".join(config_label(k) for k in winners[1:])
            print(f"Other qualifying configurations (best first): {others}")
        print("Freeze this triple, then run >=30 paired seeds for the confirmatory measurement.")
    else:
        print(
            "\nNO node count met all three criteria in this sweep. Widen it: try larger "
            "--nodes-list and keep --area ~= 4x --max-range (e.g. area=600 maxRange=150), "
            "or relax --min-baseline if 0.90 is stricter than your target."
        )


def write_summary_csv(summaries: dict[int, NodeSummary], path: Path, arguments: argparse.Namespace) -> None:
    """Persist the aggregated table for the record / plotting."""

    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "nodes", "area_m", "maxSpeed_mps", "maxRange_m", "ratio", "seedsOk",
                "baselinePdrMean", "baselinePdrMin", "baselinePdrStd",
                "attackPdrMean", "dropPP", "meanHopsRaw", "meanHopsCorrected", "meanDelayMs",
                "seedsWithEffect", "failures", "flowCount", "dataRate",
            ]
        )
        for key in sorted(summaries):
            s = summaries[key]
            writer.writerow(
                [
                    s.nodes, s.area, s.max_speed, arguments.max_range,
                    arguments.ratio, len(s.seeds),
                    f"{s.baseline_mean():.6f}", f"{s.baseline_min():.6f}", f"{s.baseline_std():.6f}",
                    f"{s.attack_mean():.6f}", f"{100*s.effect_mean():.4f}",
                    f"{s.hops_mean():.4f}", f"{s.hops_corrected():.4f}",
                    f"{1000*s.delay_mean():.4f}",
                    s.seeds_with_effect(), s.failures,
                    arguments.flow_count, arguments.data_rate,
                ]
            )


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def _float_list(text: str) -> list[float]:
    return [float(part) for part in text.replace(" ", "").split(",") if part]


def _int_list(text: str) -> list[int]:
    return [int(part) for part in text.replace(" ", "").split(",") if part]


def _parse_arguments(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--ns3-dir", default=".", help="ns-3.48 root containing ./ns3")
    parser.add_argument("--exe", default="mtcaodv-pilot-attack", help="pilot example name")
    parser.add_argument("--nodes-list", type=_int_list, default=[30, 40, 50, 70],
                        help="comma-separated node counts to sweep")
    parser.add_argument("--seeds", type=_int_list, default=[1, 2, 3, 4, 5],
                        help="comma-separated seeds")
    parser.add_argument("--scenarios", default="",
                        help="sweep (nodes, area) PAIRS instead of node counts at a "
                             "fixed area, e.g. \"30:600,45:750,64:900,84:1150\". This is "
                             "the axis that actually changes hop count: raising nodes at "
                             "a fixed area only raises the degree and SHORTENS paths. "
                             "Node counts must be distinct. Overrides --nodes-list/--area.")
    parser.add_argument("--area", type=float, default=500.0, help="square area side in metres")
    parser.add_argument("--max-range", type=float, default=120.0, help="radio range in metres")
    parser.add_argument("--ratio", type=float, default=0.20, help="attacker ratio for the attack arm")
    parser.add_argument("--attack-start", type=float, default=10.0)
    parser.add_argument("--sim-time", type=float, default=60.0)
    parser.add_argument("--min-speed", type=float, default=1.0)
    parser.add_argument("--max-speed", type=float, default=20.0)
    parser.add_argument("--speeds", type=_float_list, default=None,
                        help="sweep maximum node speed as an independent axis, e.g. "
                             "\"5,10,20\". Geometry sets how many hops a path needs; "
                             "speed sets how long each link survives, and a route needs "
                             "ALL its links alive at once. The comparison is paired: "
                             "RandomWaypoint draws positions and speeds from separate "
                             "RNG streams, so a given seed keeps the same waypoints and "
                             "only its traversal speed changes. Overrides --max-speed.")
    parser.add_argument("--run", type=int, default=1)
    parser.add_argument("--timeout", type=int, default=600, help="per-run timeout seconds")
    parser.add_argument("--min-baseline", type=float, default=0.90,
                        help="required minimum baseline PDR on every seed")
    parser.add_argument("--flow-count", type=int, default=16,
                        help="number of concurrent UDP flows. PDR is a mean over this "
                             "many endpoint pairs, so this sets the measurement's "
                             "resolution: 4 flows quantise PDR to 0.25 and give a "
                             "sampling error near 0.20, which exceeded the differences "
                             "the sweep was trying to resolve. Raised to 16.")
    parser.add_argument("--data-rate", default="16kbps",
                        help="per-flow application rate. The default keeps the TOTAL "
                             "offered load at 16x16 = 256 kbps, identical to the former "
                             "4x64 kbps, so raising the flow count changes the sampling "
                             "WITHOUT changing the load the network must carry.")
    parser.add_argument("--min-hops", type=float, default=3.0,
                        help="minimum mean hop count for the scenario to count as "
                             "multi-hop; measured from FlowMonitor, not inferred")
    parser.add_argument("--min-delay", type=float, default=0.010,
                        help="RETAINED FOR THE RECORD ONLY: no longer a selection "
                             "criterion. Delay was refuted as a multi-hop proxy "
                             "(see the module docstring); --min-hops replaced it. "
                             "The flag is kept so old invocations still parse and so "
                             "the refuted threshold stays visible in the audit trail.")
    parser.add_argument("--min-effect", type=float, default=0.05,
                        help="required mean PDR drop (fraction) under attack")
    parser.add_argument("--summary-csv", type=Path, default=Path("mtcaodv-step01-calibration.csv"))
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _parse_arguments(sys.argv[1:] if argv is None else argv)
    outcomes = run_grid(arguments)
    summaries = aggregate(outcomes)
    winners = select(
        summaries,
        min_baseline=arguments.min_baseline,
        min_hops=arguments.min_hops,
        min_effect=arguments.min_effect,
    )
    print_report(summaries, winners, arguments)
    write_summary_csv(summaries, arguments.summary_csv, arguments)
    print(f"\nAggregated summary written to {arguments.summary_csv}")
    # Exit 0 if a scenario was selected, 2 if none qualified (fail-closed signal).
    return 0 if winners else 2


if __name__ == "__main__":
    raise SystemExit(main())
