#!/usr/bin/env python3
# MTCAODV_DELIVERY_REVISION: r24
"""Tests de analyze_rerr.py. Bibliotheque standard uniquement."""

import json
import math
import tempfile
import unittest
from pathlib import Path

import analyze_rerr as r
from analyze_forwarding import ForwardingAnalysisError

OBS_HEADER = ("openTime_s,closeTime_s,observerNodeId,neighborNodeId,neighborIp,"
              "destinationIp,forwardingObserved,closureReason")
RERR_HEADER = "time_s,observerNodeId,originIp,unreachableIp,sequenceNumber"


def _obs(close=1.0, observer=0, neighbor=1, neighbor_ip="10.1.0.2",
         destination="10.1.0.9", observed=0):
    return (f"{close - 0.15},{close},{observer},{neighbor},{neighbor_ip},"
            f"{destination},{observed},"
            f"{'MATCHED' if observed else 'DEADLINE'}")


def _rerr(time=1.2, observer=0, origin="10.1.0.2", unreachable="10.1.0.9", seq=7):
    return f"{time},{observer},{origin},{unreachable},{seq}"


def _write(name, header, lines):
    path = Path(tempfile.mkdtemp()) / name
    path.write_text(header + "\n" + "\n".join(lines) + ("\n" if lines else ""),
                    encoding="utf-8")
    return path


class CoherenceTests(unittest.TestCase):
    """Les trois conditions de coherence, chacune testee isolement."""

    def _delay(self, obs_line, rerr_lines):
        rows = r.load_observations(_write("o.csv", OBS_HEADER, [obs_line]))
        index = r.load_rerr(_write("r.csv", RERR_HEADER, rerr_lines))
        return r.delay_to_next_coherent_rerr(rows[0], index)

    def test_fully_coherent_rerr_is_matched(self):
        self.assertAlmostEqual(self._delay(_obs(close=1.0), [_rerr(time=1.2)]), 0.2)

    def test_other_observer_does_not_match(self):
        self.assertTrue(math.isnan(self._delay(_obs(), [_rerr(observer=3)])))

    def test_other_origin_does_not_match(self):
        """Un RERR d'un AUTRE voisin n'explique rien."""
        self.assertTrue(math.isnan(self._delay(_obs(), [_rerr(origin="10.1.0.7")])))

    def test_other_destination_does_not_match(self):
        """LA condition qui separe explication et correlation.

        Le meme voisin declarant injoignable une AUTRE destination ne dit rien
        du paquet suivi. Sans ce test, la jointure mesurerait « ce voisin a des
        ruptures » et non « il ne pouvait pas relayer CE paquet ».
        """
        self.assertTrue(math.isnan(self._delay(_obs(), [_rerr(unreachable="10.1.0.4")])))

    def test_earlier_rerr_does_not_explain(self):
        """Un RERR ANTERIEUR ne peut pas expliquer un evenement pas encore survenu."""
        self.assertTrue(math.isnan(self._delay(_obs(close=1.0), [_rerr(time=0.5)])))

    def test_first_posterior_rerr_is_taken(self):
        delay = self._delay(_obs(close=1.0),
                            [_rerr(time=0.5), _rerr(time=1.3), _rerr(time=2.9)])
        self.assertAlmostEqual(delay, 0.3)

    def test_simultaneous_rerr_counts(self):
        """Un RERR au meme instant que la cloture est POSTERIEUR ou egal."""
        self.assertAlmostEqual(self._delay(_obs(close=1.0), [_rerr(time=1.0)]), 0.0)


class SummaryTests(unittest.TestCase):
    def test_coverage_grid_is_cumulative(self):
        rows = r.load_observations(_write("o.csv", OBS_HEADER, [
            _obs(close=1.0, destination="10.1.0.9"),
            _obs(close=2.0, destination="10.1.0.8"),
            _obs(close=3.0, destination="10.1.0.7"),
        ]))
        index = r.load_rerr(_write("r.csv", RERR_HEADER, [
            _rerr(time=1.02, unreachable="10.1.0.9"),   # 20 ms
            _rerr(time=2.90, unreachable="10.1.0.8"),   # 900 ms
            # rien pour 10.1.0.7
        ]))
        summary = r.summarise(rows, index, "t")
        self.assertEqual(summary["missed"], 3)
        self.assertEqual(summary["withAnyRerr"], 2)
        self.assertEqual(summary["coverage"][0.05], 1)
        self.assertEqual(summary["coverage"][0.15], 1)
        self.assertEqual(summary["coverage"][1.0], 2)
        self.assertEqual(summary["coverage"][5.0], 2)

    def test_matched_windows_are_excluded(self):
        """Une retransmission OBSERVEE n'a pas besoin d'explication benigne."""
        rows = r.load_observations(_write("o.csv", OBS_HEADER, [_obs(observed=1)]))
        index = r.load_rerr(_write("r.csv", RERR_HEADER, [_rerr()]))
        self.assertEqual(r.summarise(rows, index, "t")["missed"], 0)

    def test_empty_rerr_stream_is_a_measurement(self):
        """Un flux vide se lit, et donne une couverture nulle -- pas une erreur."""
        rows = r.load_observations(_write("o.csv", OBS_HEADER, [_obs()]))
        index = r.load_rerr(_write("r.csv", RERR_HEADER, []))
        summary = r.summarise(rows, index, "t")
        self.assertEqual(summary["withAnyRerr"], 0)
        self.assertTrue(math.isnan(summary["minDelay"]))


class ContractTests(unittest.TestCase):
    def test_missing_destination_column_is_refused(self):
        """Sans destination, la coherence ne peut pas etre testee : on REFUSE.

        Se rabattre sur le seul voisin mesurerait une correlation et la
        presenterait comme une explication.
        """
        header = OBS_HEADER.replace(",destinationIp", "")
        line = _obs().replace(",10.1.0.9", "")
        with self.assertRaises(ForwardingAnalysisError) as ctx:
            r.load_observations(_write("o.csv", header, [line]))
        self.assertIn("destinationIp", str(ctx.exception))

    def test_empty_observations_are_refused(self):
        with self.assertRaises(ForwardingAnalysisError):
            r.load_observations(_write("o.csv", OBS_HEADER, []))


if __name__ == "__main__":
    unittest.main()
