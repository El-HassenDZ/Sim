#!/usr/bin/env bash
# MTCAODV_DELIVERY_REVISION: r24
# ---------------------------------------------------------------------------
# MTC-AODV — sequence complete : construction, tests, execution, validation.
#
# Usage :  bash run_all.sh [racine-ns3]        (defaut : repertoire courant)
#
# Le script est FAIL CLOSED : il s'arrete a la premiere anomalie et n'execute
# jamais une simulation sur un arbre incoherent. Un chiffre produit par un build
# qui ne correspond pas aux sources n'appartient a aucune version du code, ce qui
# est pire qu'une erreur franche : cela ressemble a une donnee.
#
# Toutes les commandes ci-dessous ont ete executees et confirmees sur
# l'installation de l'utilisateur ; aucune n'est supposee.
# ---------------------------------------------------------------------------
set -u
ROOT="${1:-$(pwd)}"
cd "$ROOT" || { echo "racine introuvable : $ROOT"; exit 1; }

SEED=1
RUN=1
SCENARIO="--nodes=30 --areaSize=600 --maxRange=200 --minSpeed=1 --maxSpeed=5 \
--simTime=300 --flowCount=5 --dataRate=51.2kbps --attackerRatio=0.20 \
--attackStart=10 --seed=$SEED --run=$RUN"

# Les douze suites, verifiees par ./test.py -l sur l'installation utilisateur.
# Les quatre premieres sont AODV AMONT : elles verifient que le module officiel
# fonctionne toujours. ATTENTION : la suite amont s'appelle `routing-aodv`, pas
# `aodv`, et `mtcaodv-rrep-screening` N'EXISTE PAS (les tests de depistage
# STEP 2 sont dans mtcaodv-rrep-anomaly-detector).
SUITES="routing-aodv routing-aodv-loopback routing-aodv-regression \
aodv-routing-id-cache mtcaodv-routing-protocol mtcaodv-attack-manager \
mtcaodv-blackhole-behavior mtcaodv-step00-baseline-metrics \
mtcaodv-rrep-anomaly-detector mtcaodv-packet-fingerprint \
mtcaodv-forwarding-observer \
mtcaodv-ocea-attribution"

step() { printf '\n\033[1m== %s\033[0m\n' "$1"; }
die()  { printf '\n\033[1mARRET : %s\033[0m\n' "$1"; exit 1; }

# --- 1. Arithmetique A3.3, AVANT toute construction ------------------------
# L'unite `ocea-attribution` n'inclut aucun en-tete ns-3 : elle se compile avec
# un simple g++ en une seconde. Placer ce controle EN TETE n'est pas cosmetique
# -- une erreur dans les Eq. (6)-(10) est signalee immediatement au lieu de
# l'etre apres dix minutes de build ns-3.
step "1/8  Contre-controle arithmetique A3.3 (sans ns-3)"
bash experiments/check_ocea_arithmetic.sh "$ROOT" || die "l'arithmetique A3.3 ne concorde pas"

# --- 2. Construction -------------------------------------------------------
# `configure` est obligatoire, pas optionnel : tout changement de CMakeLists.txt
# fait re-executer CMake au premier build, et cette re-execution REMET les
# options aux defauts (Examples: OFF, Tests: OFF).
step "2/8  Construction"
./ns3 configure --enable-examples --enable-tests >/dev/null || die "configure a echoue"
./ns3 build || die "build a echoue"

# --- 3. Garde post-build ---------------------------------------------------
step "3/8  Garde post-build (coherence de l'arbre)"
bash experiments/check_step03_build.sh "$ROOT" || die "build incoherent -- voir ci-dessus"

# --- 4. Suites ns-3 --------------------------------------------------------
step "4/8  Suites ns-3 (12)"
FAILED=""
for s in $SUITES; do
    if ./test.py -s "$s" 2>&1 | grep -q "^1 of 1 tests passed"; then
        printf '  ok    %s\n' "$s"
    else
        printf '  FAIL  %s\n' "$s"; FAILED="$FAILED $s"
    fi
done
[ -z "$FAILED" ] || die "suites en echec :$FAILED"

# --- 5. Tests Python -------------------------------------------------------
step "5/8  Tests Python"
( cd experiments && python3 -m unittest test_validate_step03 test_analyze_forwarding test_analyze_features test_analyze_baseline_seeds test_ocea_reference \
  test_analyze_rerr -q ) \
    || die "tests Python en echec"

# --- 6. AODV amont preserve ------------------------------------------------
# Le passage des suites amont prouve que le module se comporte bien ; il ne
# prouve PAS que ses sources sont intactes. Ce sont deux affirmations
# differentes et seule la seconde est la contrainte permanente.
step "6/8  Contrainte « preserver AODV »"
TOUCHED="$(find src/aodv -type f -newer src/olsr/CMakeLists.txt 2>/dev/null)"
if [ -n "$TOUCHED" ]; then
    printf '%s\n' "$TOUCHED"
    die "src/aodv a ete modifie -- violation de la contrainte"
fi
echo "  ok    src/aodv intact (temoin : src/olsr)"

# --- 7. Les deux bras, et la comparaison ----------------------------------
step "7/8  Execution : observation ON puis OFF"
./ns3 run "mtcaodv-pilot-attack $SCENARIO --observationsCsv=obs-atk.csv --rerrCsv=rerr-atk.csv" \
    > /tmp/mtc_on.txt 2>&1 || { cat /tmp/mtc_on.txt; die "le run ON a echoue"; }
cp mtcaodv-step01-manifest.json man-atk.json
cp mtcaodv-step01-results.csv  res-atk.csv

./ns3 run "mtcaodv-pilot-attack $SCENARIO --enableObservation=false" \
    > /tmp/mtc_off.txt 2>&1 || { cat /tmp/mtc_off.txt; die "le run OFF a echoue"; }

PDR_ON="$(grep  -m1 '^pdr=' /tmp/mtc_on.txt  | cut -d= -f2)"
PDR_OFF="$(grep -m1 '^pdr=' /tmp/mtc_off.txt | cut -d= -f2)"
OPENED="$(grep  -m1 '^windowsOpened='  /tmp/mtc_on.txt | cut -d= -f2)"
MATCHED="$(grep -m1 '^windowsMatched=' /tmp/mtc_on.txt | cut -d= -f2)"
SKIPLH="$(grep  -m1 '^skippedLastHop=' /tmp/mtc_on.txt | cut -d= -f2)"
LINKOK="$(grep   -m1 '^linkSuccesses=' /tmp/mtc_on.txt | cut -d= -f2)"
LINKKO="$(grep   -m1 '^linkFailures='  /tmp/mtc_on.txt | cut -d= -f2)"
SELFMATCH="$(grep -m1 '^matchedFromSelf=' /tmp/mtc_on.txt | cut -d= -f2)"
REJECTED="$(grep -m1 '^matchesRejectedSameInstant=' /tmp/mtc_on.txt | cut -d= -f2)"
ZEROLAT="$(grep -m1 '^matchedAtZeroLatency=' /tmp/mtc_on.txt | cut -d= -f2)"
ZEROREL="$(grep -m1 '^matchedAtZeroLatencyByRelay=' /tmp/mtc_on.txt | cut -d= -f2)"
DIAGOK="$(grep -m1 '^windowsWithLinkOutcome=' /tmp/mtc_on.txt | cut -d= -f2)"
DIAGKO="$(grep -m1 '^windowsWithLinkFailure=' /tmp/mtc_on.txt | cut -d= -f2)"
DIAGNOMAC="$(grep -m1 '^windowsPeerMacUnknownAtOpen=' /tmp/mtc_on.txt | cut -d= -f2)"
DIAGAMB="$(grep -m1 '^windowsMultipleLinkOutcomes=' /tmp/mtc_on.txt | cut -d= -f2)"

printf '  pdr(ON)=%s  pdr(OFF)=%s\n' "$PDR_ON" "$PDR_OFF"
printf '  windowsOpened=%s  windowsMatched=%s  skippedLastHop=%s\n' \
       "$OPENED" "$MATCHED" "$SKIPLH"
printf '  linkSuccesses=%s  linkFailures=%s\n' "$LINKOK" "$LINKKO"
printf '  matchedFromSelf=%s (DOIT valoir 0)\n' "$SELFMATCH"
# ECHEC DUR, et non un avertissement : un appariement sur sa propre emission
# fabrique z_e = 1. L'Eq. (9) accorderait (1,0,0,0) -- preuve positive pleine --
# a un voisin qui n'a rien relaye, et toute masse calculee en aval serait fausse
# SANS LE PARAITRE. On arrete la chaine plutot que de la laisser produire des
# chiffres d'apparence normale.
if [ "${SELFMATCH:-0}" -ne 0 ]; then
    die "matchedFromSelf=$SELFMATCH : l observateur s est apparie sur SA PROPRE emission"
fi
printf '  matchesRejectedSameInstant=%s  matchedAtZeroLatency=%s (DOIT valoir 0)\n' \
       "$REJECTED" "$ZEROLAT"
# ECHEC DUR. Le defaut a ete diagnostique en r21 et corrige en r22 : un
# appariement dans le meme instant que l ouverture est la trame ENTRANTE du
# paquet, pas une retransmission de j. Non nul = la correction ne s applique pas.
if [ "${ZEROLAT:-0}" -ne 0 ]; then
    die "matchedAtZeroLatency=$ZEROLAT : la correction r22 ne s applique pas"
fi
# Un compteur de rejets NUL signalerait un chemin inerte : des qu un noeud
# relaie, la trame entrante se presente. Signale, non bloquant.
if [ "${REJECTED:-0}" -eq 0 ]; then
    printf '  WARN  AUCUN appariement rejete : le chemin de rejet r22 n est\n'
    printf '        pas exerce, ou les relais ont disparu du scenario.\n'
fi
printf '  windowsWithLinkOutcome=%s (d_e > 0)  windowsWithLinkFailure=%s (y_l = 1)\n' \
       "$DIAGOK" "$DIAGKO"
printf '  windowsPeerMacUnknownAtOpen=%s  windowsMultipleLinkOutcomes=%s\n' \
       "$DIAGNOMAC" "$DIAGAMB"
# LE compteur qui decide si l'Eq. (8) s'applique. A zero, d_e = 0 partout et
# A3.3 renverrait (0,0,0,1) pour la TOTALITE des evenements -- le cas que le
# critere de fermeture n. 7 declare FAIL. Signale sans bloquer : c'est un fait
# a interpreter, pas une panne de build.
if [ "${DIAGOK:-0}" -eq 0 ] && [ "${OPENED:-0}" -gt 0 ]; then
    printf '  WARN  AUCUNE fenetre n a pu etre diagnostiquee : d_e = 0 partout,\n'
    printf '        A3.3 renverrait (0,0,0,1) pour tous les evenements.\n'
fi
# L attribution est par PAIR, non par PAQUET. Ce compteur borne l erreur.
if [ "${DIAGAMB:-0}" -gt 0 ] && [ "${DIAGOK:-0}" -gt 0 ]; then
    printf '  NOTE  %s fenetres ont vu PLUSIEURS issues MAC vers j : pour\n' "$DIAGAMB"
    printf '        celles-la, l issue attribuee n est pas forcement celle du\n'
    printf '        paquet suivi. Ambiguite MESUREE, non supposee negligeable.\n'
fi
grep -E '^macDrops|^linkReliabilityChangedDuringWindow' /tmp/mtc_on.txt | sed 's/^/  /'
# Fuite temporelle : nombre de fenetres ou la fiabilite a change entre
# l'ouverture et la cloture. C'est exactement ce que le GEL de x_link empeche
# d'entrer dans l'Eq. (7). Non bloquant : c'est une mesure, pas une panne.
CHANGED="$(grep -m1 '^linkReliabilityChangedDuringWindow=' /tmp/mtc_on.txt | cut -d= -f2)"
if [ "${CHANGED:-0}" -gt 0 ]; then
    printf '  NOTE  %s fenetres auraient vu x_link changer avant la cloture :\n' "$CHANGED"
    printf '        c est la contamination que le gel supprime, desormais mesuree.\n'
fi
# Un compteur d'echecs NUL signale une instrumentation borgne : la fiabilite
# vaudrait alors structurellement 1 et ne mesurerait plus rien. Signale, non
# bloquant : c'est un fait a interpreter, pas une panne de build.
if [ "${LINKKO:-0}" -eq 0 ] && [ "${LINKOK:-0}" -gt 0 ]; then
    printf '  WARN  aucun ECHEC de lien enregistre : linkReliability vaut\n'
    printf '        structurellement 1 et ne porte aucune information.\n'
fi

# Critere 3 : egalite EXACTE, comparee sur les chaines. L'observation est
# passive ; elle ne consomme aucun flux RNG et ne doit rien changer. Un gain
# serait un BUG, pas un succes.
[ -n "$PDR_ON" ] && [ -n "$PDR_OFF" ] || die "pdr illisible dans la sortie"
[ "$PDR_ON" = "$PDR_OFF" ] || die "pdr(ON) != pdr(OFF) : l'observation a modifie la livraison"
echo "  ok    critere 3 : pdr identique au chiffre pres"
[ "${OPENED:-0}" -gt 0 ] && [ "${MATCHED:-0}" -gt 0 ] \
    || die "critere 4 : aucune fenetre ouverte ou appariee"
echo "  ok    critere 4 : fenetres ouvertes et appariees"

# --- 8. Validation et analyse ---------------------------------------------
step "8/8  Validation et mesure"
python3 experiments/validate_step03.py --csv res-atk.csv --manifest man-atk.json \
    || die "le validateur a rejete le run"
python3 experiments/analyze_forwarding.py --observations obs-atk.csv \
    --manifest man-atk.json --after-attack-start || die "l'analyse a echoue"

# Mesure prealable STEP 4 : le plafond d'attribution d'OCEA. L'Eq. (7) etant une
# moyenne geometrique, une visibilite nulle donne O_e = 0 donc I_e = 0, quels que
# soient les diagnostics ajoutes ensuite. C'est une borne dure, pas une estimation.
python3 experiments/analyze_features.py --observations obs-atk.csv \
    --manifest man-atk.json || die "la mesure des caracteristiques a echoue"

# Second diagnostic y_l : le RERR coherent. Jointure HORS LIGNE, parce que le
# RERR qui explique une non-observation arrive APRES elle -- une fenetre close
# ne peut pas le porter. Le delai reste donc un parametre libre de l analyse.
python3 experiments/analyze_rerr.py --observations obs-atk.csv \
    --rerr rerr-atk.csv --manifest man-atk.json || die "la jointure RERR a echoue"

printf '\n\033[1mSEQUENCE COMPLETE -- les cinq criteres STEP 3 sont satisfaits.\033[0m\n'
printf 'La baseline de non-observation honnete ci-dessus n a AUCUN seuil\n'
printf 'prevu : elle est rapportee, jamais comparee a une valeur attendue.\n'
printf '\n\033[1mSTEP 4 : PARTIEL, et il faut le dire.\033[0m\n'
printf 'Couverts : criteres 1 (T-13), 2 (fail closed), 3 (oracles calcules\n'
printf 'avant encodage) -- etapes 1/8 et 4/8 ; 5 (compteurs de disponibilite)\n'
printf 'et 7 (fraction non interpretable) -- mesures a l etape 8/8 ci-dessus.\n'
printf 'NON couverts : 4 (coherentRerr reste accessible et non instrumente),\n'
printf '6 (distributions des masses : exige l adaptateur, non livre), et 8\n'
printf 'partiellement.\n'
# CE BLOC A DEJA MENTI UNE FOIS. En r17 il affirmait encore « aucun diagnostic
# y_l n est instrumente » alors que le lot venait d en instrumenter un, et que
# les chiffres imprimes vingt lignes plus haut le contredisaient. Texte
# narratif qui n a pas suivi le code -- deuxieme occurrence du meme defaut.
# Ne rien affirmer ici qui ne soit relu sur la sortie du run.
printf 'Lisez windowsWithLinkOutcome et la ligne COUVERTURE DIAGNOSTIQUE\n'
printf 'ci-dessus : ce sont eux qui tranchent le critere 7, pas ce texte.\n'
