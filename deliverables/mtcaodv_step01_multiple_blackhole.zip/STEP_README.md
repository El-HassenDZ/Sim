# MTC-AODV — STEP 1 : Multiple Full Blackhole (fork AODV ns-3.48)

**Statut de livraison :** `À compiler et tester sur le PC utilisateur`
**Cible :** Linux, ns-3.48, C++17, Python 3
**Répertoire cible :** `/home/hassen/res/ns-3.48`

> Aucune exécution C++ ns-3.48 n'a été effectuée dans l'environnement de
> génération. Les tests Python de niveau 1 du validateur ont, eux, été
> exécutés avec succès (10/10). Tout résultat réseau doit être produit sur
> votre PC.

## 1. Numéro de l'étape

**STEP 1 — Multiple Full Blackhole.** C'est la première étape non validée après
la baseline STEP 0. Elle correspond, dans la spécification, à l'activation
réelle de l'attaque au niveau du protocole (les « hooks Gate 1B » marqués
*Implémenté — à vérifier*), que le zip STEP 0 ne contenait pas encore.

## 2. Objectif scientifique

Rendre observable, de façon reproductible et appariable, l'effet de plusieurs
nœuds *full Blackhole* simultanés sur un MANET AODV :

- chaque attaquant annonce un RREP forgé attractif (numéro de séquence gonflé,
  faible nombre de sauts, longue durée) — Éq. (23), A2.3 ;
- puis abandonne silencieusement les données en transit — A2.4 ;
- le plan de contrôle AODV est préservé, de sorte que l'attaquant reste
  participant et attire durablement le trafic.

Aucune défense n'est introduite. Le but est de mesurer la dégradation
(PDR/goodput/délai) et de compter les événements d'attaque, pour disposer de la
variante **A (AODV sous attaque)** de la campagne appariée.

## 3. Objectif logiciel

- Introduire un **fork propre des sources exactes d'AODV de ns-3.48** dans
  `contrib/mtcaodv/`, sous le namespace isolé `ns3::mtcaodv`, sans modifier
  `src/aodv/`.
- Ajouter **deux et seulement deux** points d'ancrage comportementaux au fork
  (RREP forgé, abandon silencieux), pilotés par l'interface `AttackBehavior`
  déjà validée en Gate 1A. Sans politique attachée, le fork se comporte
  exactement comme AODV standard.
- Fournir un pilote `mtcaodv-pilot-attack` (20 nœuds / 60 s, RandomWaypoint
  1–20 m/s, `AdhocWifiMac`, 10.1.0.0/24, UDP) qui sélectionne les attaquants de
  façon reproductible, installe une instance `BlackholeBehavior` distincte par
  attaquant, agrège les compteurs et étend le CSV.

## 4. Dépendances

- STEP 0 validé (baseline saine) — infrastructure de mesure réutilisée telle
  quelle (`BaselineMetricsCollector`, mobilité, Wi-Fi, trafic UDP, FlowMonitor).
- Gate 1A validé — `AttackManager` (Éq. 2, tirage sans remise), `AttackBehavior`
  et `BlackholeBehavior` (profil forgé, wrap-around 2^32, drop transit).
- Modules ns-3.48 : core, network, internet, internet-apps, wifi, applications,
  mobility, flow-monitor.

## 5. Fichiers ajoutés

Fork AODV ns-3.48 (namespace `ns3::mtcaodv`, TypeId `ns3::mtcaodv::*`) :

```
contrib/mtcaodv/model/mtc-aodv-dpd.{h,cc}
contrib/mtcaodv/model/mtc-aodv-id-cache.{h,cc}
contrib/mtcaodv/model/mtc-aodv-neighbor.{h,cc}
contrib/mtcaodv/model/mtc-aodv-packet.{h,cc}
contrib/mtcaodv/model/mtc-aodv-rqueue.{h,cc}
contrib/mtcaodv/model/mtc-aodv-rtable.{h,cc}
contrib/mtcaodv/model/mtc-aodv-routing-protocol.{h,cc}   <- + 2 hooks d'attaque
contrib/mtcaodv/helper/mtc-aodv-helper.{h,cc}
contrib/mtcaodv/examples/mtcaodv-pilot-attack.cc
contrib/mtcaodv/test/mtc-aodv-routing-protocol-test-suite.cc
experiments/validate_step01.py
experiments/test_validate_step01.py
experiments/schemas/step01_results_schema.json
experiments/configs/step01_pilot.json
```

## 6. Fichiers modifiés

- `contrib/mtcaodv/CMakeLists.txt` — ajoute les sources du fork + le nouveau
  test système ; ajoute les libs internet/wifi/internet-apps.
- `contrib/mtcaodv/examples/CMakeLists.txt` — ajoute l'exemple
  `mtcaodv-pilot-attack` ; conserve `mtcaodv-pilot` (STEP 0) et `mtcaodv-gate1`.
- `STEP_README.md` (ce fichier).

Le fichier STEP 0 `contrib/mtcaodv/examples/mtcaodv-pilot.cc` et tous les
composants Gate 1A **restent inchangés**.

## 7. Classes

- `ns3::mtcaodv::RoutingProtocol` — fork d'`ns3::aodv::RoutingProtocol`. Ajouts
  fork-only : `SetAttackBehavior()`, `GetAttackBehavior()`,
  `GetForgedReplyCount()`, `GetBlackholeTransitDropCount()`, `SendForgedReply()`,
  membres `m_attackBehavior`, `m_forgedReplyCount`,
  `m_blackholeTransitDropCount`, TraceSources `ForgedReply`, `BlackholeDrop`.
- `ns3::mtcaodv::MtcAodvHelper` — fork d'`AodvHelper` bindé sur le TypeId
  `ns3::mtcaodv::RoutingProtocol` ; méthode `InstallAttackBehavior()`.
- Classes AODV forkées inchangées (comportement) : `RreqHeader`, `RrepHeader`,
  `RerrHeader`, `RoutingTable`, `RoutingTableEntry`, `Neighbors`, `IdCache`,
  `DuplicatePacketDetection`, `RequestQueue`.

## 8. Méthodes importantes

| Méthode | Rôle | Équation / Algorithme |
|---|---|---|
| `RoutingProtocol::RecvRequest()` | hook RREP forgé après création de la route inverse | A2.3, Éq. (23) |
| `RoutingProtocol::SendForgedReply()` | sérialise et unicaste le RREP forgé (format standard) | A2.3, Éq. (23) |
| `RoutingProtocol::Forwarding()` | hook d'abandon silencieux en tête du chemin de forwarding | A2.4 |
| `MtcAodvHelper::InstallAttackBehavior()` | attache une politique à un nœud (couche scénario) | A2 |
| `BlackholeBehavior::CreateForgedReplyProfile()` | `seq_fake=(seq_obs+Δseq) mod 2^32` | Éq. (23) |
| `AttackManager::SelectAttackers()` | tirage sans remise reproductible | Éq. (2), A2.1/A2.2 |

## 9. Paramètres

Pilote `mtcaodv-pilot-attack` (nouveaux ou modifiés par rapport à STEP 0) :

| Paramètre CLI | Rôle | Défaut |
|---|---|---|
| `--attackerRatio` | fraction d'attaquants `r_a` ∈ [0,1) | 0.0 |
| `--attackStart` | instant d'activation `t_attack` (inclusif), s | 10.0 |
| `--attackStream` | stream RNG du tirage des attaquants | 73001 |

Attributs `BlackholeBehavior` (Gate 1A, inchangés) : `AttackStartTime`,
`SequenceNumberOffset` (1000), `AdvertisedHopCount` (1), `ForgedRouteLifetime`
(60 s), `DropTransitData` (true), `PreserveControlPlane` (true). Le pilote
règle `AttackStartTime` sur `--attackStart`.

Les autres paramètres (nodes, simTime, min/maxSpeed, seed, run, areaSize,
maxRange, flowCount, packetSize, dataRate, appStart, sourceStartStagger) sont
identiques à STEP 0. Les valeurs physiques restent des valeurs pilote **non
gelées**.

## 10. Équations implémentées

- **Éq. (2)** compte d'attaquants : `AttackManager::ComputeAttackerCount`
  (Gate 1A) + vérifié par `validate_step01.py`.
- **Éq. (23)** séquence forgée avec wrap-around 2^32 :
  `BlackholeBehavior::CreateForgedReplyProfile` → `SendForgedReply`.
- **A2.3 / A2.4** règles booléennes déterministes (forge / drop).
- **Éq. (20), (24), (25), (26)** PDR/PLR/throughput/goodput/délai réutilisées
  telles quelles depuis STEP 0 (`BaselineMetricsCollector`).

## 11. TraceSources

- `ns3::mtcaodv::RoutingProtocol::ForgedReply` — `(destination, forgedDstSeqno,
  reverseNextHop)`, émise à chaque RREP forgé.
- `ns3::mtcaodv::RoutingProtocol::BlackholeDrop` — `(packetUid, ipSource,
  ipDestination)`, émise à chaque paquet transit consommé.
- (STEP 0) `OnOffApplication::Tx` et `PacketSink::RxWithSeqTsSize` inchangées.

## 12. RNG streams

| Composant | Base | Note |
|---|---|---|
| RandomWaypoint | 10000 | 4 streams / nœud (inchangé STEP 0) |
| Fork MTC-AODV | 20000 | `MtcAodvHelper::AssignStreams` (mêmes streams que stock AODV → appariement STEP 0) |
| Wi-Fi PHY/MAC | 30000 | inchangé |
| Trafic UDP | 40000 | inchangé |
| Tirage attaquants | 73001 | `AttackManager::AssignStream` (défaut Gate 1A), configurable `--attackStream` |

Jamais `std::rand()`. Le tirage des attaquants est disjoint des blocs
exogènes (espacés de 10 000) pour ne partager aucun état.

## 13. Compilation

```bash
cd /home/hassen/res/ns-3.48
# Copier le contenu de la livraison dans l'arbre ns-3.48 (contrib/ et experiments/).
./ns3 configure --enable-examples --enable-tests
./ns3 build
```

Recompilation incrémentale après une correction ponctuelle : `./ns3 build`
suffit (pas de reconfiguration).

## 14. Tests

```bash
cd /home/hassen/res/ns-3.48

# Niveau 1 (Python, sans ns-3) — logique du validateur STEP 1 :
cd contrib/mtcaodv/../../   # racine ns-3.48
python3 experiments/test_validate_step01.py            # 10 tests attendus OK

# Niveau 1/2 (C++) — suites déjà validées + nouvelle suite d'intégration :
./test.py -s mtcaodv-attack-manager
./test.py -s mtcaodv-blackhole-behavior
./test.py -s mtcaodv-baseline-metrics
./test.py -s mtcaodv-routing-protocol      # STEP 1 : diamant causal T-08
```

`mtcaodv-routing-protocol` est une suite `SYSTEM` de durée `EXTENSIVE` (elle
construit deux fois le scénario diamant). Si votre configuration filtre les
tests EXTENSIVE, lancez : `./test.py -s mtcaodv-routing-protocol -f EXTENSIVE`
ou exécutez directement l'exemple pilote ci-dessous.

## 15. Commande de simulation pilote

Sanity « fork sans attaque » (doit suivre la baseline STEP 0) :

```bash
cd /home/hassen/res/ns-3.48
./ns3 run "mtcaodv-pilot-attack \
  --nodes=20 --simTime=60 --minSpeed=1 --maxSpeed=20 \
  --attackerRatio=0 --seed=12345 --run=1"
```

Attaque multiple Blackhole (≈4 attaquants pour 20 nœuds) :

```bash
./ns3 run "mtcaodv-pilot-attack \
  --nodes=20 --simTime=60 --minSpeed=1 --maxSpeed=20 \
  --attackerRatio=0.20 --attackStart=10 --seed=12345 --run=1"
```

Validation fail-closed du CSV + manifest produits :

```bash
python3 experiments/validate_step01.py \
  --csv mtcaodv-step01-results.csv \
  --manifest mtcaodv-step01-manifest.json
```

## 16. Fichiers de sortie générés

- `mtcaodv-step01-results.csv` — préfixe STEP 0 **intact** + colonnes
  append-only : `forgedRrepCount, blackholeDropCount, attackStream,
  attackerSelectionStreamsConsumed`. La colonne `attackerCount` (déjà présente)
  est désormais renseignée.
- `mtcaodv-step01-manifest.json` — ajoute le bloc `attack`
  (`forgedRrepCount`, `blackholeDropCount`, `attackerNodeIds[]`) et le stream de
  sélection.
- `mtcaodv-step01-flowmon.xml` — FlowMonitor brut (diagnostic).

## 17. Résultats attendus qualitativement

Aucune valeur numérique n'est fournie car aucune exécution ns-3 n'a été faite.
Attendus qualitatifs :

- `attackerRatio=0` : `forgedRrepCount=0`, `blackholeDropCount=0`,
  `attackerCount=0`, PDR proche de la baseline STEP 0 (même code de routage).
- `attackerRatio=0.20` : `attackerCount=4` (Éq. 2), `forgedRrepCount>0`,
  `blackholeDropCount>0`, PDR/goodput **inférieurs** au cas sans attaque, délai
  moyen éventuellement plus faible (seuls les paquets non interceptés arrivent)
  ou `NaN` si aucune livraison.
- Test `mtcaodv-routing-protocol` : run honnête livre des octets ; run attaqué
  forge, drop et livre strictement moins.

## 18. Critères PASS / FAIL

**PASS si :**
- compilation `./ns3 build` sans erreur ;
- les 4 suites de test passent, dont `mtcaodv-routing-protocol` ;
- `attackerRatio=0` produit forge=drop=attackerCount=0 ;
- `attackerRatio=0.20` produit `attackerCount=4`, `forgedRrepCount>0`,
  `blackholeDropCount>0`, et PDR(attaque) < PDR(sans attaque) au même seed/run ;
- `validate_step01.py` retourne `PASS` sur les deux runs.

**FAIL si :** erreur de compilation/linker ; un test échoue ; l'attaque ne
produit ni forge ni drop ; le validateur rejette un run ; le préfixe CSV STEP 0
est cassé ; une fuite de la vérité terrain apparaît dans un composant non
autorisé.

## 19. Limitations de cette étape

- Le RREP forgé est émis dès qu'une route inverse valide existe et que l'attaque
  est active ; il n'y a pas encore de sélection fine de cible.
- Le pilote suppose `node.GetId() == index de conteneur` (vrai pour un unique
  `NodeContainer` créé en une fois, comme dans STEP 0 et le fixture spec).
- Les valeurs physiques (aire, portée, charge) restent des valeurs pilote non
  gelées : un PDR sans attaque faible relève d'un diagnostic physique, pas de la
  sécurité.
- Le test système `mtcaodv-routing-protocol` construit un petit scénario radio ;
  il valide la chaîne causale, pas une performance de mobilité.

## 20. Éléments volontairement non implémentés

Conformément au développement step-by-step, **rien** de la défense n'est
implémenté à cette étape : pas de détecteur RREP (STEP 2), pas de
`ForwardingObserver` (STEP 3), pas d'OCEA / masses (STEP 4), pas de MOBeta-Trust
(STEP 5), pas de machine à états (STEP 6), pas de témoins/certificats (STEP 7),
pas de PTMB (STEP 8+). Le hook de réception RREP côté défense (`RecvReply`) n'est
pas ajouté ici : il appartient à STEP 2.

La vérité terrain (`attackerNodeIds`) n'est accessible qu'au générateur de
scénario (pilote), à `AttackManager` et à l'installation des comportements —
jamais à un composant de détection (aucun n'existe encore).

## Prochaine étape prévue

**STEP 2 — RREP anomaly screening** : buffer borné de RREP candidats, médiane /
MAD, anomalies séquence/hop/timing, score logistique `A_RREP` (Éq. 3–5), passage
en `WATCH` (jamais quarantaine), hook non-intrusif dans `RecvReply()` du fork.
À n'entamer qu'après validation de STEP 1 sur votre PC.

---

## Ce que je dois vous renvoyer

Merci de me renvoyer uniquement :

1. la sortie de `./ns3 build` (ou les erreurs de compilation/linker) ;
2. le résultat des 4 suites `./test.py -s mtcaodv-*` ;
3. la sortie console des deux `./ns3 run "mtcaodv-pilot-attack ..."` ;
4. les fichiers `mtcaodv-step01-results.csv` et `mtcaodv-step01-manifest.json`
   des deux runs ;
5. la sortie de `validate_step01.py` ;
6. toute erreur runtime éventuelle.

Je ne commencerai STEP 2 qu'après réception de ces résultats.
