#!/usr/bin/env python3
"""Standard-library unit tests for calibrate_step01.py (no ns-3 required).

The focus is the hop-count measurement that replaced the refuted delay proxy.
That replacement only improves the calibration if the estimator is right about
the two things that actually broke in practice: the FlowMonitor XML structure,
and what to do when the measurement is unavailable.
"""

from __future__ import annotations

import argparse
import math
import tempfile
import unittest
from pathlib import Path

import calibrate_step01 as c


class MeanHopsTests(unittest.TestCase):
    """The estimator must survive the real XML shape, and fail closed otherwise."""

    def _write(self, text: str) -> Path:
        path = Path(tempfile.mkdtemp()) / "fm.xml"
        path.write_text(text, encoding="utf-8")
        return path

    @staticmethod
    def _xml(stats: str, classifier: str) -> str:
        return (f"<FlowMonitor><FlowStats>{stats}</FlowStats>"
                f"<Ipv4FlowClassifier>{classifier}</Ipv4FlowClassifier></FlowMonitor>")

    def test_control_traffic_is_excluded_by_port(self):
        """AODV control traffic (port 654) must not enter the data-flow estimate."""
        path = self._write(self._xml(
            '<Flow flowId="1" rxPackets="100" txPackets="100" timesForwarded="150"/>'
            '<Flow flowId="2" rxPackets="10" txPackets="10" timesForwarded="900"/>',
            '<Flow flowId="1" destinationPort="9000"/>'
            '<Flow flowId="2" destinationPort="654"/>'
        ))
        self.assertAlmostEqual(c.mean_hops_from_flowmonitor(path), 2.5)

    def test_dead_data_flows_are_kept(self):
        """The bug this replaced: selecting flows by RECEPTION count.

        A flow that delivered nothing is exactly the evidence that the network
        is partitioned. Dropping it inflated the delivery ratio and, through the
        loss correction, the hop count. Measured consequence on a real run: the
        pilot reported PDR 0.293 while the estimator reported 1.000.
        """
        path = self._write(self._xml(
            '<Flow flowId="1" rxPackets="100" txPackets="100" timesForwarded="100"/>'
            '<Flow flowId="2" rxPackets="0" txPackets="100" timesForwarded="0"/>',
            '<Flow flowId="1" destinationPort="9000"/>'
            '<Flow flowId="2" destinationPort="9000"/>'
        ))
        # The dead flow must halve the delivery ratio, not vanish from it.
        self.assertAlmostEqual(c.delivery_ratio_from_flowmonitor(path), 0.5)
        self.assertAlmostEqual(c.mean_hops_from_flowmonitor(path), 2.0)

    def test_single_hop_network_reads_as_one(self):
        """A network with no relaying must report exactly 1 hop, not 0."""
        path = self._write(self._xml(
            '<Flow flowId="1" rxPackets="500" txPackets="500" timesForwarded="0"/>',
            '<Flow flowId="1" destinationPort="9000"/>'
        ))
        self.assertAlmostEqual(c.mean_hops_from_flowmonitor(path), 1.0)

    def test_unmeasurable_cases_are_nan_never_zero(self):
        """Fail closed: a missing measurement is NaN, never a fabricated number."""
        cases = [
            self._write(self._xml('<Flow flowId="1" rxPackets="100"/>',
                                  '<Flow flowId="1" destinationPort="9000"/>')),
            self._write(self._xml('', '')),
            self._write('<FlowMonitor/>'),
            self._write('<FlowMonitor><FlowStats>'),
            # Counters present but no flow matches the data port.
            self._write(self._xml(
                '<Flow flowId="1" rxPackets="100" txPackets="100" timesForwarded="100"/>',
                '<Flow flowId="1" destinationPort="654"/>')),
        ]
        for path in cases:
            self.assertTrue(math.isnan(c.mean_hops_from_flowmonitor(path)))
        self.assertTrue(math.isnan(c.mean_hops_from_flowmonitor(Path("/nonexistent.xml"))))


class HopCorrectionTests(unittest.TestCase):
    """The raw estimator is inflated by loss; the correction must remove that."""

    @staticmethod
    def _summary(raw_hops: float, pdr: float) -> c.NodeSummary:
        summary = c.NodeSummary(nodes=30, area=600.0, max_speed=20.0)
        for seed in (1, 2):
            summary.seeds.append(seed)
            summary.baseline_pdr.append(pdr)
            summary.attack_pdr.append(pdr / 2)
            summary.baseline_delay.append(0.006)
            summary.baseline_hops.append(raw_hops)
            summary.baseline_flow_delivery.append(pdr)
            summary.attack_drops.append(500)
        return summary

    def test_lossless_run_is_unchanged(self):
        """With no loss there is no inflation term, so nothing to correct."""
        self.assertAlmostEqual(self._summary(2.50, 1.0).hops_corrected(), 2.50)

    def test_heavy_loss_collapses_an_apparently_multi_hop_value(self):
        """Real case from the sweep: PDR 0.074 reported 4.02 raw hops.

        Almost all of that was the inflation term. Judging on the raw value
        would have selected the worst-delivering scenario in the sweep.
        """
        corrected = self._summary(4.02, 0.074).hops_corrected()
        self.assertLess(corrected, 1.5)

    def test_correction_is_monotone_in_loss(self):
        """More loss at the same raw value must correct further downward."""
        low = self._summary(2.40, 0.90).hops_corrected()
        high = self._summary(2.40, 0.50).hops_corrected()
        self.assertGreater(low, high)

    def test_unusable_inputs_are_nan(self):
        self.assertTrue(math.isnan(self._summary(float("nan"), 0.9).hops_corrected()))
        self.assertTrue(math.isnan(self._summary(2.4, 0.0).hops_corrected()))


class SelectHopCriterionTests(unittest.TestCase):
    """Criterion 2 is now the measured hop count, and it must fail closed."""

    @staticmethod
    def _summary(nodes: int, hops: float, baseline: float = 0.95,
                 attack: float = 0.60) -> c.NodeSummary:
        summary = c.NodeSummary(nodes=nodes, area=600.0, max_speed=20.0)
        for seed in (1, 2, 3):
            summary.seeds.append(seed)
            summary.baseline_pdr.append(baseline)
            summary.attack_pdr.append(attack)
            summary.baseline_delay.append(0.006)
            summary.baseline_hops.append(hops)
            summary.baseline_flow_delivery.append(baseline)
            summary.attack_drops.append(500)
        return summary

    @staticmethod
    def _key(nodes: int) -> c.ConfigKey:
        return (nodes, 600.0, 20.0)

    def test_single_hop_scenario_is_rejected(self):
        """1.6 raw hops is the measured value of the previously frozen scenario."""
        summaries = {self._key(30): self._summary(30, hops=1.6)}
        self.assertEqual(
            c.select(summaries, min_baseline=0.80, min_hops=3.0, min_effect=0.05), []
        )

    def test_multi_hop_scenario_is_accepted(self):
        """A genuinely multi-hop scenario must survive the correction.

        baseline 0.95 keeps the inflation term small, so 3.4 raw stays above 3.0
        once corrected -- which is what "genuinely multi-hop" has to mean.
        """
        summaries = {self._key(64): self._summary(64, hops=3.4)}
        self.assertEqual(
            c.select(summaries, min_baseline=0.80, min_hops=3.0, min_effect=0.05),
            [self._key(64)]
        )

    def test_unmeasured_hops_are_not_multi_hop(self):
        """A scenario whose hop count could not be measured must not be selected.

        Silently treating NaN as passing would let an unverifiable scenario be
        frozen, which is the exact failure mode this criterion exists to prevent.
        """
        summaries = {self._key(30): self._summary(30, hops=float("nan"))}
        self.assertEqual(
            c.select(summaries, min_baseline=0.80, min_hops=3.0, min_effect=0.05), []
        )

    def test_raw_multi_hop_from_pure_loss_is_rejected(self):
        """A high raw hop count produced by heavy loss must NOT be selected.

        Without the correction this scenario -- 4.0 raw hops at a 0.25 baseline --
        would look like the best multi-hop candidate in a sweep while actually
        being the one that delivers almost nothing.
        """
        summaries = {self._key(84): self._summary(84, hops=4.0, baseline=0.25, attack=0.05)}
        self.assertEqual(
            c.select(summaries, min_baseline=0.20, min_hops=3.0, min_effect=0.05), []
        )

    def test_low_delay_no_longer_blocks_a_multi_hop_scenario(self):
        """The refuted proxy must not veto a scenario the direct measure accepts."""
        summary = self._summary(64, hops=3.4)
        summary.baseline_delay = [0.001, 0.001, 0.001]  # far below the old 10 ms bar
        self.assertEqual(
            c.select({self._key(64): summary}, min_baseline=0.80, min_hops=3.0,
                     min_effect=0.05),
            [self._key(64)],
        )


class BuildScenariosTests(unittest.TestCase):
    """The duplicate guard must match the aggregation key, or it blocks valid work.

    The guard was written when results were keyed by node count alone. After the
    key became (nodes, area, maxSpeed) it kept rejecting "64:900,64:1000" -- a
    perfectly valid pair that isolates geometry at a fixed node count -- with a
    message describing an aggregation that no longer existed. A guard that
    outlives its reason silently forbids the experiment it was meant to protect.
    """

    @staticmethod
    def _args(scenarios: str) -> argparse.Namespace:
        return argparse.Namespace(scenarios=scenarios, area=600.0, nodes_list=[30, 45])

    def test_same_node_count_at_different_areas_is_allowed(self):
        self.assertEqual(
            c.build_scenarios(self._args("45:750,64:900,64:1000")),
            [(45, 750.0), (64, 900.0), (64, 1000.0)],
        )

    def test_exact_duplicate_pair_is_rejected(self):
        with self.assertRaises(SystemExit):
            c.build_scenarios(self._args("64:900,64:900"))

    def test_malformed_entry_is_rejected(self):
        with self.assertRaises(SystemExit):
            c.build_scenarios(self._args("64-900"))

    def test_falls_back_to_nodes_list_and_area(self):
        args = self._args("")
        self.assertEqual(c.build_scenarios(args), [(30, 600.0), (45, 600.0)])


if __name__ == "__main__":
    unittest.main()
